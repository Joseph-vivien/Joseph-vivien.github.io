# 🚀 技术指标参数优化系统

## 📋 概述

这是一个完整的技术指标参数优化系统，提供多种优化算法来寻找最佳的技术指标参数组合，以提升交易策略的表现。

## 🔧 功能特性

### 1. 多种优化算法
- **网格搜索**: 穷举所有参数组合，适合参数空间较小的情况
- **遗传算法**: 使用进化算法寻找最优解，适合复杂参数空间
- **参数敏感性分析**: 分析各参数对策略表现的影响程度

### 2. 支持的技术指标
- **RSI**: 相对强弱指数（周期、超买超卖阈值）
- **MACD**: 移动平均收敛发散（快线、慢线、信号线周期）
- **布林带**: 布林带（周期、标准差倍数）
- **移动平均线**: SMA/EMA（短期、中期、长期周期）
- **随机指标**: KD指标（K周期、D周期、超买超卖阈值）
- **ATR**: 平均真实波幅（周期）
- **CCI**: 商品通道指数（周期、超买超卖阈值）

### 3. 评估指标
- **总收益率**: 策略的总体盈利能力
- **夏普比率**: 风险调整后收益
- **最大回撤**: 最大亏损幅度
- **胜率**: 盈利交易占比
- **盈亏比**: 平均盈利/平均亏损
- **综合得分**: 多指标加权评分

## 🚀 快速开始

### 1. 环境准备

确保已安装必要的依赖：
```bash
pip install numpy pandas scipy
```

### 2. 数据准备

确保有历史数据文件：
```
user_data/data/BTCUSDT_5m.csv
```

### 3. 运行优化

#### 网格搜索优化
```bash
python user_data/optimization/optimize_parameters.py --method grid_search --max_combinations 1000
```

#### 遗传算法优化
```bash
python user_data/optimization/optimize_parameters.py --method genetic --population_size 50 --generations 100
```

#### 参数敏感性分析
```bash
python user_data/optimization/optimize_parameters.py --method sensitivity
```

## 📊 参数配置

### 默认参数范围

```python
# RSI参数
'rsi_period': 5-25 (步长2)
'rsi_oversold': 20-35 (步长5)
'rsi_overbought': 65-80 (步长5)

# MACD参数
'macd_fast_period': 6-12 (步长1)
'macd_slow_period': 18-28 (步长2)
'macd_signal_period': 5-10 (步长1)

# 布林带参数
'bb_period': 12-25 (步长2)
'bb_dev_up': 1.5-2.5 (步长0.2)
'bb_dev_down': 1.5-2.5 (步长0.2)

# 移动平均线参数
'sma_short': 5-15 (步长2)
'sma_medium': 20-35 (步长3)
'sma_long': 80-120 (步长10)
```

## 📈 结果分析

### 1. 优化结果文件

优化完成后会生成以下文件：
- `user_data/optimization/results/optimization_result_*.json`: 详细优化结果
- `user_data/config/optimized_params.json`: 最佳参数配置
- `user_data/config/optimized_params_code.py`: Python代码格式的参数

### 2. 应用优化结果

优化完成后，系统会自动生成优化参数文件。可以通过以下方式应用：

1. **直接使用配置文件**:
   ```python
   import json
   with open('user_data/config/optimized_params.json', 'r') as f:
       config = json.load(f)
   optimized_params = config['technical_indicators']['optimized_params']
   ```

2. **使用Python代码**:
   ```python
   from user_data.config.optimized_params_code import OPTIMIZED_TECHNICAL_PARAMS
   # 在策略中使用
   self.params.update(OPTIMIZED_TECHNICAL_PARAMS)
   ```

## ⚙️ 高级配置

### 1. 评估函数自定义

可以在 `StrategyEvaluator` 类中修改评估权重：

```python
weights = {
    'total_return': 0.3,      # 总收益率权重
    'sharpe_ratio': 0.25,     # 夏普比率权重
    'win_rate': 0.2,          # 胜率权重
    'profit_factor': 0.15,    # 盈亏比权重
    'max_drawdown': 0.1       # 最大回撤权重
}
```

### 2. 并行处理

网格搜索支持并行处理：
```bash
python user_data/optimization/optimize_parameters.py --method grid_search --max_combinations 5000
```

### 3. 数据文件指定

可以指定不同的数据文件：
```bash
python user_data/optimization/optimize_parameters.py --data_file user_data/data/ETHUSDT_5m.csv
```

## 📝 注意事项

### 1. 计算资源
- 网格搜索的计算量随参数数量指数增长
- 建议先用较小的参数范围测试
- 遗传算法适合复杂参数空间的优化

### 2. 过拟合风险
- 避免在同一数据集上过度优化
- 建议使用样本外数据验证结果
- 定期重新优化参数以适应市场变化

### 3. 参数稳定性
- 关注参数敏感性分析结果
- 选择对参数变化不敏感的策略
- 考虑参数的实际交易意义

## 🔄 集成到交易系统

### 1. 修复参数不一致问题

系统已自动修复以下文件中的参数不一致：
- `MasterStrategy.py`: 统一策略参数
- `market_analyzer.py`: 修复硬编码参数
- `technical_signals.py`: 使用优化后的参数

### 2. 动态参数更新

可以实现动态参数更新机制：
```python
# 定期重新优化参数
def update_parameters():
    optimizer = ParameterOptimizer()
    evaluator = StrategyEvaluator()
    result = optimizer.grid_search_optimization(...)
    optimizer.apply_optimized_parameters(result.best_params)
```

## 🎯 最佳实践

1. **分阶段优化**: 先优化核心参数，再优化次要参数
2. **多时间框架验证**: 在不同时间周期上验证参数有效性
3. **市场环境适应**: 针对不同市场环境优化不同参数集
4. **风险控制**: 始终将风险控制放在首位
5. **持续监控**: 定期监控参数表现，及时调整

## 📞 支持

如有问题或建议，请查看：
- 日志文件: `user_data/logs/`
- 错误排查: 检查数据格式和依赖安装
- 性能调优: 调整并行进程数和参数范围
