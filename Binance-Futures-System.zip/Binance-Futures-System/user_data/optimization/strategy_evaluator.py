#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
策略评估器

该模块提供策略评估功能，用于参数优化过程中的策略表现评估。

作者: 高级Python工程师
日期: 2024-05-23
"""

import sys
import os
import tempfile
import subprocess
import json
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("strategy_evaluator")

class StrategyEvaluator:
    """
    策略评估器
    
    用于评估不同参数组合下的策略表现
    """
    
    def __init__(self, 
                 data_file: str = "user_data/data/BTCUSDT_5m.csv",
                 initial_cash: float = 10000.0,
                 commission: float = 0.001):
        """
        初始化策略评估器
        
        参数:
            data_file: 数据文件路径
            initial_cash: 初始资金
            commission: 手续费率
        """
        self.data_file = data_file
        self.initial_cash = initial_cash
        self.commission = commission
        
        # 加载数据
        self.data = self._load_data()
        
        logger.info(f"策略评估器初始化完成，数据长度: {len(self.data)}")
    
    def _load_data(self) -> pd.DataFrame:
        """加载数据"""
        try:
            data = pd.read_csv(self.data_file)
            data['timestamp'] = pd.to_datetime(data['timestamp'])
            data.set_index('timestamp', inplace=True)
            return data
        except Exception as e:
            logger.error(f"加载数据失败: {e}")
            # 返回空数据框
            return pd.DataFrame()
    
    def evaluate_parameters(self, params: Dict[str, Any]) -> float:
        """
        评估参数组合
        
        参数:
            params: 参数字典
            
        返回:
            评估得分（越高越好）
        """
        try:
            # 使用简化的评估方法
            score = self._quick_evaluate(params)
            return score
            
        except Exception as e:
            logger.error(f"评估参数失败: {params}, 错误: {e}")
            return float('-inf')
    
    def _quick_evaluate(self, params: Dict[str, Any]) -> float:
        """
        快速评估方法
        
        使用简化的技术指标计算来快速评估参数组合
        """
        if self.data.empty:
            return 0.0
        
        try:
            # 计算技术指标
            indicators = self._calculate_indicators(params)
            
            # 生成交易信号
            signals = self._generate_signals(indicators, params)
            
            # 计算策略表现
            performance = self._calculate_performance(signals)
            
            # 计算综合得分
            score = self._calculate_composite_score(performance)
            
            return score
            
        except Exception as e:
            logger.error(f"快速评估失败: {e}")
            return float('-inf')
    
    def _calculate_indicators(self, params: Dict[str, Any]) -> Dict[str, pd.Series]:
        """计算技术指标"""
        indicators = {}
        
        try:
            # RSI
            rsi_period = params.get('rsi_period', 14)
            indicators['rsi'] = self._calculate_rsi(self.data['close'], rsi_period)
            
            # 移动平均线
            sma_short = params.get('sma_short', 10)
            sma_medium = params.get('sma_medium', 25)
            sma_long = params.get('sma_long', 100)
            
            indicators['sma_short'] = self.data['close'].rolling(window=sma_short).mean()
            indicators['sma_medium'] = self.data['close'].rolling(window=sma_medium).mean()
            indicators['sma_long'] = self.data['close'].rolling(window=sma_long).mean()
            
            # MACD
            macd_fast = params.get('macd_fast_period', 8)
            macd_slow = params.get('macd_slow_period', 21)
            macd_signal = params.get('macd_signal_period', 6)
            
            macd_line, macd_signal_line = self._calculate_macd(
                self.data['close'], macd_fast, macd_slow, macd_signal
            )
            indicators['macd'] = macd_line
            indicators['macd_signal'] = macd_signal_line
            
            # 布林带
            bb_period = params.get('bb_period', 15)
            bb_dev = params.get('bb_dev_up', 1.8)
            
            bb_middle = self.data['close'].rolling(window=bb_period).mean()
            bb_std = self.data['close'].rolling(window=bb_period).std()
            indicators['bb_upper'] = bb_middle + (bb_std * bb_dev)
            indicators['bb_lower'] = bb_middle - (bb_std * bb_dev)
            indicators['bb_middle'] = bb_middle
            
        except Exception as e:
            logger.error(f"计算技术指标失败: {e}")
        
        return indicators
    
    def _calculate_rsi(self, prices: pd.Series, period: int) -> pd.Series:
        """计算RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, prices: pd.Series, fast: int, slow: int, signal: int) -> tuple:
        """计算MACD"""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        macd_signal = macd_line.ewm(span=signal).mean()
        return macd_line, macd_signal
    
    def _generate_signals(self, indicators: Dict[str, pd.Series], params: Dict[str, Any]) -> pd.Series:
        """生成交易信号"""
        signals = pd.Series(0, index=self.data.index)
        
        try:
            # RSI信号
            rsi_oversold = params.get('rsi_oversold', 25)
            rsi_overbought = params.get('rsi_overbought', 75)
            
            rsi_buy = indicators['rsi'] < rsi_oversold
            rsi_sell = indicators['rsi'] > rsi_overbought
            
            # 移动平均线信号
            ma_buy = (indicators['sma_short'] > indicators['sma_medium']) & \
                    (indicators['sma_medium'] > indicators['sma_long'])
            ma_sell = (indicators['sma_short'] < indicators['sma_medium']) & \
                     (indicators['sma_medium'] < indicators['sma_long'])
            
            # MACD信号
            macd_buy = indicators['macd'] > indicators['macd_signal']
            macd_sell = indicators['macd'] < indicators['macd_signal']
            
            # 布林带信号
            bb_buy = self.data['close'] < indicators['bb_lower']
            bb_sell = self.data['close'] > indicators['bb_upper']
            
            # 综合信号（至少2个指标同意）
            buy_votes = rsi_buy.astype(int) + ma_buy.astype(int) + macd_buy.astype(int) + bb_buy.astype(int)
            sell_votes = rsi_sell.astype(int) + ma_sell.astype(int) + macd_sell.astype(int) + bb_sell.astype(int)
            
            signals[buy_votes >= 2] = 1   # 买入信号
            signals[sell_votes >= 2] = -1  # 卖出信号
            
        except Exception as e:
            logger.error(f"生成交易信号失败: {e}")
        
        return signals
    
    def _calculate_performance(self, signals: pd.Series) -> Dict[str, float]:
        """计算策略表现"""
        performance = {
            'total_return': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'win_rate': 0.0,
            'profit_factor': 0.0,
            'total_trades': 0
        }
        
        try:
            # 计算持仓
            positions = signals.shift(1).fillna(0)
            
            # 计算收益率
            returns = self.data['close'].pct_change() * positions
            returns = returns.fillna(0)
            
            # 扣除手续费
            trade_signals = signals.diff().abs()
            commission_cost = trade_signals * self.commission
            returns = returns - commission_cost
            
            # 计算累计收益
            cumulative_returns = (1 + returns).cumprod()
            
            if len(cumulative_returns) > 0:
                performance['total_return'] = (cumulative_returns.iloc[-1] - 1) * 100
                
                # 夏普比率
                if returns.std() > 0:
                    performance['sharpe_ratio'] = returns.mean() / returns.std() * np.sqrt(252)
                
                # 最大回撤
                running_max = cumulative_returns.expanding().max()
                drawdown = (cumulative_returns - running_max) / running_max
                performance['max_drawdown'] = abs(drawdown.min()) * 100
                
                # 交易统计
                trades = self._analyze_trades(signals, self.data['close'])
                performance.update(trades)
            
        except Exception as e:
            logger.error(f"计算策略表现失败: {e}")
        
        return performance
    
    def _analyze_trades(self, signals: pd.Series, prices: pd.Series) -> Dict[str, float]:
        """分析交易"""
        trades = {
            'total_trades': 0,
            'win_rate': 0.0,
            'profit_factor': 0.0
        }
        
        try:
            # 找到交易点
            position_changes = signals.diff()
            entry_points = position_changes[position_changes != 0]
            
            if len(entry_points) < 2:
                return trades
            
            # 计算每笔交易的盈亏
            trade_returns = []
            current_position = 0
            entry_price = 0
            
            for timestamp, signal_change in entry_points.items():
                current_price = prices.loc[timestamp]
                
                if current_position != 0:  # 平仓
                    trade_return = (current_price - entry_price) / entry_price * current_position
                    trade_returns.append(trade_return)
                
                # 开新仓
                if signal_change != 0:
                    current_position = signals.loc[timestamp]
                    entry_price = current_price
            
            if trade_returns:
                trades['total_trades'] = len(trade_returns)
                winning_trades = [r for r in trade_returns if r > 0]
                losing_trades = [r for r in trade_returns if r < 0]
                
                trades['win_rate'] = len(winning_trades) / len(trade_returns) * 100
                
                if losing_trades:
                    avg_win = np.mean(winning_trades) if winning_trades else 0
                    avg_loss = abs(np.mean(losing_trades))
                    trades['profit_factor'] = avg_win / avg_loss if avg_loss > 0 else 0
                else:
                    trades['profit_factor'] = float('inf') if winning_trades else 0
            
        except Exception as e:
            logger.error(f"分析交易失败: {e}")
        
        return trades
    
    def _calculate_composite_score(self, performance: Dict[str, float]) -> float:
        """计算综合得分"""
        try:
            # 权重配置
            weights = {
                'total_return': 0.3,      # 总收益率权重30%
                'sharpe_ratio': 0.25,     # 夏普比率权重25%
                'win_rate': 0.2,          # 胜率权重20%
                'profit_factor': 0.15,    # 盈亏比权重15%
                'max_drawdown': 0.1       # 最大回撤权重10%（负向）
            }
            
            # 标准化各指标
            normalized_scores = {}
            
            # 总收益率（目标：>10%）
            normalized_scores['total_return'] = min(performance['total_return'] / 10.0, 2.0)
            
            # 夏普比率（目标：>1.0）
            normalized_scores['sharpe_ratio'] = min(max(performance['sharpe_ratio'], 0) / 1.0, 2.0)
            
            # 胜率（目标：>50%）
            normalized_scores['win_rate'] = min(performance['win_rate'] / 50.0, 2.0)
            
            # 盈亏比（目标：>1.5）
            normalized_scores['profit_factor'] = min(performance['profit_factor'] / 1.5, 2.0)
            
            # 最大回撤（目标：<10%，越小越好）
            max_dd = performance['max_drawdown']
            if max_dd <= 5:
                normalized_scores['max_drawdown'] = 2.0
            elif max_dd <= 10:
                normalized_scores['max_drawdown'] = 1.5
            elif max_dd <= 20:
                normalized_scores['max_drawdown'] = 1.0
            else:
                normalized_scores['max_drawdown'] = 0.5
            
            # 计算加权得分
            composite_score = 0.0
            for metric, weight in weights.items():
                composite_score += normalized_scores.get(metric, 0) * weight
            
            # 交易次数惩罚（避免过度交易）
            total_trades = performance.get('total_trades', 0)
            if total_trades > 100:
                composite_score *= 0.9  # 减少10%
            elif total_trades < 10:
                composite_score *= 0.8  # 减少20%
            
            return composite_score
            
        except Exception as e:
            logger.error(f"计算综合得分失败: {e}")
            return 0.0
