#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
技术指标参数优化主程序

该程序提供完整的技术指标参数优化流程，包括：
- 参数范围定义
- 优化算法选择
- 结果分析和保存
- 参数应用

使用方法:
python user_data/optimization/optimize_parameters.py --method grid_search --max_combinations 1000

作者: 高级Python工程师
日期: 2024-05-23
"""

import argparse
import sys
import os
from datetime import datetime
from typing import Dict, Any

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from user_data.optimization.parameter_optimizer import ParameterOptimizer, ParameterRange
from user_data.optimization.strategy_evaluator import StrategyEvaluator
from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("optimize_parameters")

def create_custom_parameter_ranges() -> Dict[str, ParameterRange]:
    """创建自定义参数范围"""
    return {
        # 核心RSI参数
        'rsi_period': ParameterRange('rsi_period', 5, 25, 2, param_type='int'),
        'rsi_oversold': ParameterRange('rsi_oversold', 20, 35, 5, param_type='int'),
        'rsi_overbought': ParameterRange('rsi_overbought', 65, 80, 5, param_type='int'),
        
        # 移动平均线参数
        'sma_short': ParameterRange('sma_short', 5, 15, 2, param_type='int'),
        'sma_medium': ParameterRange('sma_medium', 20, 35, 3, param_type='int'),
        'sma_long': ParameterRange('sma_long', 80, 120, 10, param_type='int'),
        
        # MACD参数
        'macd_fast_period': ParameterRange('macd_fast_period', 6, 12, 1, param_type='int'),
        'macd_slow_period': ParameterRange('macd_slow_period', 18, 28, 2, param_type='int'),
        'macd_signal_period': ParameterRange('macd_signal_period', 5, 10, 1, param_type='int'),
        
        # 布林带参数
        'bb_period': ParameterRange('bb_period', 12, 25, 2, param_type='int'),
        'bb_dev_up': ParameterRange('bb_dev_up', 1.5, 2.5, 0.2, param_type='float'),
        'bb_dev_down': ParameterRange('bb_dev_down', 1.5, 2.5, 0.2, param_type='float'),
    }

def run_grid_search_optimization(optimizer: ParameterOptimizer, 
                               evaluator: StrategyEvaluator,
                               max_combinations: int = 1000) -> None:
    """运行网格搜索优化"""
    logger.info("🔍 开始网格搜索参数优化...")
    
    # 定义参数范围
    parameter_ranges = create_custom_parameter_ranges()
    
    # 执行优化
    result = optimizer.grid_search_optimization(
        parameter_ranges=parameter_ranges,
        evaluation_function=evaluator.evaluate_parameters,
        max_combinations=max_combinations,
        parallel=True,
        max_workers=4
    )
    
    # 保存结果
    result_file = optimizer.save_optimization_results(result)
    
    # 生成报告
    report = optimizer.generate_optimization_report(result)
    print("\n" + "="*80)
    print("📊 网格搜索优化报告")
    print("="*80)
    print(report)
    
    # 应用最佳参数
    optimizer.apply_optimized_parameters(result.best_params)
    
    logger.info(f"✅ 网格搜索优化完成！最佳得分: {result.best_score:.4f}")

def run_genetic_algorithm_optimization(optimizer: ParameterOptimizer,
                                     evaluator: StrategyEvaluator,
                                     population_size: int = 50,
                                     generations: int = 100) -> None:
    """运行遗传算法优化"""
    logger.info("🧬 开始遗传算法参数优化...")
    
    # 定义参数范围
    parameter_ranges = create_custom_parameter_ranges()
    
    # 执行优化
    result = optimizer.genetic_algorithm_optimization(
        parameter_ranges=parameter_ranges,
        evaluation_function=evaluator.evaluate_parameters,
        population_size=population_size,
        generations=generations,
        mutation_rate=0.1,
        crossover_rate=0.8
    )
    
    # 保存结果
    result_file = optimizer.save_optimization_results(result)
    
    # 生成报告
    report = optimizer.generate_optimization_report(result)
    print("\n" + "="*80)
    print("📊 遗传算法优化报告")
    print("="*80)
    print(report)
    
    # 应用最佳参数
    optimizer.apply_optimized_parameters(result.best_params)
    
    logger.info(f"✅ 遗传算法优化完成！最佳得分: {result.best_score:.4f}")

def run_sensitivity_analysis(optimizer: ParameterOptimizer,
                           evaluator: StrategyEvaluator) -> None:
    """运行参数敏感性分析"""
    logger.info("📈 开始参数敏感性分析...")
    
    # 使用当前默认参数作为基准
    base_params = {
        'rsi_period': 9,
        'rsi_oversold': 25,
        'rsi_overbought': 75,
        'sma_short': 10,
        'sma_medium': 25,
        'sma_long': 100,
        'macd_fast_period': 8,
        'macd_slow_period': 21,
        'macd_signal_period': 6,
        'bb_period': 15,
        'bb_dev_up': 1.8,
        'bb_dev_down': 1.8,
    }
    
    # 定义参数范围
    parameter_ranges = create_custom_parameter_ranges()
    
    # 执行敏感性分析
    sensitivity_results = optimizer.analyze_parameter_sensitivity(
        base_params=base_params,
        parameter_ranges=parameter_ranges,
        evaluation_function=evaluator.evaluate_parameters,
        sensitivity_range=0.3  # 30%的变化范围
    )
    
    # 显示结果
    print("\n" + "="*80)
    print("📈 参数敏感性分析报告")
    print("="*80)
    
    for param_name, sensitivity in sensitivity_results.items():
        print(f"\n🔧 {param_name}:")
        print(f"  基准值: {sensitivity['base_value']}")
        print(f"  基准得分: {sensitivity['base_score']:.4f}")
        
        # 找到最敏感的变化
        max_sensitivity = 0
        best_variation = None
        
        for variation in sensitivity['variations']:
            if abs(variation['sensitivity']) > abs(max_sensitivity):
                max_sensitivity = variation['sensitivity']
                best_variation = variation
        
        if best_variation:
            print(f"  最大敏感性: {max_sensitivity:.4f}")
            print(f"  最佳变化值: {best_variation['value']}")
            print(f"  得分变化: {best_variation['score_change']:.4f}")
    
    logger.info("✅ 参数敏感性分析完成！")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='技术指标参数优化')
    parser.add_argument('--method', choices=['grid_search', 'genetic', 'sensitivity'], 
                       default='grid_search', help='优化方法')
    parser.add_argument('--max_combinations', type=int, default=1000, 
                       help='网格搜索最大组合数')
    parser.add_argument('--population_size', type=int, default=50, 
                       help='遗传算法种群大小')
    parser.add_argument('--generations', type=int, default=100, 
                       help='遗传算法进化代数')
    parser.add_argument('--data_file', type=str, default='user_data/data/BTCUSDT_5m.csv',
                       help='数据文件路径')
    
    args = parser.parse_args()
    
    print("🚀 技术指标参数优化系统")
    print("="*50)
    print(f"优化方法: {args.method}")
    print(f"数据文件: {args.data_file}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*50)
    
    # 检查数据文件是否存在
    if not os.path.exists(args.data_file):
        logger.error(f"数据文件不存在: {args.data_file}")
        print("❌ 请先下载数据文件或检查路径是否正确")
        return
    
    try:
        # 初始化组件
        optimizer = ParameterOptimizer()
        evaluator = StrategyEvaluator(
            data_file=args.data_file,
            initial_cash=10000.0,
            commission=0.001
        )
        
        # 根据选择的方法执行优化
        if args.method == 'grid_search':
            run_grid_search_optimization(optimizer, evaluator, args.max_combinations)
        elif args.method == 'genetic':
            run_genetic_algorithm_optimization(optimizer, evaluator, 
                                             args.population_size, args.generations)
        elif args.method == 'sensitivity':
            run_sensitivity_analysis(optimizer, evaluator)
        
        print("\n🎉 参数优化完成！")
        print("📁 结果文件保存在: user_data/optimization/results/")
        print("📁 优化参数保存在: user_data/config/optimized_params.json")
        print("💡 请查看生成的报告了解详细结果")
        
    except Exception as e:
        logger.error(f"参数优化失败: {e}")
        print(f"❌ 优化过程中出现错误: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
