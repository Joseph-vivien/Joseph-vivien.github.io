#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
技术指标参数优化器

该模块提供完整的技术指标参数优化功能，包括：
- 网格搜索优化
- 遗传算法优化
- 贝叶斯优化
- 参数敏感性分析
- 多目标优化

作者: 高级Python工程师
日期: 2024-05-23
"""

import os
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple, Optional, Callable
from dataclasses import dataclass
from concurrent.futures import ProcessPoolExecutor, as_completed
import itertools
from scipy.optimize import differential_evolution
import warnings
warnings.filterwarnings('ignore')

from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("parameter_optimizer")

@dataclass
class ParameterRange:
    """参数范围定义"""
    name: str
    min_value: float
    max_value: float
    step: float = None
    values: List[float] = None
    param_type: str = 'float'  # 'int', 'float', 'choice'

    def get_values(self) -> List[float]:
        """获取参数值列表"""
        if self.values is not None:
            return self.values
        elif self.step is not None:
            if self.param_type == 'int':
                return list(range(int(self.min_value), int(self.max_value) + 1, int(self.step)))
            else:
                return list(np.arange(self.min_value, self.max_value + self.step, self.step))
        else:
            # 默认生成10个值
            if self.param_type == 'int':
                return list(range(int(self.min_value), int(self.max_value) + 1))
            else:
                return list(np.linspace(self.min_value, self.max_value, 10))

@dataclass
class OptimizationResult:
    """优化结果"""
    best_params: Dict[str, Any]
    best_score: float
    all_results: List[Dict[str, Any]]
    optimization_time: float
    total_combinations: int
    method: str

class ParameterOptimizer:
    """
    技术指标参数优化器

    提供多种优化算法来寻找最佳技术指标参数组合
    """

    def __init__(self, output_dir: str = "user_data/optimization/results"):
        """
        初始化参数优化器

        参数:
            output_dir: 结果输出目录
        """
        self.output_dir = output_dir
        self.ensure_output_dir()

        # 预定义的技术指标参数范围
        self.default_parameter_ranges = self._get_default_parameter_ranges()

        logger.info("参数优化器初始化完成")

    def ensure_output_dir(self):
        """确保输出目录存在"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def _get_default_parameter_ranges(self) -> Dict[str, ParameterRange]:
        """获取默认的技术指标参数范围"""
        return {
            # RSI参数
            'rsi_period': ParameterRange('rsi_period', 5, 25, 1, param_type='int'),
            'rsi_oversold': ParameterRange('rsi_oversold', 15, 35, 5, param_type='int'),
            'rsi_overbought': ParameterRange('rsi_overbought', 65, 85, 5, param_type='int'),

            # MACD参数
            'macd_fast_period': ParameterRange('macd_fast_period', 5, 15, 1, param_type='int'),
            'macd_slow_period': ParameterRange('macd_slow_period', 15, 35, 2, param_type='int'),
            'macd_signal_period': ParameterRange('macd_signal_period', 3, 12, 1, param_type='int'),

            # 布林带参数
            'bb_period': ParameterRange('bb_period', 10, 30, 2, param_type='int'),
            'bb_dev_up': ParameterRange('bb_dev_up', 1.0, 3.0, 0.2, param_type='float'),
            'bb_dev_down': ParameterRange('bb_dev_down', 1.0, 3.0, 0.2, param_type='float'),

            # 移动平均线参数
            'sma_short': ParameterRange('sma_short', 5, 20, 1, param_type='int'),
            'sma_medium': ParameterRange('sma_medium', 15, 40, 2, param_type='int'),
            'sma_long': ParameterRange('sma_long', 50, 200, 10, param_type='int'),

            # 随机指标参数
            'stoch_k_period': ParameterRange('stoch_k_period', 3, 15, 1, param_type='int'),
            'stoch_d_period': ParameterRange('stoch_d_period', 2, 8, 1, param_type='int'),
            'stoch_oversold': ParameterRange('stoch_oversold', 15, 30, 5, param_type='int'),
            'stoch_overbought': ParameterRange('stoch_overbought', 70, 85, 5, param_type='int'),

            # ATR参数
            'atr_period': ParameterRange('atr_period', 7, 21, 1, param_type='int'),

            # CCI参数
            'cci_period': ParameterRange('cci_period', 7, 21, 1, param_type='int'),
            'cci_oversold': ParameterRange('cci_oversold', -150, -80, 10, param_type='int'),
            'cci_overbought': ParameterRange('cci_overbought', 80, 150, 10, param_type='int'),

            # 成交量参数
            'volume_ma_period': ParameterRange('volume_ma_period', 10, 30, 2, param_type='int'),
            'volume_threshold': ParameterRange('volume_threshold', 1.1, 2.0, 0.1, param_type='float'),
        }

    def grid_search_optimization(self,
                                parameter_ranges: Dict[str, ParameterRange],
                                evaluation_function: Callable,
                                max_combinations: int = 10000,
                                parallel: bool = True,
                                max_workers: int = 4) -> OptimizationResult:
        """
        网格搜索优化

        参数:
            parameter_ranges: 参数范围字典
            evaluation_function: 评估函数，接受参数字典，返回评分
            max_combinations: 最大组合数
            parallel: 是否并行执行
            max_workers: 最大工作进程数

        返回:
            优化结果
        """
        start_time = datetime.now()
        logger.info("开始网格搜索优化...")

        # 生成参数组合
        param_combinations = self._generate_parameter_combinations(parameter_ranges, max_combinations)
        total_combinations = len(param_combinations)

        logger.info(f"生成了 {total_combinations} 个参数组合")

        # 评估参数组合
        if parallel and total_combinations > 100:
            results = self._parallel_evaluation(param_combinations, evaluation_function, max_workers)
        else:
            results = self._sequential_evaluation(param_combinations, evaluation_function)

        # 找到最佳结果
        best_result = max(results, key=lambda x: x['score'])

        optimization_time = (datetime.now() - start_time).total_seconds()

        logger.info(f"网格搜索完成，最佳得分: {best_result['score']:.4f}")

        return OptimizationResult(
            best_params=best_result['params'],
            best_score=best_result['score'],
            all_results=results,
            optimization_time=optimization_time,
            total_combinations=total_combinations,
            method='grid_search'
        )

    def genetic_algorithm_optimization(self,
                                     parameter_ranges: Dict[str, ParameterRange],
                                     evaluation_function: Callable,
                                     population_size: int = 50,
                                     generations: int = 100,
                                     mutation_rate: float = 0.1,
                                     crossover_rate: float = 0.8) -> OptimizationResult:
        """
        遗传算法优化

        参数:
            parameter_ranges: 参数范围字典
            evaluation_function: 评估函数
            population_size: 种群大小
            generations: 进化代数
            mutation_rate: 变异率
            crossover_rate: 交叉率

        返回:
            优化结果
        """
        start_time = datetime.now()
        logger.info("开始遗传算法优化...")

        # 准备参数边界
        bounds = []
        param_names = list(parameter_ranges.keys())

        for param_name in param_names:
            param_range = parameter_ranges[param_name]
            bounds.append((param_range.min_value, param_range.max_value))

        # 定义目标函数（最大化）
        def objective_function(x):
            params = {}
            for i, param_name in enumerate(param_names):
                param_range = parameter_ranges[param_name]
                if param_range.param_type == 'int':
                    params[param_name] = int(round(x[i]))
                else:
                    params[param_name] = x[i]

            try:
                score = evaluation_function(params)
                return -score  # differential_evolution最小化，所以取负值
            except Exception as e:
                logger.error(f"评估参数失败: {e}")
                return float('inf')

        # 执行遗传算法
        result = differential_evolution(
            objective_function,
            bounds,
            maxiter=generations,
            popsize=population_size,
            mutation=mutation_rate,
            recombination=crossover_rate,
            seed=42,
            disp=True
        )

        # 构建最佳参数
        best_params = {}
        for i, param_name in enumerate(param_names):
            param_range = parameter_ranges[param_name]
            if param_range.param_type == 'int':
                best_params[param_name] = int(round(result.x[i]))
            else:
                best_params[param_name] = result.x[i]

        optimization_time = (datetime.now() - start_time).total_seconds()

        logger.info(f"遗传算法优化完成，最佳得分: {-result.fun:.4f}")

        return OptimizationResult(
            best_params=best_params,
            best_score=-result.fun,
            all_results=[],  # 遗传算法不保存所有结果
            optimization_time=optimization_time,
            total_combinations=population_size * generations,
            method='genetic_algorithm'
        )

    def _generate_parameter_combinations(self,
                                       parameter_ranges: Dict[str, ParameterRange],
                                       max_combinations: int) -> List[Dict[str, Any]]:
        """生成参数组合"""
        param_names = list(parameter_ranges.keys())
        param_values = [parameter_ranges[name].get_values() for name in param_names]

        # 计算总组合数
        total_combinations = 1
        for values in param_values:
            total_combinations *= len(values)

        if total_combinations > max_combinations:
            logger.warning(f"总组合数 {total_combinations} 超过限制 {max_combinations}，将进行随机采样")
            # 随机采样
            combinations = []
            for _ in range(max_combinations):
                combination = {}
                for i, param_name in enumerate(param_names):
                    combination[param_name] = np.random.choice(param_values[i])
                combinations.append(combination)
            return combinations
        else:
            # 生成所有组合
            combinations = []
            for combination in itertools.product(*param_values):
                param_dict = {}
                for i, param_name in enumerate(param_names):
                    param_dict[param_name] = combination[i]
                combinations.append(param_dict)
            return combinations

    def _sequential_evaluation(self,
                             param_combinations: List[Dict[str, Any]],
                             evaluation_function: Callable) -> List[Dict[str, Any]]:
        """顺序评估参数组合"""
        results = []
        total = len(param_combinations)

        for i, params in enumerate(param_combinations):
            try:
                score = evaluation_function(params)
                results.append({
                    'params': params,
                    'score': score
                })

                if (i + 1) % 100 == 0:
                    logger.info(f"已评估 {i + 1}/{total} 个组合")

            except Exception as e:
                logger.error(f"评估参数组合失败: {params}, 错误: {e}")
                results.append({
                    'params': params,
                    'score': float('-inf')
                })

        return results

    def _parallel_evaluation(self,
                           param_combinations: List[Dict[str, Any]],
                           evaluation_function: Callable,
                           max_workers: int) -> List[Dict[str, Any]]:
        """并行评估参数组合"""
        results = []
        total = len(param_combinations)

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有任务
            future_to_params = {
                executor.submit(evaluation_function, params): params
                for params in param_combinations
            }

            # 收集结果
            completed = 0
            for future in as_completed(future_to_params):
                params = future_to_params[future]
                try:
                    score = future.result()
                    results.append({
                        'params': params,
                        'score': score
                    })
                except Exception as e:
                    logger.error(f"评估参数组合失败: {params}, 错误: {e}")
                    results.append({
                        'params': params,
                        'score': float('-inf')
                    })

                completed += 1
                if completed % 100 == 0:
                    logger.info(f"已完成 {completed}/{total} 个组合")

        return results

    def analyze_parameter_sensitivity(self,
                                    base_params: Dict[str, Any],
                                    parameter_ranges: Dict[str, ParameterRange],
                                    evaluation_function: Callable,
                                    sensitivity_range: float = 0.2) -> Dict[str, Any]:
        """
        参数敏感性分析

        参数:
            base_params: 基准参数
            parameter_ranges: 参数范围
            evaluation_function: 评估函数
            sensitivity_range: 敏感性分析范围（相对于基准值的百分比）

        返回:
            敏感性分析结果
        """
        logger.info("开始参数敏感性分析...")

        base_score = evaluation_function(base_params)
        sensitivity_results = {}

        for param_name, param_range in parameter_ranges.items():
            if param_name not in base_params:
                continue

            base_value = base_params[param_name]
            param_sensitivity = {
                'base_value': base_value,
                'base_score': base_score,
                'variations': []
            }

            # 生成变化值
            if param_range.param_type == 'int':
                variations = [
                    max(param_range.min_value, int(base_value * (1 - sensitivity_range))),
                    int(base_value * (1 - sensitivity_range/2)),
                    base_value,
                    int(base_value * (1 + sensitivity_range/2)),
                    min(param_range.max_value, int(base_value * (1 + sensitivity_range)))
                ]
            else:
                variations = [
                    max(param_range.min_value, base_value * (1 - sensitivity_range)),
                    base_value * (1 - sensitivity_range/2),
                    base_value,
                    base_value * (1 + sensitivity_range/2),
                    min(param_range.max_value, base_value * (1 + sensitivity_range))
                ]

            # 测试每个变化值
            for variation in variations:
                test_params = base_params.copy()
                test_params[param_name] = variation

                try:
                    score = evaluation_function(test_params)
                    score_change = score - base_score
                    param_change = (variation - base_value) / base_value if base_value != 0 else 0

                    param_sensitivity['variations'].append({
                        'value': variation,
                        'score': score,
                        'score_change': score_change,
                        'param_change': param_change,
                        'sensitivity': score_change / param_change if param_change != 0 else 0
                    })
                except Exception as e:
                    logger.error(f"敏感性分析失败: {param_name}={variation}, 错误: {e}")

            sensitivity_results[param_name] = param_sensitivity

        return sensitivity_results

    def save_optimization_results(self, result: OptimizationResult, filename: str = None) -> str:
        """
        保存优化结果

        参数:
            result: 优化结果
            filename: 文件名（可选）

        返回:
            保存的文件路径
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"optimization_result_{result.method}_{timestamp}.json"

        filepath = os.path.join(self.output_dir, filename)

        # 准备保存数据
        save_data = {
            'optimization_info': {
                'method': result.method,
                'optimization_time': result.optimization_time,
                'total_combinations': result.total_combinations,
                'timestamp': datetime.now().isoformat()
            },
            'best_result': {
                'params': result.best_params,
                'score': result.best_score
            },
            'all_results': result.all_results[:1000] if len(result.all_results) > 1000 else result.all_results  # 限制保存数量
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2, ensure_ascii=False)

        logger.info(f"优化结果已保存到: {filepath}")
        return filepath

    def apply_optimized_parameters(self, optimized_params: Dict[str, Any],
                                 target_file: str = "user_data/config/optimized_params.json"):
        """
        应用优化后的参数

        参数:
            optimized_params: 优化后的参数
            target_file: 目标配置文件
        """
        config = {
            'technical_indicators': {
                'optimization_timestamp': datetime.now().isoformat(),
                'optimized_params': optimized_params,
                'description': '通过参数优化器生成的最佳技术指标参数'
            }
        }

        # 确保目录存在
        os.makedirs(os.path.dirname(target_file), exist_ok=True)

        with open(target_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        logger.info(f"优化参数已保存到: {target_file}")

        # 生成Python代码片段
        python_code = f"""# 优化后的技术指标参数
# 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

OPTIMIZED_TECHNICAL_PARAMS = {{
"""

        for param_name, param_value in optimized_params.items():
            if isinstance(param_value, (int, float)):
                python_code += f"    '{param_name}': {param_value},\n"
            else:
                python_code += f"    '{param_name}': '{param_value}',\n"

        python_code += "}\n"

        code_file = target_file.replace('.json', '_code.py')
        with open(code_file, 'w', encoding='utf-8') as f:
            f.write(python_code)

        logger.info(f"Python代码已生成: {code_file}")