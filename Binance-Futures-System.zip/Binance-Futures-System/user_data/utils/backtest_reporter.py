#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
回测报告生成器

该模块负责生成详细的回测报告，包括控制台输出和HTML可视化报告。

作者: 高级Python工程师
日期: 2024-05-22
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.offline as pyo

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("backtest_reporter")

class BacktestReporter:
    """
    回测报告生成器

    负责生成详细的回测分析报告，包括交易统计、图表分析和HTML报告
    """

    def __init__(self, output_dir: str = "user_data/backtest_results"):
        """
        初始化回测报告生成器

        参数:
            output_dir: 报告输出目录
        """
        self.output_dir = output_dir
        self.ensure_output_dir()

        # 报告数据
        self.trades = []
        self.signals = []
        self.portfolio_values = []
        self.positions = []
        self.orders = []
        self.price_data = []

        logger.info(f"回测报告生成器初始化完成，输出目录: {output_dir}")

    def ensure_output_dir(self):
        """确保输出目录存在"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def add_trade(self, trade_data: Dict[str, Any]):
        """添加交易记录"""
        trade_data['timestamp'] = datetime.now()
        self.trades.append(trade_data)

    def add_signal(self, signal_data: Dict[str, Any]):
        """添加信号记录"""
        signal_data['timestamp'] = datetime.now()
        self.signals.append(signal_data)

    def add_portfolio_value(self, value_data: Dict[str, Any]):
        """添加组合价值记录"""
        value_data['timestamp'] = datetime.now()
        self.portfolio_values.append(value_data)

    def add_position(self, position_data: Dict[str, Any]):
        """添加持仓记录"""
        position_data['timestamp'] = datetime.now()
        self.positions.append(position_data)

    def add_order(self, order_data: Dict[str, Any]):
        """添加订单记录"""
        order_data['timestamp'] = datetime.now()
        self.orders.append(order_data)

    def add_price_data(self, price_data: Dict[str, Any]):
        """添加价格数据"""
        price_data['timestamp'] = datetime.now()
        self.price_data.append(price_data)

    def calculate_metrics(self) -> Dict[str, Any]:
        """计算详细的交易指标"""
        if not self.trades:
            return {
                'total_trades': 0,
                'win_rate': 0,
                'profit_factor': 0,
                'sharpe_ratio': 0,
                'max_drawdown': 0,
                'total_return': 0
            }

        # 转换为DataFrame便于分析
        trades_df = pd.DataFrame(self.trades)

        # 基本统计
        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['pnl'] > 0])
        losing_trades = len(trades_df[trades_df['pnl'] < 0])

        # 胜率
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0

        # 盈亏比
        avg_win = trades_df[trades_df['pnl'] > 0]['pnl'].mean() if winning_trades > 0 else 0
        avg_loss = abs(trades_df[trades_df['pnl'] < 0]['pnl'].mean()) if losing_trades > 0 else 0
        profit_factor = (avg_win / avg_loss) if avg_loss > 0 else 0

        # 总收益
        total_pnl = trades_df['pnl'].sum()

        # 最大连续亏损
        max_consecutive_losses = self._calculate_max_consecutive_losses(trades_df)

        # 最大连续盈利
        max_consecutive_wins = self._calculate_max_consecutive_wins(trades_df)

        # 计算回撤
        if self.portfolio_values:
            portfolio_df = pd.DataFrame(self.portfolio_values)
            max_drawdown = self._calculate_max_drawdown(portfolio_df)
            sharpe_ratio = self._calculate_sharpe_ratio(portfolio_df)
        else:
            max_drawdown = 0
            sharpe_ratio = 0

        return {
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'total_pnl': total_pnl,
            'max_consecutive_losses': max_consecutive_losses,
            'max_consecutive_wins': max_consecutive_wins,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio
        }

    def _calculate_max_consecutive_losses(self, trades_df: pd.DataFrame) -> int:
        """计算最大连续亏损次数"""
        if trades_df.empty:
            return 0

        consecutive_losses = 0
        max_consecutive = 0

        for pnl in trades_df['pnl']:
            if pnl < 0:
                consecutive_losses += 1
                max_consecutive = max(max_consecutive, consecutive_losses)
            else:
                consecutive_losses = 0

        return max_consecutive

    def _calculate_max_consecutive_wins(self, trades_df: pd.DataFrame) -> int:
        """计算最大连续盈利次数"""
        if trades_df.empty:
            return 0

        consecutive_wins = 0
        max_consecutive = 0

        for pnl in trades_df['pnl']:
            if pnl > 0:
                consecutive_wins += 1
                max_consecutive = max(max_consecutive, consecutive_wins)
            else:
                consecutive_wins = 0

        return max_consecutive

    def _calculate_max_drawdown(self, portfolio_df: pd.DataFrame) -> float:
        """计算最大回撤"""
        if portfolio_df.empty:
            return 0

        values = portfolio_df['total_value']
        peak = values.expanding().max()
        drawdown = (values - peak) / peak * 100
        return abs(drawdown.min())

    def _calculate_sharpe_ratio(self, portfolio_df: pd.DataFrame) -> float:
        """计算夏普比率"""
        if len(portfolio_df) < 2:
            return 0

        returns = portfolio_df['total_value'].pct_change().dropna()
        if returns.std() == 0:
            return 0

        # 假设无风险利率为0
        return (returns.mean() / returns.std()) * np.sqrt(252)  # 年化

    def print_detailed_console_report(self):
        """打印详细的控制台报告"""
        metrics = self.calculate_metrics()

        # 使用更美观的边框和颜色
        print("\n" + "🚀" + "="*78 + "🚀")
        print("🎯" + " "*30 + "超级详细回测报告" + " "*30 + "🎯")
        print("🚀" + "="*78 + "🚀")

        # 基本统计 - 使用表格格式
        print(f"\n📊 基本统计")
        print("┌" + "─"*50 + "┐")
        print(f"│ 📈 总交易次数: {metrics['total_trades']:>30} │")
        print(f"│ ✅ 盈利交易:   {metrics['winning_trades']:>30} │")
        print(f"│ ❌ 亏损交易:   {metrics['losing_trades']:>30} │")
        print(f"│ 🎯 胜率:       {metrics['win_rate']:>28.2f}% │")
        print("└" + "─"*50 + "┘")

        # 盈亏分析
        print(f"\n💰 盈亏分析")
        print("┌" + "─"*50 + "┐")
        print(f"│ 📈 平均盈利:   {metrics['avg_win']:>28.2f} │")
        print(f"│ 📉 平均亏损:   {metrics['avg_loss']:>28.2f} │")
        print(f"│ ⚖️  盈亏比:     {metrics['profit_factor']:>28.2f} │")
        print(f"│ 💵 总盈亏:     {metrics['total_pnl']:>28.2f} │")
        print("└" + "─"*50 + "┘")

        # 风险指标
        print(f"\n⚠️ 风险指标")
        print("┌" + "─"*50 + "┐")
        print(f"│ 📉 最大回撤:   {metrics['max_drawdown']:>26.2f}% │")
        print(f"│ 📊 夏普比率:   {metrics['sharpe_ratio']:>28.2f} │")
        print(f"│ 🔴 最大连亏:   {metrics['max_consecutive_losses']:>30} │")
        print(f"│ 🟢 最大连盈:   {metrics['max_consecutive_wins']:>30} │")
        print("└" + "─"*50 + "┘")

        # 详细交易记录 - 使用表格格式
        if self.trades:
            print(f"\n📋 详细交易记录")
            print("┌" + "─"*4 + "┬" + "─"*20 + "┬" + "─"*6 + "┬" + "─"*10 + "┬" + "─"*12 + "┬" + "─"*10 + "┬" + "─"*8 + "┐")
            print("│ 序号 │        时间          │ 类型 │   价格   │    数量      │   盈亏   │  手续费  │")
            print("├" + "─"*4 + "┼" + "─"*20 + "┼" + "─"*6 + "┼" + "─"*10 + "┼" + "─"*12 + "┼" + "─"*10 + "┼" + "─"*8 + "┤")

            for i, trade in enumerate(self.trades, 1):
                timestamp = str(trade.get('timestamp', 'N/A'))[:19]  # 截取到秒
                trade_type = trade.get('type', 'N/A')
                price = trade.get('price', 0)
                size = trade.get('size', 0)
                pnl = trade.get('pnl', 0)
                commission = trade.get('commission', 0)

                # 根据盈亏添加颜色标记
                pnl_str = f"{pnl:>8.2f}"
                if pnl > 0:
                    pnl_str = f"🟢{pnl:>6.2f}"
                elif pnl < 0:
                    pnl_str = f"🔴{pnl:>6.2f}"
                else:
                    pnl_str = f"⚪{pnl:>6.2f}"

                print(f"│ {i:>2} │ {timestamp:<18} │ {trade_type:>4} │ {price:>8.2f} │ {size:>10.6f} │ {pnl_str} │ {commission:>6.2f} │")

            print("└" + "─"*4 + "┴" + "─"*20 + "┴" + "─"*6 + "┴" + "─"*10 + "┴" + "─"*12 + "┴" + "─"*10 + "┴" + "─"*8 + "┘")

        # 信号统计 - 使用柱状图风格
        if self.signals:
            signal_df = pd.DataFrame(self.signals)
            print(f"\n🎯 信号统计")
            print("┌" + "─"*40 + "┐")
            signal_counts = signal_df['signal_type'].value_counts()
            max_count = signal_counts.max() if len(signal_counts) > 0 else 1

            for signal_type, count in signal_counts.items():
                # 创建简单的柱状图
                bar_length = int((count / max_count) * 20)
                bar = "█" * bar_length + "░" * (20 - bar_length)

                # 根据信号类型添加颜色
                if 'BUY' in signal_type:
                    icon = "🟢"
                elif 'SELL' in signal_type:
                    icon = "🔴"
                else:
                    icon = "⚪"

                print(f"│ {icon} {signal_type:<15} │{bar}│ {count:>4} │")
            print("└" + "─"*40 + "┘")

        print("\n🚀" + "="*78 + "🚀")
        print("🎉" + " "*28 + "报告生成完成！" + " "*28 + "🎉")
        print("🚀" + "="*78 + "🚀")

    def save_data_to_json(self):
        """保存所有数据到JSON文件"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        data = {
            'timestamp': timestamp,
            'trades': self.trades,
            'signals': self.signals,
            'portfolio_values': self.portfolio_values,
            'positions': self.positions,
            'orders': self.orders,
            'price_data': self.price_data,
            'metrics': self.calculate_metrics()
        }

        # 转换datetime对象为字符串
        data = self._convert_datetime_to_string(data)

        filename = f"backtest_data_{timestamp}.json"
        filepath = os.path.join(self.output_dir, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.info(f"回测数据已保存到: {filepath}")
        return filepath

    def _convert_datetime_to_string(self, obj):
        """递归转换datetime对象和numpy类型为字符串"""
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()  # 转换numpy类型为Python原生类型
        elif isinstance(obj, np.ndarray):
            return obj.tolist()  # 转换numpy数组为列表
        elif isinstance(obj, dict):
            return {key: self._convert_datetime_to_string(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_datetime_to_string(item) for item in obj]
        else:
            return obj

    def generate_html_report(self) -> str:
        """生成HTML可视化报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"backtest_report_{timestamp}.html"
        filepath = os.path.join(self.output_dir, filename)

        # 生成图表
        charts_html = self._generate_charts()

        # 计算指标
        metrics = self.calculate_metrics()

        # 生成HTML内容
        html_content = self._generate_html_content(charts_html, metrics, timestamp)

        # 保存HTML文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"HTML报告已生成: {filepath}")
        return filepath

    def _generate_charts(self) -> str:
        """生成所有图表的HTML"""
        charts = []

        # 1. 价格走势图
        if self.price_data:
            price_chart = self._create_price_chart()
            charts.append(price_chart)

        # 2. 组合价值图
        if self.portfolio_values:
            portfolio_chart = self._create_portfolio_chart()
            charts.append(portfolio_chart)

        # 3. 交易分布图
        if self.trades:
            trade_chart = self._create_trade_distribution_chart()
            charts.append(trade_chart)

        # 4. 信号统计图
        if self.signals:
            signal_chart = self._create_signal_chart()
            charts.append(signal_chart)

        # 5. 回撤图
        if self.portfolio_values:
            drawdown_chart = self._create_drawdown_chart()
            charts.append(drawdown_chart)

        return '\n'.join(charts)

    def _create_price_chart(self) -> str:
        """创建价格走势图"""
        df = pd.DataFrame(self.price_data)

        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=('价格走势', '成交量'),
            vertical_spacing=0.1,
            row_heights=[0.7, 0.3]
        )

        # 价格K线图
        fig.add_trace(
            go.Candlestick(
                x=df['timestamp'],
                open=df['open'],
                high=df['high'],
                low=df['low'],
                close=df['close'],
                name='价格'
            ),
            row=1, col=1
        )

        # 添加交易点
        if self.trades:
            trades_df = pd.DataFrame(self.trades)
            buy_trades = trades_df[trades_df['type'] == 'BUY']
            sell_trades = trades_df[trades_df['type'] == 'SELL']

            if not buy_trades.empty:
                fig.add_trace(
                    go.Scatter(
                        x=buy_trades['timestamp'],
                        y=buy_trades['price'],
                        mode='markers',
                        marker=dict(color='green', size=10, symbol='triangle-up'),
                        name='买入'
                    ),
                    row=1, col=1
                )

            if not sell_trades.empty:
                fig.add_trace(
                    go.Scatter(
                        x=sell_trades['timestamp'],
                        y=sell_trades['price'],
                        mode='markers',
                        marker=dict(color='red', size=10, symbol='triangle-down'),
                        name='卖出'
                    ),
                    row=1, col=1
                )

        # 成交量
        fig.add_trace(
            go.Bar(
                x=df['timestamp'],
                y=df['volume'],
                name='成交量',
                marker_color='lightblue'
            ),
            row=2, col=1
        )

        fig.update_layout(
            title='价格走势与交易记录',
            xaxis_rangeslider_visible=False,
            height=600
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_portfolio_chart(self) -> str:
        """创建组合价值图"""
        df = pd.DataFrame(self.portfolio_values)

        fig = go.Figure()

        fig.add_trace(
            go.Scatter(
                x=df['timestamp'],
                y=df['total_value'],
                mode='lines',
                name='组合价值',
                line=dict(color='blue', width=2)
            )
        )

        fig.update_layout(
            title='组合价值变化',
            xaxis_title='时间',
            yaxis_title='价值',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_trade_distribution_chart(self) -> str:
        """创建交易分布图"""
        df = pd.DataFrame(self.trades)

        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('盈亏分布', '交易类型分布'),
            specs=[[{"type": "histogram"}, {"type": "pie"}]]
        )

        # 盈亏分布直方图
        fig.add_trace(
            go.Histogram(
                x=df['pnl'],
                nbinsx=20,
                name='盈亏分布',
                marker_color='lightgreen'
            ),
            row=1, col=1
        )

        # 交易类型饼图
        type_counts = df['type'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=type_counts.index,
                values=type_counts.values,
                name='交易类型'
            ),
            row=1, col=2
        )

        fig.update_layout(
            title='交易分析',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_signal_chart(self) -> str:
        """创建信号统计图"""
        df = pd.DataFrame(self.signals)

        signal_counts = df['signal_type'].value_counts()

        fig = go.Figure(data=[
            go.Bar(
                x=signal_counts.index,
                y=signal_counts.values,
                marker_color=['green' if 'BUY' in x else 'red' if 'SELL' in x else 'gray'
                             for x in signal_counts.index]
            )
        ])

        fig.update_layout(
            title='信号类型统计',
            xaxis_title='信号类型',
            yaxis_title='数量',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_drawdown_chart(self) -> str:
        """创建回撤图"""
        df = pd.DataFrame(self.portfolio_values)

        # 计算回撤
        peak = df['total_value'].expanding().max()
        drawdown = (df['total_value'] - peak) / peak * 100

        fig = go.Figure()

        fig.add_trace(
            go.Scatter(
                x=df['timestamp'],
                y=drawdown,
                mode='lines',
                fill='tonexty',
                name='回撤',
                line=dict(color='red'),
                fillcolor='rgba(255,0,0,0.3)'
            )
        )

        fig.update_layout(
            title='回撤分析',
            xaxis_title='时间',
            yaxis_title='回撤 (%)',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _generate_html_content(self, charts_html: str, metrics: Dict[str, Any], timestamp: str) -> str:
        """生成完整的HTML内容"""
        return f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>回测报告 - {timestamp}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }}
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .metric-card {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
        }}
        .metric-card:hover {{
            transform: translateY(-5px);
        }}
        .metric-value {{
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .metric-label {{
            font-size: 0.9em;
            opacity: 0.9;
        }}
        .chart-container {{
            margin-bottom: 30px;
            padding: 20px;
            background-color: #fafafa;
            border-radius: 10px;
        }}
        .trade-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        .trade-table th, .trade-table td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }}
        .trade-table th {{
            background-color: #f2f2f2;
            font-weight: bold;
        }}
        .profit {{
            color: green;
            font-weight: bold;
        }}
        .loss {{
            color: red;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 超级详细回测报告 🚀</h1>
            <p style="font-size: 1.2em; color: #666;">📅 生成时间: {timestamp}</p>
            <p style="font-size: 1.1em; color: #888;">🎯 专业量化交易回测分析</p>
        </div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-value">{metrics['total_trades']}</div>
                <div class="metric-label">总交易次数</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics['win_rate']:.1f}%</div>
                <div class="metric-label">胜率</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics['profit_factor']:.2f}</div>
                <div class="metric-label">盈亏比</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics['total_pnl']:.2f}</div>
                <div class="metric-label">总盈亏</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics['max_drawdown']:.1f}%</div>
                <div class="metric-label">最大回撤</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics['sharpe_ratio']:.2f}</div>
                <div class="metric-label">夏普比率</div>
            </div>
        </div>

        <div class="chart-container">
            {charts_html}
        </div>

        <h2>📋 详细交易记录</h2>
        """ + self._generate_trade_table() + """

    </div>
</body>
</html>
"""

    def _generate_trade_table(self) -> str:
        """生成交易记录表格"""
        if not self.trades:
            return "<p>暂无交易记录</p>"

        table_rows = []
        for i, trade in enumerate(self.trades, 1):
            pnl_class = "profit" if trade.get('pnl', 0) > 0 else "loss"
            row = f"""
            <tr>
                <td>{i}</td>
                <td>{trade.get('timestamp', 'N/A')}</td>
                <td>{trade.get('type', 'N/A')}</td>
                <td>{trade.get('price', 0):.2f}</td>
                <td>{trade.get('size', 0):.6f}</td>
                <td class="{pnl_class}">{trade.get('pnl', 0):.2f}</td>
                <td>{trade.get('commission', 0):.2f}</td>
            </tr>
            """
            table_rows.append(row)

        return f"""
        <table class="trade-table">
            <thead>
                <tr>
                    <th>序号</th>
                    <th>时间</th>
                    <th>类型</th>
                    <th>价格</th>
                    <th>数量</th>
                    <th>盈亏</th>
                    <th>手续费</th>
                </tr>
            </thead>
            <tbody>
                {''.join(table_rows)}
            </tbody>
        </table>
        """
