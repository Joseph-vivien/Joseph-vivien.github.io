#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
专业控制台报告生成器

该模块生成世界级的量化交易控制台报告，包括：
- 超详细的统计分析
- 美观的表格和图表
- 专业的风险指标
- 交易行为分析

作者: 高级Python工程师
日期: 2024-05-23
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich.progress import Progress, BarColumn, TextColumn
from rich.text import Text
from rich.align import Align
import plotext as plt

from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("professional_console_reporter")

class ProfessionalConsoleReporter:
    """
    专业控制台报告生成器

    生成世界级的量化交易控制台报告
    """

    def __init__(self):
        """初始化报告生成器"""
        self.console = Console(width=120)

    def generate_comprehensive_report(self, metrics: Dict[str, Any],
                                    trades_data: List[Dict] = None,
                                    signals_data: List[Dict] = None) -> str:
        """
        生成综合报告

        参数:
            metrics: 计算得到的指标
            trades_data: 交易数据
            signals_data: 信号数据

        返回:
            报告字符串
        """
        report_sections = []

        # 1. 报告头部
        report_sections.append(self._create_header())

        # 2. 执行摘要
        report_sections.append(self._create_executive_summary(metrics))

        # 3. 基础统计
        report_sections.append(self._create_basic_statistics(metrics))

        # 4. 风险分析
        report_sections.append(self._create_risk_analysis(metrics))

        # 5. 交易行为分析
        report_sections.append(self._create_trading_behavior_analysis(metrics))

        # 6. 时间分析
        report_sections.append(self._create_time_analysis(metrics))

        # 7. 信号质量分析
        if signals_data:
            report_sections.append(self._create_signal_quality_analysis(metrics))

        # 8. 详细交易记录
        if trades_data:
            report_sections.append(self._create_detailed_trades_table(trades_data))

        # 9. 建议和总结
        report_sections.append(self._create_recommendations(metrics))

        # 10. 报告尾部
        report_sections.append(self._create_footer())

        return '\n'.join(report_sections)

    def _create_header(self) -> str:
        """创建报告头部"""
        title = Text("🚀 专业量化交易回测分析报告 🚀", style="bold magenta")
        subtitle = Text(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", style="dim")

        header_panel = Panel(
            Align.center(title + "\n" + subtitle),
            border_style="bright_blue",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(header_panel)

        return capture.get()

    def _create_executive_summary(self, metrics: Dict[str, Any]) -> str:
        """创建执行摘要"""
        # 计算关键指标
        total_trades = metrics.get('total_trades', 0)
        win_rate = metrics.get('win_rate', 0)
        total_return = metrics.get('total_return_pct', 0)
        max_drawdown = metrics.get('max_drawdown_pct', 0)
        sharpe_ratio = metrics.get('sharpe_ratio', 0)

        # 策略评级
        strategy_grade = self._calculate_strategy_grade(metrics)

        summary_text = f"""
📊 [bold]策略表现概览[/bold]

🎯 [green]策略评级[/green]: {strategy_grade}
📈 [blue]总交易次数[/blue]: {total_trades}
🏆 [green]胜率[/green]: {win_rate:.2f}%
💰 [yellow]总收益率[/yellow]: {total_return:.2f}%
📉 [red]最大回撤[/red]: {max_drawdown:.2f}%
⚡ [cyan]夏普比率[/cyan]: {sharpe_ratio:.3f}

{self._get_performance_emoji(total_return)} [bold]{self._get_performance_text(total_return)}[/bold]
        """

        summary_panel = Panel(
            summary_text,
            title="📋 执行摘要",
            border_style="green",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(summary_panel)

        return capture.get()

    def _create_basic_statistics(self, metrics: Dict[str, Any]) -> str:
        """创建基础统计表格"""
        table = Table(title="📊 基础交易统计", show_header=True, header_style="bold magenta")
        table.add_column("指标", style="cyan", width=25)
        table.add_column("数值", style="green", width=20)
        table.add_column("说明", style="dim", width=40)

        # 添加基础统计数据
        stats = [
            ("总交易次数", f"{metrics.get('total_trades', 0)}", "策略执行的总交易数量"),
            ("盈利交易", f"{metrics.get('winning_trades', 0)}", "产生正收益的交易数量"),
            ("亏损交易", f"{metrics.get('losing_trades', 0)}", "产生负收益的交易数量"),
            ("胜率", f"{metrics.get('win_rate', 0):.2f}%", "盈利交易占总交易的比例"),
            ("平均盈利", f"{metrics.get('avg_win', 0):.2f}", "单笔盈利交易的平均收益"),
            ("平均亏损", f"{metrics.get('avg_loss', 0):.2f}", "单笔亏损交易的平均损失"),
            ("盈亏比", f"{metrics.get('profit_factor', 0):.2f}", "平均盈利与平均亏损的比值"),
            ("最大单笔盈利", f"{metrics.get('max_win', 0):.2f}", "单笔交易的最大盈利"),
            ("最大单笔亏损", f"{metrics.get('max_loss', 0):.2f}", "单笔交易的最大亏损"),
            ("总手续费", f"{metrics.get('total_commission', 0):.2f}", "所有交易产生的手续费总和"),
        ]

        for metric, value, description in stats:
            # 根据指标类型添加颜色
            if "盈利" in metric or "胜率" in metric:
                value_style = "green"
            elif "亏损" in metric or "手续费" in metric:
                value_style = "red"
            else:
                value_style = "white"

            table.add_row(metric, f"[{value_style}]{value}[/{value_style}]", description)

        with self.console.capture() as capture:
            self.console.print(table)

        return capture.get()

    def _create_risk_analysis(self, metrics: Dict[str, Any]) -> str:
        """创建风险分析表格"""
        table = Table(title="⚠️ 风险指标分析", show_header=True, header_style="bold red")
        table.add_column("风险指标", style="cyan", width=25)
        table.add_column("数值", style="yellow", width=20)
        table.add_column("风险等级", style="bold", width=15)
        table.add_column("说明", style="dim", width=35)

        # 风险指标数据
        risk_metrics = [
            ("最大回撤", f"{metrics.get('max_drawdown_pct', 0):.2f}%",
             self._get_risk_level(metrics.get('max_drawdown_pct', 0), 'drawdown'),
             "投资组合价值的最大跌幅"),
            ("夏普比率", f"{metrics.get('sharpe_ratio', 0):.3f}",
             self._get_risk_level(metrics.get('sharpe_ratio', 0), 'sharpe'),
             "风险调整后的收益率"),
            ("索提诺比率", f"{metrics.get('sortino_ratio', 0):.3f}",
             self._get_risk_level(metrics.get('sortino_ratio', 0), 'sortino'),
             "下行风险调整后的收益率"),
            ("最大连续亏损", f"{metrics.get('max_consecutive_losses', 0)}",
             self._get_risk_level(metrics.get('max_consecutive_losses', 0), 'consecutive_loss'),
             "连续亏损交易的最大次数"),
            ("VaR (95%)", f"{metrics.get('var_95', 0):.2f}",
             self._get_risk_level(abs(metrics.get('var_95', 0)), 'var'),
             "95%置信度下的风险价值"),
            ("CVaR (95%)", f"{metrics.get('cvar_95', 0):.2f}",
             self._get_risk_level(abs(metrics.get('cvar_95', 0)), 'cvar'),
             "条件风险价值"),
            ("卡尔玛比率", f"{metrics.get('calmar_ratio', 0):.3f}",
             self._get_risk_level(metrics.get('calmar_ratio', 0), 'calmar'),
             "年化收益率与最大回撤的比值"),
        ]

        for metric, value, risk_level, description in risk_metrics:
            table.add_row(metric, value, risk_level, description)

        with self.console.capture() as capture:
            self.console.print(table)

        return capture.get()

    def _create_trading_behavior_analysis(self, metrics: Dict[str, Any]) -> str:
        """创建交易行为分析"""
        table = Table(title="🎯 交易行为分析", show_header=True, header_style="bold blue")
        table.add_column("行为指标", style="cyan", width=25)
        table.add_column("数值", style="green", width=20)
        table.add_column("评价", style="bold", width=15)
        table.add_column("建议", style="dim", width=35)

        # 交易行为指标
        behavior_metrics = [
            ("平均交易间隔", f"{metrics.get('avg_time_between_trades_hours', 0):.2f}小时",
             self._evaluate_trading_frequency(metrics.get('avg_time_between_trades_hours', 0)),
             "调整交易频率以优化表现"),
            ("平均交易规模", f"{metrics.get('avg_trade_size', 0):.6f}",
             self._evaluate_trade_size(metrics.get('avg_trade_size', 0)),
             "根据风险承受能力调整仓位"),
            ("买卖比例", f"{metrics.get('buy_sell_ratio', 0):.2f}",
             self._evaluate_buy_sell_ratio(metrics.get('buy_sell_ratio', 0)),
             "保持买卖信号的平衡性"),
            ("交易规模标准差", f"{metrics.get('trade_size_std', 0):.6f}",
             self._evaluate_size_consistency(metrics.get('trade_size_std', 0)),
             "保持仓位管理的一致性"),
        ]

        for metric, value, evaluation, suggestion in behavior_metrics:
            table.add_row(metric, value, evaluation, suggestion)

        with self.console.capture() as capture:
            self.console.print(table)

        return capture.get()

    def _create_time_analysis(self, metrics: Dict[str, Any]) -> str:
        """创建时间分析"""
        time_panel_content = f"""
🕐 [bold]最佳交易时间[/bold]: {metrics.get('best_trading_hour', 0):02d}:00
🕐 [bold]最差交易时间[/bold]: {metrics.get('worst_trading_hour', 0):02d}:00

📅 [bold]最佳交易日[/bold]: {self._get_weekday_name(metrics.get('best_trading_weekday', 0))}
📅 [bold]最差交易日[/bold]: {self._get_weekday_name(metrics.get('worst_trading_weekday', 0))}

💡 [yellow]建议[/yellow]: 在最佳时间段增加交易频率，在最差时间段降低仓位或暂停交易
        """

        time_panel = Panel(
            time_panel_content,
            title="⏰ 时间分析",
            border_style="yellow",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(time_panel)

        return capture.get()

    def _create_signal_quality_analysis(self, metrics: Dict[str, Any]) -> str:
        """创建信号质量分析"""
        signal_content = f"""
📊 [bold]信号统计[/bold]
• 总信号数: {metrics.get('total_signals', 0)}
• 平均信心度: {metrics.get('avg_signal_confidence', 0):.3f}
• 高信心度信号: {metrics.get('high_confidence_signals', 0)} ({metrics.get('high_confidence_ratio_pct', 0):.1f}%)

🎯 [bold]信号质量评估[/bold]: {self._evaluate_signal_quality(metrics)}

💡 [yellow]优化建议[/yellow]: {self._get_signal_optimization_advice(metrics)}
        """

        signal_panel = Panel(
            signal_content,
            title="🎯 信号质量分析",
            border_style="cyan",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(signal_panel)

        return capture.get()

    def _create_detailed_trades_table(self, trades_data: List[Dict]) -> str:
        """创建详细交易记录表格"""
        if not trades_data:
            return ""

        # 只显示最近的20笔交易
        recent_trades = trades_data[-20:] if len(trades_data) > 20 else trades_data

        table = Table(title=f"📋 详细交易记录 (最近{len(recent_trades)}笔)",
                     show_header=True, header_style="bold magenta")

        table.add_column("序号", style="dim", width=6)
        table.add_column("时间", style="cyan", width=19)
        table.add_column("类型", style="bold", width=6)
        table.add_column("价格", style="yellow", width=10)
        table.add_column("数量", style="blue", width=12)
        table.add_column("盈亏", style="bold", width=10)
        table.add_column("手续费", style="dim", width=8)
        table.add_column("累计盈亏", style="bold", width=12)

        cumulative_pnl = 0
        for i, trade in enumerate(recent_trades, 1):
            timestamp = str(trade.get('timestamp', 'N/A'))[:19]
            trade_type = trade.get('type', 'N/A')
            price = trade.get('price', 0)
            size = trade.get('size', 0)
            pnl = trade.get('pnl', 0)
            commission = trade.get('commission', 0)

            cumulative_pnl += pnl

            # 根据盈亏设置颜色
            if pnl > 0:
                pnl_style = "green"
                pnl_icon = "🟢"
            elif pnl < 0:
                pnl_style = "red"
                pnl_icon = "🔴"
            else:
                pnl_style = "white"
                pnl_icon = "⚪"

            # 交易类型颜色
            type_style = "green" if trade_type == "BUY" else "red"

            table.add_row(
                str(len(trades_data) - len(recent_trades) + i),
                timestamp,
                f"[{type_style}]{trade_type}[/{type_style}]",
                f"{price:.2f}",
                f"{size:.6f}",
                f"[{pnl_style}]{pnl_icon}{pnl:.2f}[/{pnl_style}]",
                f"{commission:.2f}",
                f"[{'green' if cumulative_pnl > 0 else 'red'}]{cumulative_pnl:.2f}[/{'green' if cumulative_pnl > 0 else 'red'}]"
            )

        with self.console.capture() as capture:
            self.console.print(table)

        return capture.get()

    def _create_recommendations(self, metrics: Dict[str, Any]) -> str:
        """创建建议和总结"""
        recommendations = self._generate_recommendations(metrics)

        rec_content = "\n".join([f"• {rec}" for rec in recommendations])

        rec_panel = Panel(
            rec_content,
            title="💡 优化建议",
            border_style="bright_green",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(rec_panel)

        return capture.get()

    def _create_footer(self) -> str:
        """创建报告尾部"""
        footer_text = Text("📊 报告生成完成 | 祝您交易顺利！ 🚀", style="bold bright_blue")

        footer_panel = Panel(
            Align.center(footer_text),
            border_style="bright_blue",
            padding=(1, 2)
        )

        with self.console.capture() as capture:
            self.console.print(footer_panel)

        return capture.get()

    # 辅助方法
    def _calculate_strategy_grade(self, metrics: Dict[str, Any]) -> str:
        """计算策略评级"""
        score = 0

        # 胜率评分 (30%)
        win_rate = metrics.get('win_rate', 0)
        if win_rate >= 60:
            score += 30
        elif win_rate >= 50:
            score += 25
        elif win_rate >= 40:
            score += 20
        elif win_rate >= 30:
            score += 15
        else:
            score += 10

        # 盈亏比评分 (25%)
        profit_factor = metrics.get('profit_factor', 0)
        if profit_factor >= 2.0:
            score += 25
        elif profit_factor >= 1.5:
            score += 20
        elif profit_factor >= 1.2:
            score += 15
        elif profit_factor >= 1.0:
            score += 10
        else:
            score += 5

        # 夏普比率评分 (25%)
        sharpe = metrics.get('sharpe_ratio', 0)
        if sharpe >= 1.5:
            score += 25
        elif sharpe >= 1.0:
            score += 20
        elif sharpe >= 0.5:
            score += 15
        elif sharpe >= 0:
            score += 10
        else:
            score += 5

        # 最大回撤评分 (20%)
        max_dd = metrics.get('max_drawdown_pct', 100)
        if max_dd <= 5:
            score += 20
        elif max_dd <= 10:
            score += 15
        elif max_dd <= 20:
            score += 10
        elif max_dd <= 30:
            score += 5
        else:
            score += 0

        # 评级映射
        if score >= 85:
            return "[bold green]A+ (优秀)[/bold green]"
        elif score >= 75:
            return "[green]A (良好)[/green]"
        elif score >= 65:
            return "[yellow]B+ (中等偏上)[/yellow]"
        elif score >= 55:
            return "[yellow]B (中等)[/yellow]"
        elif score >= 45:
            return "[red]C+ (中等偏下)[/red]"
        elif score >= 35:
            return "[red]C (较差)[/red]"
        else:
            return "[bold red]D (很差)[/bold red]"

    def _get_performance_emoji(self, return_pct: float) -> str:
        """根据收益率获取表情符号"""
        if return_pct >= 20:
            return "🚀"
        elif return_pct >= 10:
            return "📈"
        elif return_pct >= 5:
            return "✅"
        elif return_pct >= 0:
            return "😐"
        elif return_pct >= -5:
            return "😕"
        elif return_pct >= -10:
            return "😰"
        else:
            return "💥"

    def _get_performance_text(self, return_pct: float) -> str:
        """根据收益率获取表现描述"""
        if return_pct >= 20:
            return "表现卓越！"
        elif return_pct >= 10:
            return "表现优秀"
        elif return_pct >= 5:
            return "表现良好"
        elif return_pct >= 0:
            return "表现平平"
        elif return_pct >= -5:
            return "表现不佳"
        elif return_pct >= -10:
            return "表现较差"
        else:
            return "表现很差"

    def _get_risk_level(self, value: float, metric_type: str) -> str:
        """获取风险等级"""
        if metric_type == 'drawdown':
            if value <= 5:
                return "[green]低风险[/green]"
            elif value <= 15:
                return "[yellow]中风险[/yellow]"
            else:
                return "[red]高风险[/red]"
        elif metric_type in ['sharpe', 'sortino', 'calmar']:
            if value >= 1.0:
                return "[green]优秀[/green]"
            elif value >= 0.5:
                return "[yellow]良好[/yellow]"
            else:
                return "[red]较差[/red]"
        elif metric_type == 'consecutive_loss':
            if value <= 3:
                return "[green]可控[/green]"
            elif value <= 6:
                return "[yellow]注意[/yellow]"
            else:
                return "[red]危险[/red]"
        elif metric_type in ['var', 'cvar']:
            if value <= 2:
                return "[green]低风险[/green]"
            elif value <= 5:
                return "[yellow]中风险[/yellow]"
            else:
                return "[red]高风险[/red]"
        else:
            return "[white]正常[/white]"

    def _evaluate_trading_frequency(self, hours: float) -> str:
        """评估交易频率"""
        if hours >= 24:
            return "[green]合理[/green]"
        elif hours >= 12:
            return "[yellow]偏高[/yellow]"
        elif hours >= 6:
            return "[red]过高[/red]"
        else:
            return "[bold red]极高[/bold red]"

    def _evaluate_trade_size(self, size: float) -> str:
        """评估交易规模"""
        if 0.1 <= size <= 1.0:
            return "[green]合理[/green]"
        elif size > 1.0:
            return "[yellow]偏大[/yellow]"
        else:
            return "[red]偏小[/red]"

    def _evaluate_buy_sell_ratio(self, ratio: float) -> str:
        """评估买卖比例"""
        if 0.8 <= ratio <= 1.2:
            return "[green]平衡[/green]"
        elif 0.5 <= ratio <= 2.0:
            return "[yellow]偏斜[/yellow]"
        else:
            return "[red]失衡[/red]"

    def _evaluate_size_consistency(self, std: float) -> str:
        """评估仓位一致性"""
        if std <= 0.05:
            return "[green]一致[/green]"
        elif std <= 0.1:
            return "[yellow]一般[/yellow]"
        else:
            return "[red]不一致[/red]"

    def _get_weekday_name(self, weekday: int) -> str:
        """获取星期名称"""
        names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        return names[weekday] if 0 <= weekday < 7 else "未知"

    def _evaluate_signal_quality(self, metrics: Dict[str, Any]) -> str:
        """评估信号质量"""
        avg_confidence = metrics.get('avg_signal_confidence', 0)
        high_confidence_ratio = metrics.get('high_confidence_ratio_pct', 0)

        if avg_confidence >= 0.7 and high_confidence_ratio >= 30:
            return "[green]优秀[/green]"
        elif avg_confidence >= 0.5 and high_confidence_ratio >= 20:
            return "[yellow]良好[/yellow]"
        elif avg_confidence >= 0.3:
            return "[red]一般[/red]"
        else:
            return "[bold red]较差[/bold red]"

    def _get_signal_optimization_advice(self, metrics: Dict[str, Any]) -> str:
        """获取信号优化建议"""
        avg_confidence = metrics.get('avg_signal_confidence', 0)

        if avg_confidence < 0.3:
            return "建议调整信号生成参数，提高信号质量"
        elif avg_confidence < 0.5:
            return "建议优化技术指标参数，增强信号可靠性"
        elif avg_confidence < 0.7:
            return "信号质量良好，可考虑增加信号过滤条件"
        else:
            return "信号质量优秀，保持当前设置"

    def _generate_recommendations(self, metrics: Dict[str, Any]) -> List[str]:
        """生成优化建议"""
        recommendations = []

        # 胜率建议
        win_rate = metrics.get('win_rate', 0)
        if win_rate < 40:
            recommendations.append("胜率偏低，建议优化入场条件和信号质量")
        elif win_rate > 70:
            recommendations.append("胜率较高，可考虑适当增加交易频率")

        # 盈亏比建议
        profit_factor = metrics.get('profit_factor', 0)
        if profit_factor < 1.2:
            recommendations.append("盈亏比偏低，建议优化止盈止损策略")
        elif profit_factor > 3.0:
            recommendations.append("盈亏比很高，可考虑适当放宽入场条件")

        # 回撤建议
        max_drawdown = metrics.get('max_drawdown_pct', 0)
        if max_drawdown > 20:
            recommendations.append("最大回撤过大，建议加强风险控制和仓位管理")
        elif max_drawdown > 10:
            recommendations.append("回撤适中，可考虑优化止损策略")

        # 交易频率建议
        avg_time = metrics.get('avg_time_between_trades_hours', 0)
        if avg_time < 6:
            recommendations.append("交易频率过高，建议增加交易冷却时间")
        elif avg_time > 48:
            recommendations.append("交易频率偏低，可考虑放宽信号条件")

        # 夏普比率建议
        sharpe = metrics.get('sharpe_ratio', 0)
        if sharpe < 0.5:
            recommendations.append("风险调整收益偏低，建议平衡风险与收益")
        elif sharpe > 2.0:
            recommendations.append("风险调整收益优秀，可考虑适当增加仓位")

        # 连续亏损建议
        max_consecutive_losses = metrics.get('max_consecutive_losses', 0)
        if max_consecutive_losses > 5:
            recommendations.append("连续亏损次数较多，建议增加信号过滤条件")

        if not recommendations:
            recommendations.append("策略表现良好，继续保持当前设置")

        return recommendations
