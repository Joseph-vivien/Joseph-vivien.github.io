#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
高级回测分析器

该模块提供世界级的量化交易回测分析功能，包括：
- 详细的风险指标分析
- 交易行为分析
- 信号质量评估
- 策略表现归因分析
- 市场环境适应性分析

作者: 高级Python工程师
日期: 2024-05-23
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.figure_factory as ff
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("advanced_analyzer")

class AdvancedBacktestAnalyzer:
    """
    高级回测分析器

    提供专业级的量化交易回测分析功能
    """

    def __init__(self, trades_data: List[Dict], portfolio_data: List[Dict],
                 signals_data: List[Dict], price_data: List[Dict]):
        """
        初始化分析器

        参数:
            trades_data: 交易数据
            portfolio_data: 组合价值数据
            signals_data: 信号数据
            price_data: 价格数据
        """
        self.trades_df = pd.DataFrame(trades_data) if trades_data else pd.DataFrame()
        self.portfolio_df = pd.DataFrame(portfolio_data) if portfolio_data else pd.DataFrame()
        self.signals_df = pd.DataFrame(signals_data) if signals_data else pd.DataFrame()
        self.price_df = pd.DataFrame(price_data) if price_data else pd.DataFrame()

        # 数据预处理
        self._preprocess_data()

        logger.info("高级回测分析器初始化完成")

    def _preprocess_data(self):
        """数据预处理"""
        # 转换时间戳
        for df_name, df in [('trades', self.trades_df), ('portfolio', self.portfolio_df),
                           ('signals', self.signals_df), ('price', self.price_df)]:
            if not df.empty and 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                df.set_index('timestamp', inplace=True)
                df.sort_index(inplace=True)

    def calculate_comprehensive_metrics(self) -> Dict[str, Any]:
        """计算全面的交易指标"""
        metrics = {}

        if not self.trades_df.empty:
            # 基础交易指标
            metrics.update(self._calculate_basic_metrics())

            # 风险指标
            metrics.update(self._calculate_risk_metrics())

            # 交易行为指标
            metrics.update(self._calculate_trading_behavior_metrics())

            # 时间分析指标
            metrics.update(self._calculate_time_analysis_metrics())

        if not self.portfolio_df.empty:
            # 组合表现指标
            metrics.update(self._calculate_portfolio_metrics())

        if not self.signals_df.empty:
            # 信号质量指标
            metrics.update(self._calculate_signal_quality_metrics())

        return metrics

    def _calculate_basic_metrics(self) -> Dict[str, Any]:
        """计算基础交易指标"""
        trades = self.trades_df

        total_trades = len(trades)
        if total_trades == 0:
            return {}

        # 盈亏分析
        winning_trades = trades[trades['pnl'] > 0]
        losing_trades = trades[trades['pnl'] < 0]

        win_count = len(winning_trades)
        loss_count = len(losing_trades)

        # 基础统计
        total_pnl = trades['pnl'].sum()
        total_commission = trades['commission'].sum() if 'commission' in trades.columns else 0
        net_pnl = total_pnl - total_commission

        # 胜率和盈亏比
        win_rate = (win_count / total_trades) * 100 if total_trades > 0 else 0

        avg_win = winning_trades['pnl'].mean() if win_count > 0 else 0
        avg_loss = abs(losing_trades['pnl'].mean()) if loss_count > 0 else 0
        profit_factor = avg_win / avg_loss if avg_loss > 0 else float('inf')

        # 最大单笔盈亏
        max_win = trades['pnl'].max()
        max_loss = trades['pnl'].min()

        return {
            'total_trades': total_trades,
            'winning_trades': win_count,
            'losing_trades': loss_count,
            'win_rate': win_rate,
            'total_pnl': total_pnl,
            'net_pnl': net_pnl,
            'total_commission': total_commission,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'max_win': max_win,
            'max_loss': max_loss,
            'avg_trade_pnl': trades['pnl'].mean(),
            'median_trade_pnl': trades['pnl'].median(),
            'pnl_std': trades['pnl'].std()
        }

    def _calculate_risk_metrics(self) -> Dict[str, Any]:
        """计算风险指标"""
        trades = self.trades_df

        if trades.empty:
            return {}

        # 连续盈亏分析
        consecutive_wins = self._calculate_consecutive_runs(trades['pnl'] > 0)
        consecutive_losses = self._calculate_consecutive_runs(trades['pnl'] < 0)

        # 回撤分析
        cumulative_pnl = trades['pnl'].cumsum()
        running_max = cumulative_pnl.expanding().max()
        drawdown = cumulative_pnl - running_max
        max_drawdown = abs(drawdown.min())
        max_drawdown_pct = (max_drawdown / running_max.max() * 100) if running_max.max() > 0 else 0

        # 风险调整收益
        returns = trades['pnl']
        sharpe_ratio = returns.mean() / returns.std() if returns.std() > 0 else 0

        # 下行风险
        negative_returns = returns[returns < 0]
        downside_deviation = negative_returns.std() if len(negative_returns) > 0 else 0
        sortino_ratio = returns.mean() / downside_deviation if downside_deviation > 0 else 0

        # VaR计算 (95%置信度)
        var_95 = np.percentile(returns, 5) if len(returns) > 0 else 0
        cvar_95 = returns[returns <= var_95].mean() if len(returns[returns <= var_95]) > 0 else 0

        return {
            'max_consecutive_wins': max(consecutive_wins) if consecutive_wins else 0,
            'max_consecutive_losses': max(consecutive_losses) if consecutive_losses else 0,
            'max_drawdown': max_drawdown,
            'max_drawdown_pct': max_drawdown_pct,
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'var_95': var_95,
            'cvar_95': cvar_95,
            'downside_deviation': downside_deviation,
            'calmar_ratio': (returns.mean() * len(returns)) / max_drawdown if max_drawdown > 0 else 0
        }

    def _calculate_consecutive_runs(self, condition_series: pd.Series) -> List[int]:
        """计算连续满足条件的次数"""
        runs = []
        current_run = 0

        for value in condition_series:
            if value:
                current_run += 1
            else:
                if current_run > 0:
                    runs.append(current_run)
                current_run = 0

        if current_run > 0:
            runs.append(current_run)

        return runs

    def _calculate_trading_behavior_metrics(self) -> Dict[str, Any]:
        """计算交易行为指标"""
        trades = self.trades_df

        if trades.empty:
            return {}

        # 交易频率分析
        if len(trades) > 1:
            time_between_trades = trades.index.to_series().diff().dt.total_seconds() / 3600  # 小时
            avg_time_between_trades = time_between_trades.mean()
            min_time_between_trades = time_between_trades.min()
            max_time_between_trades = time_between_trades.max()
        else:
            avg_time_between_trades = min_time_between_trades = max_time_between_trades = 0

        # 交易规模分析
        if 'size' in trades.columns:
            avg_trade_size = trades['size'].abs().mean()
            trade_size_std = trades['size'].abs().std()
            max_trade_size = trades['size'].abs().max()
            min_trade_size = trades['size'].abs().min()
        else:
            avg_trade_size = trade_size_std = max_trade_size = min_trade_size = 0

        # 交易类型分析
        if 'type' in trades.columns:
            buy_trades = len(trades[trades['type'] == 'BUY'])
            sell_trades = len(trades[trades['type'] == 'SELL'])
            buy_sell_ratio = buy_trades / sell_trades if sell_trades > 0 else float('inf')
        else:
            buy_trades = sell_trades = 0
            buy_sell_ratio = 0

        return {
            'avg_time_between_trades_hours': avg_time_between_trades,
            'min_time_between_trades_hours': min_time_between_trades,
            'max_time_between_trades_hours': max_time_between_trades,
            'avg_trade_size': avg_trade_size,
            'trade_size_std': trade_size_std,
            'max_trade_size': max_trade_size,
            'min_trade_size': min_trade_size,
            'buy_trades': buy_trades,
            'sell_trades': sell_trades,
            'buy_sell_ratio': buy_sell_ratio
        }

    def _calculate_time_analysis_metrics(self) -> Dict[str, Any]:
        """计算时间分析指标"""
        trades = self.trades_df

        if trades.empty:
            return {}

        # 按小时分析
        trades['hour'] = trades.index.hour
        hourly_pnl = trades.groupby('hour')['pnl'].agg(['count', 'sum', 'mean'])
        best_hour = hourly_pnl['sum'].idxmax() if not hourly_pnl.empty else 0
        worst_hour = hourly_pnl['sum'].idxmin() if not hourly_pnl.empty else 0

        # 按星期分析
        trades['weekday'] = trades.index.weekday
        weekly_pnl = trades.groupby('weekday')['pnl'].agg(['count', 'sum', 'mean'])
        best_weekday = weekly_pnl['sum'].idxmax() if not weekly_pnl.empty else 0
        worst_weekday = weekly_pnl['sum'].idxmin() if not weekly_pnl.empty else 0

        return {
            'best_trading_hour': int(best_hour),
            'worst_trading_hour': int(worst_hour),
            'best_trading_weekday': int(best_weekday),
            'worst_trading_weekday': int(worst_weekday),
            'hourly_trade_distribution': hourly_pnl.to_dict() if not hourly_pnl.empty else {},
            'weekly_trade_distribution': weekly_pnl.to_dict() if not weekly_pnl.empty else {}
        }

    def _calculate_portfolio_metrics(self) -> Dict[str, Any]:
        """计算组合表现指标"""
        portfolio = self.portfolio_df

        if portfolio.empty or 'total_value' not in portfolio.columns:
            return {}

        # 收益率计算
        returns = portfolio['total_value'].pct_change().dropna()

        if len(returns) == 0:
            return {}

        # 基础统计
        total_return = (portfolio['total_value'].iloc[-1] / portfolio['total_value'].iloc[0] - 1) * 100
        annualized_return = ((portfolio['total_value'].iloc[-1] / portfolio['total_value'].iloc[0]) ** (252 / len(portfolio)) - 1) * 100

        # 波动率
        volatility = returns.std() * np.sqrt(252) * 100  # 年化波动率

        # 最大回撤
        running_max = portfolio['total_value'].expanding().max()
        drawdown = (portfolio['total_value'] - running_max) / running_max
        max_drawdown = abs(drawdown.min()) * 100

        # 夏普比率 (假设无风险利率为0)
        sharpe_ratio = (returns.mean() * 252) / (returns.std() * np.sqrt(252)) if returns.std() > 0 else 0

        # 信息比率
        benchmark_return = 0  # 假设基准收益为0
        excess_returns = returns - benchmark_return / 252
        information_ratio = excess_returns.mean() / excess_returns.std() if excess_returns.std() > 0 else 0

        return {
            'total_return_pct': total_return,
            'annualized_return_pct': annualized_return,
            'volatility_pct': volatility,
            'portfolio_sharpe_ratio': sharpe_ratio,
            'information_ratio': information_ratio,
            'portfolio_max_drawdown_pct': max_drawdown,
            'calmar_ratio': annualized_return / max_drawdown if max_drawdown > 0 else 0
        }

    def _calculate_signal_quality_metrics(self) -> Dict[str, Any]:
        """计算信号质量指标"""
        signals = self.signals_df

        if signals.empty:
            return {}

        # 信号分布
        signal_counts = signals['signal_type'].value_counts()
        total_signals = len(signals)

        # 信心度分析
        if 'confidence' in signals.columns:
            avg_confidence = signals['confidence'].mean()
            confidence_std = signals['confidence'].std()
            high_confidence_signals = len(signals[signals['confidence'] >= 0.7])
            high_confidence_ratio = high_confidence_signals / total_signals * 100
        else:
            avg_confidence = confidence_std = high_confidence_signals = high_confidence_ratio = 0

        return {
            'total_signals': total_signals,
            'signal_distribution': signal_counts.to_dict(),
            'avg_signal_confidence': avg_confidence,
            'signal_confidence_std': confidence_std,
            'high_confidence_signals': high_confidence_signals,
            'high_confidence_ratio_pct': high_confidence_ratio
        }

    def generate_advanced_charts(self) -> Dict[str, str]:
        """生成高级图表"""
        charts = {}

        # 1. 交易表现热力图
        if not self.trades_df.empty:
            charts['performance_heatmap'] = self._create_performance_heatmap()

        # 2. 风险收益散点图
        if not self.trades_df.empty:
            charts['risk_return_scatter'] = self._create_risk_return_scatter()

        # 3. 回撤分析图
        if not self.portfolio_df.empty:
            charts['drawdown_analysis'] = self._create_drawdown_analysis()

        # 4. 交易分布箱线图
        if not self.trades_df.empty:
            charts['trade_distribution'] = self._create_trade_distribution_boxplot()

        # 5. 信号质量分析
        if not self.signals_df.empty:
            charts['signal_quality'] = self._create_signal_quality_chart()

        # 6. 时间序列分解
        if not self.portfolio_df.empty:
            charts['time_series_decomposition'] = self._create_time_series_decomposition()

        return charts

    def _create_performance_heatmap(self) -> str:
        """创建交易表现热力图"""
        trades = self.trades_df.copy()

        if trades.empty:
            return ""

        # 按小时和星期分组
        trades['hour'] = trades.index.hour
        trades['weekday'] = trades.index.weekday

        # 创建透视表
        heatmap_data = trades.pivot_table(
            values='pnl',
            index='weekday',
            columns='hour',
            aggfunc='sum',
            fill_value=0
        )

        # 星期标签
        weekday_labels = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

        fig = go.Figure(data=go.Heatmap(
            z=heatmap_data.values,
            x=[f"{h:02d}:00" for h in heatmap_data.columns],
            y=[weekday_labels[i] for i in heatmap_data.index],
            colorscale='RdYlGn',
            colorbar=dict(title="盈亏"),
            hoverongaps=False
        ))

        fig.update_layout(
            title='交易表现热力图 (按时间分布)',
            xaxis_title='小时',
            yaxis_title='星期',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_risk_return_scatter(self) -> str:
        """创建风险收益散点图"""
        trades = self.trades_df.copy()

        if trades.empty or 'size' not in trades.columns:
            return ""

        # 计算每笔交易的风险收益比
        trades['return_pct'] = trades['pnl'] / (trades['size'].abs() * trades['price']) * 100
        trades['risk_level'] = trades['size'].abs()

        # 根据盈亏着色
        colors = ['red' if pnl < 0 else 'green' for pnl in trades['pnl']]

        fig = go.Figure(data=go.Scatter(
            x=trades['risk_level'],
            y=trades['return_pct'],
            mode='markers',
            marker=dict(
                color=colors,
                size=trades['pnl'].abs() / trades['pnl'].abs().max() * 20 + 5,
                opacity=0.7,
                line=dict(width=1, color='black')
            ),
            text=[f"盈亏: {pnl:.2f}<br>时间: {ts}" for pnl, ts in zip(trades['pnl'], trades.index)],
            hovertemplate='<b>风险水平</b>: %{x:.4f}<br>' +
                         '<b>收益率</b>: %{y:.2f}%<br>' +
                         '%{text}<extra></extra>'
        ))

        fig.update_layout(
            title='风险收益散点图',
            xaxis_title='风险水平 (交易规模)',
            yaxis_title='收益率 (%)',
            height=500
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_drawdown_analysis(self) -> str:
        """创建回撤分析图"""
        portfolio = self.portfolio_df.copy()

        if portfolio.empty or 'total_value' not in portfolio.columns:
            return ""

        # 计算回撤
        running_max = portfolio['total_value'].expanding().max()
        drawdown = (portfolio['total_value'] - running_max) / running_max * 100

        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=('组合价值', '回撤'),
            vertical_spacing=0.1
        )

        # 组合价值
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=portfolio['total_value'],
                mode='lines',
                name='组合价值',
                line=dict(color='blue')
            ),
            row=1, col=1
        )

        # 最高点标记
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=running_max,
                mode='lines',
                name='历史最高',
                line=dict(color='green', dash='dash')
            ),
            row=1, col=1
        )

        # 回撤
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=drawdown,
                mode='lines',
                name='回撤',
                fill='tonexty',
                fillcolor='rgba(255,0,0,0.3)',
                line=dict(color='red')
            ),
            row=2, col=1
        )

        fig.update_layout(
            title='回撤分析',
            height=600,
            showlegend=True
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_trade_distribution_boxplot(self) -> str:
        """创建交易分布箱线图"""
        trades = self.trades_df.copy()

        if trades.empty:
            return ""

        # 按交易类型分组
        if 'type' in trades.columns:
            fig = go.Figure()

            for trade_type in trades['type'].unique():
                type_trades = trades[trades['type'] == trade_type]

                fig.add_trace(go.Box(
                    y=type_trades['pnl'],
                    name=f'{trade_type} 交易',
                    boxpoints='outliers',
                    jitter=0.3,
                    pointpos=-1.8
                ))
        else:
            fig = go.Figure(data=go.Box(
                y=trades['pnl'],
                name='所有交易',
                boxpoints='outliers'
            ))

        fig.update_layout(
            title='交易盈亏分布箱线图',
            yaxis_title='盈亏',
            height=400
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_signal_quality_chart(self) -> str:
        """创建信号质量分析图"""
        signals = self.signals_df.copy()

        if signals.empty:
            return ""

        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('信号类型分布', '信心度分布', '信号时间分布', '信心度vs时间'),
            specs=[[{"type": "pie"}, {"type": "histogram"}],
                   [{"type": "bar"}, {"type": "scatter"}]]
        )

        # 1. 信号类型分布饼图
        signal_counts = signals['signal_type'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=signal_counts.index,
                values=signal_counts.values,
                name="信号分布"
            ),
            row=1, col=1
        )

        # 2. 信心度分布直方图
        if 'confidence' in signals.columns:
            fig.add_trace(
                go.Histogram(
                    x=signals['confidence'],
                    nbinsx=20,
                    name="信心度分布"
                ),
                row=1, col=2
            )

        # 3. 按小时的信号分布
        signals['hour'] = signals.index.hour
        hourly_signals = signals.groupby('hour').size()
        fig.add_trace(
            go.Bar(
                x=hourly_signals.index,
                y=hourly_signals.values,
                name="小时分布"
            ),
            row=2, col=1
        )

        # 4. 信心度随时间变化
        if 'confidence' in signals.columns:
            fig.add_trace(
                go.Scatter(
                    x=signals.index,
                    y=signals['confidence'],
                    mode='markers',
                    name="信心度时序"
                ),
                row=2, col=2
            )

        fig.update_layout(
            title='信号质量分析',
            height=800,
            showlegend=False
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')

    def _create_time_series_decomposition(self) -> str:
        """创建时间序列分解图"""
        portfolio = self.portfolio_df.copy()

        if portfolio.empty or 'total_value' not in portfolio.columns or len(portfolio) < 10:
            return ""

        # 简单的移动平均分解
        portfolio['ma_short'] = portfolio['total_value'].rolling(window=5).mean()
        portfolio['ma_long'] = portfolio['total_value'].rolling(window=20).mean()
        portfolio['trend'] = portfolio['ma_long']
        portfolio['residual'] = portfolio['total_value'] - portfolio['trend']

        fig = make_subplots(
            rows=3, cols=1,
            subplot_titles=('原始序列', '趋势', '残差'),
            vertical_spacing=0.08
        )

        # 原始序列
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=portfolio['total_value'],
                mode='lines',
                name='原始值',
                line=dict(color='blue')
            ),
            row=1, col=1
        )

        # 趋势
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=portfolio['trend'],
                mode='lines',
                name='趋势',
                line=dict(color='red')
            ),
            row=2, col=1
        )

        # 残差
        fig.add_trace(
            go.Scatter(
                x=portfolio.index,
                y=portfolio['residual'],
                mode='lines',
                name='残差',
                line=dict(color='green')
            ),
            row=3, col=1
        )

        fig.update_layout(
            title='时间序列分解',
            height=800,
            showlegend=False
        )

        return fig.to_html(full_html=False, include_plotlyjs='cdn')
