#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
增强版HTML报告生成器

该模块生成世界级的量化交易HTML报告，包括：
- 现代化的响应式设计
- 交互式图表和仪表板
- 详细的性能分析
- 专业的视觉效果

作者: 高级Python工程师
日期: 2024-05-23
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
import pandas as pd
import numpy as np

from user_data.strategies.utils.logging_utils import get_logger

logger = get_logger("enhanced_html_reporter")

class EnhancedHTMLReporter:
    """
    增强版HTML报告生成器

    生成世界级的量化交易HTML报告
    """

    def __init__(self, output_dir: str = "user_data/backtest_results"):
        """
        初始化HTML报告生成器

        参数:
            output_dir: 报告输出目录
        """
        self.output_dir = output_dir
        self.ensure_output_dir()

    def ensure_output_dir(self):
        """确保输出目录存在"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def generate_enhanced_report(self,
                                metrics: Dict[str, Any],
                                trades_data: List[Dict] = None,
                                portfolio_data: List[Dict] = None,
                                signals_data: List[Dict] = None,
                                price_data: List[Dict] = None,
                                advanced_charts: Dict[str, str] = None) -> str:
        """
        生成增强版HTML报告

        参数:
            metrics: 计算得到的指标
            trades_data: 交易数据
            portfolio_data: 组合数据
            signals_data: 信号数据
            price_data: 价格数据
            advanced_charts: 高级图表HTML

        返回:
            HTML文件路径
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"enhanced_backtest_report_{timestamp}.html"
        filepath = os.path.join(self.output_dir, filename)

        # 生成HTML内容
        html_content = self._generate_enhanced_html_content(
            metrics, trades_data, portfolio_data, signals_data,
            price_data, advanced_charts, timestamp
        )

        # 保存HTML文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"增强版HTML报告已生成: {filepath}")
        return filepath

    def _generate_enhanced_html_content(self,
                                      metrics: Dict[str, Any],
                                      trades_data: List[Dict],
                                      portfolio_data: List[Dict],
                                      signals_data: List[Dict],
                                      price_data: List[Dict],
                                      advanced_charts: Dict[str, str],
                                      timestamp: str) -> str:
        """生成增强版HTML内容"""

        # 生成各个部分
        css_styles = self._generate_enhanced_css()
        header_section = self._generate_header_section(timestamp)
        dashboard_section = self._generate_dashboard_section(metrics)
        charts_section = self._generate_charts_section(advanced_charts)
        detailed_analysis_section = self._generate_detailed_analysis_section(metrics)
        trades_section = self._generate_enhanced_trades_section(trades_data)
        footer_section = self._generate_footer_section()
        javascript_section = self._generate_javascript_section()

        return f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 专业量化交易回测报告 - {timestamp}</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    {css_styles}
</head>
<body>
    <div class="main-container">
        {header_section}
        {dashboard_section}
        {charts_section}
        {detailed_analysis_section}
        {trades_section}
        {footer_section}
    </div>
    {javascript_section}
</body>
</html>
        """

    def _generate_enhanced_css(self) -> str:
        """生成增强版CSS样式"""
        return """
<style>
    :root {
        --primary-color: #2563eb;
        --secondary-color: #1e40af;
        --success-color: #10b981;
        --danger-color: #ef4444;
        --warning-color: #f59e0b;
        --info-color: #06b6d4;
        --dark-color: #1f2937;
        --light-color: #f8fafc;
        --border-color: #e5e7eb;
        --text-primary: #111827;
        --text-secondary: #6b7280;
        --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        color: var(--text-primary);
        line-height: 1.6;
    }

    .main-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
    }

    /* 头部样式 */
    .header {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 40px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: var(--shadow-xl);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .header h1 {
        font-size: 3rem;
        font-weight: 700;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 10px;
    }

    .header .subtitle {
        font-size: 1.2rem;
        color: var(--text-secondary);
        margin-bottom: 20px;
    }

    .header .timestamp {
        display: inline-block;
        background: var(--primary-color);
        color: white;
        padding: 8px 16px;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: 500;
    }

    /* 仪表板样式 */
    .dashboard {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .metric-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 24px;
        box-shadow: var(--shadow-lg);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .metric-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    }

    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-xl);
    }

    .metric-header {
        display: flex;
        align-items: center;
        margin-bottom: 16px;
    }

    .metric-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 16px;
        font-size: 1.5rem;
        color: white;
    }

    .metric-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: var(--text-primary);
        margin-bottom: 4px;
    }

    .metric-label {
        font-size: 0.9rem;
        color: var(--text-secondary);
        font-weight: 500;
    }

    .metric-change {
        font-size: 0.8rem;
        font-weight: 600;
        margin-top: 8px;
    }

    .positive { color: var(--success-color); }
    .negative { color: var(--danger-color); }
    .neutral { color: var(--text-secondary); }

    /* 图表容器样式 */
    .charts-section {
        margin-bottom: 30px;
    }

    .chart-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-lg);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .chart-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 20px;
        display: flex;
        align-items: center;
    }

    .chart-title i {
        margin-right: 12px;
        color: var(--primary-color);
    }
</style>
        """

    def _generate_header_section(self, timestamp: str) -> str:
        """生成头部区域"""
        return f"""
        <div class="header fade-in-up">
            <h1>🚀 专业量化交易回测报告</h1>
            <div class="subtitle">基于人工智能的期货交易策略分析</div>
            <div class="timestamp">📅 生成时间: {timestamp}</div>
        </div>
        """

    def _generate_dashboard_section(self, metrics: Dict[str, Any]) -> str:
        """生成仪表板区域"""
        # 计算策略评级
        strategy_grade = self._calculate_strategy_grade(metrics)
        grade_color = self._get_grade_color(strategy_grade)

        return f"""
        <div class="dashboard fade-in-up">
            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: var(--primary-color);">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
                <div class="metric-value">{metrics.get('total_trades', 0)}</div>
                <div class="metric-label">总交易次数</div>
                <div class="metric-change neutral">
                    <i class="fas fa-info-circle"></i> 交易频率分析
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: var(--success-color);">
                        <i class="fas fa-percentage"></i>
                    </div>
                </div>
                <div class="metric-value">{metrics.get('win_rate', 0):.1f}%</div>
                <div class="metric-label">胜率</div>
                <div class="metric-change {'positive' if metrics.get('win_rate', 0) >= 50 else 'negative'}">
                    <i class="fas fa-{'arrow-up' if metrics.get('win_rate', 0) >= 50 else 'arrow-down'}"></i>
                    {'优秀' if metrics.get('win_rate', 0) >= 60 else '良好' if metrics.get('win_rate', 0) >= 50 else '需改进'}
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: var(--warning-color);">
                        <i class="fas fa-balance-scale"></i>
                    </div>
                </div>
                <div class="metric-value">{metrics.get('profit_factor', 0):.2f}</div>
                <div class="metric-label">盈亏比</div>
                <div class="metric-change {'positive' if metrics.get('profit_factor', 0) >= 1.5 else 'negative'}">
                    <i class="fas fa-{'thumbs-up' if metrics.get('profit_factor', 0) >= 1.5 else 'thumbs-down'}"></i>
                    {'优秀' if metrics.get('profit_factor', 0) >= 2.0 else '良好' if metrics.get('profit_factor', 0) >= 1.5 else '需改进'}
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: var(--{'success' if metrics.get('total_pnl', 0) >= 0 else 'danger'}-color);">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                </div>
                <div class="metric-value">{metrics.get('total_pnl', 0):.2f}</div>
                <div class="metric-label">总盈亏</div>
                <div class="metric-change {'positive' if metrics.get('total_pnl', 0) >= 0 else 'negative'}">
                    <i class="fas fa-{'arrow-up' if metrics.get('total_pnl', 0) >= 0 else 'arrow-down'}"></i>
                    {'盈利' if metrics.get('total_pnl', 0) >= 0 else '亏损'}
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: var(--danger-color);">
                        <i class="fas fa-chart-area"></i>
                    </div>
                </div>
                <div class="metric-value">{metrics.get('max_drawdown_pct', 0):.1f}%</div>
                <div class="metric-label">最大回撤</div>
                <div class="metric-change {'positive' if metrics.get('max_drawdown_pct', 0) <= 10 else 'negative'}">
                    <i class="fas fa-shield-alt"></i>
                    {'低风险' if metrics.get('max_drawdown_pct', 0) <= 5 else '中风险' if metrics.get('max_drawdown_pct', 0) <= 15 else '高风险'}
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-icon" style="background: {grade_color};">
                        <i class="fas fa-star"></i>
                    </div>
                </div>
                <div class="metric-value">{strategy_grade}</div>
                <div class="metric-label">策略评级</div>
                <div class="metric-change neutral">
                    <i class="fas fa-award"></i> 综合评估
                </div>
            </div>
        </div>
        """

    def _generate_charts_section(self, advanced_charts: Dict[str, str]) -> str:
        """生成图表区域"""
        if not advanced_charts:
            return ""

        charts_html = ""
        chart_titles = {
            'performance_heatmap': ('📊 交易表现热力图', 'fas fa-th'),
            'risk_return_scatter': ('💹 风险收益散点图', 'fas fa-chart-scatter'),
            'drawdown_analysis': ('📉 回撤分析图', 'fas fa-chart-area'),
            'trade_distribution': ('📈 交易分布箱线图', 'fas fa-chart-bar'),
            'signal_quality': ('🎯 信号质量分析', 'fas fa-bullseye'),
            'time_series_decomposition': ('🔄 时间序列分解', 'fas fa-wave-square')
        }

        for chart_key, chart_html in advanced_charts.items():
            title, icon = chart_titles.get(chart_key, (chart_key, 'fas fa-chart-line'))
            charts_html += f"""
            <div class="chart-container fade-in-up">
                <div class="chart-title">
                    <i class="{icon}"></i>
                    {title}
                </div>
                {chart_html}
            </div>
            """

        return f"""
        <div class="charts-section">
            {charts_html}
        </div>
        """

    def _generate_detailed_analysis_section(self, metrics: Dict[str, Any]) -> str:
        """生成详细分析区域"""
        return f"""
        <div class="analysis-grid fade-in-up">
            <div class="analysis-card">
                <div class="analysis-title">
                    <i class="fas fa-chart-pie"></i>
                    基础统计分析
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">盈利交易数</span>
                    <span class="analysis-value positive">{metrics.get('winning_trades', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">亏损交易数</span>
                    <span class="analysis-value negative">{metrics.get('losing_trades', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">平均盈利</span>
                    <span class="analysis-value positive">{metrics.get('avg_win', 0):.2f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">平均亏损</span>
                    <span class="analysis-value negative">{metrics.get('avg_loss', 0):.2f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最大单笔盈利</span>
                    <span class="analysis-value positive">{metrics.get('max_win', 0):.2f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最大单笔亏损</span>
                    <span class="analysis-value negative">{metrics.get('max_loss', 0):.2f}</span>
                </div>
            </div>

            <div class="analysis-card">
                <div class="analysis-title">
                    <i class="fas fa-shield-alt"></i>
                    风险指标分析
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">夏普比率</span>
                    <span class="analysis-value">{metrics.get('sharpe_ratio', 0):.3f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">索提诺比率</span>
                    <span class="analysis-value">{metrics.get('sortino_ratio', 0):.3f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最大连续亏损</span>
                    <span class="analysis-value negative">{metrics.get('max_consecutive_losses', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最大连续盈利</span>
                    <span class="analysis-value positive">{metrics.get('max_consecutive_wins', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">VaR (95%)</span>
                    <span class="analysis-value">{metrics.get('var_95', 0):.2f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">卡尔玛比率</span>
                    <span class="analysis-value">{metrics.get('calmar_ratio', 0):.3f}</span>
                </div>
            </div>

            <div class="analysis-card">
                <div class="analysis-title">
                    <i class="fas fa-clock"></i>
                    交易行为分析
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">平均交易间隔</span>
                    <span class="analysis-value">{metrics.get('avg_time_between_trades_hours', 0):.1f}小时</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">平均交易规模</span>
                    <span class="analysis-value">{metrics.get('avg_trade_size', 0):.6f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">买入交易数</span>
                    <span class="analysis-value positive">{metrics.get('buy_trades', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">卖出交易数</span>
                    <span class="analysis-value negative">{metrics.get('sell_trades', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最佳交易时间</span>
                    <span class="analysis-value">{metrics.get('best_trading_hour', 0):02d}:00</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">最差交易时间</span>
                    <span class="analysis-value">{metrics.get('worst_trading_hour', 0):02d}:00</span>
                </div>
            </div>

            <div class="analysis-card">
                <div class="analysis-title">
                    <i class="fas fa-bullseye"></i>
                    信号质量分析
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">总信号数</span>
                    <span class="analysis-value">{metrics.get('total_signals', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">平均信心度</span>
                    <span class="analysis-value">{metrics.get('avg_signal_confidence', 0):.3f}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">高信心度信号</span>
                    <span class="analysis-value positive">{metrics.get('high_confidence_signals', 0)}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">高信心度比例</span>
                    <span class="analysis-value">{metrics.get('high_confidence_ratio_pct', 0):.1f}%</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">信号质量评级</span>
                    <span class="analysis-value">{self._evaluate_signal_quality(metrics)}</span>
                </div>
            </div>
        </div>
        """

    def _generate_enhanced_trades_section(self, trades_data: List[Dict]) -> str:
        """生成增强版交易记录区域"""
        if not trades_data:
            return ""

        # 只显示最近的50笔交易
        recent_trades = trades_data[-50:] if len(trades_data) > 50 else trades_data

        trades_rows = ""
        cumulative_pnl = 0

        for i, trade in enumerate(recent_trades, 1):
            timestamp = str(trade.get('timestamp', 'N/A'))[:19]
            trade_type = trade.get('type', 'N/A')
            price = trade.get('price', 0)
            size = trade.get('size', 0)
            pnl = trade.get('pnl', 0)
            commission = trade.get('commission', 0)

            cumulative_pnl += pnl

            # 样式类
            pnl_class = "trade-profit" if pnl > 0 else "trade-loss" if pnl < 0 else ""
            type_class = "trade-type-buy" if trade_type == "BUY" else "trade-type-sell"
            cumulative_class = "positive" if cumulative_pnl > 0 else "negative"

            trades_rows += f"""
            <tr>
                <td>{len(trades_data) - len(recent_trades) + i}</td>
                <td>{timestamp}</td>
                <td><span class="{type_class}">{trade_type}</span></td>
                <td>{price:.2f}</td>
                <td>{size:.6f}</td>
                <td class="{pnl_class}">{pnl:.2f}</td>
                <td>{commission:.2f}</td>
                <td class="{cumulative_class}">{cumulative_pnl:.2f}</td>
            </tr>
            """

        return f"""
        <div class="trades-section fade-in-up">
            <div class="chart-title">
                <i class="fas fa-list"></i>
                详细交易记录 (最近{len(recent_trades)}笔)
            </div>
            <div style="overflow-x: auto;">
                <table class="trades-table">
                    <thead>
                        <tr>
                            <th>序号</th>
                            <th>时间</th>
                            <th>类型</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>盈亏</th>
                            <th>手续费</th>
                            <th>累计盈亏</th>
                        </tr>
                    </thead>
                    <tbody>
                        {trades_rows}
                    </tbody>
                </table>
            </div>
        </div>
        """

    def _generate_footer_section(self) -> str:
        """生成页脚区域"""
        return """
        <div class="footer fade-in-up">
            <p>🚀 <strong>专业量化交易回测报告</strong> | 基于人工智能的期货交易策略分析</p>
            <p>📊 报告包含详细的统计分析、风险评估和交易行为分析</p>
            <p>💡 建议结合多个时间周期和市场环境进行综合评估</p>
            <p style="margin-top: 16px; font-size: 0.9rem; opacity: 0.7;">
                生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |
                版权所有 © 2024 量化交易系统
            </p>
        </div>
        """

    def _generate_javascript_section(self) -> str:
        """生成JavaScript区域"""
        return """
        <script>
            // 页面加载动画
            document.addEventListener('DOMContentLoaded', function() {
                // 添加淡入动画
                const elements = document.querySelectorAll('.fade-in-up');
                elements.forEach((el, index) => {
                    el.style.animationDelay = `${index * 0.1}s`;
                });

                // 添加悬停效果
                const cards = document.querySelectorAll('.metric-card, .analysis-card, .chart-container');
                cards.forEach(card => {
                    card.addEventListener('mouseenter', function() {
                        this.style.transform = 'translateY(-5px)';
                    });

                    card.addEventListener('mouseleave', function() {
                        this.style.transform = 'translateY(0)';
                    });
                });

                // 表格行悬停效果
                const tableRows = document.querySelectorAll('.trades-table tbody tr');
                tableRows.forEach(row => {
                    row.addEventListener('mouseenter', function() {
                        this.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
                    });

                    row.addEventListener('mouseleave', function() {
                        this.style.backgroundColor = '';
                    });
                });

                // 平滑滚动
                document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                    anchor.addEventListener('click', function (e) {
                        e.preventDefault();
                        const target = document.querySelector(this.getAttribute('href'));
                        if (target) {
                            target.scrollIntoView({
                                behavior: 'smooth',
                                block: 'start'
                            });
                        }
                    });
                });

                console.log('🚀 专业量化交易回测报告已加载完成！');
            });

            // 工具提示功能
            function showTooltip(element, text) {
                const tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.textContent = text;
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 0.8rem;
                    z-index: 1000;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;

                document.body.appendChild(tooltip);

                const rect = element.getBoundingClientRect();
                tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
                tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';

                setTimeout(() => tooltip.style.opacity = '1', 10);

                element.addEventListener('mouseleave', function() {
                    tooltip.style.opacity = '0';
                    setTimeout(() => document.body.removeChild(tooltip), 300);
                }, { once: true });
            }
        </script>
        """

    # 辅助方法
    def _calculate_strategy_grade(self, metrics: Dict[str, Any]) -> str:
        """计算策略评级"""
        score = 0

        # 胜率评分 (30%)
        win_rate = metrics.get('win_rate', 0)
        if win_rate >= 60:
            score += 30
        elif win_rate >= 50:
            score += 25
        elif win_rate >= 40:
            score += 20
        elif win_rate >= 30:
            score += 15
        else:
            score += 10

        # 盈亏比评分 (25%)
        profit_factor = metrics.get('profit_factor', 0)
        if profit_factor >= 2.0:
            score += 25
        elif profit_factor >= 1.5:
            score += 20
        elif profit_factor >= 1.2:
            score += 15
        elif profit_factor >= 1.0:
            score += 10
        else:
            score += 5

        # 夏普比率评分 (25%)
        sharpe = metrics.get('sharpe_ratio', 0)
        if sharpe >= 1.5:
            score += 25
        elif sharpe >= 1.0:
            score += 20
        elif sharpe >= 0.5:
            score += 15
        elif sharpe >= 0:
            score += 10
        else:
            score += 5

        # 最大回撤评分 (20%)
        max_dd = metrics.get('max_drawdown_pct', 100)
        if max_dd <= 5:
            score += 20
        elif max_dd <= 10:
            score += 15
        elif max_dd <= 20:
            score += 10
        elif max_dd <= 30:
            score += 5
        else:
            score += 0

        # 评级映射
        if score >= 85:
            return "A+"
        elif score >= 75:
            return "A"
        elif score >= 65:
            return "B+"
        elif score >= 55:
            return "B"
        elif score >= 45:
            return "C+"
        elif score >= 35:
            return "C"
        else:
            return "D"

    def _get_grade_color(self, grade: str) -> str:
        """获取评级对应的颜色"""
        grade_colors = {
            'A+': 'var(--success-color)',
            'A': 'var(--success-color)',
            'B+': 'var(--info-color)',
            'B': 'var(--info-color)',
            'C+': 'var(--warning-color)',
            'C': 'var(--warning-color)',
            'D': 'var(--danger-color)'
        }
        return grade_colors.get(grade, 'var(--text-secondary)')

    def _evaluate_signal_quality(self, metrics: Dict[str, Any]) -> str:
        """评估信号质量"""
        avg_confidence = metrics.get('avg_signal_confidence', 0)
        high_confidence_ratio = metrics.get('high_confidence_ratio_pct', 0)

        if avg_confidence >= 0.7 and high_confidence_ratio >= 30:
            return "优秀"
        elif avg_confidence >= 0.5 and high_confidence_ratio >= 20:
            return "良好"
        elif avg_confidence >= 0.3:
            return "一般"
        else:
            return "较差"