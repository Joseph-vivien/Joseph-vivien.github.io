#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
配置管理模块

该模块负责加载、验证和管理系统配置，支持从JSON文件、环境变量和命令行参数获取配置。

作者: 高级Python工程师
日期: 2024-05-21
"""

import os
import json
import argparse
from typing import Dict, Any, Optional, Union, List
from pathlib import Path

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("config_manager")

class ConfigManager:
    """
    配置管理类
    
    负责加载、验证和管理系统配置，支持多种配置源和配置合并
    """
    
    def __init__(self, config_path: str = "user_data/config/config.json"):
        """
        初始化配置管理器
        
        参数:
            config_path: 配置文件路径
        """
        self.config_path = config_path
        self.config = {}
        self.env_prefix = "BINANCE_"
        
    def load_config(self, config_path: Optional[str] = None, 
                   merge_env: bool = True, 
                   merge_args: bool = True) -> Dict[str, Any]:
        """
        加载配置
        
        参数:
            config_path: 配置文件路径，如果为None则使用初始化时的路径
            merge_env: 是否合并环境变量
            merge_args: 是否合并命令行参数
            
        返回:
            配置字典
        """
        if config_path is None:
            config_path = self.config_path
            
        # 确保配置目录存在
        config_dir = os.path.dirname(config_path)
        if not os.path.exists(config_dir):
            os.makedirs(config_dir, exist_ok=True)
            
        # 加载配置文件
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info(f"已加载配置文件: {config_path}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
                # 如果配置文件加载失败，使用默认配置
                self.config = self._get_default_config()
        else:
            logger.warning(f"配置文件不存在: {config_path}，将使用默认配置")
            self.config = self._get_default_config()
            # 保存默认配置到文件
            self.save_config()
            
        # 合并环境变量
        if merge_env:
            self._merge_env_vars()
            
        # 合并命令行参数
        if merge_args:
            self._merge_cmd_args()
            
        # 验证配置
        self._validate_config()
            
        return self.config
    
    def save_config(self, config_path: Optional[str] = None) -> bool:
        """
        保存配置到文件
        
        参数:
            config_path: 配置文件路径，如果为None则使用当前路径
            
        返回:
            是否保存成功
        """
        if config_path is None:
            config_path = self.config_path
            
        try:
            # 确保配置目录存在
            config_dir = os.path.dirname(config_path)
            if not os.path.exists(config_dir):
                os.makedirs(config_dir, exist_ok=True)
                
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info(f"配置已保存到: {config_path}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置项
        
        参数:
            key: 配置键，支持点号分隔的嵌套键
            default: 默认值，当键不存在时返回
            
        返回:
            配置值或默认值
        """
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
                
        return value
    
    def set(self, key: str, value: Any) -> None:
        """
        设置配置项
        
        参数:
            key: 配置键，支持点号分隔的嵌套键
            value: 配置值
        """
        keys = key.split('.')
        config = self.config
        
        # 遍历除最后一个键外的所有键
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
            
        # 设置最后一个键的值
        config[keys[-1]] = value
        
    def _get_default_config(self) -> Dict[str, Any]:
        """
        获取默认配置
        
        返回:
            默认配置字典
        """
        return {
            "exchange": {
                "name": "binance",
                "key": "",
                "secret": "",
                "ccxt_config": {
                    "enableRateLimit": True
                },
                "ccxt_async_config": {
                    "enableRateLimit": True
                }
            },
            "trading_mode": "futures",
            "margin_mode": "cross",
            "leverage": 25,  # 默认固定杠杆25倍
            "unfilledtimeout": {
                "entry": 10,
                "exit": 10
            },
            "order_types": {
                "entry": "limit",
                "exit": "limit",
                "emergency_exit": "market",
                "stoploss": "market",
                "stoploss_on_exchange": False
            },
            "bid_strategy": {
                "price_side": "ask",
                "ask_last_balance": 0.0,
                "use_order_book": False,
                "order_book_top": 1
            },
            "ask_strategy": {
                "price_side": "bid",
                "bid_last_balance": 0.0,
                "use_order_book": False,
                "order_book_top": 1
            },
            "exchange_endpoints": {
                "api": "api.binance.com",
                "websocket": "stream.binance.com"
            },
            "pair_whitelist": [
                "BTC/USDT",
                "ETH/USDT",
                "BNB/USDT",
                "SOL/USDT",
                "ADA/USDT"
            ],
            "pair_blacklist": [],
            "max_open_trades": 5,
            "stake_currency": "USDT",
            "stake_amount": 100,
            "tradable_balance_ratio": 0.99,
            "dry_run": True,
            "timeframe": "5m",
            "strategy": "MasterStrategy",
            "db_url": "sqlite:///user_data/data/tradesv3.sqlite",
            "initial_state": "running",
            "force_entry_enable": False,
            "internals": {
                "process_throttle_secs": 5,
                "heartbeat_interval": 60
            },
            "api_server": {
                "enabled": False,
                "listen_ip_address": "127.0.0.1",
                "listen_port": 8080,
                "verbosity": "error",
                "jwt_secret_key": "",
                "CORS_origins": [],
                "username": "",
                "password": ""
            },
            "telegram": {
                "enabled": False,
                "token": "",
                "chat_id": ""
            },
            "logging": {
                "level": "INFO",
                "console_output": True,
                "file_output": True,
                "log_dir": "user_data/logs"
            },
            "risk_management": {
                "max_account_risk_pct": 2.0,  # 单笔交易最大账户风险百分比
                "max_position_size_pct": 20.0,  # 单个仓位最大占比
                "max_total_risk_pct": 50.0,  # 总风险敞口最大占比
                "max_drawdown_pct": 15.0,  # 最大回撤百分比
                "stoploss_pct": 2.0,  # 默认止损百分比
                "trailing_stop": True,  # 是否启用追踪止损
                "trailing_stop_positive": 0.5,  # 盈利多少后启用追踪止损
                "trailing_stop_positive_offset": 0.0,  # 追踪止损偏移量
                "trailing_only_offset_is_reached": False  # 是否仅在达到偏移量后启用追踪止损
            },
            "machine_learning": {
                "enabled": True,
                "model_type": "lstm",  # lstm, gru, xgboost
                "prediction_timeframes": ["5m", "15m", "1h"],
                "training_interval_hours": 24,  # 每24小时重新训练一次
                "prediction_confidence_threshold": 0.65,  # 预测置信度阈值
                "feature_importance_threshold": 0.05  # 特征重要性阈值
            }
        }
    
    def _merge_env_vars(self) -> None:
        """
        合并环境变量到配置
        
        环境变量格式: BINANCE_SECTION_KEY=value
        例如: BINANCE_EXCHANGE_KEY=your_api_key
        """
        for env_key, env_value in os.environ.items():
            if env_key.startswith(self.env_prefix):
                # 移除前缀并转换为小写
                key = env_key[len(self.env_prefix):].lower()
                # 将下划线分隔的键转换为嵌套结构
                sections = key.split('_')
                
                # 处理特殊情况
                if len(sections) == 1:
                    self.config[sections[0]] = self._convert_value(env_value)
                else:
                    # 构建嵌套结构
                    current = self.config
                    for section in sections[:-1]:
                        if section not in current:
                            current[section] = {}
                        current = current[section]
                    current[sections[-1]] = self._convert_value(env_value)
    
    def _merge_cmd_args(self) -> None:
        """
        合并命令行参数到配置
        """
        parser = argparse.ArgumentParser(description='币安智能杠杆交易系统')
        
        # 添加常用命令行参数
        parser.add_argument('--config', type=str, help='配置文件路径')
        parser.add_argument('--strategy', type=str, help='交易策略名称')
        parser.add_argument('--timeframe', type=str, help='交易时间周期')
        parser.add_argument('--dry-run', action='store_true', help='启用模拟交易模式')
        parser.add_argument('--live', action='store_true', help='启用实盘交易模式')
        parser.add_argument('--leverage', type=int, help='固定杠杆倍数')
        parser.add_argument('--log-level', type=str, help='日志级别')
        
        # 解析命令行参数
        args, _ = parser.parse_known_args()
        
        # 合并参数到配置
        if args.strategy:
            self.config['strategy'] = args.strategy
            
        if args.timeframe:
            self.config['timeframe'] = args.timeframe
            
        if args.dry_run:
            self.config['dry_run'] = True
            
        if args.live:
            self.config['dry_run'] = False
            
        if args.leverage:
            self.config['leverage'] = args.leverage
            
        if args.log_level:
            if 'logging' not in self.config:
                self.config['logging'] = {}
            self.config['logging']['level'] = args.log_level.upper()
    
    def _validate_config(self) -> None:
        """
        验证配置有效性
        """
        # 检查必要的配置项
        required_keys = [
            'exchange.name',
            'trading_mode',
            'margin_mode',
            'leverage',
            'timeframe',
            'strategy'
        ]
        
        for key in required_keys:
            if self.get(key) is None:
                logger.warning(f"缺少必要的配置项: {key}")
                
        # 验证杠杆倍数
        leverage = self.get('leverage')
        if leverage is not None:
            if not isinstance(leverage, (int, float)) or leverage <= 0:
                logger.warning(f"无效的杠杆倍数: {leverage}，将使用默认值25")
                self.set('leverage', 25)
                
        # 验证交易模式
        trading_mode = self.get('trading_mode')
        if trading_mode not in ['futures', 'spot']:
            logger.warning(f"无效的交易模式: {trading_mode}，将使用默认值futures")
            self.set('trading_mode', 'futures')
            
        # 验证保证金模式
        margin_mode = self.get('margin_mode')
        if margin_mode not in ['cross', 'isolated']:
            logger.warning(f"无效的保证金模式: {margin_mode}，将使用默认值cross")
            self.set('margin_mode', 'cross')
    
    @staticmethod
    def _convert_value(value: str) -> Union[str, int, float, bool, List, Dict]:
        """
        转换字符串值为适当的类型
        
        参数:
            value: 字符串值
            
        返回:
            转换后的值
        """
        # 尝试转换为JSON
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            pass
            
        # 尝试转换为布尔值
        if value.lower() in ('true', 'yes', '1'):
            return True
        if value.lower() in ('false', 'no', '0'):
            return False
            
        # 尝试转换为数字
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            pass
            
        # 保持为字符串
        return value

# 创建默认配置管理器实例
config_manager = ConfigManager()

def get_config_manager() -> ConfigManager:
    """
    获取配置管理器实例
    
    返回:
        ConfigManager实例
    """
    return config_manager
