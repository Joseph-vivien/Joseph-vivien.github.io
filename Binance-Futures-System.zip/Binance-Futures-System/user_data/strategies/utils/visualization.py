#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
可视化工具模块

该模块提供绘制交易图表和性能指标的功能，支持多种图表类型和自定义样式。

作者: 高级Python工程师
日期: 2024-05-21
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter
import seaborn as sns
from typing import List, Dict, Tuple, Optional, Union, Any
from datetime import datetime, timedelta

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("visualization")

# 设置Seaborn样式
sns.set(style="darkgrid", palette="muted", font_scale=1.2)

class Visualizer:
    """
    可视化工具类
    
    提供绘制交易图表和性能指标的功能，支持多种图表类型和自定义样式
    """
    
    def __init__(self, output_dir: str = "user_data/backtest_results/plots"):
        """
        初始化可视化工具
        
        参数:
            output_dir: 图表输出目录
        """
        self.output_dir = output_dir
        
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 设置默认图表样式
        self.figsize = (14, 8)
        self.dpi = 100
        self.colors = {
            'price': '#2E86C1',
            'volume': '#AED6F1',
            'buy': '#27AE60',
            'sell': '#E74C3C',
            'profit': '#27AE60',
            'loss': '#E74C3C',
            'sma': '#F39C12',
            'ema': '#8E44AD',
            'upper_band': '#D4AC0D',
            'middle_band': '#F39C12',
            'lower_band': '#D4AC0D',
            'background': '#F5F5F5',
            'grid': '#D5D8DC',
            'text': '#2C3E50'
        }
        
    def plot_ohlcv(self, data: pd.DataFrame, title: str = "价格图表", 
                  show_volume: bool = True, show_ma: bool = True,
                  show_bb: bool = False, trades: List[Dict] = None,
                  save: bool = True, filename: str = None) -> plt.Figure:
        """
        绘制OHLCV图表
        
        参数:
            data: OHLCV数据
            title: 图表标题
            show_volume: 是否显示成交量
            show_ma: 是否显示移动平均线
            show_bb: 是否显示布林带
            trades: 交易记录列表
            save: 是否保存图表
            filename: 保存的文件名
            
        返回:
            matplotlib图表对象
        """
        if data.empty:
            logger.warning("数据为空，无法绘制图表")
            return None
            
        try:
            # 创建图表
            fig = plt.figure(figsize=self.figsize, dpi=self.dpi, facecolor=self.colors['background'])
            
            # 确定子图数量
            n_subplots = 1 + int(show_volume)
            
            # 创建价格子图
            ax1 = plt.subplot(n_subplots, 1, 1)
            
            # 绘制K线图
            ax1.plot(data['timestamp'], data['close'], color=self.colors['price'], linewidth=1.5)
            
            # 添加移动平均线
            if show_ma and 'sma20' in data.columns and 'sma50' in data.columns:
                ax1.plot(data['timestamp'], data['sma20'], color=self.colors['sma'], linewidth=1, label='SMA20')
                ax1.plot(data['timestamp'], data['sma50'], color=self.colors['ema'], linewidth=1, label='SMA50')
                
            # 添加布林带
            if show_bb and all(col in data.columns for col in ['upperband', 'middleband', 'lowerband']):
                ax1.plot(data['timestamp'], data['upperband'], color=self.colors['upper_band'], 
                        linewidth=0.8, linestyle='--', label='Upper Band')
                ax1.plot(data['timestamp'], data['middleband'], color=self.colors['middle_band'], 
                        linewidth=0.8, linestyle='--', label='Middle Band')
                ax1.plot(data['timestamp'], data['lowerband'], color=self.colors['lower_band'], 
                        linewidth=0.8, linestyle='--', label='Lower Band')
                
            # 添加交易标记
            if trades:
                buy_times = []
                buy_prices = []
                sell_times = []
                sell_prices = []
                
                for trade in trades:
                    if trade.get('side') == 'buy':
                        buy_times.append(trade.get('timestamp'))
                        buy_prices.append(trade.get('price'))
                    elif trade.get('side') == 'sell':
                        sell_times.append(trade.get('timestamp'))
                        sell_prices.append(trade.get('price'))
                        
                if buy_times:
                    ax1.scatter(buy_times, buy_prices, color=self.colors['buy'], 
                               marker='^', s=100, label='买入')
                if sell_times:
                    ax1.scatter(sell_times, sell_prices, color=self.colors['sell'], 
                               marker='v', s=100, label='卖出')
                    
            # 设置价格子图样式
            ax1.set_title(title, fontsize=16, color=self.colors['text'])
            ax1.set_ylabel('价格', fontsize=12, color=self.colors['text'])
            ax1.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            ax1.legend(loc='upper left')
            
            # 格式化x轴日期
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            ax1.xaxis.set_major_locator(mdates.AutoDateLocator())
            
            # 如果显示成交量，创建成交量子图
            if show_volume:
                ax2 = plt.subplot(n_subplots, 1, 2, sharex=ax1)
                ax2.bar(data['timestamp'], data['volume'], color=self.colors['volume'], alpha=0.7)
                ax2.set_ylabel('成交量', fontsize=12, color=self.colors['text'])
                ax2.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
                
                # 格式化y轴数值
                ax2.yaxis.set_major_formatter(FuncFormatter(lambda x, p: format(int(x), ',')))
                
            # 调整布局
            plt.tight_layout()
            plt.subplots_adjust(hspace=0.1)
            
            # 旋转x轴标签
            plt.xticks(rotation=45)
            
            # 保存图表
            if save:
                if filename is None:
                    # 生成默认文件名
                    start_date = data['timestamp'].min().strftime('%Y%m%d')
                    end_date = data['timestamp'].max().strftime('%Y%m%d')
                    filename = f"ohlcv_{start_date}_{end_date}.png"
                    
                file_path = os.path.join(self.output_dir, filename)
                plt.savefig(file_path, dpi=self.dpi, bbox_inches='tight')
                logger.info(f"已保存图表: {file_path}")
                
            return fig
            
        except Exception as e:
            logger.error(f"绘制OHLCV图表失败: {e}")
            return None
    
    def plot_equity_curve(self, equity_data: pd.DataFrame, 
                         benchmark_data: pd.DataFrame = None,
                         title: str = "权益曲线", 
                         save: bool = True, 
                         filename: str = None) -> plt.Figure:
        """
        绘制权益曲线
        
        参数:
            equity_data: 权益曲线数据
            benchmark_data: 基准数据
            title: 图表标题
            save: 是否保存图表
            filename: 保存的文件名
            
        返回:
            matplotlib图表对象
        """
        if equity_data.empty:
            logger.warning("数据为空，无法绘制权益曲线")
            return None
            
        try:
            # 创建图表
            fig, ax = plt.subplots(figsize=self.figsize, dpi=self.dpi, 
                                  facecolor=self.colors['background'])
            
            # 绘制权益曲线
            ax.plot(equity_data['timestamp'], equity_data['equity'], 
                   color=self.colors['price'], linewidth=2, label='策略')
            
            # 如果有基准数据，添加基准曲线
            if benchmark_data is not None and not benchmark_data.empty:
                ax.plot(benchmark_data['timestamp'], benchmark_data['equity'], 
                       color=self.colors['sma'], linewidth=1.5, linestyle='--', label='基准')
                
            # 设置图表样式
            ax.set_title(title, fontsize=16, color=self.colors['text'])
            ax.set_xlabel('日期', fontsize=12, color=self.colors['text'])
            ax.set_ylabel('权益', fontsize=12, color=self.colors['text'])
            ax.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            ax.legend(loc='upper left')
            
            # 格式化x轴日期
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            
            # 格式化y轴数值
            ax.yaxis.set_major_formatter(FuncFormatter(lambda x, p: format(int(x), ',')))
            
            # 添加初始值和最终值标注
            initial_equity = equity_data['equity'].iloc[0]
            final_equity = equity_data['equity'].iloc[-1]
            
            ax.annotate(f'初始: {initial_equity:.2f}', 
                       xy=(equity_data['timestamp'].iloc[0], initial_equity),
                       xytext=(10, 10), textcoords='offset points',
                       color=self.colors['text'], fontsize=10)
                       
            ax.annotate(f'最终: {final_equity:.2f}', 
                       xy=(equity_data['timestamp'].iloc[-1], final_equity),
                       xytext=(10, 10), textcoords='offset points',
                       color=self.colors['text'], fontsize=10)
                       
            # 计算并标注收益率
            returns = (final_equity - initial_equity) / initial_equity * 100
            ax.annotate(f'收益率: {returns:.2f}%', 
                       xy=(0.02, 0.95), xycoords='axes fraction',
                       color=self.colors['text'], fontsize=12)
                       
            # 调整布局
            plt.tight_layout()
            
            # 旋转x轴标签
            plt.xticks(rotation=45)
            
            # 保存图表
            if save:
                if filename is None:
                    # 生成默认文件名
                    start_date = equity_data['timestamp'].min().strftime('%Y%m%d')
                    end_date = equity_data['timestamp'].max().strftime('%Y%m%d')
                    filename = f"equity_curve_{start_date}_{end_date}.png"
                    
                file_path = os.path.join(self.output_dir, filename)
                plt.savefig(file_path, dpi=self.dpi, bbox_inches='tight')
                logger.info(f"已保存图表: {file_path}")
                
            return fig
            
        except Exception as e:
            logger.error(f"绘制权益曲线失败: {e}")
            return None
    
    def plot_drawdown(self, equity_data: pd.DataFrame, 
                     title: str = "回撤分析", 
                     save: bool = True, 
                     filename: str = None) -> plt.Figure:
        """
        绘制回撤分析图
        
        参数:
            equity_data: 权益曲线数据
            title: 图表标题
            save: 是否保存图表
            filename: 保存的文件名
            
        返回:
            matplotlib图表对象
        """
        if equity_data.empty:
            logger.warning("数据为空，无法绘制回撤分析图")
            return None
            
        try:
            # 计算回撤
            equity = equity_data['equity'].values
            timestamps = equity_data['timestamp'].values
            
            # 计算累计最大值
            running_max = np.maximum.accumulate(equity)
            
            # 计算回撤
            drawdown = (equity - running_max) / running_max * 100
            
            # 创建图表
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=self.figsize, dpi=self.dpi, 
                                          facecolor=self.colors['background'], sharex=True)
            
            # 绘制权益曲线
            ax1.plot(timestamps, equity, color=self.colors['price'], linewidth=2, label='权益')
            ax1.plot(timestamps, running_max, color=self.colors['sma'], linewidth=1.5, 
                    linestyle='--', label='历史最高点')
            
            # 设置权益曲线样式
            ax1.set_title(title, fontsize=16, color=self.colors['text'])
            ax1.set_ylabel('权益', fontsize=12, color=self.colors['text'])
            ax1.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            ax1.legend(loc='upper left')
            
            # 绘制回撤曲线
            ax2.fill_between(timestamps, 0, drawdown, color=self.colors['loss'], alpha=0.3)
            ax2.plot(timestamps, drawdown, color=self.colors['loss'], linewidth=1.5)
            
            # 设置回撤曲线样式
            ax2.set_xlabel('日期', fontsize=12, color=self.colors['text'])
            ax2.set_ylabel('回撤 (%)', fontsize=12, color=self.colors['text'])
            ax2.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            
            # 找出最大回撤
            max_dd_idx = np.argmin(drawdown)
            max_dd = drawdown[max_dd_idx]
            max_dd_time = timestamps[max_dd_idx]
            
            # 标注最大回撤
            ax2.annotate(f'最大回撤: {max_dd:.2f}%', 
                        xy=(max_dd_time, max_dd),
                        xytext=(10, -30), textcoords='offset points',
                        arrowprops=dict(arrowstyle='->', color=self.colors['text']),
                        color=self.colors['text'], fontsize=10)
                        
            # 格式化x轴日期
            ax2.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            ax2.xaxis.set_major_locator(mdates.AutoDateLocator())
            
            # 调整布局
            plt.tight_layout()
            plt.subplots_adjust(hspace=0.1)
            
            # 旋转x轴标签
            plt.xticks(rotation=45)
            
            # 保存图表
            if save:
                if filename is None:
                    # 生成默认文件名
                    start_date = equity_data['timestamp'].min().strftime('%Y%m%d')
                    end_date = equity_data['timestamp'].max().strftime('%Y%m%d')
                    filename = f"drawdown_{start_date}_{end_date}.png"
                    
                file_path = os.path.join(self.output_dir, filename)
                plt.savefig(file_path, dpi=self.dpi, bbox_inches='tight')
                logger.info(f"已保存图表: {file_path}")
                
            return fig
            
        except Exception as e:
            logger.error(f"绘制回撤分析图失败: {e}")
            return None
    
    def plot_trade_analysis(self, trades: List[Dict], 
                          title: str = "交易分析", 
                          save: bool = True, 
                          filename: str = None) -> plt.Figure:
        """
        绘制交易分析图
        
        参数:
            trades: 交易记录列表
            title: 图表标题
            save: 是否保存图表
            filename: 保存的文件名
            
        返回:
            matplotlib图表对象
        """
        if not trades:
            logger.warning("没有交易记录，无法绘制交易分析图")
            return None
            
        try:
            # 提取交易数据
            profits = [t.get('profit', 0) for t in trades]
            durations = []
            for trade in trades:
                entry_time = trade.get('entry_time')
                exit_time = trade.get('exit_time')
                if entry_time and exit_time:
                    if isinstance(entry_time, str):
                        entry_time = datetime.fromisoformat(entry_time.replace('Z', '+00:00'))
                    if isinstance(exit_time, str):
                        exit_time = datetime.fromisoformat(exit_time.replace('Z', '+00:00'))
                    duration = (exit_time - entry_time).total_seconds() / 3600  # 小时
                    durations.append(duration)
                else:
                    durations.append(0)
                    
            # 创建图表
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=self.figsize, dpi=self.dpi, 
                                                       facecolor=self.colors['background'])
            
            # 1. 盈亏分布直方图
            ax1.hist(profits, bins=20, color=self.colors['price'], alpha=0.7)
            ax1.axvline(x=0, color='black', linestyle='--', linewidth=1)
            ax1.set_title('盈亏分布', fontsize=14, color=self.colors['text'])
            ax1.set_xlabel('盈亏', fontsize=12, color=self.colors['text'])
            ax1.set_ylabel('交易次数', fontsize=12, color=self.colors['text'])
            ax1.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            
            # 2. 持仓时间分布
            ax2.hist(durations, bins=20, color=self.colors['volume'], alpha=0.7)
            ax2.set_title('持仓时间分布', fontsize=14, color=self.colors['text'])
            ax2.set_xlabel('持仓时间 (小时)', fontsize=12, color=self.colors['text'])
            ax2.set_ylabel('交易次数', fontsize=12, color=self.colors['text'])
            ax2.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            
            # 3. 累计盈亏曲线
            cumulative_profits = np.cumsum(profits)
            ax3.plot(cumulative_profits, color=self.colors['price'], linewidth=2)
            ax3.set_title('累计盈亏', fontsize=14, color=self.colors['text'])
            ax3.set_xlabel('交易次数', fontsize=12, color=self.colors['text'])
            ax3.set_ylabel('累计盈亏', fontsize=12, color=self.colors['text'])
            ax3.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            
            # 4. 盈亏与持仓时间散点图
            ax4.scatter(durations, profits, color=self.colors['price'], alpha=0.7)
            ax4.axhline(y=0, color='black', linestyle='--', linewidth=1)
            ax4.set_title('盈亏与持仓时间关系', fontsize=14, color=self.colors['text'])
            ax4.set_xlabel('持仓时间 (小时)', fontsize=12, color=self.colors['text'])
            ax4.set_ylabel('盈亏', fontsize=12, color=self.colors['text'])
            ax4.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5)
            
            # 添加统计信息
            win_trades = [t for t in trades if t.get('profit', 0) > 0]
            loss_trades = [t for t in trades if t.get('profit', 0) <= 0]
            
            win_rate = len(win_trades) / len(trades) * 100 if trades else 0
            avg_profit = np.mean([t.get('profit', 0) for t in win_trades]) if win_trades else 0
            avg_loss = np.mean([t.get('profit', 0) for t in loss_trades]) if loss_trades else 0
            
            stats_text = (
                f"总交易次数: {len(trades)}\n"
                f"盈利交易: {len(win_trades)} ({win_rate:.2f}%)\n"
                f"亏损交易: {len(loss_trades)} ({100-win_rate:.2f}%)\n"
                f"平均盈利: {avg_profit:.2f}\n"
                f"平均亏损: {avg_loss:.2f}\n"
                f"盈亏比: {abs(avg_profit/avg_loss):.2f}" if avg_loss != 0 else "盈亏比: N/A"
            )
            
            fig.text(0.02, 0.02, stats_text, fontsize=12, color=self.colors['text'])
            
            # 设置总标题
            fig.suptitle(title, fontsize=16, color=self.colors['text'])
            
            # 调整布局
            plt.tight_layout()
            plt.subplots_adjust(top=0.9)
            
            # 保存图表
            if save:
                if filename is None:
                    # 生成默认文件名
                    filename = f"trade_analysis_{len(trades)}_trades.png"
                    
                file_path = os.path.join(self.output_dir, filename)
                plt.savefig(file_path, dpi=self.dpi, bbox_inches='tight')
                logger.info(f"已保存图表: {file_path}")
                
            return fig
            
        except Exception as e:
            logger.error(f"绘制交易分析图失败: {e}")
            return None
    
    def plot_performance_metrics(self, metrics: Dict[str, float], 
                               title: str = "性能指标", 
                               save: bool = True, 
                               filename: str = None) -> plt.Figure:
        """
        绘制性能指标图
        
        参数:
            metrics: 性能指标字典
            title: 图表标题
            save: 是否保存图表
            filename: 保存的文件名
            
        返回:
            matplotlib图表对象
        """
        if not metrics:
            logger.warning("没有性能指标数据，无法绘制性能指标图")
            return None
            
        try:
            # 选择要显示的指标
            key_metrics = {
                '总收益率': metrics.get('total_return', 0) * 100,
                '年化收益率': metrics.get('annual_return', 0) * 100,
                '最大回撤': metrics.get('max_drawdown', 0) * 100,
                '夏普比率': metrics.get('sharpe_ratio', 0),
                '索提诺比率': metrics.get('sortino_ratio', 0),
                '卡玛比率': metrics.get('calmar_ratio', 0),
                '胜率': metrics.get('win_rate', 0) * 100,
                '盈亏比': metrics.get('profit_factor', 0),
                '期望收益': metrics.get('expected_return', 0),
                '交易频率': metrics.get('trade_frequency', 0),
                '平均持仓时间': metrics.get('avg_holding_time', 0),
                '波动率': metrics.get('volatility', 0) * 100
            }
            
            # 创建图表
            fig, ax = plt.subplots(figsize=self.figsize, dpi=self.dpi, 
                                  facecolor=self.colors['background'])
            
            # 准备数据
            metrics_names = list(key_metrics.keys())
            metrics_values = list(key_metrics.values())
            
            # 创建条形图
            bars = ax.barh(metrics_names, metrics_values, color=self.colors['price'], alpha=0.7)
            
            # 添加数值标签
            for i, bar in enumerate(bars):
                width = bar.get_width()
                label_x_pos = width if width >= 0 else 0
                ax.text(label_x_pos, bar.get_y() + bar.get_height()/2, 
                       f'{metrics_values[i]:.2f}', 
                       va='center', ha='left' if width >= 0 else 'right',
                       color=self.colors['text'], fontsize=10)
                       
            # 设置图表样式
            ax.set_title(title, fontsize=16, color=self.colors['text'])
            ax.set_xlabel('数值', fontsize=12, color=self.colors['text'])
            ax.grid(True, color=self.colors['grid'], linestyle='--', linewidth=0.5, axis='x')
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            if save:
                if filename is None:
                    # 生成默认文件名
                    filename = f"performance_metrics.png"
                    
                file_path = os.path.join(self.output_dir, filename)
                plt.savefig(file_path, dpi=self.dpi, bbox_inches='tight')
                logger.info(f"已保存图表: {file_path}")
                
            return fig
            
        except Exception as e:
            logger.error(f"绘制性能指标图失败: {e}")
            return None
