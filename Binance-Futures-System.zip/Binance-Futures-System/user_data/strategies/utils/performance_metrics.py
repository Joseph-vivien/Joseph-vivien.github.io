#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
性能指标计算工具

该模块提供计算交易策略性能指标的功能，包括收益率、夏普比率、最大回撤等。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Union, Any
from datetime import datetime

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("performance_metrics")

class PerformanceMetrics:
    """
    性能指标计算类
    
    计算交易策略的各种性能指标，包括收益率、风险调整指标和交易质量指标
    """
    
    def __init__(self, trades: List[Dict[str, Any]] = None, 
                 equity_curve: pd.DataFrame = None,
                 risk_free_rate: float = 0.0):
        """
        初始化性能指标计算器
        
        参数:
            trades: 交易记录列表
            equity_curve: 权益曲线数据
            risk_free_rate: 无风险利率，用于计算夏普比率等指标
        """
        self.trades = trades if trades is not None else []
        self.equity_curve = equity_curve
        self.risk_free_rate = risk_free_rate
        
    def set_trades(self, trades: List[Dict[str, Any]]) -> None:
        """
        设置交易记录
        
        参数:
            trades: 交易记录列表
        """
        self.trades = trades
        
    def set_equity_curve(self, equity_curve: pd.DataFrame) -> None:
        """
        设置权益曲线数据
        
        参数:
            equity_curve: 权益曲线数据，包含时间戳和权益值
        """
        self.equity_curve = equity_curve
        
    def calculate_all_metrics(self) -> Dict[str, Any]:
        """
        计算所有性能指标
        
        返回:
            包含所有性能指标的字典
        """
        if not self.trades and self.equity_curve is None:
            logger.warning("没有交易记录和权益曲线数据，无法计算性能指标")
            return {}
            
        # 如果有交易记录但没有权益曲线，则根据交易记录生成权益曲线
        if self.trades and self.equity_curve is None:
            self.equity_curve = self._generate_equity_curve()
            
        metrics = {}
        
        # 基础指标
        metrics.update(self.calculate_basic_metrics())
        
        # 风险调整指标
        metrics.update(self.calculate_risk_adjusted_metrics())
        
        # 交易质量指标
        metrics.update(self.calculate_trade_quality_metrics())
        
        # 策略特性指标
        metrics.update(self.calculate_strategy_characteristics())
        
        return metrics
    
    def calculate_basic_metrics(self) -> Dict[str, float]:
        """
        计算基础性能指标
        
        返回:
            包含基础性能指标的字典
        """
        metrics = {}
        
        if self.equity_curve is None or len(self.equity_curve) < 2:
            logger.warning("权益曲线数据不足，无法计算基础指标")
            return metrics
            
        # 总收益率
        initial_equity = self.equity_curve.iloc[0]['equity']
        final_equity = self.equity_curve.iloc[-1]['equity']
        total_return = (final_equity - initial_equity) / initial_equity
        metrics['total_return'] = total_return
        
        # 年化收益率
        days = (self.equity_curve.iloc[-1]['timestamp'] - 
                self.equity_curve.iloc[0]['timestamp']).days
        if days > 0:
            annual_return = (1 + total_return) ** (365 / days) - 1
            metrics['annual_return'] = annual_return
        else:
            metrics['annual_return'] = 0.0
            
        # 最大回撤
        max_drawdown, max_drawdown_duration = self._calculate_max_drawdown()
        metrics['max_drawdown'] = max_drawdown
        metrics['max_drawdown_duration'] = max_drawdown_duration
        
        # 波动率
        returns = self.equity_curve['equity'].pct_change().dropna()
        volatility = returns.std() * np.sqrt(252)  # 年化波动率
        metrics['volatility'] = volatility
        
        return metrics
    
    def calculate_risk_adjusted_metrics(self) -> Dict[str, float]:
        """
        计算风险调整指标
        
        返回:
            包含风险调整指标的字典
        """
        metrics = {}
        
        if self.equity_curve is None or len(self.equity_curve) < 2:
            logger.warning("权益曲线数据不足，无法计算风险调整指标")
            return metrics
            
        # 获取基础指标
        basic_metrics = self.calculate_basic_metrics()
        annual_return = basic_metrics.get('annual_return', 0.0)
        volatility = basic_metrics.get('volatility', 0.0)
        max_drawdown = basic_metrics.get('max_drawdown', 0.0)
        
        # 夏普比率
        if volatility > 0:
            sharpe_ratio = (annual_return - self.risk_free_rate) / volatility
            metrics['sharpe_ratio'] = sharpe_ratio
        else:
            metrics['sharpe_ratio'] = 0.0
            
        # 索提诺比率
        downside_returns = self.equity_curve['equity'].pct_change().dropna()
        downside_returns = downside_returns[downside_returns < 0]
        if len(downside_returns) > 0:
            downside_deviation = downside_returns.std() * np.sqrt(252)
            if downside_deviation > 0:
                sortino_ratio = (annual_return - self.risk_free_rate) / downside_deviation
                metrics['sortino_ratio'] = sortino_ratio
            else:
                metrics['sortino_ratio'] = 0.0
        else:
            metrics['sortino_ratio'] = 0.0
            
        # 卡玛比率
        if max_drawdown > 0:
            calmar_ratio = annual_return / max_drawdown
            metrics['calmar_ratio'] = calmar_ratio
        else:
            metrics['calmar_ratio'] = 0.0
            
        # 欧米茄比率
        if volatility > 0 and max_drawdown > 0:
            omega_ratio = annual_return / (volatility * max_drawdown)
            metrics['omega_ratio'] = omega_ratio
        else:
            metrics['omega_ratio'] = 0.0
            
        return metrics
    
    def calculate_trade_quality_metrics(self) -> Dict[str, float]:
        """
        计算交易质量指标
        
        返回:
            包含交易质量指标的字典
        """
        metrics = {}
        
        if not self.trades:
            logger.warning("没有交易记录，无法计算交易质量指标")
            return metrics
            
        # 总交易次数
        total_trades = len(self.trades)
        metrics['total_trades'] = total_trades
        
        # 盈利交易和亏损交易
        profitable_trades = [t for t in self.trades if t.get('profit', 0) > 0]
        losing_trades = [t for t in self.trades if t.get('profit', 0) <= 0]
        
        # 胜率
        win_rate = len(profitable_trades) / total_trades if total_trades > 0 else 0
        metrics['win_rate'] = win_rate
        
        # 平均盈利和平均亏损
        avg_profit = np.mean([t.get('profit', 0) for t in profitable_trades]) if profitable_trades else 0
        avg_loss = np.mean([t.get('profit', 0) for t in losing_trades]) if losing_trades else 0
        metrics['avg_profit'] = avg_profit
        metrics['avg_loss'] = avg_loss
        
        # 盈亏比
        profit_factor = abs(avg_profit / avg_loss) if avg_loss != 0 else 0
        metrics['profit_factor'] = profit_factor
        
        # 期望收益
        expected_return = win_rate * avg_profit + (1 - win_rate) * avg_loss
        metrics['expected_return'] = expected_return
        
        # 最大连续盈利和亏损次数
        profit_streak, loss_streak = self._calculate_streaks()
        metrics['max_profit_streak'] = profit_streak
        metrics['max_loss_streak'] = loss_streak
        
        return metrics
    
    def calculate_strategy_characteristics(self) -> Dict[str, float]:
        """
        计算策略特性指标
        
        返回:
            包含策略特性指标的字典
        """
        metrics = {}
        
        if not self.trades:
            logger.warning("没有交易记录，无法计算策略特性指标")
            return metrics
            
        # 交易频率
        if self.equity_curve is not None and len(self.equity_curve) >= 2:
            days = (self.equity_curve.iloc[-1]['timestamp'] - 
                    self.equity_curve.iloc[0]['timestamp']).days
            if days > 0:
                trade_frequency = len(self.trades) / days
                metrics['trade_frequency'] = trade_frequency
                
        # 平均持仓时间
        holding_times = []
        for trade in self.trades:
            entry_time = trade.get('entry_time')
            exit_time = trade.get('exit_time')
            if entry_time and exit_time:
                if isinstance(entry_time, str):
                    entry_time = datetime.fromisoformat(entry_time.replace('Z', '+00:00'))
                if isinstance(exit_time, str):
                    exit_time = datetime.fromisoformat(exit_time.replace('Z', '+00:00'))
                holding_time = (exit_time - entry_time).total_seconds() / 3600  # 小时
                holding_times.append(holding_time)
                
        if holding_times:
            avg_holding_time = np.mean(holding_times)
            metrics['avg_holding_time'] = avg_holding_time
            
        # 回撤恢复时间
        if self.equity_curve is not None:
            recovery_time = self._calculate_recovery_time()
            metrics['avg_recovery_time'] = recovery_time
            
        return metrics
    
    def _generate_equity_curve(self) -> pd.DataFrame:
        """
        根据交易记录生成权益曲线
        
        返回:
            权益曲线数据
        """
        if not self.trades:
            logger.warning("没有交易记录，无法生成权益曲线")
            return pd.DataFrame(columns=['timestamp', 'equity'])
            
        # 按时间排序交易记录
        sorted_trades = sorted(self.trades, key=lambda x: x.get('entry_time', 0))
        
        # 初始化权益曲线
        equity_points = []
        current_equity = 100.0  # 假设初始权益为100
        
        # 添加初始点
        first_trade_time = sorted_trades[0].get('entry_time')
        if isinstance(first_trade_time, str):
            first_trade_time = datetime.fromisoformat(first_trade_time.replace('Z', '+00:00'))
        equity_points.append({
            'timestamp': first_trade_time,
            'equity': current_equity
        })
        
        # 添加每笔交易后的权益点
        for trade in sorted_trades:
            profit = trade.get('profit', 0)
            exit_time = trade.get('exit_time')
            if isinstance(exit_time, str):
                exit_time = datetime.fromisoformat(exit_time.replace('Z', '+00:00'))
                
            current_equity += profit
            equity_points.append({
                'timestamp': exit_time,
                'equity': current_equity
            })
            
        return pd.DataFrame(equity_points)
    
    def _calculate_max_drawdown(self) -> Tuple[float, int]:
        """
        计算最大回撤和回撤持续时间
        
        返回:
            (最大回撤百分比, 回撤持续天数)
        """
        if self.equity_curve is None or len(self.equity_curve) < 2:
            return 0.0, 0
            
        equity = self.equity_curve['equity'].values
        max_dd = 0.0
        max_dd_duration = 0
        
        peak = equity[0]
        peak_idx = 0
        
        for i, value in enumerate(equity):
            if value > peak:
                peak = value
                peak_idx = i
            else:
                dd = (peak - value) / peak
                if dd > max_dd:
                    max_dd = dd
                    # 计算回撤持续时间
                    if i > peak_idx:
                        duration = (self.equity_curve.iloc[i]['timestamp'] - 
                                   self.equity_curve.iloc[peak_idx]['timestamp']).days
                        max_dd_duration = duration
                        
        return max_dd, max_dd_duration
    
    def _calculate_streaks(self) -> Tuple[int, int]:
        """
        计算最大连续盈利和亏损次数
        
        返回:
            (最大连续盈利次数, 最大连续亏损次数)
        """
        if not self.trades:
            return 0, 0
            
        # 提取每笔交易的盈亏情况
        profits = [1 if t.get('profit', 0) > 0 else 0 for t in self.trades]
        
        # 计算连续盈利次数
        max_profit_streak = 0
        current_profit_streak = 0
        
        for p in profits:
            if p == 1:
                current_profit_streak += 1
                max_profit_streak = max(max_profit_streak, current_profit_streak)
            else:
                current_profit_streak = 0
                
        # 计算连续亏损次数
        max_loss_streak = 0
        current_loss_streak = 0
        
        for p in profits:
            if p == 0:
                current_loss_streak += 1
                max_loss_streak = max(max_loss_streak, current_loss_streak)
            else:
                current_loss_streak = 0
                
        return max_profit_streak, max_loss_streak
    
    def _calculate_recovery_time(self) -> float:
        """
        计算平均回撤恢复时间
        
        返回:
            平均回撤恢复时间（天）
        """
        if self.equity_curve is None or len(self.equity_curve) < 3:
            return 0.0
            
        equity = self.equity_curve['equity'].values
        timestamps = self.equity_curve['timestamp'].values
        
        recovery_times = []
        in_drawdown = False
        peak = equity[0]
        peak_time = timestamps[0]
        drawdown_start_time = None
        
        for i in range(1, len(equity)):
            if equity[i] > peak:
                # 新高
                if in_drawdown:
                    # 从回撤中恢复
                    recovery_time = (timestamps[i] - drawdown_start_time).days
                    recovery_times.append(recovery_time)
                    in_drawdown = False
                peak = equity[i]
                peak_time = timestamps[i]
            elif equity[i] < peak and not in_drawdown:
                # 开始回撤
                in_drawdown = True
                drawdown_start_time = timestamps[i]
                
        if recovery_times:
            return np.mean(recovery_times)
        else:
            return 0.0
