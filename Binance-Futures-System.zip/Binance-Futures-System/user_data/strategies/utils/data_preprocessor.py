#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
数据预处理工具

该模块提供数据清洗、转换和特征工程功能，为策略和机器学习模型准备数据。

作者: 高级Python工程师
日期: 2024-05-21
"""

import os
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
import talib
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("data_preprocessor")

class DataPreprocessor:
    """
    数据预处理类

    提供数据清洗、转换和特征工程功能，为策略和机器学习模型准备数据
    """

    def __init__(self, data_dir: str = "user_data/data"):
        """
        初始化数据预处理器

        参数:
            data_dir: 数据目录
        """
        self.data_dir = data_dir
        self.historical_dir = os.path.join(data_dir, "historical")
        self.live_dir = os.path.join(data_dir, "live")

        # 确保目录存在
        os.makedirs(self.historical_dir, exist_ok=True)
        os.makedirs(self.live_dir, exist_ok=True)

        # 初始化缩放器
        self.price_scaler = MinMaxScaler(feature_range=(0, 1))
        self.volume_scaler = MinMaxScaler(feature_range=(0, 1))
        self.feature_scaler = StandardScaler()

    def load_ohlcv_data(self, symbol: str, timeframe: str,
                       start_date: Optional[datetime] = None,
                       end_date: Optional[datetime] = None,
                       limit: int = 1000) -> pd.DataFrame:
        """
        加载OHLCV数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            start_date: 开始日期
            end_date: 结束日期
            limit: 最大记录数

        返回:
            OHLCV数据
        """
        # 构建文件路径
        symbol_dir = os.path.join(self.historical_dir, "binance", symbol.replace('/', '_'))
        timeframe_dir = os.path.join(symbol_dir, timeframe)

        if not os.path.exists(timeframe_dir):
            logger.warning(f"数据目录不存在: {timeframe_dir}")
            return pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])

        # 查找符合日期范围的文件
        files = []
        for file in os.listdir(timeframe_dir):
            if file.endswith('.csv'):
                file_date_str = file.split('_')[0]
                file_date = None

                # 尝试不同的日期格式
                date_formats = ['%Y%m%d', '%Y%m', '%Y-%m-%d', '%Y-%m']

                for date_format in date_formats:
                    try:
                        file_date = datetime.strptime(file_date_str, date_format)
                        break
                    except ValueError:
                        continue

                # 如果无法解析日期，直接包含文件（用于调试）
                if file_date is None:
                    logger.debug(f"无法解析文件日期: {file}, 将包含在数据中")
                    files.append(os.path.join(timeframe_dir, file))
                    continue

                # 检查日期范围
                if (start_date is None or file_date >= start_date) and \
                   (end_date is None or file_date <= end_date):
                    files.append(os.path.join(timeframe_dir, file))

        if not files:
            logger.warning(f"未找到符合条件的数据文件: {symbol} {timeframe}")
            return pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])

        # 读取并合并数据
        dfs = []
        for file in sorted(files):
            try:
                df = pd.read_csv(file)
                dfs.append(df)
            except Exception as e:
                logger.error(f"读取数据文件失败: {file}, 错误: {e}")

        if not dfs:
            logger.warning(f"未能成功读取任何数据文件: {symbol} {timeframe}")
            return pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])

        # 合并数据
        data = pd.concat(dfs, ignore_index=True)

        # 确保列名一致
        expected_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        if not all(col in data.columns for col in expected_columns):
            # 尝试重命名列
            if 'time' in data.columns and 'timestamp' not in data.columns:
                data = data.rename(columns={'time': 'timestamp'})

            # 检查是否有缺失列
            missing_columns = [col for col in expected_columns if col not in data.columns]
            if missing_columns:
                logger.error(f"数据缺少必要的列: {missing_columns}")
                # 添加缺失的列
                for col in missing_columns:
                    data[col] = np.nan

        # 确保timestamp是datetime类型
        if 'timestamp' in data.columns:
            if data['timestamp'].dtype == 'object':
                try:
                    data['timestamp'] = pd.to_datetime(data['timestamp'])
                except Exception as e:
                    logger.error(f"转换timestamp列失败: {e}")
                    # 尝试不同的格式
                    try:
                        data['timestamp'] = pd.to_datetime(data['timestamp'], unit='ms')
                    except:
                        pass
            elif data['timestamp'].dtype == 'int64':
                try:
                    data['timestamp'] = pd.to_datetime(data['timestamp'], unit='ms')
                except Exception as e:
                    logger.error(f"转换timestamp列失败: {e}")

        # 排序并去重
        data = data.sort_values('timestamp').drop_duplicates(subset=['timestamp'])

        # 应用日期过滤
        if start_date:
            data = data[data['timestamp'] >= pd.Timestamp(start_date)]
        if end_date:
            data = data[data['timestamp'] <= pd.Timestamp(end_date)]

        # 限制记录数
        if limit and len(data) > limit:
            data = data.tail(limit)

        return data

    def clean_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        清洗数据，处理缺失值和异常值

        参数:
            data: 原始数据

        返回:
            清洗后的数据
        """
        if data.empty:
            return data

        # 复制数据，避免修改原始数据
        df = data.copy()

        # 处理缺失值
        # 对于OHLCV数据，使用前向填充
        df = df.fillna(method='ffill')

        # 如果仍有缺失值，使用后向填充
        df = df.fillna(method='bfill')

        # 处理异常值
        # 对于价格数据，使用3倍标准差作为异常值判断标准
        for col in ['open', 'high', 'low', 'close']:
            if col in df.columns:
                mean = df[col].mean()
                std = df[col].std()
                lower_bound = mean - 3 * std
                upper_bound = mean + 3 * std

                # 标记异常值
                outliers = (df[col] < lower_bound) | (df[col] > upper_bound)
                if outliers.any():
                    logger.warning(f"发现{outliers.sum()}个{col}列异常值")

                    # 对于异常值，使用前后值的平均值替代
                    for idx in df[outliers].index:
                        if idx > 0 and idx < len(df) - 1:
                            df.loc[idx, col] = (df.loc[idx-1, col] + df.loc[idx+1, col]) / 2
                        elif idx == 0:
                            df.loc[idx, col] = df.loc[idx+1, col]
                        else:
                            df.loc[idx, col] = df.loc[idx-1, col]

        # 确保价格数据的合理性
        # 确保 high >= open >= low 和 high >= close >= low
        if all(col in df.columns for col in ['open', 'high', 'low', 'close']):
            # 修复high < open的情况
            mask = df['high'] < df['open']
            if mask.any():
                logger.warning(f"发现{mask.sum()}个high < open的异常值")
                df.loc[mask, 'high'] = df.loc[mask, 'open']

            # 修复high < close的情况
            mask = df['high'] < df['close']
            if mask.any():
                logger.warning(f"发现{mask.sum()}个high < close的异常值")
                df.loc[mask, 'high'] = df.loc[mask, 'close']

            # 修复low > open的情况
            mask = df['low'] > df['open']
            if mask.any():
                logger.warning(f"发现{mask.sum()}个low > open的异常值")
                df.loc[mask, 'low'] = df.loc[mask, 'open']

            # 修复low > close的情况
            mask = df['low'] > df['close']
            if mask.any():
                logger.warning(f"发现{mask.sum()}个low > close的异常值")
                df.loc[mask, 'low'] = df.loc[mask, 'close']

        return df

    def add_technical_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        添加技术指标

        参数:
            data: OHLCV数据

        返回:
            添加技术指标后的数据
        """
        if data.empty:
            return data

        # 复制数据，避免修改原始数据
        df = data.copy()

        # 确保数据包含必要的列
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_columns):
            missing_columns = [col for col in required_columns if col not in df.columns]
            logger.error(f"数据缺少必要的列: {missing_columns}")
            return df

        try:
            # 移动平均线
            df['sma5'] = talib.SMA(df['close'].values, timeperiod=5)
            df['sma10'] = talib.SMA(df['close'].values, timeperiod=10)
            df['sma20'] = talib.SMA(df['close'].values, timeperiod=20)
            df['sma50'] = talib.SMA(df['close'].values, timeperiod=50)
            df['sma100'] = talib.SMA(df['close'].values, timeperiod=100)
            df['sma200'] = talib.SMA(df['close'].values, timeperiod=200)

            # 指数移动平均线
            df['ema5'] = talib.EMA(df['close'].values, timeperiod=5)
            df['ema10'] = talib.EMA(df['close'].values, timeperiod=10)
            df['ema20'] = talib.EMA(df['close'].values, timeperiod=20)
            df['ema50'] = talib.EMA(df['close'].values, timeperiod=50)
            df['ema100'] = talib.EMA(df['close'].values, timeperiod=100)
            df['ema200'] = talib.EMA(df['close'].values, timeperiod=200)

            # 布林带
            df['upperband'], df['middleband'], df['lowerband'] = talib.BBANDS(
                df['close'].values, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)

            # RSI
            df['rsi7'] = talib.RSI(df['close'].values, timeperiod=7)
            df['rsi14'] = talib.RSI(df['close'].values, timeperiod=14)
            df['rsi21'] = talib.RSI(df['close'].values, timeperiod=21)

            # MACD
            df['macd'], df['macdsignal'], df['macdhist'] = talib.MACD(
                df['close'].values, fastperiod=12, slowperiod=26, signalperiod=9)

            # 随机指标
            df['slowk'], df['slowd'] = talib.STOCH(
                df['high'].values, df['low'].values, df['close'].values,
                fastk_period=5, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0)

            # ATR
            df['atr'] = talib.ATR(
                df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

            # CCI
            df['cci'] = talib.CCI(
                df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

            # ADX
            df['adx'] = talib.ADX(
                df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

            # OBV
            df['obv'] = talib.OBV(df['close'].values, df['volume'].values)

            # 威廉指标
            df['willr'] = talib.WILLR(
                df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

            # MFI
            df['mfi'] = talib.MFI(
                df['high'].values, df['low'].values, df['close'].values,
                df['volume'].values, timeperiod=14)

            # 计算价格变化率
            df['price_change'] = df['close'].pct_change()
            df['price_change_1d'] = df['close'].pct_change(periods=1)
            df['price_change_3d'] = df['close'].pct_change(periods=3)
            df['price_change_5d'] = df['close'].pct_change(periods=5)
            df['price_change_10d'] = df['close'].pct_change(periods=10)

            # 计算成交量变化率
            df['volume_change'] = df['volume'].pct_change()
            df['volume_change_1d'] = df['volume'].pct_change(periods=1)
            df['volume_change_3d'] = df['volume'].pct_change(periods=3)
            df['volume_change_5d'] = df['volume'].pct_change(periods=5)

            # 计算波动率
            df['volatility'] = df['close'].rolling(window=20).std() / df['close'].rolling(window=20).mean()

            # 计算价格与移动平均线的距离
            df['dist_sma20'] = (df['close'] - df['sma20']) / df['sma20']
            df['dist_sma50'] = (df['close'] - df['sma50']) / df['sma50']
            df['dist_sma200'] = (df['close'] - df['sma200']) / df['sma200']

            # 计算布林带宽度
            df['bb_width'] = (df['upperband'] - df['lowerband']) / df['middleband']

            # 计算布林带位置
            df['bb_position'] = (df['close'] - df['lowerband']) / (df['upperband'] - df['lowerband'])

        except Exception as e:
            logger.error(f"计算技术指标失败: {e}")

        return df

    def normalize_data(self, data: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """
        归一化数据

        参数:
            data: 原始数据
            fit: 是否拟合缩放器

        返回:
            归一化后的数据
        """
        if data.empty:
            return data

        # 复制数据，避免修改原始数据
        df = data.copy()

        try:
            # 价格数据归一化
            price_columns = ['open', 'high', 'low', 'close',
                            'sma5', 'sma10', 'sma20', 'sma50', 'sma100', 'sma200',
                            'ema5', 'ema10', 'ema20', 'ema50', 'ema100', 'ema200',
                            'upperband', 'middleband', 'lowerband']

            price_columns = [col for col in price_columns if col in df.columns]

            if price_columns:
                price_data = df[price_columns].values
                if fit:
                    price_data_scaled = self.price_scaler.fit_transform(price_data)
                else:
                    price_data_scaled = self.price_scaler.transform(price_data)

                for i, col in enumerate(price_columns):
                    df[f"{col}_norm"] = price_data_scaled[:, i]

            # 成交量数据归一化
            volume_columns = ['volume', 'obv']
            volume_columns = [col for col in volume_columns if col in df.columns]

            if volume_columns:
                volume_data = df[volume_columns].values.reshape(-1, len(volume_columns))
                if fit:
                    volume_data_scaled = self.volume_scaler.fit_transform(volume_data)
                else:
                    volume_data_scaled = self.volume_scaler.transform(volume_data)

                for i, col in enumerate(volume_columns):
                    df[f"{col}_norm"] = volume_data_scaled[:, i]

            # 其他特征标准化
            feature_columns = ['rsi7', 'rsi14', 'rsi21', 'macd', 'macdsignal', 'macdhist',
                              'slowk', 'slowd', 'atr', 'cci', 'adx', 'willr', 'mfi',
                              'price_change', 'price_change_1d', 'price_change_3d',
                              'price_change_5d', 'price_change_10d',
                              'volume_change', 'volume_change_1d', 'volume_change_3d',
                              'volume_change_5d', 'volatility',
                              'dist_sma20', 'dist_sma50', 'dist_sma200',
                              'bb_width', 'bb_position']

            feature_columns = [col for col in feature_columns if col in df.columns]

            if feature_columns:
                # 填充NaN值
                for col in feature_columns:
                    df[col] = df[col].fillna(df[col].mean())

                feature_data = df[feature_columns].values
                if fit:
                    feature_data_scaled = self.feature_scaler.fit_transform(feature_data)
                else:
                    feature_data_scaled = self.feature_scaler.transform(feature_data)

                for i, col in enumerate(feature_columns):
                    df[f"{col}_norm"] = feature_data_scaled[:, i]

        except Exception as e:
            logger.error(f"归一化数据失败: {e}")

        return df

    def prepare_ml_features(self, data: pd.DataFrame,
                          window_size: int = 20,
                          prediction_horizon: int = 5) -> Tuple[np.ndarray, np.ndarray]:
        """
        准备机器学习特征和标签

        参数:
            data: 处理后的数据
            window_size: 时间窗口大小
            prediction_horizon: 预测时间范围

        返回:
            (特征数组, 标签数组)
        """
        if data.empty or len(data) < window_size + prediction_horizon:
            logger.warning("数据不足，无法准备机器学习特征")
            return np.array([]), np.array([])

        try:
            # 选择归一化后的特征
            norm_columns = [col for col in data.columns if col.endswith('_norm')]

            if not norm_columns:
                logger.warning("未找到归一化特征，将使用原始特征")
                # 使用原始特征
                feature_columns = ['close', 'volume', 'rsi14', 'macd', 'bb_position']
                feature_columns = [col for col in feature_columns if col in data.columns]
            else:
                feature_columns = norm_columns

            # 准备特征序列
            X = []
            y = []

            for i in range(len(data) - window_size - prediction_horizon + 1):
                # 提取时间窗口内的特征
                features = data[feature_columns].iloc[i:i+window_size].values

                # 计算未来价格变化作为标签
                future_price = data['close'].iloc[i+window_size+prediction_horizon-1]
                current_price = data['close'].iloc[i+window_size-1]
                price_change = (future_price - current_price) / current_price

                X.append(features)
                y.append(price_change)

            return np.array(X), np.array(y)

        except Exception as e:
            logger.error(f"准备机器学习特征失败: {e}")
            return np.array([]), np.array([])

    def save_processed_data(self, data: pd.DataFrame, symbol: str,
                          timeframe: str, suffix: str = "processed") -> bool:
        """
        保存处理后的数据

        参数:
            data: 处理后的数据
            symbol: 交易对符号
            timeframe: 时间周期
            suffix: 文件后缀

        返回:
            是否保存成功
        """
        if data.empty:
            logger.warning("数据为空，无法保存")
            return False

        try:
            # 构建保存路径
            symbol_dir = os.path.join(self.historical_dir, "indicators", symbol.replace('/', '_'))
            timeframe_dir = os.path.join(symbol_dir, timeframe)

            # 确保目录存在
            os.makedirs(timeframe_dir, exist_ok=True)

            # 生成文件名
            start_date = data['timestamp'].min().strftime('%Y%m%d')
            end_date = data['timestamp'].max().strftime('%Y%m%d')
            filename = f"{start_date}_{end_date}_{suffix}.csv"

            # 保存数据
            file_path = os.path.join(timeframe_dir, filename)
            data.to_csv(file_path, index=False)

            logger.info(f"已保存处理后的数据: {file_path}")
            return True

        except Exception as e:
            logger.error(f"保存处理后的数据失败: {e}")
            return False
