#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
日志工具模块

该模块提供统一的日志记录功能，支持输出到控制台和文件，
并根据不同的日志级别进行格式化和颜色区分。

作者: 高级Python工程师
日期: 2024-05-21
"""

import os
import sys
import logging
import logging.handlers
from datetime import datetime
from typing import Optional, Union, Dict, Any

# 定义日志颜色（用于控制台输出）
COLORS = {
    'DEBUG': '\033[36m',     # 青色
    'INFO': '\033[32m',      # 绿色
    'WARNING': '\033[33m',   # 黄色
    'ERROR': '\033[31m',     # 红色
    'CRITICAL': '\033[35m',  # 紫色
    'RESET': '\033[0m'       # 重置颜色
}

class ColoredFormatter(logging.Formatter):
    """
    自定义日志格式化器，为不同级别的日志添加颜色
    """
    def format(self, record):
        """
        格式化日志记录

        参数:
            record: 日志记录对象

        返回:
            格式化后的日志字符串
        """
        # 保存原始的levelname
        levelname = record.levelname
        # 如果是控制台输出且系统支持颜色显示
        if sys.stdout.isatty():
            # 为日志级别添加颜色
            record.levelname = f"{COLORS.get(levelname, '')}{levelname}{COLORS['RESET']}"
        # 调用父类的format方法
        result = super().format(record)
        # 恢复原始的levelname
        record.levelname = levelname
        return result

class BinanceLogger:
    """
    币安交易系统日志类

    提供统一的日志记录接口，支持多种输出方式和格式化选项
    """

    def __init__(
        self,
        name: str = "binance_futures",
        log_level: str = "INFO",
        log_dir: str = "user_data/logs",
        console_output: bool = True,
        file_output: bool = True,
        max_file_size: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5
    ):
        """
        初始化日志记录器

        参数:
            name: 日志记录器名称
            log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir: 日志文件存储目录
            console_output: 是否输出到控制台
            file_output: 是否输出到文件
            max_file_size: 单个日志文件最大大小（字节）
            backup_count: 保留的日志文件数量
        """
        # 创建日志目录（如果不存在）
        if file_output and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        # 获取日志级别
        numeric_level = getattr(logging, log_level.upper(), None)
        if not isinstance(numeric_level, int):
            raise ValueError(f"无效的日志级别: {log_level}")

        # 创建日志记录器
        self.logger = logging.getLogger(name)
        self.logger.setLevel(numeric_level)
        self.logger.propagate = False

        # 清除已有的处理器
        if self.logger.handlers:
            self.logger.handlers.clear()

        # 日志格式
        detailed_formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

        colored_formatter = ColoredFormatter(
            '%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

        # 添加控制台处理器
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(colored_formatter)
            self.logger.addHandler(console_handler)

        # 添加文件处理器
        if file_output:
            # 常规日志文件
            log_file = os.path.join(log_dir, f"{name}.log")
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=max_file_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setFormatter(detailed_formatter)
            self.logger.addHandler(file_handler)

            # 错误日志单独存储
            error_log_file = os.path.join(log_dir, f"{name}_error.log")
            error_file_handler = logging.handlers.RotatingFileHandler(
                error_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            error_file_handler.setLevel(logging.ERROR)
            error_file_handler.setFormatter(detailed_formatter)
            self.logger.addHandler(error_file_handler)

            # 交易日志单独存储
            trade_log_file = os.path.join(log_dir, f"{name}_trades.log")
            self.trade_file_handler = logging.handlers.RotatingFileHandler(
                trade_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            self.trade_file_handler.setFormatter(detailed_formatter)
            # 不添加到logger，仅在记录交易时使用

    def debug(self, message: str, *args, **kwargs):
        """记录调试级别日志"""
        self.logger.debug(message, *args, **kwargs)

    def info(self, message: str, *args, **kwargs):
        """记录信息级别日志"""
        self.logger.info(message, *args, **kwargs)

    def warning(self, message: str, *args, **kwargs):
        """记录警告级别日志"""
        self.logger.warning(message, *args, **kwargs)

    def error(self, message: str, *args, **kwargs):
        """记录错误级别日志"""
        self.logger.error(message, *args, **kwargs)

    def critical(self, message: str, *args, **kwargs):
        """记录严重错误级别日志"""
        self.logger.critical(message, *args, **kwargs)

    def exception(self, message: str, *args, **kwargs):
        """记录异常信息，包含堆栈跟踪"""
        self.logger.exception(message, *args, **kwargs)

    def trade_log(self, trade_type: str, symbol: str, side: str,
                 amount: float, price: float, order_id: str = None,
                 extra_info: Dict[str, Any] = None):
        """
        记录交易信息到专门的交易日志文件

        参数:
            trade_type: 交易类型 (ENTRY, EXIT, CANCEL等)
            symbol: 交易对符号
            side: 交易方向 (BUY, SELL)
            amount: 交易数量
            price: 交易价格
            order_id: 订单ID
            extra_info: 额外信息字典
        """
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        trade_info = {
            "timestamp": timestamp,
            "type": trade_type,
            "symbol": symbol,
            "side": side,
            "amount": amount,
            "price": price,
            "order_id": order_id
        }

        if extra_info:
            trade_info.update(extra_info)

        trade_message = f"{timestamp} [TRADE] {trade_type} {symbol} {side} {amount}@{price}"
        if order_id:
            trade_message += f" (ID: {order_id})"

        # 记录到主日志
        self.logger.info(trade_message)

        # 记录到交易日志文件
        trade_record = logging.LogRecord(
            name="trade",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg=trade_message,
            args=(),
            exc_info=None
        )
        self.trade_file_handler.emit(trade_record)

        return trade_info

# 创建默认日志记录器实例
default_logger = BinanceLogger()

# 提供便捷的全局访问函数
def get_logger(name: str = None, **kwargs) -> BinanceLogger:
    """
    获取或创建日志记录器

    参数:
        name: 日志记录器名称
        kwargs: 其他日志配置参数

    返回:
        BinanceLogger实例
    """
    if name is None:
        return default_logger
    return BinanceLogger(name=name, **kwargs)

def setup_logging(log_level: str = "INFO", log_dir: str = "user_data/logs",
                 console_output: bool = True, file_output: bool = True) -> None:
    """
    设置全局日志配置

    参数:
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: 日志文件存储目录
        console_output: 是否输出到控制台
        file_output: 是否输出到文件
    """
    global default_logger

    # 创建日志目录
    if file_output and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    # 重新配置默认日志记录器
    default_logger = BinanceLogger(
        name="binance_futures",
        log_level=log_level,
        log_dir=log_dir,
        console_output=console_output,
        file_output=file_output
    )

    # 配置Python标准库的根日志记录器
    root_logger = logging.getLogger()

    # 清除已有的处理器
    if root_logger.handlers:
        root_logger.handlers.clear()

    # 设置日志级别
    numeric_level = getattr(logging, log_level.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError(f"无效的日志级别: {log_level}")
    root_logger.setLevel(numeric_level)

    # 添加控制台处理器
    if console_output:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(ColoredFormatter(
            '%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        root_logger.addHandler(console_handler)

    # 添加文件处理器
    if file_output:
        log_file = os.path.join(log_dir, "system.log")
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        root_logger.addHandler(file_handler)

    # 记录日志设置完成
    root_logger.info(f"日志系统初始化完成，级别: {log_level}, 目录: {log_dir}")

def log_trade(trade_type: str, symbol: str, side: str, amount: float,
             price: float, order_id: str = None, extra_info: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    记录交易信息的便捷函数

    参数:
        trade_type: 交易类型 (ENTRY, EXIT, CANCEL等)
        symbol: 交易对符号
        side: 交易方向 (BUY, SELL)
        amount: 交易数量
        price: 交易价格
        order_id: 订单ID
        extra_info: 额外信息字典

    返回:
        交易信息字典
    """
    return default_logger.trade_log(
        trade_type=trade_type,
        symbol=symbol,
        side=side,
        amount=amount,
        price=price,
        order_id=order_id,
        extra_info=extra_info
    )
