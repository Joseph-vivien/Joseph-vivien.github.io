#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
CCXT数据源

该模块为Backtrader提供CCXT数据源支持，用于获取实时和历史市场数据。

作者: 高级Python工程师
日期: 2024-05-21
"""

import backtrader as bt
import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import threading
from typing import Dict, List, Optional, Any
import logging

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("ccxt_data")

class CCXTData(bt.feeds.DataBase):
    """
    CCXT数据源类

    为Backtrader提供CCXT交易所数据支持
    """

    params = (
        ('exchange', None),  # CCXT交易所对象
        ('symbol', ''),      # 交易对符号
        ('timeframe', '1m'), # 时间框架
        ('since', None),     # 开始时间
        ('limit', 2000),     # 数据限制
        ('live', False),     # 是否实时数据
        ('historical', True), # 是否历史数据
        ('backfill_start', True), # 是否回填开始数据
        ('debug', False),    # 调试模式
    )

    def __init__(self):
        """初始化CCXT数据源"""
        super(CCXTData, self).__init__()

        self.exchange = self.p.exchange
        self.symbol = self.p.symbol
        self.timeframe = self.p.timeframe
        self.live = self.p.live
        self.historical = self.p.historical

        # 设置Backtrader时间框架参数
        self._set_backtrader_timeframe()

        # 数据缓存
        self.data_cache = []
        self.current_index = 0

        # 实时数据相关
        self.live_data = []
        self.last_update = None
        self.update_thread = None
        self.running = False

        # 时间框架转换
        self.timeframe_seconds = self._get_timeframe_seconds()

        logger.info(f"初始化CCXT数据源: {self.symbol} {self.timeframe}")

    def _set_backtrader_timeframe(self):
        """设置Backtrader时间框架参数"""
        # 时间框架映射
        timeframe_map = {
            '1m': (bt.TimeFrame.Minutes, 1),
            '3m': (bt.TimeFrame.Minutes, 3),
            '5m': (bt.TimeFrame.Minutes, 5),
            '15m': (bt.TimeFrame.Minutes, 15),
            '30m': (bt.TimeFrame.Minutes, 30),
            '1h': (bt.TimeFrame.Minutes, 60),
            '2h': (bt.TimeFrame.Minutes, 120),
            '4h': (bt.TimeFrame.Minutes, 240),
            '6h': (bt.TimeFrame.Minutes, 360),
            '8h': (bt.TimeFrame.Minutes, 480),
            '12h': (bt.TimeFrame.Minutes, 720),
            '1d': (bt.TimeFrame.Days, 1),
            '3d': (bt.TimeFrame.Days, 3),
            '1w': (bt.TimeFrame.Weeks, 1),
            '1M': (bt.TimeFrame.Months, 1),
        }

        # 获取时间框架和压缩比
        tf_info = timeframe_map.get(self.timeframe, (bt.TimeFrame.Minutes, 1))
        self.p.timeframe = tf_info[0]
        self.p.compression = tf_info[1]

    def _get_timeframe_seconds(self) -> int:
        """获取时间框架对应的秒数"""
        timeframe_map = {
            '1m': 60,
            '3m': 180,
            '5m': 300,
            '15m': 900,
            '30m': 1800,
            '1h': 3600,
            '2h': 7200,
            '4h': 14400,
            '6h': 21600,
            '8h': 28800,
            '12h': 43200,
            '1d': 86400,
            '3d': 259200,
            '1w': 604800,
            '1M': 2592000,
        }
        return timeframe_map.get(self.timeframe, 60)

    def start(self):
        """启动数据源"""
        super(CCXTData, self).start()

        if self.exchange is None:
            logger.error("交易所对象未设置")
            return

        # 加载历史数据
        if self.historical:
            self._load_historical_data()

        # 启动实时数据
        if self.live:
            self._start_live_data()

    def stop(self):
        """停止数据源"""
        super(CCXTData, self).stop()

        self.running = False
        if self.update_thread and self.update_thread.is_alive():
            self.update_thread.join(timeout=5)

        logger.info(f"停止CCXT数据源: {self.symbol}")

    def _load_historical_data(self):
        """加载历史数据"""
        try:
            logger.info(f"加载历史数据: {self.symbol} {self.timeframe}")

            # 计算开始时间
            if self.p.since:
                since = self.p.since
            else:
                # 根据时间框架计算合适的开始时间
                if self.timeframe in ['1m', '3m', '5m']:
                    # 分钟级数据：获取最近7天
                    days_back = 7
                elif self.timeframe in ['15m', '30m']:
                    # 15分钟/30分钟数据：获取最近30天
                    days_back = 30
                elif self.timeframe in ['1h', '2h', '4h']:
                    # 小时级数据：获取最近90天
                    days_back = 90
                else:
                    # 日线及以上：获取最近365天
                    days_back = 365

                since = int((datetime.now() - timedelta(days=days_back)).timestamp() * 1000)

            # 获取OHLCV数据 - 分批获取以避免API限制
            ohlcv = self._fetch_ohlcv_batch(since, self.p.limit)

            if not ohlcv:
                logger.warning(f"未获取到历史数据: {self.symbol}")
                return

            # 转换数据格式
            self.data_cache = []
            for candle in ohlcv:
                timestamp, open_price, high, low, close, volume = candle

                # 转换时间戳
                dt = datetime.fromtimestamp(timestamp / 1000)

                self.data_cache.append({
                    'datetime': dt,
                    'open': open_price,
                    'high': high,
                    'low': low,
                    'close': close,
                    'volume': volume,
                    'openinterest': 0.0
                })

            logger.info(f"加载历史数据完成: {len(self.data_cache)} 条记录")

        except Exception as e:
            logger.error(f"加载历史数据失败: {e}")

    def _fetch_ohlcv_batch(self, since: int, total_limit: int) -> List:
        """
        分批获取OHLCV数据

        参数:
            since: 开始时间戳
            total_limit: 总数据限制

        返回:
            OHLCV数据列表
        """
        all_ohlcv = []
        current_since = since
        batch_size = min(1000, total_limit)  # 每批最多1000条

        try:
            while len(all_ohlcv) < total_limit:
                # 计算本批次需要获取的数量
                remaining = total_limit - len(all_ohlcv)
                current_limit = min(batch_size, remaining)

                logger.debug(f"获取数据批次: since={current_since}, limit={current_limit}")

                # 获取本批次数据
                batch_ohlcv = self.exchange.fetch_ohlcv(
                    self.symbol,
                    self.timeframe,
                    since=current_since,
                    limit=current_limit
                )

                if not batch_ohlcv:
                    logger.warning("获取到空数据，停止批次获取")
                    break

                # 添加到总数据中
                all_ohlcv.extend(batch_ohlcv)

                # 更新下一批次的开始时间
                last_timestamp = batch_ohlcv[-1][0]
                current_since = last_timestamp + self.timeframe_seconds * 1000

                # 如果获取的数据少于请求的数量，说明已经到了最新数据
                if len(batch_ohlcv) < current_limit:
                    logger.info("已获取到最新数据")
                    break

                # 避免API频率限制
                time.sleep(0.1)

            logger.info(f"分批获取完成，总共获取 {len(all_ohlcv)} 条数据")
            return all_ohlcv

        except Exception as e:
            logger.error(f"分批获取数据失败: {e}")
            return all_ohlcv  # 返回已获取的数据

    def _start_live_data(self):
        """启动实时数据"""
        if not self.live:
            return

        self.running = True
        self.update_thread = threading.Thread(target=self._update_live_data)
        self.update_thread.daemon = True
        self.update_thread.start()

        logger.info(f"启动实时数据: {self.symbol}")

    def _update_live_data(self):
        """更新实时数据"""
        while self.running:
            try:
                # 获取最新的K线数据
                ohlcv = self.exchange.fetch_ohlcv(
                    self.symbol,
                    self.timeframe,
                    limit=1
                )

                if ohlcv:
                    candle = ohlcv[0]
                    timestamp, open_price, high, low, close, volume = candle

                    # 转换时间戳
                    dt = datetime.fromtimestamp(timestamp / 1000)

                    # 检查是否是新的K线
                    if not self.last_update or dt > self.last_update:
                        new_data = {
                            'datetime': dt,
                            'open': open_price,
                            'high': high,
                            'low': low,
                            'close': close,
                            'volume': volume,
                            'openinterest': 0.0
                        }

                        self.live_data.append(new_data)
                        self.last_update = dt

                        if self.p.debug:
                            logger.debug(f"新K线数据: {dt} OHLCV={open_price}/{high}/{low}/{close}/{volume}")

                # 等待下一次更新
                time.sleep(min(30, self.timeframe_seconds // 2))  # 最多等待30秒

            except Exception as e:
                logger.error(f"更新实时数据失败: {e}")
                time.sleep(60)  # 出错时等待1分钟

    def _load(self):
        """加载下一条数据"""
        # 首先处理历史数据
        if self.current_index < len(self.data_cache):
            data = self.data_cache[self.current_index]
            self.current_index += 1

            # 设置数据
            self.lines.datetime[0] = bt.date2num(data['datetime'])
            self.lines.open[0] = data['open']
            self.lines.high[0] = data['high']
            self.lines.low[0] = data['low']
            self.lines.close[0] = data['close']
            self.lines.volume[0] = data['volume']
            self.lines.openinterest[0] = data['openinterest']

            return True

        # 然后处理实时数据
        if self.live and self.live_data:
            data = self.live_data.pop(0)

            # 设置数据
            self.lines.datetime[0] = bt.date2num(data['datetime'])
            self.lines.open[0] = data['open']
            self.lines.high[0] = data['high']
            self.lines.low[0] = data['low']
            self.lines.close[0] = data['close']
            self.lines.volume[0] = data['volume']
            self.lines.openinterest[0] = data['openinterest']

            return True

        # 没有更多数据
        return False

class CCXTStore:
    """
    CCXT存储类

    管理CCXT交易所连接和数据源
    """

    def __init__(self, exchange_name: str = 'binance', config: Optional[Dict] = None):
        """
        初始化CCXT存储

        参数:
            exchange_name: 交易所名称
            config: 交易所配置
        """
        self.exchange_name = exchange_name
        self.config = config or {}

        # 初始化交易所
        self.exchange = self._init_exchange()

        # 数据源缓存
        self.data_feeds = {}

        logger.info(f"初始化CCXT存储: {exchange_name}")

    def _init_exchange(self):
        """初始化交易所"""
        try:
            exchange_class = getattr(ccxt, self.exchange_name)

            # 设置默认配置
            default_config = {
                'apiKey': '',
                'secret': '',
                'password': '',  # 某些交易所需要
                'sandbox': True,  # 默认使用测试环境
                'enableRateLimit': True,
                'options': {
                    'defaultType': 'future',  # 期货交易
                }
            }

            # 合并配置
            config = {**default_config, **self.config}

            exchange = exchange_class(config)

            # 加载市场信息
            exchange.load_markets()

            logger.info(f"交易所初始化成功: {self.exchange_name}")
            return exchange

        except Exception as e:
            logger.error(f"交易所初始化失败: {e}")
            return None

    def getdata(self, symbol: str, timeframe: str = '1m', **kwargs) -> CCXTData:
        """
        获取数据源

        参数:
            symbol: 交易对符号
            timeframe: 时间框架
            **kwargs: 其他参数

        返回:
            CCXT数据源
        """
        # 创建数据源键
        key = f"{symbol}_{timeframe}"

        if key not in self.data_feeds:
            # 创建新的数据源
            data_feed = CCXTData(
                exchange=self.exchange,
                symbol=symbol,
                timeframe=timeframe,
                **kwargs
            )

            self.data_feeds[key] = data_feed

        return self.data_feeds[key]

    def get_exchange(self):
        """获取交易所对象"""
        return self.exchange
