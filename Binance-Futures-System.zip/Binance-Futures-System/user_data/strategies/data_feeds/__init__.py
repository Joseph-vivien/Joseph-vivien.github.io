#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
数据源模块初始化文件
"""

from user_data.strategies.data_feeds.ccxt_data import CCXTData, CCXTStore

__all__ = ['CCXTData', 'CCXTStore']
