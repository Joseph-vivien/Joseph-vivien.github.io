#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
风险管理模块

该模块负责管理交易风险，包括仓位管理、止损设置、风险评估和资金管理。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import math

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.volatility_analyzer import VolatilityAnalyzer
from user_data.strategies.modules.risk_manager.global_risk_monitor import GlobalRiskMonitor, SystemRiskLevel
from user_data.strategies.modules.risk_manager.position_risk_calculator import PositionRiskCalculator
from user_data.strategies.modules.risk_manager.stop_loss_manager import StopLossManager, StopLossType

# 获取日志记录器
logger = get_logger("risk_manager")

class RiskLevel(Enum):
    """风险级别枚举"""
    LOW = "低风险"
    MEDIUM = "中等风险"
    HIGH = "高风险"
    EXTREME = "极高风险"

class PositionSizing(Enum):
    """仓位大小计算方法枚举"""
    FIXED = "固定金额"
    PERCENTAGE = "账户百分比"
    VOLATILITY = "波动率调整"
    KELLY = "凯利公式"
    OPTIMAL_F = "最优f值"

class RiskManager:
    """
    风险管理类

    负责管理交易风险，包括仓位管理、止损设置、风险评估和资金管理
    """

    def __init__(self):
        """初始化风险管理器"""
        # 加载配置
        self.config_manager = get_config_manager()

        # 风险参数
        self.params = {
            # 账户风险参数
            'max_account_risk_pct': 2.0,  # 单笔交易最大账户风险百分比
            'max_position_size_pct': 20.0,  # 单个仓位最大账户百分比
            'max_total_risk_pct': 50.0,  # 总风险敞口最大账户百分比
            'max_drawdown_pct': 15.0,  # 最大允许回撤百分比

            # 止损参数
            'stoploss_pct': 2.0,  # 默认止损百分比
            'trailing_stop': True,  # 是否启用追踪止损
            'trailing_stop_positive': 0.5,  # 追踪止损激活百分比
            'trailing_stop_positive_offset': 0.0,  # 追踪止损偏移量
            'trailing_only_offset_is_reached': False,  # 是否仅在达到偏移量时启用追踪止损

            # 仓位管理参数
            'position_sizing_method': PositionSizing.PERCENTAGE,  # 仓位大小计算方法
            'fixed_position_size': 100.0,  # 固定仓位大小
            'percentage_position_size': 5.0,  # 账户百分比仓位大小
            'volatility_lookback': 20,  # 波动率计算回溯期
            'volatility_factor': 1.0,  # 波动率调整因子
            'kelly_fraction': 0.5,  # 凯利公式分数
            'optimal_f': 0.1,  # 最优f值

            # 风险评估参数
            'risk_free_rate': 0.0,  # 无风险利率
            'target_sharpe': 1.0,  # 目标夏普比率
            'max_correlation': 0.7,  # 最大相关性
            'max_var_pct': 5.0,  # 最大风险价值百分比

            # 资金管理参数
            'reserve_pct': 10.0,  # 保留资金百分比
            'profit_taking_pct': 20.0,  # 利润提取百分比
            'reinvestment_pct': 50.0  # 利润再投资百分比
        }

        # 初始化波动率分析器
        self.volatility_analyzer = VolatilityAnalyzer()

        # 初始化全局风险监控器
        self.global_risk_monitor = GlobalRiskMonitor()

        # 初始化仓位风险计算器
        self.position_risk_calculator = PositionRiskCalculator()

        # 初始化止损管理器
        self.stop_loss_manager = StopLossManager()

        # 当前持仓
        self.positions = {}

        # 账户信息
        self.account = {
            'balance': 0.0,
            'equity': 0.0,
            'used_margin': 0.0,
            'free_margin': 0.0,
            'positions_value': 0.0,
            'open_positions': 0
        }

        # 启动风险监控
        self.global_risk_monitor.start_monitoring()

    def update_account(self, account_info: Dict[str, float]) -> None:
        """
        更新账户信息

        参数:
            account_info: 账户信息字典
        """
        self.account.update(account_info)
        logger.debug(f"已更新账户信息: {self.account}")

    def update_positions(self, positions: Dict[str, Dict[str, Any]]) -> None:
        """
        更新持仓信息

        参数:
            positions: 持仓信息字典 {symbol: position_info}
        """
        self.positions = positions
        self.account['open_positions'] = len(positions)
        self.account['positions_value'] = sum(p.get('value', 0.0) for p in positions.values())
        logger.debug(f"已更新持仓信息: {len(positions)} 个持仓")

    def calculate_position_size(self, symbol: str, entry_price: float,
                              stoploss_price: float, data: pd.DataFrame) -> Dict[str, Any]:
        """
        计算仓位大小

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stoploss_price: 止损价格
            data: OHLCV数据

        返回:
            仓位计算结果
        """
        if entry_price <= 0 or stoploss_price <= 0:
            logger.warning(f"无效的价格: entry_price={entry_price}, stoploss_price={stoploss_price}")
            return {
                'position_size': 0.0,
                'position_size_quote': 0.0,
                'risk_amount': 0.0,
                'risk_pct': 0.0,
                'stoploss_pct': 0.0
            }

        try:
            # 计算止损百分比
            is_long = entry_price > stoploss_price
            stoploss_pct = abs(entry_price - stoploss_price) / entry_price * 100

            # 获取账户余额
            balance = self.account.get('balance', 0.0)

            if balance <= 0:
                logger.warning("账户余额为零或负数")
                return {
                    'position_size': 0.0,
                    'position_size_quote': 0.0,
                    'risk_amount': 0.0,
                    'risk_pct': 0.0,
                    'stoploss_pct': stoploss_pct
                }

            # 使用仓位风险计算器计算仓位大小
            self.position_risk_calculator.set_account_balance(balance)

            # 更新市场数据
            if not data.empty:
                market_data = {
                    'volatility': {
                        symbol: self.volatility_analyzer.analyze_volatility(
                            data, short_window=self.params['volatility_lookback']).get('atr_percent', 0.01)
                    }
                }
                self.position_risk_calculator.update_market_data(symbol, market_data)

            # 计算仓位风险
            risk_result = self.position_risk_calculator.calculate_position_risk(
                symbol, 1.0, entry_price, entry_price, stoploss_price, 1.0, data)

            # 根据仓位计算方法确定仓位大小
            method = self.params['position_sizing_method']

            if method == PositionSizing.FIXED:
                # 固定金额
                position_size_quote = self.params['fixed_position_size']

            elif method == PositionSizing.PERCENTAGE:
                # 账户百分比
                position_size_quote = balance * (self.params['percentage_position_size'] / 100)

            elif method == PositionSizing.VOLATILITY:
                # 波动率调整
                if data.empty:
                    logger.warning("数据为空，无法计算波动率调整仓位")
                    position_size_quote = balance * (self.params['percentage_position_size'] / 100)
                else:
                    # 分析波动率
                    volatility = self.volatility_analyzer.analyze_volatility(
                        data, short_window=self.params['volatility_lookback'])

                    # 根据波动率调整仓位
                    volatility_factor = self.params['volatility_factor']
                    atr_percent = volatility.get('atr_percent', 1.0)

                    # 波动率越高，仓位越小
                    position_pct = self.params['percentage_position_size'] / (atr_percent * volatility_factor)
                    position_size_quote = balance * (position_pct / 100)

            elif method == PositionSizing.KELLY:
                # 凯利公式
                # 需要胜率和盈亏比
                win_rate = 0.5  # 默认胜率
                profit_loss_ratio = 2.0  # 默认盈亏比

                # 如果有历史交易数据，可以计算实际胜率和盈亏比
                # TODO: 实现历史交易数据分析

                # 计算凯利比例
                kelly_pct = (win_rate * profit_loss_ratio - (1 - win_rate)) / profit_loss_ratio

                # 应用凯利分数
                kelly_pct *= self.params['kelly_fraction']

                # 限制在合理范围内
                kelly_pct = max(0.0, min(kelly_pct, self.params['max_position_size_pct'] / 100))

                position_size_quote = balance * kelly_pct

            elif method == PositionSizing.OPTIMAL_F:
                # 最优f值
                optimal_f = self.params['optimal_f']
                position_size_quote = balance * optimal_f

            else:
                # 默认使用账户百分比
                position_size_quote = balance * (self.params['percentage_position_size'] / 100)

            # 确保仓位不超过最大允许值
            max_position_size = balance * (self.params['max_position_size_pct'] / 100)
            position_size_quote = min(position_size_quote, max_position_size)

            # 确保风险不超过最大允许值
            risk_amount = balance * (self.params['max_account_risk_pct'] / 100)
            if stoploss_pct > 0:
                max_position_by_risk = risk_amount / (stoploss_pct / 100)
                position_size_quote = min(position_size_quote, max_position_by_risk)

            # 计算实际风险
            actual_risk_amount = position_size_quote * (stoploss_pct / 100)
            actual_risk_pct = (actual_risk_amount / balance) * 100

            # 计算仓位大小（币数量）
            position_size = position_size_quote / entry_price

            # 更新全局风险监控
            self.global_risk_monitor.update_account_info({
                'balance': balance,
                'equity': self.account.get('equity', balance),
                'positions': {
                    symbol: {
                        'value': position_size_quote,
                        'leverage': 1.0
                    }
                }
            })

            return {
                'position_size': position_size,
                'position_size_quote': position_size_quote,
                'risk_amount': actual_risk_amount,
                'risk_pct': actual_risk_pct,
                'stoploss_pct': stoploss_pct,
                'risk_level': risk_result.get('risk_level', 'unknown')
            }

        except Exception as e:
            logger.error(f"计算仓位大小失败: {e}")
            return {
                'position_size': 0.0,
                'position_size_quote': 0.0,
                'risk_amount': 0.0,
                'risk_pct': 0.0,
                'stoploss_pct': 0.0
            }

    def calculate_stoploss(self, symbol: str, entry_price: float,
                         is_long: bool, data: pd.DataFrame) -> Dict[str, Any]:
        """
        计算止损价格

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            is_long: 是否做多
            data: OHLCV数据

        返回:
            止损计算结果
        """
        if entry_price <= 0:
            logger.warning(f"无效的入场价格: {entry_price}")
            return {
                'stoploss_price': 0.0,
                'stoploss_pct': 0.0,
                'risk_reward_ratio': 0.0
            }

        try:
            # 使用止损管理器计算止损价格
            current_price = entry_price  # 初始时当前价格等于入场价格

            # 设置止损管理器参数
            stop_loss_params = {
                'fixed_stop_loss_pct': self.params['stoploss_pct'] / 100,
                'use_trailing_stop': self.params['trailing_stop'],
                'trailing_stop_activation_pct': self.params['trailing_stop_positive'] / 100,
                'trailing_stop_distance_pct': self.params['trailing_stop_positive'] / 100,
                'use_volatility_stop': True,
                'volatility_lookback': self.params['volatility_lookback'],
                'volatility_multiplier': self.params['volatility_factor']
            }
            self.stop_loss_manager.set_parameters(stop_loss_params)

            # 计算止损价格
            stop_loss_result = self.stop_loss_manager.calculate_stop_loss(
                symbol, entry_price, current_price, is_long, data)

            # 获取止损价格和类型
            stoploss_price = stop_loss_result.get('stop_loss_price', 0.0)
            stoploss_type = stop_loss_result.get('stop_loss_type', StopLossType.FIXED.value)
            stoploss_pct = stop_loss_result.get('stop_loss_pct', self.params['stoploss_pct'])

            # 如果止损价格无效，使用默认止损
            if stoploss_price <= 0:
                # 默认止损百分比
                stoploss_pct = self.params['stoploss_pct']

                # 如果有数据，使用波动率调整止损
                if not data.empty:
                    # 计算基于波动率的最优止损
                    optimal_stop = self.volatility_analyzer.calculate_optimal_stop_loss(
                        data, volatility_adjustment=True)

                    if is_long:
                        stoploss_pct = optimal_stop.get('stop_percent', stoploss_pct)
                    else:
                        stoploss_pct = optimal_stop.get('stop_percent', stoploss_pct)

                # 计算止损价格
                if is_long:
                    stoploss_price = entry_price * (1 - stoploss_pct / 100)
                else:
                    stoploss_price = entry_price * (1 + stoploss_pct / 100)

                stoploss_type = StopLossType.FIXED.value

            # 计算风险回报比（假设目标价格是入场价格的两倍止损距离）
            if is_long:
                target_price = entry_price * (1 + stoploss_pct * 2 / 100)
            else:
                target_price = entry_price * (1 - stoploss_pct * 2 / 100)

            risk = abs(entry_price - stoploss_price)
            reward = abs(target_price - entry_price)
            risk_reward_ratio = reward / risk if risk > 0 else 0.0

            # 计算部分止损和分层止损
            partial_stops = self.stop_loss_manager.calculate_partial_stops(
                symbol, entry_price, 1.0, is_long)

            tiered_stops = self.stop_loss_manager.calculate_tiered_stops(
                symbol, entry_price, is_long)

            return {
                'stoploss_price': stoploss_price,
                'stoploss_pct': stoploss_pct,
                'stoploss_type': stoploss_type,
                'target_price': target_price,
                'risk_reward_ratio': risk_reward_ratio,
                'partial_stops': partial_stops,
                'tiered_stops': tiered_stops
            }

        except Exception as e:
            logger.error(f"计算止损价格失败: {e}")
            return {
                'stoploss_price': 0.0,
                'stoploss_pct': 0.0,
                'risk_reward_ratio': 0.0
            }

    def update_trailing_stoploss(self, symbol: str, current_price: float,
                               position_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新追踪止损

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            position_info: 持仓信息

        返回:
            更新后的止损信息
        """
        if not self.params['trailing_stop']:
            return position_info

        try:
            # 获取持仓信息
            entry_price = position_info.get('entry_price', 0.0)
            stoploss_price = position_info.get('stoploss_price', 0.0)
            is_long = position_info.get('is_long', True)

            if entry_price <= 0 or stoploss_price <= 0:
                return position_info

            # 使用止损管理器更新追踪止损
            # 首先计算止损
            stop_loss_result = self.stop_loss_manager.calculate_stop_loss(
                symbol, entry_price, current_price, is_long, None)

            # 获取新的止损价格
            new_stoploss = stop_loss_result.get('stop_loss_price', 0.0)
            stoploss_type = stop_loss_result.get('stop_loss_type', StopLossType.FIXED.value)

            # 如果是追踪止损并且新止损有效
            if stoploss_type == StopLossType.TRAILING.value and new_stoploss > 0:
                # 检查是否需要更新止损
                if is_long:
                    # 只有当新止损高于当前止损时才更新
                    if new_stoploss > stoploss_price:
                        position_info['stoploss_price'] = new_stoploss
                        position_info['stoploss_pct'] = (entry_price - new_stoploss) / entry_price * 100
                        position_info['stoploss_type'] = stoploss_type
                        logger.debug(f"更新做多追踪止损: {symbol} {new_stoploss:.8f}")
                else:
                    # 只有当新止损低于当前止损时才更新
                    if new_stoploss < stoploss_price:
                        position_info['stoploss_price'] = new_stoploss
                        position_info['stoploss_pct'] = (new_stoploss - entry_price) / entry_price * 100
                        position_info['stoploss_type'] = stoploss_type
                        logger.debug(f"更新做空追踪止损: {symbol} {new_stoploss:.8f}")

            # 检查是否需要更新为保本止损
            elif stoploss_type == StopLossType.BREAKEVEN.value and new_stoploss > 0:
                if is_long:
                    # 只有当新止损高于当前止损时才更新
                    if new_stoploss > stoploss_price:
                        position_info['stoploss_price'] = new_stoploss
                        position_info['stoploss_pct'] = (entry_price - new_stoploss) / entry_price * 100
                        position_info['stoploss_type'] = stoploss_type
                        logger.debug(f"更新为保本止损: {symbol} {new_stoploss:.8f}")
                else:
                    # 只有当新止损低于当前止损时才更新
                    if new_stoploss < stoploss_price:
                        position_info['stoploss_price'] = new_stoploss
                        position_info['stoploss_pct'] = (new_stoploss - entry_price) / entry_price * 100
                        position_info['stoploss_type'] = stoploss_type
                        logger.debug(f"更新为保本止损: {symbol} {new_stoploss:.8f}")

            # 检查部分止损是否触发
            triggered_partial_stops = self.stop_loss_manager.check_partial_stops_triggered(symbol, current_price)
            if triggered_partial_stops:
                position_info['triggered_partial_stops'] = triggered_partial_stops
                logger.info(f"触发部分止损: {symbol} {len(triggered_partial_stops)} 个级别")

            # 检查分层止损是否触发
            triggered_tiered_stops = self.stop_loss_manager.check_tiered_stops_triggered(symbol, current_price)
            if triggered_tiered_stops:
                position_info['triggered_tiered_stops'] = triggered_tiered_stops
                logger.info(f"触发分层止损: {symbol} {len(triggered_tiered_stops)} 个级别")

            return position_info

        except Exception as e:
            logger.error(f"更新追踪止损失败: {e}")
            return position_info

    def check_stoploss_hit(self, symbol: str, current_price: float,
                         position_info: Dict[str, Any]) -> bool:
        """
        检查是否触发止损

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            position_info: 持仓信息

        返回:
            是否触发止损
        """
        try:
            # 获取持仓信息
            entry_price = position_info.get('entry_price', 0.0)
            stoploss_price = position_info.get('stoploss_price', 0.0)
            is_long = position_info.get('is_long', True)

            if stoploss_price <= 0:
                return False

            # 使用止损管理器检查止损是否触发
            is_triggered = self.stop_loss_manager.check_stop_loss_triggered(symbol, current_price)

            # 如果止损管理器没有触发，使用传统方法检查
            if not is_triggered:
                # 检查是否触发止损
                if is_long and current_price <= stoploss_price:
                    logger.info(f"触发做多止损: {symbol} 当前价格={current_price:.8f} 止损价格={stoploss_price:.8f}")
                    return True
                elif not is_long and current_price >= stoploss_price:
                    logger.info(f"触发做空止损: {symbol} 当前价格={current_price:.8f} 止损价格={stoploss_price:.8f}")
                    return True
            else:
                logger.info(f"止损管理器触发止损: {symbol} 当前价格={current_price:.8f}")
                return True

            return False

        except Exception as e:
            logger.error(f"检查止损触发失败: {e}")
            return False

    def assess_risk_level(self) -> RiskLevel:
        """
        评估当前风险级别

        返回:
            风险级别
        """
        try:
            # 更新全局风险监控器的账户信息
            self.global_risk_monitor.update_account_info(self.account)

            # 更新全局风险监控器的市场信息
            market_info = {
                'volatility': {},
                'correlation': {},
                'spreads': {},
                'volumes': {}
            }
            self.global_risk_monitor.update_market_info(market_info)

            # 使用全局风险监控器评估风险
            risk_state = self.global_risk_monitor.assess_risk()

            # 获取系统风险级别
            system_risk_level = risk_state.get('system_risk_level', SystemRiskLevel.NORMAL)

            # 将系统风险级别转换为风险级别
            if system_risk_level == SystemRiskLevel.EMERGENCY:
                return RiskLevel.EXTREME
            elif system_risk_level == SystemRiskLevel.EXTREME:
                return RiskLevel.EXTREME
            elif system_risk_level == SystemRiskLevel.HIGH:
                return RiskLevel.HIGH
            elif system_risk_level == SystemRiskLevel.ELEVATED:
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估风险级别失败: {e}")

            # 如果全局风险监控器失败，使用传统方法评估风险
            try:
                # 获取账户信息
                balance = self.account.get('balance', 0.0)
                equity = self.account.get('equity', 0.0)
                positions_value = self.account.get('positions_value', 0.0)
                open_positions = self.account.get('open_positions', 0)

                if balance <= 0:
                    return RiskLevel.EXTREME

                # 计算风险指标
                # 1. 仓位占比
                position_ratio = positions_value / balance if balance > 0 else 0.0

                # 2. 杠杆率
                leverage = positions_value / equity if equity > 0 else 0.0

                # 3. 回撤率
                drawdown = (balance - equity) / balance if balance > 0 else 0.0

                # 4. 集中度（单个仓位的最大占比）
                max_position_ratio = 0.0
                if open_positions > 0:
                    max_position_ratio = max(p.get('value', 0.0) for p in self.positions.values()) / balance if balance > 0 else 0.0

                # 根据风险指标确定风险级别
                if (position_ratio > self.params['max_total_risk_pct'] / 100 or
                    drawdown > self.params['max_drawdown_pct'] / 100 or
                    max_position_ratio > self.params['max_position_size_pct'] / 100 * 1.5 or
                    leverage > 3.0):
                    return RiskLevel.EXTREME
                elif (position_ratio > self.params['max_total_risk_pct'] / 100 * 0.8 or
                     drawdown > self.params['max_drawdown_pct'] / 100 * 0.8 or
                     max_position_ratio > self.params['max_position_size_pct'] / 100 * 1.2 or
                     leverage > 2.0):
                    return RiskLevel.HIGH
                elif (position_ratio > self.params['max_total_risk_pct'] / 100 * 0.5 or
                     drawdown > self.params['max_drawdown_pct'] / 100 * 0.5 or
                     max_position_ratio > self.params['max_position_size_pct'] / 100 or
                     leverage > 1.5):
                    return RiskLevel.MEDIUM
                else:
                    return RiskLevel.LOW

            except Exception as nested_e:
                logger.error(f"传统风险评估也失败: {nested_e}")
                return RiskLevel.HIGH

    def can_open_position(self, symbol: str, position_size_quote: float) -> Tuple[bool, str]:
        """
        检查是否可以开仓

        参数:
            symbol: 交易对符号
            position_size_quote: 仓位大小（计价货币）

        返回:
            (是否可以开仓, 原因)
        """
        try:
            # 获取账户信息
            balance = self.account.get('balance', 0.0)
            equity = self.account.get('equity', 0.0)
            positions_value = self.account.get('positions_value', 0.0)
            open_positions = self.account.get('open_positions', 0)

            if balance <= 0:
                return False, "账户余额为零或负数"

            # 检查风险级别
            risk_level = self.assess_risk_level()

            if risk_level == RiskLevel.EXTREME:
                return False, "当前风险级别极高，禁止开仓"

            # 检查全局风险监控器的风险状态
            risk_state = self.global_risk_monitor.get_risk_state()
            system_risk_level_str = risk_state.get('system_risk_level', 'NORMAL')

            # 将字符串转换为枚举值
            try:
                system_risk_level = SystemRiskLevel[system_risk_level_str]
            except KeyError:
                system_risk_level = SystemRiskLevel.NORMAL

            if system_risk_level in [SystemRiskLevel.EXTREME, SystemRiskLevel.EMERGENCY]:
                return False, f"系统风险级别为{system_risk_level.value}，禁止开仓"

            # 检查是否有活动警报
            active_alerts = self.global_risk_monitor.get_active_alerts()
            if active_alerts:
                for alert in active_alerts:
                    if alert.get('level') in [SystemRiskLevel.EXTREME.value, SystemRiskLevel.EMERGENCY.value]:
                        return False, f"存在高风险警报: {alert.get('message')}"

            # 使用仓位风险计算器评估风险
            self.position_risk_calculator.set_account_balance(balance)

            # 计算仓位风险
            risk_result = self.position_risk_calculator.calculate_position_risk(
                symbol, position_size_quote / 100, 100, 100, 95, 1.0, None)

            # 检查仓位风险级别
            if risk_result.get('risk_level') == "极高风险":
                return False, "仓位风险级别极高，禁止开仓"

            # 计算投资组合风险
            portfolio_risk = self.position_risk_calculator.calculate_portfolio_risk()

            # 检查投资组合风险级别
            if portfolio_risk.get('risk_level') == "极高风险":
                return False, "投资组合风险级别极高，禁止开仓"

            # 检查是否已有相同交易对的持仓
            if symbol in self.positions:
                return False, f"已有 {symbol} 的持仓"

            # 检查仓位大小是否超过最大允许值
            max_position_size = balance * (self.params['max_position_size_pct'] / 100)
            if position_size_quote > max_position_size:
                return False, f"仓位大小 {position_size_quote:.2f} 超过最大允许值 {max_position_size:.2f}"

            # 检查总风险敞口是否超过最大允许值
            new_positions_value = positions_value + position_size_quote
            max_total_risk = balance * (self.params['max_total_risk_pct'] / 100)
            if new_positions_value > max_total_risk:
                return False, f"总风险敞口 {new_positions_value:.2f} 超过最大允许值 {max_total_risk:.2f}"

            # 根据风险级别调整开仓条件
            if risk_level == RiskLevel.HIGH:
                # 高风险时，减少仓位大小
                if position_size_quote > max_position_size * 0.5:
                    return False, f"高风险状态下，仓位大小 {position_size_quote:.2f} 超过调整后的最大允许值 {max_position_size * 0.5:.2f}"

            return True, "可以开仓"

        except Exception as e:
            logger.error(f"检查是否可以开仓失败: {e}")
            return False, f"检查失败: {e}"

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置风险管理参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取风险管理参数

        返回:
            参数字典
        """
        return self.params.copy()
