#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
出场管理器模块

该模块负责管理交易出场，包括止损、止盈、追踪止损和时间出场等策略。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any, TYPE_CHECKING
from enum import Enum
import time
from datetime import datetime, timedelta

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.position_manager import PositionType, PositionStatus
from user_data.strategies.modules.signal_generator import SignalType
from user_data.strategies.modules.market_analyzer import MarketState

# 避免循环导入
if TYPE_CHECKING:
    from user_data.strategies.modules.position_manager.position_manager import PositionManager

# 获取日志记录器
logger = get_logger("exit_manager")

class ExitSignalStatus(Enum):
    """出场信号状态枚举"""
    PENDING = "等待中"
    CONFIRMED = "已确认"
    REJECTED = "已拒绝"
    EXPIRED = "已过期"
    EXECUTED = "已执行"

class ExitType(Enum):
    """出场类型枚举"""
    TAKE_PROFIT = "止盈"
    STOP_LOSS = "止损"
    TRAILING_STOP = "追踪止损"
    TIME_EXIT = "时间出场"
    SIGNAL_EXIT = "信号出场"
    MANUAL_EXIT = "手动出场"
    RISK_EXIT = "风险出场"

class ExitManager:
    """
    出场管理器类

    负责管理交易出场，包括止损、止盈、追踪止损和时间出场等策略
    """

    def __init__(self, position_manager: Optional['PositionManager'] = None):
        """
        初始化出场管理器

        参数:
            position_manager: 仓位管理器
        """
        self.position_manager = position_manager

        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 止损参数
            'use_stop_loss': True,  # 是否使用止损
            'stop_loss_pct': 0.02,  # 默认止损百分比（2%）
            'dynamic_stop_loss': True,  # 是否使用动态止损
            'atr_stop_loss_multiplier': 2.0,  # ATR止损乘数
            'min_stop_loss_pct': 0.01,  # 最小止损百分比（1%）
            'max_stop_loss_pct': 0.05,  # 最大止损百分比（5%）

            # 止盈参数
            'use_take_profit': True,  # 是否使用止盈
            'take_profit_pct': 0.05,  # 默认止盈百分比（5%）
            'dynamic_take_profit': True,  # 是否使用动态止盈
            'atr_take_profit_multiplier': 3.0,  # ATR止盈乘数
            'min_take_profit_pct': 0.02,  # 最小止盈百分比（2%）
            'max_take_profit_pct': 0.2,  # 最大止盈百分比（20%）

            # 追踪止损参数
            'use_trailing_stop': True,  # 是否使用追踪止损
            'trailing_stop_activation_pct': 0.02,  # 追踪止损激活百分比（2%）
            'trailing_stop_distance_pct': 0.01,  # 追踪止损距离百分比（1%）
            'trailing_stop_step_pct': 0.005,  # 追踪止损步长百分比（0.5%）

            # 分段出场参数
            'use_staged_exit': True,  # 是否使用分段出场
            'profit_targets': [0.03, 0.05, 0.1],  # 利润目标（3%, 5%, 10%）
            'exit_percentages': [0.3, 0.3, 0.4],  # 出场百分比（30%, 30%, 40%）

            # 时间出场参数
            'use_time_exit': True,  # 是否使用时间出场
            'max_trade_duration': 24 * 60 * 60,  # 最大交易持续时间（秒）
            'time_exit_percentage': 1.0,  # 时间出场百分比（100%）

            # 信号出场参数
            'use_signal_exit': True,  # 是否使用信号出场
            'signal_exit_confirmation': 2,  # 信号出场确认数
            'signal_exit_percentage': 1.0,  # 信号出场百分比（100%）

            # 风险出场参数
            'use_risk_exit': True,  # 是否使用风险出场
            'max_loss_per_trade': 0.02,  # 单笔交易最大亏损（账户的2%）
            'max_loss_per_day': 0.05,  # 每日最大亏损（账户的5%）
            'max_consecutive_losses': 3,  # 最大连续亏损次数

            # 出场订单参数
            'use_limit_exit': True,  # 是否使用限价单出场
            'limit_price_buffer': 0.001,  # 限价缓冲（0.1%）
            'max_slippage': 0.002,  # 最大滑点（0.2%）
            'retry_attempts': 3,  # 重试次数
            'retry_delay': 5,  # 重试延迟（秒）
        }

        # 出场信号队列
        self.exit_signals = []  # [{symbol, exit_type, position_type, price, timestamp, status, ...}]

        # 出场历史
        self.exit_history = []

        # 追踪止损状态
        self.trailing_stops = {}  # {symbol: {activation_price, current_stop, ...}}

        # 分段出场状态
        self.staged_exits = {}  # {symbol: [{target_price, exit_pct, status}, ...]}

        # 风险管理状态
        self.risk_state = {
            'daily_loss': 0.0,
            'consecutive_losses': 0,
            'last_reset_date': datetime.now().date()
        }

    def add_exit_signal(self, symbol: str, exit_type: ExitType,
                      price: float, exit_percentage: float = 1.0,
                      reason: str = "") -> Dict[str, Any]:
        """
        添加出场信号

        参数:
            symbol: 交易对符号
            exit_type: 出场类型
            price: 出场价格
            exit_percentage: 出场百分比
            reason: 出场原因

        返回:
            出场信号信息
        """
        try:
            # 检查是否有持仓
            if self.position_manager and symbol not in self.position_manager.get_all_positions():
                logger.warning(f"未找到 {symbol} 的持仓，无法添加出场信号")
                return {
                    'symbol': symbol,
                    'status': ExitSignalStatus.REJECTED,
                    'reason': '未找到持仓'
                }

            # 获取持仓信息
            position = self.position_manager.get_position(symbol) if self.position_manager else None

            if position is None:
                logger.warning(f"未找到 {symbol} 的持仓信息，无法添加出场信号")
                return {
                    'symbol': symbol,
                    'status': ExitSignalStatus.REJECTED,
                    'reason': '未找到持仓信息'
                }

            # 检查是否已有相同类型的出场信号
            for signal in self.exit_signals:
                if signal['symbol'] == symbol and signal['exit_type'] == exit_type and signal['status'] == ExitSignalStatus.PENDING:
                    logger.info(f"已存在 {symbol} 的 {exit_type.value} 出场信号，忽略新信号")
                    return signal

            # 创建出场信号
            exit_signal = {
                'symbol': symbol,
                'exit_type': exit_type,
                'position_type': position['position_type'],
                'price': price,
                'exit_percentage': min(exit_percentage, 1.0),  # 确保不超过100%
                'reason': reason,
                'timestamp': datetime.now(),
                'status': ExitSignalStatus.PENDING,
                'confirmations': 0,
                'confirmation_prices': [],
                'optimized_exit_price': price,
                'expiry_time': datetime.now() + timedelta(seconds=300)  # 5分钟过期
            }

            # 添加到信号队列
            self.exit_signals.append(exit_signal)

            logger.info(f"添加出场信号: {symbol} {exit_type.value} @ {price} ({exit_percentage:.0%})")

            return exit_signal

        except Exception as e:
            logger.error(f"添加出场信号失败: {e}")
            return {
                'symbol': symbol,
                'status': ExitSignalStatus.REJECTED,
                'reason': f'添加信号失败: {e}'
            }

    def update_exit_signal(self, symbol: str, current_price: float) -> Dict[str, Any]:
        """
        更新出场信号

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            更新后的出场信号信息
        """
        try:
            # 查找信号
            signal = None
            for s in self.exit_signals:
                if s['symbol'] == symbol and s['status'] == ExitSignalStatus.PENDING:
                    signal = s
                    break

            if signal is None:
                return None

            # 检查信号是否过期
            if datetime.now() > signal['expiry_time']:
                signal['status'] = ExitSignalStatus.EXPIRED
                logger.info(f"出场信号已过期: {symbol} {signal['exit_type'].value}")

                # 添加到历史记录
                self.exit_history.append(signal)

                # 从队列中移除
                self.exit_signals.remove(signal)

                return signal

            # 更新确认价格
            signal['confirmation_prices'].append(current_price)

            # 保留最近的3个价格
            if len(signal['confirmation_prices']) > 3:
                signal['confirmation_prices'] = signal['confirmation_prices'][-3:]

            # 检查价格确认
            price_confirmed = False
            if len(signal['confirmation_prices']) >= 2:  # 至少需要2个价格确认
                if signal['exit_type'] == ExitType.STOP_LOSS or signal['exit_type'] == ExitType.TRAILING_STOP:
                    # 止损信号：价格应该低于或等于止损价格（多头）或高于或等于止损价格（空头）
                    if signal['position_type'] == PositionType.LONG:
                        price_confirmed = sum(1 for p in signal['confirmation_prices'] if p <= signal['price']) >= 2
                    else:
                        price_confirmed = sum(1 for p in signal['confirmation_prices'] if p >= signal['price']) >= 2
                elif signal['exit_type'] == ExitType.TAKE_PROFIT:
                    # 止盈信号：价格应该高于或等于止盈价格（多头）或低于或等于止盈价格（空头）
                    if signal['position_type'] == PositionType.LONG:
                        price_confirmed = sum(1 for p in signal['confirmation_prices'] if p >= signal['price']) >= 2
                    else:
                        price_confirmed = sum(1 for p in signal['confirmation_prices'] if p <= signal['price']) >= 2
                else:
                    # 其他信号：简单确认
                    price_confirmed = True

            # 更新确认计数
            if price_confirmed:
                signal['confirmations'] += 1
            else:
                signal['confirmations'] = 0

            # 检查是否达到确认阈值
            if signal['confirmations'] >= 2:  # 需要连续2次确认
                signal['status'] = ExitSignalStatus.CONFIRMED
                logger.info(f"出场信号已确认: {symbol} {signal['exit_type'].value}")

                # 优化出场价格
                signal['optimized_exit_price'] = self._optimize_exit_price(signal, current_price)

                # 执行出场
                self._execute_exit(signal)

            return signal

        except Exception as e:
            logger.error(f"更新出场信号失败: {e}")
            return None

    def _optimize_exit_price(self, signal: Dict[str, Any], current_price: float) -> float:
        """
        优化出场价格

        参数:
            signal: 出场信号
            current_price: 当前价格

        返回:
            优化后的出场价格
        """
        try:
            # 初始化为当前价格
            optimized_price = current_price

            # 根据出场类型调整价格
            if signal['exit_type'] == ExitType.STOP_LOSS or signal['exit_type'] == ExitType.TRAILING_STOP:
                # 止损出场：使用市价单或略低于当前价格的限价单（多头）或略高于当前价格的限价单（空头）
                if self.params['use_limit_exit']:
                    if signal['position_type'] == PositionType.LONG:
                        optimized_price = current_price * (1 - self.params['limit_price_buffer'])
                    else:
                        optimized_price = current_price * (1 + self.params['limit_price_buffer'])
                else:
                    optimized_price = current_price
            elif signal['exit_type'] == ExitType.TAKE_PROFIT:
                # 止盈出场：使用限价单，价格略高于当前价格（多头）或略低于当前价格（空头）
                if self.params['use_limit_exit']:
                    if signal['position_type'] == PositionType.LONG:
                        optimized_price = current_price * (1 + self.params['limit_price_buffer'])
                    else:
                        optimized_price = current_price * (1 - self.params['limit_price_buffer'])
                else:
                    optimized_price = current_price
            else:
                # 其他出场类型：使用市价单
                optimized_price = current_price

            return optimized_price

        except Exception as e:
            logger.error(f"优化出场价格失败: {e}")
            return current_price

    def _execute_exit(self, signal: Dict[str, Any]) -> bool:
        """
        执行出场

        参数:
            signal: 出场信号

        返回:
            是否执行成功
        """
        try:
            if self.position_manager is None:
                logger.warning("仓位管理器未设置，无法执行出场")
                return False

            # 获取持仓信息
            position = self.position_manager.get_position(signal['symbol'])

            if position is None:
                logger.warning(f"未找到 {signal['symbol']} 的持仓，无法执行出场")
                return False

            # 计算出场数量
            exit_size = position['size'] * signal['exit_percentage']

            # 创建出场订单
            exit_order = self.position_manager.create_exit_order(
                signal['symbol'],
                signal['optimized_exit_price'],
                exit_size,
                f"{signal['exit_type'].value}: {signal['reason']}"
            )

            # 更新信号状态
            signal['status'] = ExitSignalStatus.EXECUTED
            signal['exit_order'] = exit_order

            # 添加到历史记录
            self.exit_history.append(signal)

            # 从队列中移除
            self.exit_signals.remove(signal)

            logger.info(f"执行出场: {signal['symbol']} {exit_size} @ {signal['optimized_exit_price']} ({signal['exit_type'].value})")

            # 更新风险管理状态
            if signal['exit_type'] == ExitType.STOP_LOSS:
                self.risk_state['consecutive_losses'] += 1

                # 计算亏损金额
                if position['position_type'] == PositionType.LONG:
                    loss = (position['entry_price'] - signal['optimized_exit_price']) * exit_size
                else:
                    loss = (signal['optimized_exit_price'] - position['entry_price']) * exit_size

                # 更新每日亏损
                self._update_daily_loss(loss)
            else:
                # 非止损出场，重置连续亏损计数
                self.risk_state['consecutive_losses'] = 0

            return True

        except Exception as e:
            logger.error(f"执行出场失败: {e}")
            return False

    def _update_daily_loss(self, loss: float) -> None:
        """
        更新每日亏损

        参数:
            loss: 亏损金额
        """
        try:
            # 检查是否需要重置每日亏损
            current_date = datetime.now().date()
            if current_date != self.risk_state['last_reset_date']:
                self.risk_state['daily_loss'] = 0.0
                self.risk_state['last_reset_date'] = current_date

            # 更新每日亏损
            self.risk_state['daily_loss'] += loss

        except Exception as e:
            logger.error(f"更新每日亏损失败: {e}")

    def update_trailing_stop(self, symbol: str, current_price: float) -> Optional[Dict[str, Any]]:
        """
        更新追踪止损

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            更新后的追踪止损信息
        """
        try:
            # 检查是否启用追踪止损
            if not self.params['use_trailing_stop']:
                return None

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return None

            # 获取持仓信息
            position = self.position_manager.get_position(symbol)

            # 检查是否已有追踪止损
            if symbol not in self.trailing_stops:
                # 创建新的追踪止损
                activation_price = 0.0

                if position['position_type'] == PositionType.LONG:
                    # 多头：激活价格 = 入场价格 * (1 + 激活百分比)
                    activation_price = position['entry_price'] * (1 + self.params['trailing_stop_activation_pct'])
                    current_stop = position['stop_loss_price']  # 初始止损价格
                else:
                    # 空头：激活价格 = 入场价格 * (1 - 激活百分比)
                    activation_price = position['entry_price'] * (1 - self.params['trailing_stop_activation_pct'])
                    current_stop = position['stop_loss_price']  # 初始止损价格

                self.trailing_stops[symbol] = {
                    'activation_price': activation_price,
                    'current_stop': current_stop,
                    'highest_price': position['entry_price'] if position['position_type'] == PositionType.LONG else float('inf'),
                    'lowest_price': position['entry_price'] if position['position_type'] == PositionType.SHORT else 0.0,
                    'activated': False,
                    'last_update_time': datetime.now()
                }

            # 获取追踪止损信息
            trailing_stop = self.trailing_stops[symbol]

            # 更新最高/最低价格
            if position['position_type'] == PositionType.LONG:
                trailing_stop['highest_price'] = max(trailing_stop['highest_price'], current_price)
            else:
                trailing_stop['lowest_price'] = min(trailing_stop['lowest_price'], current_price)

            # 检查是否达到激活条件
            if not trailing_stop['activated']:
                if ((position['position_type'] == PositionType.LONG and current_price >= trailing_stop['activation_price']) or
                    (position['position_type'] == PositionType.SHORT and current_price <= trailing_stop['activation_price'])):
                    trailing_stop['activated'] = True
                    logger.info(f"追踪止损已激活: {symbol} @ {current_price}")

            # 如果已激活，更新止损价格
            if trailing_stop['activated']:
                new_stop = trailing_stop['current_stop']

                if position['position_type'] == PositionType.LONG:
                    # 多头：新止损 = 最高价 * (1 - 追踪距离)
                    calculated_stop = trailing_stop['highest_price'] * (1 - self.params['trailing_stop_distance_pct'])

                    # 只有当新止损高于当前止损时才更新
                    if calculated_stop > trailing_stop['current_stop']:
                        new_stop = calculated_stop
                else:
                    # 空头：新止损 = 最低价 * (1 + 追踪距离)
                    calculated_stop = trailing_stop['lowest_price'] * (1 + self.params['trailing_stop_distance_pct'])

                    # 只有当新止损低于当前止损时才更新
                    if calculated_stop < trailing_stop['current_stop']:
                        new_stop = calculated_stop

                # 如果止损价格有变化，更新止损
                if new_stop != trailing_stop['current_stop']:
                    trailing_stop['current_stop'] = new_stop
                    trailing_stop['last_update_time'] = datetime.now()
                    logger.info(f"更新追踪止损: {symbol} {new_stop:.8f}")

                    # 检查是否触发止损
                    if ((position['position_type'] == PositionType.LONG and current_price <= new_stop) or
                        (position['position_type'] == PositionType.SHORT and current_price >= new_stop)):
                        # 添加止损出场信号
                        self.add_exit_signal(
                            symbol,
                            ExitType.TRAILING_STOP,
                            current_price,
                            1.0,  # 全部平仓
                            "追踪止损触发"
                        )

            return trailing_stop

        except Exception as e:
            logger.error(f"更新追踪止损失败: {e}")
            return None

    def setup_staged_exit(self, symbol: str) -> bool:
        """
        设置分段出场

        参数:
            symbol: 交易对符号

        返回:
            是否设置成功
        """
        try:
            # 检查是否启用分段出场
            if not self.params['use_staged_exit']:
                return False

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return False

            # 获取持仓信息
            position = self.position_manager.get_position(symbol)

            # 检查是否已设置分段出场
            if symbol in self.staged_exits:
                return True

            # 创建分段出场目标
            targets = []

            for i, target_pct in enumerate(self.params['profit_targets']):
                # 计算目标价格
                if position['position_type'] == PositionType.LONG:
                    target_price = position['entry_price'] * (1 + target_pct)
                else:
                    target_price = position['entry_price'] * (1 - target_pct)

                # 添加到目标列表
                targets.append({
                    'target_pct': target_pct,
                    'target_price': target_price,
                    'exit_pct': self.params['exit_percentages'][i],
                    'status': 'PENDING'
                })

            # 保存分段出场目标
            self.staged_exits[symbol] = targets

            logger.info(f"设置分段出场: {symbol} {len(targets)} 个目标")

            return True

        except Exception as e:
            logger.error(f"设置分段出场失败: {e}")
            return False

    def check_staged_exit(self, symbol: str, current_price: float) -> bool:
        """
        检查分段出场

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            是否触发出场
        """
        try:
            # 检查是否启用分段出场
            if not self.params['use_staged_exit']:
                return False

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return False

            # 检查是否已设置分段出场
            if symbol not in self.staged_exits:
                self.setup_staged_exit(symbol)

            # 获取持仓信息
            position = self.position_manager.get_position(symbol)

            # 获取分段出场目标
            targets = self.staged_exits[symbol]

            # 检查是否有目标触发
            triggered = False

            for target in targets:
                if target['status'] == 'PENDING':
                    # 检查是否达到目标价格
                    if ((position['position_type'] == PositionType.LONG and current_price >= target['target_price']) or
                        (position['position_type'] == PositionType.SHORT and current_price <= target['target_price'])):

                        # 添加止盈出场信号
                        self.add_exit_signal(
                            symbol,
                            ExitType.TAKE_PROFIT,
                            current_price,
                            target['exit_pct'],
                            f"分段出场 {target['target_pct'] * 100:.1f}%"
                        )

                        # 更新目标状态
                        target['status'] = 'TRIGGERED'
                        triggered = True

                        logger.info(f"触发分段出场: {symbol} {target['target_pct'] * 100:.1f}% @ {current_price}")

                        # 只触发一个目标
                        break

            return triggered

        except Exception as e:
            logger.error(f"检查分段出场失败: {e}")
            return False

    def check_time_exit(self, symbol: str, current_price: float) -> bool:
        """
        检查时间出场

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            是否触发出场
        """
        try:
            # 检查是否启用时间出场
            if not self.params['use_time_exit']:
                return False

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return False

            # 获取持仓信息
            position = self.position_manager.get_position(symbol)

            # 检查是否达到最大持仓时间
            if (datetime.now() - position['entry_time']).total_seconds() >= self.params['max_trade_duration']:
                # 添加时间出场信号
                self.add_exit_signal(
                    symbol,
                    ExitType.TIME_EXIT,
                    current_price,
                    self.params['time_exit_percentage'],
                    "最大持仓时间到达"
                )

                logger.info(f"触发时间出场: {symbol} @ {current_price}")

                return True

            return False

        except Exception as e:
            logger.error(f"检查时间出场失败: {e}")
            return False

    def check_risk_exit(self, symbol: str, current_price: float, account_balance: float) -> bool:
        """
        检查风险出场

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            account_balance: 账户余额

        返回:
            是否触发出场
        """
        try:
            # 检查是否启用风险出场
            if not self.params['use_risk_exit']:
                return False

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return False

            # 获取持仓信息
            position = self.position_manager.get_position(symbol)

            # 计算当前亏损
            current_loss = 0.0

            if position['position_type'] == PositionType.LONG:
                if current_price < position['entry_price']:
                    current_loss = (position['entry_price'] - current_price) * position['size']
            else:
                if current_price > position['entry_price']:
                    current_loss = (current_price - position['entry_price']) * position['size']

            # 检查单笔交易最大亏损
            max_loss_amount = account_balance * self.params['max_loss_per_trade']

            if current_loss > max_loss_amount:
                # 添加风险出场信号
                self.add_exit_signal(
                    symbol,
                    ExitType.RISK_EXIT,
                    current_price,
                    1.0,  # 全部平仓
                    "单笔交易最大亏损"
                )

                logger.info(f"触发风险出场(单笔最大亏损): {symbol} 亏损={current_loss:.2f} > {max_loss_amount:.2f}")

                return True

            # 检查每日最大亏损
            max_daily_loss = account_balance * self.params['max_loss_per_day']

            if self.risk_state['daily_loss'] + current_loss > max_daily_loss:
                # 添加风险出场信号
                self.add_exit_signal(
                    symbol,
                    ExitType.RISK_EXIT,
                    current_price,
                    1.0,  # 全部平仓
                    "每日最大亏损"
                )

                logger.info(f"触发风险出场(每日最大亏损): {symbol} 总亏损={self.risk_state['daily_loss'] + current_loss:.2f} > {max_daily_loss:.2f}")

                return True

            # 检查最大连续亏损
            if self.risk_state['consecutive_losses'] >= self.params['max_consecutive_losses']:
                # 添加风险出场信号
                self.add_exit_signal(
                    symbol,
                    ExitType.RISK_EXIT,
                    current_price,
                    1.0,  # 全部平仓
                    "最大连续亏损"
                )

                logger.info(f"触发风险出场(最大连续亏损): {symbol} 连续亏损={self.risk_state['consecutive_losses']} >= {self.params['max_consecutive_losses']}")

                return True

            return False

        except Exception as e:
            logger.error(f"检查风险出场失败: {e}")
            return False

    def update_position(self, symbol: str, current_price: float, account_balance: float) -> Dict[str, Any]:
        """
        更新持仓状态

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            account_balance: 账户余额

        返回:
            更新结果
        """
        try:
            result = {
                'symbol': symbol,
                'price': current_price,
                'exits_triggered': []
            }

            # 检查是否有持仓
            if self.position_manager is None or symbol not in self.position_manager.get_all_positions():
                return result

            # 更新追踪止损
            trailing_stop = self.update_trailing_stop(symbol, current_price)
            if trailing_stop and trailing_stop.get('activated', False):
                result['trailing_stop'] = trailing_stop

            # 检查分段出场
            if self.check_staged_exit(symbol, current_price):
                result['exits_triggered'].append('staged_exit')

            # 检查时间出场
            if self.check_time_exit(symbol, current_price):
                result['exits_triggered'].append('time_exit')

            # 检查风险出场
            if self.check_risk_exit(symbol, current_price, account_balance):
                result['exits_triggered'].append('risk_exit')

            # 更新出场信号
            for signal in list(self.exit_signals):
                if signal['symbol'] == symbol and signal['status'] == ExitSignalStatus.PENDING:
                    self.update_exit_signal(symbol, current_price)

            return result

        except Exception as e:
            logger.error(f"更新持仓状态失败: {e}")
            return {
                'symbol': symbol,
                'price': current_price,
                'error': str(e)
            }

    def get_pending_signals(self) -> List[Dict[str, Any]]:
        """
        获取待处理的出场信号

        返回:
            待处理的出场信号列表
        """
        return [s for s in self.exit_signals if s['status'] == ExitSignalStatus.PENDING]

    def get_exit_history(self) -> List[Dict[str, Any]]:
        """
        获取出场历史

        返回:
            出场历史列表
        """
        return self.exit_history

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置出场管理参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取出场管理参数

        返回:
            参数字典
        """
        return self.params.copy()
