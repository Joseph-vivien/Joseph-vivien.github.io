#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
入场管理器模块

该模块负责管理交易入场，包括入场信号确认、入场时机优化和入场订单执行。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any, TYPE_CHECKING
from enum import Enum
import time
from datetime import datetime, timedelta

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.position_manager import PositionType, PositionStatus
from user_data.strategies.modules.signal_generator import SignalType
from user_data.strategies.modules.market_analyzer import MarketState

# 避免循环导入
if TYPE_CHECKING:
    from user_data.strategies.modules.position_manager.position_manager import PositionManager

# 获取日志记录器
logger = get_logger("entry_manager")

class EntrySignalStatus(Enum):
    """入场信号状态枚举"""
    PENDING = "等待中"
    CONFIRMED = "已确认"
    REJECTED = "已拒绝"
    EXPIRED = "已过期"
    EXECUTED = "已执行"

class EntryType(Enum):
    """入场类型枚举"""
    MARKET = "市价入场"
    LIMIT = "限价入场"
    STOP = "止损入场"
    STOP_LIMIT = "止损限价入场"

class EntryManager:
    """
    入场管理器类

    负责管理交易入场，包括入场信号确认、入场时机优化和入场订单执行
    """

    def __init__(self, position_manager: Optional['PositionManager'] = None):
        """
        初始化入场管理器

        参数:
            position_manager: 仓位管理器
        """
        self.position_manager = position_manager

        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 信号确认参数
            'min_signal_strength': 0.6,  # 最小信号强度
            'confirmation_window': 3,  # 确认窗口（K线数）
            'confirmation_threshold': 2,  # 确认阈值（需要多少个K线确认）
            'signal_expiry': 60 * 60,  # 信号过期时间（秒）
            'require_volume_confirmation': True,  # 是否需要成交量确认
            'volume_confirmation_threshold': 1.5,  # 成交量确认阈值（相对于平均成交量）

            # 入场时机优化参数
            'use_entry_optimization': True,  # 是否使用入场时机优化
            'wait_for_pullback': True,  # 是否等待回调入场
            'pullback_threshold': 0.005,  # 回调阈值（0.5%）
            'max_wait_time': 30 * 60,  # 最大等待时间（秒）
            'use_order_book_analysis': True,  # 是否使用订单簿分析
            'min_order_book_depth': 0.01,  # 最小订单簿深度（相对于价格的1%）

            # 入场订单参数
            'default_entry_type': EntryType.LIMIT,  # 默认入场类型
            'limit_price_buffer': 0.001,  # 限价缓冲（0.1%）
            'stop_price_buffer': 0.002,  # 止损价格缓冲（0.2%）
            'max_slippage': 0.002,  # 最大滑点（0.2%）
            'use_iceberg_orders': False,  # 是否使用冰山订单
            'iceberg_display_size': 0.2,  # 冰山订单显示比例（20%）
            'retry_attempts': 3,  # 重试次数
            'retry_delay': 5,  # 重试延迟（秒）

            # 市场状态过滤参数
            'allowed_market_states': [
                MarketState.UPTREND,
                MarketState.RANGING,
                MarketState.DOWNTREND
            ],  # 允许入场的市场状态
            'avoid_high_volatility': True,  # 是否避免高波动率
            'max_volatility_threshold': 0.03,  # 最大波动率阈值（3%）
            'avoid_news_events': True,  # 是否避免新闻事件
            'news_event_buffer': 30 * 60,  # 新闻事件缓冲时间（秒）
        }

        # 入场信号队列
        self.entry_signals = []  # [{symbol, signal_type, position_type, price, timestamp, status, ...}]

        # 入场历史
        self.entry_history = []

    def add_entry_signal(self, symbol: str, signal_type: SignalType,
                       position_type: PositionType, price: float,
                       stop_loss_price: float, signal_strength: float = 0.0,
                       market_state: MarketState = MarketState.UNKNOWN,
                       volatility: float = 0.0) -> Dict[str, Any]:
        """
        添加入场信号

        参数:
            symbol: 交易对符号
            signal_type: 信号类型
            position_type: 仓位类型
            price: 信号价格
            stop_loss_price: 止损价格
            signal_strength: 信号强度
            market_state: 市场状态
            volatility: 波动率

        返回:
            入场信号信息
        """
        try:
            # 检查是否已有相同交易对的信号
            for signal in self.entry_signals:
                if signal['symbol'] == symbol and signal['status'] == EntrySignalStatus.PENDING:
                    logger.info(f"已存在 {symbol} 的入场信号，忽略新信号")
                    return signal

            # 检查是否已有相同交易对的持仓
            if self.position_manager and symbol in self.position_manager.get_all_positions():
                logger.info(f"已存在 {symbol} 的持仓，忽略入场信号")
                return {
                    'symbol': symbol,
                    'status': EntrySignalStatus.REJECTED,
                    'reason': '已存在持仓'
                }

            # 检查信号强度
            if signal_strength < self.params['min_signal_strength']:
                logger.info(f"信号强度不足: {signal_strength} < {self.params['min_signal_strength']}")
                return {
                    'symbol': symbol,
                    'status': EntrySignalStatus.REJECTED,
                    'reason': '信号强度不足'
                }

            # 检查市场状态
            if market_state not in self.params['allowed_market_states']:
                logger.info(f"市场状态不允许入场: {market_state}")
                return {
                    'symbol': symbol,
                    'status': EntrySignalStatus.REJECTED,
                    'reason': f'市场状态不允许入场: {market_state}'
                }

            # 检查波动率
            if self.params['avoid_high_volatility'] and volatility > self.params['max_volatility_threshold']:
                logger.info(f"波动率过高: {volatility} > {self.params['max_volatility_threshold']}")
                return {
                    'symbol': symbol,
                    'status': EntrySignalStatus.REJECTED,
                    'reason': f'波动率过高: {volatility:.2%}'
                }

            # 创建入场信号
            entry_signal = {
                'symbol': symbol,
                'signal_type': signal_type,
                'position_type': position_type,
                'price': price,
                'stop_loss_price': stop_loss_price,
                'signal_strength': signal_strength,
                'market_state': market_state,
                'volatility': volatility,
                'timestamp': datetime.now(),
                'status': EntrySignalStatus.PENDING,
                'confirmations': 0,
                'confirmation_prices': [],
                'optimized_entry_price': price,
                'entry_type': self.params['default_entry_type'],
                'expiry_time': datetime.now() + timedelta(seconds=self.params['signal_expiry'])
            }

            # 添加到信号队列
            self.entry_signals.append(entry_signal)

            logger.info(f"添加入场信号: {symbol} {position_type.name} @ {price} (强度: {signal_strength:.2f})")

            return entry_signal

        except Exception as e:
            logger.error(f"添加入场信号失败: {e}")
            return {
                'symbol': symbol,
                'status': EntrySignalStatus.REJECTED,
                'reason': f'添加信号失败: {e}'
            }

    def update_entry_signal(self, symbol: str, current_price: float,
                          current_volume: float = 0.0,
                          order_book: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        更新入场信号

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            current_volume: 当前成交量
            order_book: 订单簿数据

        返回:
            更新后的入场信号信息
        """
        try:
            # 查找信号
            signal = None
            for s in self.entry_signals:
                if s['symbol'] == symbol and s['status'] == EntrySignalStatus.PENDING:
                    signal = s
                    break

            if signal is None:
                return None

            # 检查信号是否过期
            if datetime.now() > signal['expiry_time']:
                signal['status'] = EntrySignalStatus.EXPIRED
                logger.info(f"入场信号已过期: {symbol}")

                # 添加到历史记录
                self.entry_history.append(signal)

                # 从队列中移除
                self.entry_signals.remove(signal)

                return signal

            # 更新确认价格
            signal['confirmation_prices'].append(current_price)

            # 保留最近的确认窗口数量的价格
            if len(signal['confirmation_prices']) > self.params['confirmation_window']:
                signal['confirmation_prices'] = signal['confirmation_prices'][-self.params['confirmation_window']:]

            # 检查价格确认
            price_confirmed = False
            if len(signal['confirmation_prices']) >= self.params['confirmation_threshold']:
                if signal['position_type'] == PositionType.LONG:
                    # 多头信号：价格应该高于或等于信号价格
                    price_confirmed = sum(1 for p in signal['confirmation_prices'] if p >= signal['price']) >= self.params['confirmation_threshold']
                else:
                    # 空头信号：价格应该低于或等于信号价格
                    price_confirmed = sum(1 for p in signal['confirmation_prices'] if p <= signal['price']) >= self.params['confirmation_threshold']

            # 检查成交量确认
            volume_confirmed = True
            if self.params['require_volume_confirmation'] and current_volume > 0:
                # 假设我们有平均成交量数据
                avg_volume = signal.get('avg_volume', current_volume / self.params['volume_confirmation_threshold'])
                volume_confirmed = current_volume >= avg_volume * self.params['volume_confirmation_threshold']

            # 更新确认计数
            if price_confirmed and volume_confirmed:
                signal['confirmations'] += 1
            else:
                signal['confirmations'] = 0

            # 检查是否达到确认阈值
            if signal['confirmations'] >= self.params['confirmation_threshold']:
                signal['status'] = EntrySignalStatus.CONFIRMED
                logger.info(f"入场信号已确认: {symbol}")

                # 优化入场价格
                if self.params['use_entry_optimization']:
                    signal['optimized_entry_price'] = self._optimize_entry_price(signal, current_price, order_book)

                # 执行入场
                self._execute_entry(signal)

            return signal

        except Exception as e:
            logger.error(f"更新入场信号失败: {e}")
            return None

    def _optimize_entry_price(self, signal: Dict[str, Any], current_price: float,
                            order_book: Optional[Dict[str, Any]] = None) -> float:
        """
        优化入场价格

        参数:
            signal: 入场信号
            current_price: 当前价格
            order_book: 订单簿数据

        返回:
            优化后的入场价格
        """
        try:
            # 初始化为当前价格
            optimized_price = current_price

            # 如果等待回调入场
            if self.params['wait_for_pullback']:
                if signal['position_type'] == PositionType.LONG:
                    # 多头：等待价格回调
                    pullback_price = current_price * (1 - self.params['pullback_threshold'])
                    optimized_price = max(pullback_price, signal['stop_loss_price'] * 1.01)  # 确保高于止损价格
                else:
                    # 空头：等待价格反弹
                    pullback_price = current_price * (1 + self.params['pullback_threshold'])
                    optimized_price = min(pullback_price, signal['stop_loss_price'] * 0.99)  # 确保低于止损价格

            # 如果使用订单簿分析
            if self.params['use_order_book_analysis'] and order_book:
                # 分析订单簿，找到流动性最好的价格
                if signal['position_type'] == PositionType.LONG:
                    # 多头：分析买单深度
                    bids = order_book.get('bids', [])
                    if bids:
                        # 找到累计深度超过阈值的价格
                        cumulative_volume = 0
                        depth_threshold = current_price * self.params['min_order_book_depth']

                        for bid_price, bid_volume in bids:
                            cumulative_volume += bid_volume
                            if cumulative_volume >= depth_threshold:
                                # 找到有足够深度的价格
                                optimized_price = min(optimized_price, bid_price)
                                break
                else:
                    # 空头：分析卖单深度
                    asks = order_book.get('asks', [])
                    if asks:
                        # 找到累计深度超过阈值的价格
                        cumulative_volume = 0
                        depth_threshold = current_price * self.params['min_order_book_depth']

                        for ask_price, ask_volume in asks:
                            cumulative_volume += ask_volume
                            if cumulative_volume >= depth_threshold:
                                # 找到有足够深度的价格
                                optimized_price = max(optimized_price, ask_price)
                                break

            # 根据入场类型调整价格
            if signal['entry_type'] == EntryType.LIMIT:
                if signal['position_type'] == PositionType.LONG:
                    # 多头限价单：略低于当前价格
                    optimized_price = min(optimized_price, current_price * (1 - self.params['limit_price_buffer']))
                else:
                    # 空头限价单：略高于当前价格
                    optimized_price = max(optimized_price, current_price * (1 + self.params['limit_price_buffer']))
            elif signal['entry_type'] == EntryType.STOP:
                if signal['position_type'] == PositionType.LONG:
                    # 多头止损单：略高于当前价格
                    optimized_price = max(optimized_price, current_price * (1 + self.params['stop_price_buffer']))
                else:
                    # 空头止损单：略低于当前价格
                    optimized_price = min(optimized_price, current_price * (1 - self.params['stop_price_buffer']))

            return optimized_price

        except Exception as e:
            logger.error(f"优化入场价格失败: {e}")
            return current_price

    def _execute_entry(self, signal: Dict[str, Any]) -> bool:
        """
        执行入场

        参数:
            signal: 入场信号

        返回:
            是否执行成功
        """
        try:
            if self.position_manager is None:
                logger.warning("仓位管理器未设置，无法执行入场")
                return False

            # 计算仓位大小
            # 这里假设我们有账户余额信息
            account_balance = 10000.0  # 示例余额

            position_result = self.position_manager.calculate_position_size(
                signal['symbol'],
                signal['optimized_entry_price'],
                signal['stop_loss_price'],
                account_balance,
                signal['position_type']
            )

            # 创建入场订单
            entry_order = self.position_manager.create_entry_order(
                signal['symbol'],
                signal['position_type'],
                signal['optimized_entry_price'],
                signal['stop_loss_price'],
                position_result['position_size'],
                signal['signal_type'],
                signal['signal_strength']
            )

            # 更新信号状态
            signal['status'] = EntrySignalStatus.EXECUTED
            signal['entry_order'] = entry_order

            # 添加到历史记录
            self.entry_history.append(signal)

            # 从队列中移除
            self.entry_signals.remove(signal)

            logger.info(f"执行入场: {signal['symbol']} {signal['position_type'].name} {position_result['position_size']} @ {signal['optimized_entry_price']}")

            return True

        except Exception as e:
            logger.error(f"执行入场失败: {e}")
            return False

    def cancel_entry_signal(self, symbol: str, reason: str = "用户取消") -> bool:
        """
        取消入场信号

        参数:
            symbol: 交易对符号
            reason: 取消原因

        返回:
            是否取消成功
        """
        try:
            # 查找信号
            signal = None
            for s in self.entry_signals:
                if s['symbol'] == symbol and s['status'] == EntrySignalStatus.PENDING:
                    signal = s
                    break

            if signal is None:
                logger.warning(f"未找到 {symbol} 的入场信号")
                return False

            # 更新信号状态
            signal['status'] = EntrySignalStatus.REJECTED
            signal['reason'] = reason

            # 添加到历史记录
            self.entry_history.append(signal)

            # 从队列中移除
            self.entry_signals.remove(signal)

            logger.info(f"取消入场信号: {symbol} ({reason})")

            return True

        except Exception as e:
            logger.error(f"取消入场信号失败: {e}")
            return False

    def get_pending_signals(self) -> List[Dict[str, Any]]:
        """
        获取待处理的入场信号

        返回:
            待处理的入场信号列表
        """
        return [s for s in self.entry_signals if s['status'] == EntrySignalStatus.PENDING]

    def get_entry_history(self) -> List[Dict[str, Any]]:
        """
        获取入场历史

        返回:
            入场历史列表
        """
        return self.entry_history

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置入场管理参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取入场管理参数

        返回:
            参数字典
        """
        return self.params.copy()
