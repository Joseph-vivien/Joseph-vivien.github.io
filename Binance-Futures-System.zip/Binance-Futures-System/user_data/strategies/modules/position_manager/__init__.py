#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓位管理模块初始化文件
"""

from enum import Enum, auto

# 定义仓位类型枚举
class PositionType(Enum):
    """仓位类型枚举"""
    LONG = auto()  # 多头
    SHORT = auto()  # 空头

# 定义仓位状态枚举
class PositionStatus(Enum):
    """仓位状态枚举"""
    PENDING = auto()  # 等待中
    OPEN = auto()  # 已开仓
    CLOSED = auto()  # 已平仓
    CANCELLED = auto()  # 已取消

# 导入其他模块
from user_data.strategies.modules.position_manager.entry_manager import EntryManager
from user_data.strategies.modules.position_manager.exit_manager import ExitManager
from user_data.strategies.modules.position_manager.size_calculator import SizeCalculator
from user_data.strategies.modules.position_manager.position_manager import PositionManager

__all__ = ['PositionManager', 'PositionType', 'PositionStatus', 'EntryManager', 'ExitManager', 'SizeCalculator']
