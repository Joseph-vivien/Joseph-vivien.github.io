#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓位管理器

该模块提供仓位管理功能，整合入场管理、出场管理和仓位大小计算。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
from enum import Enum, auto
import logging

from user_data.strategies.modules.position_manager.entry_manager import EntryManager
from user_data.strategies.modules.position_manager.exit_manager import ExitManager
from user_data.strategies.modules.position_manager.size_calculator import SizeCalculator
from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("position_manager")

class PositionManager:
    """
    仓位管理器
    
    整合入场管理、出场管理和仓位大小计算，提供全面的仓位管理功能。
    """
    
    def __init__(self):
        """初始化仓位管理器"""
        self.entry_manager = EntryManager()
        self.exit_manager = ExitManager()
        self.size_calculator = SizeCalculator()
        
        # 默认参数
        self.parameters = {
            'entry': {
                'confirmation_window': 3,
                'timeout': 60,
                'price_buffer': 0.001,
                'use_limit_entry': True,
                'allow_partial_entry': True,
                'min_entry_fill_pct': 0.8
            },
            'exit': {
                'timeout': 60,
                'price_buffer': 0.001,
                'use_limit_exit': True,
                'allow_partial_exit': True,
                'min_exit_fill_pct': 0.8,
                'use_staged_exit': True,
                'profit_targets': [0.05, 0.1, 0.2],
                'exit_percentages': [0.3, 0.3, 0.4],
                'use_time_exit': True,
                'max_trade_duration': 86400
            },
            'size': {
                'method': 'risk',
                'fixed_size': 100.0,
                'percentage_size': 5.0,
                'risk_percentage': 2.0,
                'max_position_size': 1000.0,
                'min_position_size': 10.0
            }
        }
        
        # 活跃仓位
        self.active_positions = {}
        
        logger.info("仓位管理器初始化完成")
        
    def set_parameters(self, parameters: Dict[str, Any]) -> None:
        """
        设置仓位管理参数
        
        参数:
            parameters: 参数字典
        """
        # 更新参数
        if 'entry' in parameters:
            self.parameters['entry'].update(parameters['entry'])
        if 'exit' in parameters:
            self.parameters['exit'].update(parameters['exit'])
        if 'size' in parameters:
            self.parameters['size'].update(parameters['size'])
            
        # 更新子模块参数
        self.entry_manager.set_parameters(self.parameters['entry'])
        self.exit_manager.set_parameters(self.parameters['exit'])
        self.size_calculator.set_parameters(self.parameters['size'])
        
        logger.info("已更新仓位管理参数")
        
    def open_position(self, symbol: str, side: str, entry_price: float, 
                    stop_loss_price: float, take_profit_price: float, 
                    size: float, leverage: int = 1) -> Dict[str, Any]:
        """
        开仓
        
        参数:
            symbol: 交易对符号
            side: 交易方向 (buy, sell)
            entry_price: 入场价格
            stop_loss_price: 止损价格
            take_profit_price: 止盈价格
            size: 仓位大小
            leverage: 杠杆倍数
            
        返回:
            仓位信息
        """
        # 生成仓位ID
        position_id = f"{symbol}_{side}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # 创建仓位信息
        position = {
            'id': position_id,
            'symbol': symbol,
            'side': side,
            'entry_price': entry_price,
            'stop_loss_price': stop_loss_price,
            'take_profit_price': take_profit_price,
            'size': size,
            'filled_size': 0.0,
            'leverage': leverage,
            'status': 'pending',
            'open_time': datetime.now(),
            'close_time': None,
            'profit': 0.0,
            'profit_pct': 0.0,
            'fees': 0.0,
            'orders': []
        }
        
        # 使用入场管理器处理入场
        entry_result = self.entry_manager.execute_entry(
            symbol, side, entry_price, size, 
            use_limit=self.parameters['entry']['use_limit_entry'],
            price_buffer=self.parameters['entry']['price_buffer'],
            timeout=self.parameters['entry']['timeout']
        )
        
        # 更新仓位信息
        position.update({
            'entry_order_id': entry_result.get('order_id'),
            'entry_order_status': entry_result.get('status'),
            'filled_size': entry_result.get('filled_size', 0.0),
            'entry_price': entry_result.get('average_price', entry_price),
            'status': 'open' if entry_result.get('status') == 'filled' else 'pending'
        })
        
        # 添加订单信息
        position['orders'].append({
            'id': entry_result.get('order_id'),
            'type': 'entry',
            'side': side,
            'price': entry_price,
            'size': size,
            'filled_size': entry_result.get('filled_size', 0.0),
            'status': entry_result.get('status'),
            'time': datetime.now()
        })
        
        # 如果入场成功，设置止损和止盈
        if position['status'] == 'open':
            # 设置止损
            stop_loss_result = self.exit_manager.set_stop_loss(
                symbol, side, position['filled_size'], stop_loss_price)
                
            position['stop_loss_order_id'] = stop_loss_result.get('order_id')
            
            # 如果使用分段止盈，设置多个止盈点
            if self.parameters['exit']['use_staged_exit']:
                take_profit_results = self.exit_manager.set_staged_take_profit(
                    symbol, side, position['filled_size'], 
                    entry_price, take_profit_price,
                    self.parameters['exit']['profit_targets'],
                    self.parameters['exit']['exit_percentages']
                )
                
                position['take_profit_order_ids'] = [r.get('order_id') for r in take_profit_results]
            else:
                # 设置单一止盈
                take_profit_result = self.exit_manager.set_take_profit(
                    symbol, side, position['filled_size'], take_profit_price)
                    
                position['take_profit_order_id'] = take_profit_result.get('order_id')
        
        # 保存仓位信息
        self.active_positions[position_id] = position
        
        logger.info(f"开仓: {symbol} {side} 价格={entry_price} 数量={size} 状态={position['status']}")
        return position
        
    def close_position(self, position_id: str, reason: str = 'manual') -> Dict[str, Any]:
        """
        平仓
        
        参数:
            position_id: 仓位ID
            reason: 平仓原因
            
        返回:
            仓位信息
        """
        if position_id not in self.active_positions:
            logger.warning(f"平仓失败，仓位不存在: {position_id}")
            return {}
            
        position = self.active_positions[position_id]
        
        # 如果仓位已经关闭，直接返回
        if position['status'] == 'closed':
            return position
            
        # 取消所有未完成的订单
        for order_id in [position.get('stop_loss_order_id'), position.get('take_profit_order_id')]:
            if order_id:
                self.exit_manager.cancel_order(position['symbol'], order_id)
                
        # 如果有多个止盈订单，全部取消
        if 'take_profit_order_ids' in position:
            for order_id in position['take_profit_order_ids']:
                if order_id:
                    self.exit_manager.cancel_order(position['symbol'], order_id)
        
        # 执行市价平仓
        exit_result = self.exit_manager.execute_exit(
            position['symbol'], position['side'], position['filled_size'],
            use_limit=False
        )
        
        # 更新仓位信息
        current_price = exit_result.get('average_price', 0.0)
        
        # 计算盈亏
        if position['side'] == 'buy':
            profit = (current_price - position['entry_price']) * position['filled_size']
            profit_pct = (current_price - position['entry_price']) / position['entry_price'] * 100
        else:
            profit = (position['entry_price'] - current_price) * position['filled_size']
            profit_pct = (position['entry_price'] - current_price) / position['entry_price'] * 100
            
        position.update({
            'exit_order_id': exit_result.get('order_id'),
            'exit_price': current_price,
            'close_time': datetime.now(),
            'status': 'closed',
            'profit': profit,
            'profit_pct': profit_pct,
            'exit_reason': reason
        })
        
        # 添加订单信息
        position['orders'].append({
            'id': exit_result.get('order_id'),
            'type': 'exit',
            'side': 'sell' if position['side'] == 'buy' else 'buy',
            'price': current_price,
            'size': position['filled_size'],
            'filled_size': position['filled_size'],
            'status': exit_result.get('status'),
            'time': datetime.now()
        })
        
        logger.info(f"平仓: {position['symbol']} {position['side']} 价格={current_price} 数量={position['filled_size']} 盈亏={profit_pct:.2f}% 原因={reason}")
        return position
        
    def update_positions(self, current_prices: Dict[str, float]) -> None:
        """
        更新仓位状态
        
        参数:
            current_prices: 当前价格字典 {symbol: price}
        """
        for position_id, position in list(self.active_positions.items()):
            # 跳过已关闭的仓位
            if position['status'] == 'closed':
                continue
                
            symbol = position['symbol']
            
            # 如果没有当前价格，跳过
            if symbol not in current_prices:
                continue
                
            current_price = current_prices[symbol]
            
            # 检查是否触发止损
            if position['side'] == 'buy' and current_price <= position['stop_loss_price']:
                self.close_position(position_id, reason='stop_loss')
                continue
            elif position['side'] == 'sell' and current_price >= position['stop_loss_price']:
                self.close_position(position_id, reason='stop_loss')
                continue
                
            # 检查是否触发止盈
            if position['side'] == 'buy' and current_price >= position['take_profit_price']:
                self.close_position(position_id, reason='take_profit')
                continue
            elif position['side'] == 'sell' and current_price <= position['take_profit_price']:
                self.close_position(position_id, reason='take_profit')
                continue
                
            # 检查是否超过最大持仓时间
            if self.parameters['exit']['use_time_exit']:
                max_duration = self.parameters['exit']['max_trade_duration']
                if (datetime.now() - position['open_time']).total_seconds() > max_duration:
                    self.close_position(position_id, reason='time_exit')
                    continue
                    
            # 更新未实现盈亏
            if position['side'] == 'buy':
                unrealized_profit = (current_price - position['entry_price']) * position['filled_size']
                unrealized_profit_pct = (current_price - position['entry_price']) / position['entry_price'] * 100
            else:
                unrealized_profit = (position['entry_price'] - current_price) * position['filled_size']
                unrealized_profit_pct = (position['entry_price'] - current_price) / position['entry_price'] * 100
                
            position['unrealized_profit'] = unrealized_profit
            position['unrealized_profit_pct'] = unrealized_profit_pct
            
    def get_position(self, position_id: str) -> Dict[str, Any]:
        """
        获取仓位信息
        
        参数:
            position_id: 仓位ID
            
        返回:
            仓位信息
        """
        return self.active_positions.get(position_id, {})
        
    def get_active_positions(self) -> List[Dict[str, Any]]:
        """
        获取所有活跃仓位
        
        返回:
            活跃仓位列表
        """
        return [p for p in self.active_positions.values() if p['status'] in ['open', 'pending']]
        
    def get_closed_positions(self) -> List[Dict[str, Any]]:
        """
        获取所有已关闭仓位
        
        返回:
            已关闭仓位列表
        """
        return [p for p in self.active_positions.values() if p['status'] == 'closed']
        
    def calculate_position_size(self, symbol: str, entry_price: float, 
                              stop_loss_price: float, account_balance: float) -> float:
        """
        计算仓位大小
        
        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stop_loss_price: 止损价格
            account_balance: 账户余额
            
        返回:
            仓位大小
        """
        return self.size_calculator.calculate_position_size(
            symbol, entry_price, stop_loss_price, account_balance,
            method=self.parameters['size']['method'],
            fixed_size=self.parameters['size']['fixed_size'],
            percentage_size=self.parameters['size']['percentage_size'],
            risk_percentage=self.parameters['size']['risk_percentage'],
            max_position_size=self.parameters['size']['max_position_size'],
            min_position_size=self.parameters['size']['min_position_size']
        )
