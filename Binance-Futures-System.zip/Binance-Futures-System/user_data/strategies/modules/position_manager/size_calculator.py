#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓位大小计算器模块

该模块负责计算交易仓位大小，支持多种计算方法，包括固定金额、账户百分比、风险百分比、
波动率调整、凯利公式和最优f值等。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import math

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer

# 获取日志记录器
logger = get_logger("size_calculator")

class SizingMethod(Enum):
    """仓位大小计算方法枚举"""
    FIXED = "固定金额"
    PERCENTAGE = "账户百分比"
    RISK = "风险百分比"
    VOLATILITY = "波动率调整"
    KELLY = "凯利公式"
    OPTIMAL_F = "最优f值"

class SizeCalculator:
    """
    仓位大小计算器类

    负责计算交易仓位大小，支持多种计算方法
    """

    def __init__(self):
        """初始化仓位大小计算器"""
        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 仓位大小参数
            'sizing_method': SizingMethod.RISK,  # 默认使用风险百分比方法
            'fixed_size': 100.0,  # 固定金额（USDT）
            'percentage_size': 5.0,  # 账户百分比（%）
            'risk_percentage': 2.0,  # 风险百分比（%）
            'max_position_size': 20.0,  # 最大仓位大小（账户百分比）
            'min_position_size': 10.0,  # 最小仓位大小（USDT）

            # 波动率调整参数
            'volatility_lookback': 20,  # 波动率计算回溯期
            'volatility_factor': 1.0,  # 波动率调整因子
            'max_volatility_adjustment': 0.5,  # 最大波动率调整（50%）

            # 凯利公式参数
            'kelly_fraction': 0.5,  # 凯利公式分数（半凯利）
            'win_rate': 0.5,  # 默认胜率
            'profit_loss_ratio': 2.0,  # 默认盈亏比

            # 最优f值参数
            'optimal_f': 0.1,  # 默认最优f值

            # 杠杆参数
            'use_leverage': False,  # 是否使用杠杆
            'leverage': 1.0,  # 杠杆倍数
            'max_leverage': 10.0,  # 最大杠杆倍数
        }

        # 初始化波动率分析器
        self.volatility_analyzer = VolatilityAnalyzer()

        # 交易历史
        self.trade_history = []

    def calculate_position_size(self, account_balance: float, entry_price: float,
                              stop_loss_price: float, data: Optional[pd.DataFrame] = None,
                              **kwargs) -> Dict[str, Any]:
        """
        计算仓位大小

        参数:
            account_balance: 账户余额
            entry_price: 入场价格
            stop_loss_price: 止损价格
            data: OHLCV数据（用于波动率计算）
            **kwargs: 其他参数

        返回:
            仓位计算结果
        """
        try:
            # 获取仓位计算方法
            method = kwargs.get('method', self.params['sizing_method'])

            # 计算价格风险百分比
            price_risk_pct = abs(entry_price - stop_loss_price) / entry_price

            # 根据方法计算仓位大小
            if method == SizingMethod.FIXED:
                position_size_quote = self._calculate_fixed_size(account_balance, **kwargs)
            elif method == SizingMethod.PERCENTAGE:
                position_size_quote = self._calculate_percentage_size(account_balance, **kwargs)
            elif method == SizingMethod.RISK:
                position_size_quote = self._calculate_risk_size(account_balance, price_risk_pct, **kwargs)
            elif method == SizingMethod.VOLATILITY:
                position_size_quote = self._calculate_volatility_size(account_balance, price_risk_pct, data, **kwargs)
            elif method == SizingMethod.KELLY:
                position_size_quote = self._calculate_kelly_size(account_balance, price_risk_pct, **kwargs)
            elif method == SizingMethod.OPTIMAL_F:
                position_size_quote = self._calculate_optimal_f_size(account_balance, **kwargs)
            else:
                # 默认使用风险百分比方法
                position_size_quote = self._calculate_risk_size(account_balance, price_risk_pct, **kwargs)

            # 应用杠杆
            if self.params['use_leverage']:
                leverage = min(kwargs.get('leverage', self.params['leverage']), self.params['max_leverage'])
                position_size_quote = position_size_quote * leverage
                margin_required = position_size_quote / leverage
            else:
                leverage = 1.0
                margin_required = position_size_quote

            # 确保仓位不超过最大允许值
            max_position_size = account_balance * (self.params['max_position_size'] / 100)
            position_size_quote = min(position_size_quote, max_position_size)

            # 确保仓位不低于最小允许值
            if position_size_quote < self.params['min_position_size']:
                if account_balance >= self.params['min_position_size']:
                    position_size_quote = self.params['min_position_size']
                else:
                    position_size_quote = account_balance * 0.95  # 使用95%的账户余额

            # 计算仓位大小（币数量）
            position_size = position_size_quote / entry_price

            # 计算实际风险
            actual_risk_amount = position_size_quote * price_risk_pct
            actual_risk_pct = (actual_risk_amount / account_balance) * 100

            # 计算强平价格
            liquidation_buffer = 0.2  # 20%保证金缓冲
            is_long = entry_price > stop_loss_price

            if is_long:
                liquidation_price = entry_price * (1 - (1 - liquidation_buffer) / leverage)
            else:
                liquidation_price = entry_price * (1 + (1 - liquidation_buffer) / leverage)

            return {
                'position_size': position_size,
                'position_size_quote': position_size_quote,
                'risk_amount': actual_risk_amount,
                'risk_pct': actual_risk_pct,
                'price_risk_pct': price_risk_pct * 100,
                'leverage': leverage,
                'margin_required': margin_required,
                'liquidation_price': liquidation_price,
                'method': method.value
            }

        except Exception as e:
            logger.error(f"计算仓位大小失败: {e}")
            return {
                'position_size': 0.0,
                'position_size_quote': 0.0,
                'risk_amount': 0.0,
                'risk_pct': 0.0,
                'price_risk_pct': 0.0,
                'leverage': 1.0,
                'margin_required': 0.0,
                'liquidation_price': 0.0,
                'method': 'ERROR',
                'error': str(e)
            }

    def _calculate_fixed_size(self, account_balance: float, **kwargs) -> float:
        """
        计算固定金额仓位大小

        参数:
            account_balance: 账户余额
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        # 获取固定金额
        fixed_size = kwargs.get('fixed_size', self.params['fixed_size'])

        # 确保不超过账户余额
        return min(fixed_size, account_balance)

    def _calculate_percentage_size(self, account_balance: float, **kwargs) -> float:
        """
        计算账户百分比仓位大小

        参数:
            account_balance: 账户余额
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        # 获取账户百分比
        percentage = kwargs.get('percentage_size', self.params['percentage_size'])

        # 计算仓位大小
        return account_balance * (percentage / 100)

    def _calculate_risk_size(self, account_balance: float, price_risk_pct: float, **kwargs) -> float:
        """
        计算风险百分比仓位大小

        参数:
            account_balance: 账户余额
            price_risk_pct: 价格风险百分比
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        # 获取风险百分比
        risk_pct = kwargs.get('risk_percentage', self.params['risk_percentage'])

        # 计算风险金额
        risk_amount = account_balance * (risk_pct / 100)

        # 计算仓位大小
        if price_risk_pct > 0:
            return risk_amount / price_risk_pct
        else:
            logger.warning("价格风险为零，无法计算风险百分比仓位大小")
            return self._calculate_percentage_size(account_balance, **kwargs)

    def _calculate_volatility_size(self, account_balance: float, price_risk_pct: float,
                                 data: Optional[pd.DataFrame], **kwargs) -> float:
        """
        计算波动率调整仓位大小

        参数:
            account_balance: 账户余额
            price_risk_pct: 价格风险百分比
            data: OHLCV数据
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        # 如果没有数据，使用风险百分比方法
        if data is None or data.empty:
            logger.warning("没有数据用于波动率计算，使用风险百分比方法")
            return self._calculate_risk_size(account_balance, price_risk_pct, **kwargs)

        try:
            # 计算波动率
            lookback = kwargs.get('volatility_lookback', self.params['volatility_lookback'])
            volatility = self.volatility_analyzer.analyze_volatility(data, short_window=lookback)

            # 获取ATR百分比
            atr_pct = volatility.get('atr_percent', 0.01)  # 默认1%

            # 获取波动率调整因子
            factor = kwargs.get('volatility_factor', self.params['volatility_factor'])

            # 获取风险百分比
            risk_pct = kwargs.get('risk_percentage', self.params['risk_percentage'])

            # 计算调整后的风险百分比
            # 波动率越高，风险百分比越低
            adjusted_risk_pct = risk_pct / (atr_pct * factor * 100)

            # 限制最大调整幅度
            max_adjustment = self.params['max_volatility_adjustment']
            if adjusted_risk_pct < risk_pct * (1 - max_adjustment):
                adjusted_risk_pct = risk_pct * (1 - max_adjustment)

            # 计算风险金额
            risk_amount = account_balance * (adjusted_risk_pct / 100)

            # 计算仓位大小
            if price_risk_pct > 0:
                return risk_amount / price_risk_pct
            else:
                logger.warning("价格风险为零，无法计算波动率调整仓位大小")
                return self._calculate_percentage_size(account_balance, **kwargs)

        except Exception as e:
            logger.error(f"计算波动率调整仓位大小失败: {e}")
            return self._calculate_risk_size(account_balance, price_risk_pct, **kwargs)

    def _calculate_kelly_size(self, account_balance: float, price_risk_pct: float, **kwargs) -> float:
        """
        计算凯利公式仓位大小

        参数:
            account_balance: 账户余额
            price_risk_pct: 价格风险百分比
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        try:
            # 获取胜率和盈亏比
            win_rate = kwargs.get('win_rate', self.params['win_rate'])
            profit_loss_ratio = kwargs.get('profit_loss_ratio', self.params['profit_loss_ratio'])

            # 如果有交易历史，计算实际胜率和盈亏比
            if self.trade_history and len(self.trade_history) >= 10:
                # 计算胜率
                wins = sum(1 for t in self.trade_history if t.get('profit', 0) > 0)
                win_rate = wins / len(self.trade_history)

                # 计算盈亏比
                avg_win = sum(t.get('profit', 0) for t in self.trade_history if t.get('profit', 0) > 0) / max(wins, 1)
                avg_loss = sum(abs(t.get('profit', 0)) for t in self.trade_history if t.get('profit', 0) < 0) / max(len(self.trade_history) - wins, 1)
                profit_loss_ratio = avg_win / avg_loss if avg_loss > 0 else profit_loss_ratio

            # 计算凯利比例
            kelly_pct = (win_rate * profit_loss_ratio - (1 - win_rate)) / profit_loss_ratio

            # 应用凯利分数（半凯利）
            kelly_fraction = kwargs.get('kelly_fraction', self.params['kelly_fraction'])
            kelly_pct *= kelly_fraction

            # 确保凯利比例为正
            kelly_pct = max(0, kelly_pct)

            # 计算仓位大小
            position_size_quote = account_balance * kelly_pct

            return position_size_quote

        except Exception as e:
            logger.error(f"计算凯利公式仓位大小失败: {e}")
            return self._calculate_risk_size(account_balance, price_risk_pct, **kwargs)

    def _calculate_optimal_f_size(self, account_balance: float, **kwargs) -> float:
        """
        计算最优f值仓位大小

        参数:
            account_balance: 账户余额
            **kwargs: 其他参数

        返回:
            仓位大小（计价货币）
        """
        # 获取最优f值
        optimal_f = kwargs.get('optimal_f', self.params['optimal_f'])

        # 计算仓位大小
        return account_balance * optimal_f

    def update_trade_history(self, trade: Dict[str, Any]) -> None:
        """
        更新交易历史

        参数:
            trade: 交易信息
        """
        self.trade_history.append(trade)

        # 保留最近的100笔交易
        if len(self.trade_history) > 100:
            self.trade_history = self.trade_history[-100:]

    def calculate_optimal_stop_loss(self, entry_price: float, data: pd.DataFrame,
                                  is_long: bool = True) -> Dict[str, Any]:
        """
        计算最优止损价格

        参数:
            entry_price: 入场价格
            data: OHLCV数据
            is_long: 是否做多

        返回:
            止损计算结果
        """
        try:
            # 计算ATR
            volatility = self.volatility_analyzer.analyze_volatility(data)
            atr = volatility.get('atr', 0)

            # 计算基于ATR的止损距离
            atr_multiplier = 2.0  # 默认使用2倍ATR
            stop_distance = atr * atr_multiplier

            # 计算止损价格
            if is_long:
                stop_loss_price = entry_price - stop_distance
            else:
                stop_loss_price = entry_price + stop_distance

            # 计算止损百分比
            stop_loss_pct = abs(entry_price - stop_loss_price) / entry_price * 100

            return {
                'stop_loss_price': stop_loss_price,
                'stop_loss_pct': stop_loss_pct,
                'atr': atr,
                'atr_multiplier': atr_multiplier
            }

        except Exception as e:
            logger.error(f"计算最优止损价格失败: {e}")

            # 使用默认止损（2%）
            if is_long:
                stop_loss_price = entry_price * 0.98
            else:
                stop_loss_price = entry_price * 1.02

            return {
                'stop_loss_price': stop_loss_price,
                'stop_loss_pct': 2.0,
                'atr': 0,
                'atr_multiplier': 0
            }

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置仓位计算参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取仓位计算参数

        返回:
            参数字典
        """
        return self.params.copy()
