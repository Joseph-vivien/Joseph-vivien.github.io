#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
趋势分析组件

该模块负责分析市场趋势，包括趋势识别、趋势强度计算和趋势一致性分析。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from scipy import stats
from sklearn.linear_model import LinearRegression

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("trend_analyzer")

class TrendDirection(Enum):
    """趋势方向枚举"""
    STRONG_UP = "强上升"
    UP = "上升"
    WEAK_UP = "弱上升"
    NEUTRAL = "中性"
    WEAK_DOWN = "弱下降"
    DOWN = "下降"
    STRONG_DOWN = "强下降"
    UNKNOWN = "未知"

class TrendAnalyzer:
    """
    趋势分析类

    负责分析市场趋势，包括趋势识别、趋势强度计算和趋势一致性分析
    """

    def __init__(self):
        """初始化趋势分析器"""
        # 数据缓存
        self.data_cache = {}

    def update_data(self, symbol: str, timeframe: str, data: pd.DataFrame) -> None:
        """
        更新市场数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
        """
        if data.empty:
            logger.warning(f"更新空数据: {symbol} {timeframe}")
            return

        # 缓存数据
        key = f"{symbol}_{timeframe}"
        self.data_cache[key] = data

        logger.debug(f"已更新趋势分析数据: {symbol} {timeframe} {len(data)} 条记录")

    def get_trend_state(self, symbol: str, timeframe: str) -> str:
        """
        获取趋势状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            趋势状态字符串
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取趋势状态，数据不存在: {symbol} {timeframe}")
            return "unknown"

        # 分析趋势
        trend_result = self.analyze_trend(data)
        direction = trend_result['direction']

        # 转换为字符串
        if direction in [TrendDirection.STRONG_UP, TrendDirection.UP, TrendDirection.WEAK_UP]:
            return "uptrend"
        elif direction in [TrendDirection.STRONG_DOWN, TrendDirection.DOWN, TrendDirection.WEAK_DOWN]:
            return "downtrend"
        elif direction == TrendDirection.NEUTRAL:
            return "sideways"
        else:
            return "unknown"

    def get_indicator(self, symbol: str, timeframe: str, indicator_name: str) -> Optional[float]:
        """
        获取技术指标值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator_name: 指标名称

        返回:
            指标值
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取指标，数据不存在: {symbol} {timeframe} {indicator_name}")
            return None

        try:
            close = data['close'].values

            if indicator_name == 'sma20':
                return self._calculate_sma(close, 20)[-1] if len(close) >= 20 else None
            elif indicator_name == 'sma50':
                return self._calculate_sma(close, 50)[-1] if len(close) >= 50 else None
            elif indicator_name == 'sma200':
                return self._calculate_sma(close, 200)[-1] if len(close) >= 200 else None
            elif indicator_name == 'ema9':
                return self._calculate_ema(close, 9)[-1] if len(close) >= 9 else None
            elif indicator_name == 'ema21':
                return self._calculate_ema(close, 21)[-1] if len(close) >= 21 else None
            elif indicator_name == 'rsi':
                return self._calculate_rsi(close, 14) if len(close) >= 14 else None
            elif indicator_name == 'macd':
                return self._calculate_macd(close) if len(close) >= 26 else None
            elif indicator_name == 'stoch':
                return self._calculate_stochastic(data) if len(data) >= 14 else None
            else:
                logger.warning(f"未知指标: {indicator_name}")
                return None

        except Exception as e:
            logger.error(f"计算指标失败: {indicator_name} {e}")
            return None

    def _calculate_ema(self, data: np.ndarray, window: int) -> np.ndarray:
        """
        计算指数移动平均线

        参数:
            data: 价格数据
            window: 窗口大小

        返回:
            指数移动平均线数组
        """
        alpha = 2 / (window + 1)
        ema = np.zeros_like(data)
        ema[0] = data[0]

        for i in range(1, len(data)):
            ema[i] = alpha * data[i] + (1 - alpha) * ema[i - 1]

        return ema

    def _calculate_rsi(self, data: np.ndarray, window: int = 14) -> float:
        """
        计算RSI指标

        参数:
            data: 价格数据
            window: 窗口大小

        返回:
            RSI值
        """
        if len(data) < window + 1:
            return 50.0

        deltas = np.diff(data)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)

        avg_gain = np.mean(gains[-window:])
        avg_loss = np.mean(losses[-window:])

        if avg_loss == 0:
            return 100.0

        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))

        return rsi

    def _calculate_macd(self, data: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        """
        计算MACD指标

        参数:
            data: 价格数据
            fast: 快线周期
            slow: 慢线周期
            signal: 信号线周期

        返回:
            (MACD线, 信号线, 柱状图)
        """
        if len(data) < slow:
            return 0.0, 0.0, 0.0

        ema_fast = self._calculate_ema(data, fast)
        ema_slow = self._calculate_ema(data, slow)

        macd_line = ema_fast - ema_slow
        signal_line = self._calculate_ema(macd_line, signal)
        histogram = macd_line - signal_line

        return macd_line[-1], signal_line[-1], histogram[-1]

    def _calculate_stochastic(self, data: pd.DataFrame, k_period: int = 14, d_period: int = 3) -> Tuple[float, float]:
        """
        计算随机指标

        参数:
            data: OHLCV数据
            k_period: K线周期
            d_period: D线周期

        返回:
            (K值, D值)
        """
        if len(data) < k_period:
            return 50.0, 50.0

        high = data['high'].values
        low = data['low'].values
        close = data['close'].values

        # 计算K值
        lowest_low = np.min(low[-k_period:])
        highest_high = np.max(high[-k_period:])

        if highest_high == lowest_low:
            k_value = 50.0
        else:
            k_value = ((close[-1] - lowest_low) / (highest_high - lowest_low)) * 100

        # 计算D值（K值的移动平均）
        # 这里简化为当前K值，实际应该是K值的移动平均
        d_value = k_value

        return k_value, d_value

    def get_support_resistance_levels(self, symbol: str, timeframe: str) -> Dict[str, List[float]]:
        """
        获取支撑和阻力位

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            支撑和阻力位字典
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取支撑阻力位，数据不存在: {symbol} {timeframe}")
            return {'support': [], 'resistance': []}

        try:
            high = data['high'].values
            low = data['low'].values

            # 简单的支撑阻力位计算
            # 找到局部高点和低点
            support_levels = []
            resistance_levels = []

            window = 5
            for i in range(window, len(high) - window):
                # 检查是否是局部高点
                if all(high[i] >= high[i-j] for j in range(1, window+1)) and \
                   all(high[i] >= high[i+j] for j in range(1, window+1)):
                    resistance_levels.append(high[i])

                # 检查是否是局部低点
                if all(low[i] <= low[i-j] for j in range(1, window+1)) and \
                   all(low[i] <= low[i+j] for j in range(1, window+1)):
                    support_levels.append(low[i])

            return {
                'support': sorted(support_levels)[-5:],  # 最近5个支撑位
                'resistance': sorted(resistance_levels)[-5:]  # 最近5个阻力位
            }

        except Exception as e:
            logger.error(f"计算支撑阻力位失败: {e}")
            return {'support': [], 'resistance': []}

    def analyze_trend(self, data: pd.DataFrame,
                     short_window: int = 20,
                     medium_window: int = 50,
                     long_window: int = 200) -> Dict[str, Any]:
        """
        分析价格趋势

        参数:
            data: OHLCV数据
            short_window: 短期窗口大小
            medium_window: 中期窗口大小
            long_window: 长期窗口大小

        返回:
            趋势分析结果字典
        """
        if data.empty:
            logger.warning("数据为空，无法分析趋势")
            return {
                'direction': TrendDirection.UNKNOWN,
                'strength': 0.0,
                'consistency': 0.0,
                'duration': 0,
                'slope': 0.0,
                'r_squared': 0.0
            }

        try:
            # 计算移动平均线
            close = data['close'].values
            sma_short = self._calculate_sma(close, short_window)
            sma_medium = self._calculate_sma(close, medium_window)
            sma_long = self._calculate_sma(close, long_window)

            # 计算趋势方向
            direction = self._determine_trend_direction(close, sma_short, sma_medium, sma_long)

            # 计算趋势强度
            strength, slope, r_squared = self._calculate_trend_strength(close, window=short_window)

            # 计算趋势一致性
            consistency = self._calculate_trend_consistency(close, sma_short, sma_medium, sma_long)

            # 计算趋势持续时间
            duration = self._calculate_trend_duration(close, direction)

            return {
                'direction': direction,
                'strength': strength,
                'consistency': consistency,
                'duration': duration,
                'slope': slope,
                'r_squared': r_squared
            }

        except Exception as e:
            logger.error(f"分析趋势失败: {e}")
            return {
                'direction': TrendDirection.UNKNOWN,
                'strength': 0.0,
                'consistency': 0.0,
                'duration': 0,
                'slope': 0.0,
                'r_squared': 0.0
            }

    def _calculate_sma(self, data: np.ndarray, window: int) -> np.ndarray:
        """
        计算简单移动平均线

        参数:
            data: 价格数据
            window: 窗口大小

        返回:
            移动平均线数组
        """
        sma = np.zeros_like(data)
        for i in range(window - 1, len(data)):
            sma[i] = np.mean(data[i - window + 1:i + 1])
        return sma

    def _determine_trend_direction(self, close: np.ndarray,
                                  sma_short: np.ndarray,
                                  sma_medium: np.ndarray,
                                  sma_long: np.ndarray) -> TrendDirection:
        """
        确定趋势方向

        参数:
            close: 收盘价数组
            sma_short: 短期移动平均线
            sma_medium: 中期移动平均线
            sma_long: 长期移动平均线

        返回:
            趋势方向
        """
        if len(close) < 2:
            return TrendDirection.UNKNOWN

        # 获取最新值
        latest_close = close[-1]
        latest_sma_short = sma_short[-1]
        latest_sma_medium = sma_medium[-1]
        latest_sma_long = sma_long[-1]

        # 计算趋势得分
        trend_score = 0

        # 价格与移动平均线关系
        if latest_close > latest_sma_short:
            trend_score += 1
        else:
            trend_score -= 1

        if latest_close > latest_sma_medium:
            trend_score += 1
        else:
            trend_score -= 1

        if latest_close > latest_sma_long:
            trend_score += 1
        else:
            trend_score -= 1

        # 移动平均线排列
        if latest_sma_short > latest_sma_medium:
            trend_score += 1
        else:
            trend_score -= 1

        if latest_sma_medium > latest_sma_long:
            trend_score += 1
        else:
            trend_score -= 1

        # 短期趋势
        if close[-1] > close[-2]:
            trend_score += 0.5
        else:
            trend_score -= 0.5

        # 根据得分确定趋势方向
        if trend_score >= 4:
            return TrendDirection.STRONG_UP
        elif trend_score >= 2:
            return TrendDirection.UP
        elif trend_score >= 0.5:
            return TrendDirection.WEAK_UP
        elif trend_score >= -0.5:
            return TrendDirection.NEUTRAL
        elif trend_score >= -2:
            return TrendDirection.WEAK_DOWN
        elif trend_score >= -4:
            return TrendDirection.DOWN
        else:
            return TrendDirection.STRONG_DOWN

    def _calculate_trend_strength(self, data: np.ndarray, window: int = 20) -> Tuple[float, float, float]:
        """
        计算趋势强度

        参数:
            data: 价格数据
            window: 窗口大小

        返回:
            (趋势强度, 斜率, R平方)
        """
        if len(data) < window:
            return 0.0, 0.0, 0.0

        # 使用线性回归计算趋势强度
        x = np.arange(window).reshape(-1, 1)
        y = data[-window:]

        model = LinearRegression()
        model.fit(x, y)

        slope = model.coef_[0]
        r_squared = model.score(x, y)

        # 趋势强度 = 斜率 * R² * 价格
        # 归一化为 -1 到 1 之间的值
        strength = slope * r_squared

        # 归一化
        avg_price = np.mean(data[-window:])
        if avg_price != 0:
            strength = strength / avg_price * 100

        # 限制在 -1 到 1 之间
        strength = max(min(strength, 1.0), -1.0)

        return strength, slope, r_squared

    def _calculate_trend_consistency(self, close: np.ndarray,
                                    sma_short: np.ndarray,
                                    sma_medium: np.ndarray,
                                    sma_long: np.ndarray) -> float:
        """
        计算趋势一致性

        参数:
            close: 收盘价数组
            sma_short: 短期移动平均线
            sma_medium: 中期移动平均线
            sma_long: 长期移动平均线

        返回:
            趋势一致性 (0-1)
        """
        if len(close) < 2:
            return 0.0

        # 计算各个指标的方向
        directions = []

        # 价格方向
        if close[-1] > close[-2]:
            directions.append(1)
        else:
            directions.append(-1)

        # 短期均线方向
        if sma_short[-1] > sma_short[-2]:
            directions.append(1)
        else:
            directions.append(-1)

        # 中期均线方向
        if sma_medium[-1] > sma_medium[-2]:
            directions.append(1)
        else:
            directions.append(-1)

        # 长期均线方向
        if sma_long[-1] > sma_long[-2]:
            directions.append(1)
        else:
            directions.append(-1)

        # 计算一致性
        # 如果所有方向都一致，一致性为1
        # 如果方向不一致，一致性降低
        consistency = abs(sum(directions)) / len(directions)

        return consistency

    def _calculate_trend_duration(self, close: np.ndarray, direction: TrendDirection) -> int:
        """
        计算趋势持续时间

        参数:
            close: 收盘价数组
            direction: 当前趋势方向

        返回:
            趋势持续的周期数
        """
        if len(close) < 2 or direction == TrendDirection.UNKNOWN:
            return 0

        # 确定当前趋势是上升还是下降
        is_uptrend = direction in [TrendDirection.STRONG_UP, TrendDirection.UP, TrendDirection.WEAK_UP]
        is_downtrend = direction in [TrendDirection.STRONG_DOWN, TrendDirection.DOWN, TrendDirection.WEAK_DOWN]

        if not is_uptrend and not is_downtrend:
            return 0

        # 从最新数据向前查找趋势反转点
        duration = 1
        for i in range(len(close) - 2, -1, -1):
            if is_uptrend and close[i] > close[i + 1]:
                duration += 1
            elif is_downtrend and close[i] < close[i + 1]:
                duration += 1
            else:
                break

        return duration

    def detect_trend_change(self, data: pd.DataFrame, lookback: int = 5) -> Dict[str, Any]:
        """
        检测趋势变化

        参数:
            data: OHLCV数据
            lookback: 回溯周期数

        返回:
            趋势变化分析结果
        """
        if data.empty or len(data) < lookback + 1:
            logger.warning("数据不足，无法检测趋势变化")
            return {
                'changed': False,
                'from': TrendDirection.UNKNOWN,
                'to': TrendDirection.UNKNOWN,
                'strength': 0.0
            }

        try:
            # 分析当前趋势
            current_trend = self.analyze_trend(data)

            # 分析前一时期趋势
            previous_data = data.iloc[:-lookback].copy()
            previous_trend = self.analyze_trend(previous_data)

            # 检测趋势变化
            changed = current_trend['direction'] != previous_trend['direction']

            # 计算变化强度
            strength = abs(current_trend['strength'] - previous_trend['strength'])

            return {
                'changed': changed,
                'from': previous_trend['direction'],
                'to': current_trend['direction'],
                'strength': strength
            }

        except Exception as e:
            logger.error(f"检测趋势变化失败: {e}")
            return {
                'changed': False,
                'from': TrendDirection.UNKNOWN,
                'to': TrendDirection.UNKNOWN,
                'strength': 0.0
            }

    def analyze_multi_timeframe_trend(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        分析多时间周期趋势一致性

        参数:
            data_dict: 不同时间周期的OHLCV数据字典 {timeframe: dataframe}

        返回:
            多时间周期趋势分析结果
        """
        if not data_dict:
            logger.warning("没有数据，无法分析多时间周期趋势")
            return {
                'consensus': TrendDirection.UNKNOWN,
                'strength': 0.0,
                'consistency': 0.0,
                'timeframes': {}
            }

        try:
            # 分析每个时间周期的趋势
            timeframe_trends = {}
            for timeframe, data in data_dict.items():
                timeframe_trends[timeframe] = self.analyze_trend(data)

            # 计算趋势共识
            trend_scores = []
            for tf, trend in timeframe_trends.items():
                # 将趋势方向转换为分数
                if trend['direction'] == TrendDirection.STRONG_UP:
                    score = 3
                elif trend['direction'] == TrendDirection.UP:
                    score = 2
                elif trend['direction'] == TrendDirection.WEAK_UP:
                    score = 1
                elif trend['direction'] == TrendDirection.NEUTRAL:
                    score = 0
                elif trend['direction'] == TrendDirection.WEAK_DOWN:
                    score = -1
                elif trend['direction'] == TrendDirection.DOWN:
                    score = -2
                elif trend['direction'] == TrendDirection.STRONG_DOWN:
                    score = -3
                else:
                    score = 0

                # 考虑时间周期权重
                # 较长时间周期权重更高
                if tf == '1m':
                    weight = 0.5
                elif tf == '5m':
                    weight = 0.6
                elif tf == '15m':
                    weight = 0.7
                elif tf == '30m':
                    weight = 0.8
                elif tf == '1h':
                    weight = 0.9
                elif tf == '4h':
                    weight = 1.0
                elif tf == '1d':
                    weight = 1.1
                else:
                    weight = 0.75

                trend_scores.append(score * weight)

            # 计算加权平均分数
            avg_score = sum(trend_scores) / len(trend_scores) if trend_scores else 0

            # 确定共识趋势方向
            if avg_score >= 2:
                consensus = TrendDirection.STRONG_UP
            elif avg_score >= 1:
                consensus = TrendDirection.UP
            elif avg_score >= 0.3:
                consensus = TrendDirection.WEAK_UP
            elif avg_score >= -0.3:
                consensus = TrendDirection.NEUTRAL
            elif avg_score >= -1:
                consensus = TrendDirection.WEAK_DOWN
            elif avg_score >= -2:
                consensus = TrendDirection.DOWN
            else:
                consensus = TrendDirection.STRONG_DOWN

            # 计算一致性
            # 如果所有时间周期趋势方向一致，一致性为1
            # 如果趋势方向不一致，一致性降低
            directions = [trend['direction'] for trend in timeframe_trends.values()]
            consistency = len([d for d in directions if d == consensus]) / len(directions) if directions else 0

            # 计算整体趋势强度
            strength = abs(avg_score) / 3  # 归一化到0-1

            return {
                'consensus': consensus,
                'strength': strength,
                'consistency': consistency,
                'timeframes': timeframe_trends
            }

        except Exception as e:
            logger.error(f"分析多时间周期趋势失败: {e}")
            return {
                'consensus': TrendDirection.UNKNOWN,
                'strength': 0.0,
                'consistency': 0.0,
                'timeframes': {}
            }
