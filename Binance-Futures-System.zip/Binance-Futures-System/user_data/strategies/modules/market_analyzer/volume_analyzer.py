#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
成交量分析组件

该模块负责分析市场成交量，包括成交量趋势、成交量异常和成交量与价格的关系。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import talib
from scipy import stats

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("volume_analyzer")

class VolumeState(Enum):
    """成交量状态枚举"""
    EXTREMELY_HIGH = "极高成交量"
    HIGH = "高成交量"
    ABOVE_NORMAL = "高于正常"
    NORMAL = "正常"
    BELOW_NORMAL = "低于正常"
    LOW = "低成交量"
    EXTREMELY_LOW = "极低成交量"
    INCREASING = "成交量上升"
    DECREASING = "成交量下降"
    CLIMAX = "成交量高潮"
    EXHAUSTION = "成交量衰竭"
    DIVERGENCE_BULLISH = "看涨背离"
    DIVERGENCE_BEARISH = "看跌背离"
    UNKNOWN = "未知"

class VolumeAnalyzer:
    """
    成交量分析类

    负责分析市场成交量，包括成交量趋势、成交量异常和成交量与价格的关系
    """

    def __init__(self):
        """初始化成交量分析器"""
        # 数据缓存
        self.data_cache = {}

    def update_data(self, symbol: str, timeframe: str, data: pd.DataFrame) -> None:
        """
        更新市场数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
        """
        if data.empty:
            logger.warning(f"更新空数据: {symbol} {timeframe}")
            return

        # 缓存数据
        key = f"{symbol}_{timeframe}"
        self.data_cache[key] = data

        logger.debug(f"已更新成交量分析数据: {symbol} {timeframe} {len(data)} 条记录")

    def get_volume_state(self, symbol: str, timeframe: str) -> str:
        """
        获取成交量状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            成交量状态字符串
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取成交量状态，数据不存在: {symbol} {timeframe}")
            return "unknown"

        # 分析成交量
        volume_result = self.analyze_volume(data)
        state = volume_result['state']

        # 转换为字符串
        if state in [VolumeState.EXTREMELY_HIGH, VolumeState.HIGH, VolumeState.CLIMAX]:
            return "high"
        elif state in [VolumeState.EXTREMELY_LOW, VolumeState.LOW, VolumeState.EXHAUSTION]:
            return "low"
        elif state == VolumeState.INCREASING:
            return "increasing"
        elif state == VolumeState.DECREASING:
            return "decreasing"
        elif state == VolumeState.DIVERGENCE_BULLISH:
            return "bullish_divergence"
        elif state == VolumeState.DIVERGENCE_BEARISH:
            return "bearish_divergence"
        elif state == VolumeState.NORMAL:
            return "normal"
        else:
            return "unknown"

    def get_indicator(self, symbol: str, timeframe: str, indicator_name: str) -> Optional[float]:
        """
        获取成交量指标值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator_name: 指标名称

        返回:
            指标值
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取指标，数据不存在: {symbol} {timeframe} {indicator_name}")
            return None

        try:
            if indicator_name == 'obv':
                close = data['close'].values
                volume = data['volume'].values
                return talib.OBV(close, volume)[-1] if len(data) >= 2 else None
            elif indicator_name == 'relative_volume':
                volume_result = self.analyze_volume(data)
                return volume_result['relative_volume']
            elif indicator_name == 'volume_trend':
                volume_result = self.analyze_volume(data)
                return volume_result['trend']
            elif indicator_name == 'chaikin_oscillator':
                volume_result = self.analyze_volume(data)
                return volume_result['chaikin_oscillator']
            else:
                logger.warning(f"未知成交量指标: {indicator_name}")
                return None

        except Exception as e:
            logger.error(f"计算成交量指标失败: {indicator_name} {e}")
            return None

    def analyze_volume(self, data: pd.DataFrame,
                      short_window: int = 20,
                      long_window: int = 50) -> Dict[str, Any]:
        """
        分析成交量

        参数:
            data: OHLCV数据
            short_window: 短期窗口大小
            long_window: 长期窗口大小

        返回:
            成交量分析结果字典
        """
        # 动态调整窗口大小以适应可用数据
        if data.empty or len(data) < 10:
            logger.warning("数据不足，无法分析成交量")
            return {
                'state': VolumeState.UNKNOWN,
                'trend': 0.0,
                'percentile': 0.0,
                'relative_volume': 0.0,
                'price_volume_correlation': 0.0,
                'obv': 0.0,
                'obv_trend': 0.0,
                'chaikin_oscillator': 0.0
            }

        # 根据可用数据调整窗口大小
        data_length = len(data)
        short_window = min(short_window, data_length // 2)
        long_window = min(long_window, data_length - 1)

        if short_window < 5:
            short_window = 5
        if long_window < short_window:
            long_window = short_window

        try:
            # 获取成交量数据
            volume = data['volume'].values
            close = data['close'].values

            # 计算相对成交量
            avg_volume = np.mean(volume[-long_window:-1])
            current_volume = volume[-1]
            relative_volume = current_volume / avg_volume if avg_volume > 0 else 0

            # 计算成交量百分位
            volume_series = pd.Series(volume[:-1])
            percentile = stats.percentileofscore(volume_series, current_volume) / 100

            # 计算成交量趋势
            volume_trend = self._calculate_volume_trend(volume, window=short_window)

            # 计算价格与成交量的相关性
            price_volume_correlation = self._calculate_price_volume_correlation(close, volume, window=short_window)

            # 计算OBV
            obv = talib.OBV(close, volume)[-1]

            # 计算OBV趋势
            obv_series = talib.OBV(close, volume)
            obv_trend = self._calculate_trend(obv_series, window=short_window)

            # 计算Chaikin震荡指标
            high = data['high'].values
            low = data['low'].values
            chaikin_oscillator = self._calculate_chaikin_oscillator(high, low, close, volume)

            # 确定成交量状态
            state = self._determine_volume_state(relative_volume, percentile, volume_trend,
                                               price_volume_correlation, obv_trend, chaikin_oscillator)

            return {
                'state': state,
                'trend': volume_trend,
                'percentile': percentile,
                'relative_volume': relative_volume,
                'price_volume_correlation': price_volume_correlation,
                'obv': obv,
                'obv_trend': obv_trend,
                'chaikin_oscillator': chaikin_oscillator
            }

        except Exception as e:
            logger.error(f"分析成交量失败: {e}")
            return {
                'state': VolumeState.UNKNOWN,
                'trend': 0.0,
                'percentile': 0.0,
                'relative_volume': 0.0,
                'price_volume_correlation': 0.0,
                'obv': 0.0,
                'obv_trend': 0.0,
                'chaikin_oscillator': 0.0
            }

    def _calculate_volume_trend(self, volume: np.ndarray, window: int = 20) -> float:
        """
        计算成交量趋势

        参数:
            volume: 成交量数组
            window: 趋势计算窗口

        返回:
            成交量趋势 (正值表示上升，负值表示下降)
        """
        if len(volume) < window + 1:
            return 0.0

        # 计算最近窗口的成交量
        recent_volume = volume[-window:]

        if len(recent_volume) < 2:
            return 0.0

        # 使用线性回归计算趋势
        x = np.arange(len(recent_volume))
        slope, _, r_value, _, _ = stats.linregress(x, recent_volume)

        # 趋势 = 斜率 * R²
        trend = slope * (r_value ** 2)

        # 归一化
        if np.mean(recent_volume) > 0:
            trend = trend / np.mean(recent_volume)

        return trend

    def _calculate_price_volume_correlation(self, price: np.ndarray, volume: np.ndarray,
                                          window: int = 20) -> float:
        """
        计算价格与成交量的相关性

        参数:
            price: 价格数组
            volume: 成交量数组
            window: 计算窗口

        返回:
            相关系数 (-1到1)
        """
        if len(price) < window + 1 or len(volume) < window + 1:
            return 0.0

        # 计算价格变化
        price_change = np.diff(price[-window-1:])

        # 获取对应的成交量
        vol = volume[-window:]

        if len(price_change) != len(vol):
            return 0.0

        # 计算相关系数
        correlation, _ = stats.pearsonr(price_change, vol)

        return correlation if not np.isnan(correlation) else 0.0

    def _calculate_trend(self, data: np.ndarray, window: int = 20) -> float:
        """
        计算数据趋势

        参数:
            data: 数据数组
            window: 趋势计算窗口

        返回:
            趋势 (正值表示上升，负值表示下降)
        """
        if len(data) < window + 1:
            return 0.0

        # 计算最近窗口的数据
        recent_data = data[-window:]

        if len(recent_data) < 2:
            return 0.0

        # 使用线性回归计算趋势
        x = np.arange(len(recent_data))
        slope, _, r_value, _, _ = stats.linregress(x, recent_data)

        # 趋势 = 斜率 * R²
        trend = slope * (r_value ** 2)

        # 归一化
        if np.mean(np.abs(recent_data)) > 0:
            trend = trend / np.mean(np.abs(recent_data))

        return trend

    def _calculate_chaikin_oscillator(self, high: np.ndarray, low: np.ndarray,
                                     close: np.ndarray, volume: np.ndarray) -> float:
        """
        计算Chaikin震荡指标

        参数:
            high: 最高价数组
            low: 最低价数组
            close: 收盘价数组
            volume: 成交量数组

        返回:
            Chaikin震荡指标值
        """
        try:
            # 计算资金流量指标 (Money Flow Multiplier)
            mfm = ((close - low) - (high - close)) / (high - low)
            mfm = np.where(high == low, 0, mfm)  # 避免除以零

            # 计算资金流量 (Money Flow Volume)
            mfv = mfm * volume

            # 计算资金流量累积 (Accumulation Distribution Line)
            adl = np.cumsum(mfv)

            # 计算Chaikin震荡指标 (3日EMA - 10日EMA)
            ema3 = talib.EMA(adl, timeperiod=3)
            ema10 = talib.EMA(adl, timeperiod=10)
            chaikin = ema3 - ema10

            return chaikin[-1]

        except Exception as e:
            logger.error(f"计算Chaikin震荡指标失败: {e}")
            return 0.0

    def _determine_volume_state(self, relative_volume: float, percentile: float,
                              volume_trend: float, price_volume_correlation: float,
                              obv_trend: float, chaikin_oscillator: float) -> VolumeState:
        """
        确定成交量状态

        参数:
            relative_volume: 相对成交量
            percentile: 成交量百分位
            volume_trend: 成交量趋势
            price_volume_correlation: 价格与成交量相关性
            obv_trend: OBV趋势
            chaikin_oscillator: Chaikin震荡指标

        返回:
            成交量状态
        """
        # 检测成交量高潮
        if relative_volume > 3.0 and percentile > 0.95:
            return VolumeState.CLIMAX

        # 检测成交量衰竭
        if relative_volume < 0.3 and percentile < 0.05 and volume_trend < -0.1:
            return VolumeState.EXHAUSTION

        # 检测背离
        if price_volume_correlation < -0.5 and obv_trend > 0.1:
            return VolumeState.DIVERGENCE_BULLISH
        if price_volume_correlation < -0.5 and obv_trend < -0.1:
            return VolumeState.DIVERGENCE_BEARISH

        # 检测成交量趋势
        if volume_trend > 0.1:
            return VolumeState.INCREASING
        if volume_trend < -0.1:
            return VolumeState.DECREASING

        # 基于百分位的状态判断
        if percentile >= 0.95:
            return VolumeState.EXTREMELY_HIGH
        elif percentile >= 0.8:
            return VolumeState.HIGH
        elif percentile >= 0.6:
            return VolumeState.ABOVE_NORMAL
        elif percentile >= 0.4:
            return VolumeState.NORMAL
        elif percentile >= 0.2:
            return VolumeState.BELOW_NORMAL
        elif percentile >= 0.05:
            return VolumeState.LOW
        else:
            return VolumeState.EXTREMELY_LOW

    def detect_volume_spike(self, data: pd.DataFrame,
                           threshold: float = 2.0,
                           window: int = 20) -> Dict[str, Any]:
        """
        检测成交量突增

        参数:
            data: OHLCV数据
            threshold: 突增阈值倍数
            window: 计算窗口

        返回:
            成交量突增分析结果
        """
        if data.empty or len(data) < window + 1:
            logger.warning("数据不足，无法检测成交量突增")
            return {
                'spike': False,
                'magnitude': 0.0,
                'price_change': 0.0
            }

        try:
            # 获取成交量数据
            volume = data['volume'].values

            # 计算平均成交量
            avg_volume = np.mean(volume[-window-1:-1])

            # 获取最新成交量
            current_volume = volume[-1]

            # 检测突增
            spike = current_volume > threshold * avg_volume

            # 计算突增幅度
            magnitude = current_volume / avg_volume if avg_volume > 0 else 0

            # 计算价格变化
            close = data['close'].values
            price_change = (close[-1] - close[-2]) / close[-2] if close[-2] > 0 else 0

            return {
                'spike': spike,
                'magnitude': magnitude,
                'price_change': price_change
            }

        except Exception as e:
            logger.error(f"检测成交量突增失败: {e}")
            return {
                'spike': False,
                'magnitude': 0.0,
                'price_change': 0.0
            }

    def analyze_volume_price_action(self, data: pd.DataFrame, window: int = 20) -> Dict[str, Any]:
        """
        分析成交量价格行为

        参数:
            data: OHLCV数据
            window: 计算窗口

        返回:
            成交量价格行为分析结果
        """
        if data.empty or len(data) < window + 1:
            logger.warning("数据不足，无法分析成交量价格行为")
            return {
                'volume_confirms_price': False,
                'volume_leads_price': False,
                'volume_divergence': False,
                'buying_pressure': 0.0,
                'selling_pressure': 0.0
            }

        try:
            # 获取数据
            close = data['close'].values
            volume = data['volume'].values

            # 计算价格变化
            price_change = np.diff(close[-window-1:])

            # 获取对应的成交量
            vol = volume[-window:]

            if len(price_change) != len(vol):
                return {
                    'volume_confirms_price': False,
                    'volume_leads_price': False,
                    'volume_divergence': False,
                    'buying_pressure': 0.0,
                    'selling_pressure': 0.0
                }

            # 计算价格与成交量的相关性
            correlation, _ = stats.pearsonr(price_change, vol)
            correlation = correlation if not np.isnan(correlation) else 0

            # 判断成交量是否确认价格
            volume_confirms_price = correlation > 0.5

            # 判断成交量是否领先价格
            # 使用滞后相关性分析
            lag_correlations = []
            for lag in range(1, min(5, window // 2)):
                if lag < len(price_change):
                    lagged_correlation, _ = stats.pearsonr(price_change[:-lag], vol[lag:])
                    lag_correlations.append(lagged_correlation if not np.isnan(lagged_correlation) else 0)

            volume_leads_price = any(lc > correlation + 0.2 for lc in lag_correlations)

            # 判断成交量背离
            volume_divergence = correlation < -0.5

            # 计算买入压力和卖出压力
            up_days = price_change > 0
            down_days = price_change < 0

            buying_pressure = np.sum(vol[up_days]) / np.sum(vol) if np.sum(vol) > 0 else 0
            selling_pressure = np.sum(vol[down_days]) / np.sum(vol) if np.sum(vol) > 0 else 0

            return {
                'volume_confirms_price': volume_confirms_price,
                'volume_leads_price': volume_leads_price,
                'volume_divergence': volume_divergence,
                'buying_pressure': buying_pressure,
                'selling_pressure': selling_pressure
            }

        except Exception as e:
            logger.error(f"分析成交量价格行为失败: {e}")
            return {
                'volume_confirms_price': False,
                'volume_leads_price': False,
                'volume_divergence': False,
                'buying_pressure': 0.0,
                'selling_pressure': 0.0
            }

    def analyze_multi_timeframe_volume(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        分析多时间周期成交量

        参数:
            data_dict: 不同时间周期的OHLCV数据字典 {timeframe: dataframe}

        返回:
            多时间周期成交量分析结果
        """
        if not data_dict:
            logger.warning("没有数据，无法分析多时间周期成交量")
            return {
                'overall_state': VolumeState.UNKNOWN,
                'consistency': 0.0,
                'buying_pressure': 0.0,
                'selling_pressure': 0.0,
                'timeframes': {}
            }

        try:
            # 分析每个时间周期的成交量
            timeframe_volume = {}
            for timeframe, data in data_dict.items():
                timeframe_volume[timeframe] = self.analyze_volume(data)

            # 计算整体成交量状态
            # 统计各状态出现次数
            state_counts = {}
            for tf, vol in timeframe_volume.items():
                state = vol['state']
                if state in state_counts:
                    state_counts[state] += 1
                else:
                    state_counts[state] = 1

            # 找出出现次数最多的状态
            if state_counts:
                overall_state = max(state_counts.items(), key=lambda x: x[1])[0]
            else:
                overall_state = VolumeState.UNKNOWN

            # 计算一致性
            consistency = max(state_counts.values()) / len(timeframe_volume) if timeframe_volume else 0

            # 计算整体买入压力和卖出压力
            buying_pressure = 0.0
            selling_pressure = 0.0

            for tf, data in data_dict.items():
                vpa = self.analyze_volume_price_action(data)
                buying_pressure += vpa['buying_pressure']
                selling_pressure += vpa['selling_pressure']

            if timeframe_volume:
                buying_pressure /= len(timeframe_volume)
                selling_pressure /= len(timeframe_volume)

            return {
                'overall_state': overall_state,
                'consistency': consistency,
                'buying_pressure': buying_pressure,
                'selling_pressure': selling_pressure,
                'timeframes': timeframe_volume
            }

        except Exception as e:
            logger.error(f"分析多时间周期成交量失败: {e}")
            return {
                'overall_state': VolumeState.UNKNOWN,
                'consistency': 0.0,
                'buying_pressure': 0.0,
                'selling_pressure': 0.0,
                'timeframes': {}
            }
