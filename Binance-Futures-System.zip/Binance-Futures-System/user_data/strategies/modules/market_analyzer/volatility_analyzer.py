#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
波动率分析组件

该模块负责分析市场波动性，包括波动率计算、波动率趋势分析和波动率异常检测。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import talib
from scipy import stats

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("volatility_analyzer")

class VolatilityState(Enum):
    """波动率状态枚举"""
    EXTREMELY_HIGH = "极高波动"
    HIGH = "高波动"
    ABOVE_NORMAL = "高于正常"
    NORMAL = "正常"
    BELOW_NORMAL = "低于正常"
    LOW = "低波动"
    EXTREMELY_LOW = "极低波动"
    INCREASING = "波动率上升"
    DECREASING = "波动率下降"
    UNKNOWN = "未知"

class VolatilityAnalyzer:
    """
    波动率分析类

    负责分析市场波动性，包括波动率计算、波动率趋势分析和波动率异常检测
    """

    def __init__(self):
        """初始化波动率分析器"""
        # 数据缓存
        self.data_cache = {}

    def update_data(self, symbol: str, timeframe: str, data: pd.DataFrame) -> None:
        """
        更新市场数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
        """
        if data.empty:
            logger.warning(f"更新空数据: {symbol} {timeframe}")
            return

        # 缓存数据
        key = f"{symbol}_{timeframe}"
        self.data_cache[key] = data

        logger.debug(f"已更新波动率分析数据: {symbol} {timeframe} {len(data)} 条记录")

    def get_volatility_state(self, symbol: str, timeframe: str) -> str:
        """
        获取波动率状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            波动率状态字符串
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取波动率状态，数据不存在: {symbol} {timeframe}")
            return "unknown"

        # 分析波动率
        volatility_result = self.analyze_volatility(data)
        state = volatility_result['state']

        # 转换为字符串
        if state in [VolatilityState.EXTREMELY_HIGH, VolatilityState.HIGH]:
            return "high"
        elif state in [VolatilityState.EXTREMELY_LOW, VolatilityState.LOW]:
            return "low"
        elif state == VolatilityState.INCREASING:
            return "increasing"
        elif state == VolatilityState.DECREASING:
            return "decreasing"
        elif state == VolatilityState.NORMAL:
            return "normal"
        else:
            return "unknown"

    def get_indicator(self, symbol: str, timeframe: str, indicator_name: str) -> Optional[float]:
        """
        获取波动率指标值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator_name: 指标名称

        返回:
            指标值
        """
        key = f"{symbol}_{timeframe}"
        data = self.data_cache.get(key)

        if data is None or data.empty:
            logger.warning(f"无法获取指标，数据不存在: {symbol} {timeframe} {indicator_name}")
            return None

        try:
            if indicator_name == 'atr':
                high = data['high'].values
                low = data['low'].values
                close = data['close'].values
                return talib.ATR(high, low, close, timeperiod=14)[-1] if len(data) >= 14 else None
            elif indicator_name == 'volatility':
                volatility_result = self.analyze_volatility(data)
                return volatility_result['current']
            elif indicator_name == 'bb_width':
                close = data['close'].values
                upper, middle, lower = talib.BBANDS(close, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
                return (upper[-1] - lower[-1]) / middle[-1] if len(data) >= 20 else None
            else:
                logger.warning(f"未知波动率指标: {indicator_name}")
                return None

        except Exception as e:
            logger.error(f"计算波动率指标失败: {indicator_name} {e}")
            return None

    def analyze_volatility(self, data: pd.DataFrame,
                          short_window: int = 14,
                          long_window: int = 50) -> Dict[str, Any]:
        """
        分析价格波动率

        参数:
            data: OHLCV数据
            short_window: 短期窗口大小
            long_window: 长期窗口大小

        返回:
            波动率分析结果字典
        """
        # 动态调整窗口大小以适应可用数据
        if data.empty or len(data) < 10:
            logger.warning("数据不足，无法分析波动率")
            return {
                'current': 0.0,
                'historical': 0.0,
                'state': VolatilityState.UNKNOWN,
                'trend': 0.0,
                'percentile': 0.0,
                'atr': 0.0,
                'atr_percent': 0.0,
                'bb_width': 0.0
            }

        # 根据可用数据调整窗口大小
        data_length = len(data)
        short_window = min(short_window, data_length // 2)
        long_window = min(long_window, data_length - 1)

        if short_window < 5:
            short_window = 5
        if long_window < short_window:
            long_window = short_window

        try:
            # 计算收益率
            returns = data['close'].pct_change().dropna()

            # 计算当前波动率（短期标准差）
            current_volatility = returns.rolling(window=short_window).std().iloc[-1]

            # 计算历史波动率（长期标准差）
            historical_volatility = returns.rolling(window=long_window).std().iloc[-1]

            # 计算波动率百分位
            volatility_series = returns.rolling(window=short_window).std().dropna()
            percentile = stats.percentileofscore(volatility_series, current_volatility) / 100

            # 计算波动率趋势
            volatility_trend = self._calculate_volatility_trend(volatility_series)

            # 计算ATR
            high = data['high'].values
            low = data['low'].values
            close = data['close'].values
            atr = talib.ATR(high, low, close, timeperiod=short_window)[-1]

            # 计算ATR占比
            atr_percent = atr / close[-1] * 100

            # 计算布林带宽度
            upper, middle, lower = talib.BBANDS(close, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
            bb_width = (upper[-1] - lower[-1]) / middle[-1]

            # 确定波动率状态
            state = self._determine_volatility_state(current_volatility, historical_volatility,
                                                   percentile, volatility_trend)

            return {
                'current': current_volatility,
                'historical': historical_volatility,
                'state': state,
                'trend': volatility_trend,
                'percentile': percentile,
                'atr': atr,
                'atr_percent': atr_percent,
                'bb_width': bb_width
            }

        except Exception as e:
            logger.error(f"分析波动率失败: {e}")
            return {
                'current': 0.0,
                'historical': 0.0,
                'state': VolatilityState.UNKNOWN,
                'trend': 0.0,
                'percentile': 0.0,
                'atr': 0.0,
                'atr_percent': 0.0,
                'bb_width': 0.0
            }

    def _calculate_volatility_trend(self, volatility_series: pd.Series, window: int = 5) -> float:
        """
        计算波动率趋势

        参数:
            volatility_series: 波动率时间序列
            window: 趋势计算窗口

        返回:
            波动率趋势 (正值表示上升，负值表示下降)
        """
        if len(volatility_series) < window + 1:
            return 0.0

        # 计算波动率变化率
        recent_volatility = volatility_series.iloc[-window:].values

        if len(recent_volatility) < 2:
            return 0.0

        # 使用线性回归计算趋势
        x = np.arange(len(recent_volatility))
        slope, _, r_value, _, _ = stats.linregress(x, recent_volatility)

        # 趋势 = 斜率 * R²
        trend = slope * (r_value ** 2)

        # 归一化
        if recent_volatility.mean() != 0:
            trend = trend / recent_volatility.mean()

        return trend

    def _determine_volatility_state(self, current: float, historical: float,
                                   percentile: float, trend: float) -> VolatilityState:
        """
        确定波动率状态

        参数:
            current: 当前波动率
            historical: 历史波动率
            percentile: 波动率百分位
            trend: 波动率趋势

        返回:
            波动率状态
        """
        # 基于百分位的状态判断
        if percentile >= 0.95:
            base_state = VolatilityState.EXTREMELY_HIGH
        elif percentile >= 0.8:
            base_state = VolatilityState.HIGH
        elif percentile >= 0.6:
            base_state = VolatilityState.ABOVE_NORMAL
        elif percentile >= 0.4:
            base_state = VolatilityState.NORMAL
        elif percentile >= 0.2:
            base_state = VolatilityState.BELOW_NORMAL
        elif percentile >= 0.05:
            base_state = VolatilityState.LOW
        else:
            base_state = VolatilityState.EXTREMELY_LOW

        # 考虑趋势因素
        if trend > 0.05:
            return VolatilityState.INCREASING
        elif trend < -0.05:
            return VolatilityState.DECREASING
        else:
            return base_state

    def detect_volatility_breakout(self, data: pd.DataFrame,
                                  window: int = 20,
                                  threshold: float = 2.0) -> Dict[str, Any]:
        """
        检测波动率突破

        参数:
            data: OHLCV数据
            window: 计算窗口
            threshold: 突破阈值倍数

        返回:
            波动率突破分析结果
        """
        if data.empty or len(data) < window + 1:
            logger.warning("数据不足，无法检测波动率突破")
            return {
                'breakout': False,
                'direction': 0,
                'magnitude': 0.0
            }

        try:
            # 计算收益率
            returns = data['close'].pct_change().dropna()

            # 计算历史波动率
            historical_volatility = returns.iloc[:-1].rolling(window=window).std().iloc[-1]

            # 计算最新收益率
            latest_return = returns.iloc[-1]

            # 检测突破
            breakout = abs(latest_return) > threshold * historical_volatility

            # 确定方向
            direction = 1 if latest_return > 0 else -1 if latest_return < 0 else 0

            # 计算突破幅度
            magnitude = abs(latest_return) / historical_volatility if historical_volatility > 0 else 0

            return {
                'breakout': breakout,
                'direction': direction,
                'magnitude': magnitude
            }

        except Exception as e:
            logger.error(f"检测波动率突破失败: {e}")
            return {
                'breakout': False,
                'direction': 0,
                'magnitude': 0.0
            }

    def analyze_volatility_regime(self, data: pd.DataFrame,
                                 lookback: int = 100) -> Dict[str, Any]:
        """
        分析波动率体制

        参数:
            data: OHLCV数据
            lookback: 回溯周期数

        返回:
            波动率体制分析结果
        """
        if data.empty or len(data) < lookback:
            logger.warning("数据不足，无法分析波动率体制")
            return {
                'regime': VolatilityState.UNKNOWN,
                'stability': 0.0,
                'forecast': VolatilityState.UNKNOWN
            }

        try:
            # 计算收益率
            returns = data['close'].pct_change().dropna()

            # 计算波动率序列
            volatility_series = returns.rolling(window=20).std().dropna()

            if len(volatility_series) < 10:
                return {
                    'regime': VolatilityState.UNKNOWN,
                    'stability': 0.0,
                    'forecast': VolatilityState.UNKNOWN
                }

            # 计算波动率均值和标准差
            vol_mean = volatility_series.mean()
            vol_std = volatility_series.std()

            # 计算当前波动率
            current_vol = volatility_series.iloc[-1]

            # 确定波动率体制
            if current_vol > vol_mean + 2 * vol_std:
                regime = VolatilityState.EXTREMELY_HIGH
            elif current_vol > vol_mean + vol_std:
                regime = VolatilityState.HIGH
            elif current_vol > vol_mean + 0.5 * vol_std:
                regime = VolatilityState.ABOVE_NORMAL
            elif current_vol > vol_mean - 0.5 * vol_std:
                regime = VolatilityState.NORMAL
            elif current_vol > vol_mean - vol_std:
                regime = VolatilityState.BELOW_NORMAL
            elif current_vol > vol_mean - 2 * vol_std:
                regime = VolatilityState.LOW
            else:
                regime = VolatilityState.EXTREMELY_LOW

            # 计算波动率稳定性
            # 使用变异系数 (CV) 衡量
            cv = vol_std / vol_mean if vol_mean > 0 else 0
            stability = 1 - min(cv, 1)  # 转换为稳定性指标 (0-1)

            # 预测未来波动率趋势
            # 使用简单的均值回归假设
            if regime in [VolatilityState.EXTREMELY_HIGH, VolatilityState.HIGH]:
                forecast = VolatilityState.DECREASING
            elif regime in [VolatilityState.EXTREMELY_LOW, VolatilityState.LOW]:
                forecast = VolatilityState.INCREASING
            else:
                # 使用最近趋势
                recent_trend = self._calculate_volatility_trend(volatility_series)
                if recent_trend > 0.05:
                    forecast = VolatilityState.INCREASING
                elif recent_trend < -0.05:
                    forecast = VolatilityState.DECREASING
                else:
                    forecast = regime

            return {
                'regime': regime,
                'stability': stability,
                'forecast': forecast
            }

        except Exception as e:
            logger.error(f"分析波动率体制失败: {e}")
            return {
                'regime': VolatilityState.UNKNOWN,
                'stability': 0.0,
                'forecast': VolatilityState.UNKNOWN
            }

    def calculate_optimal_stop_loss(self, data: pd.DataFrame,
                                   atr_multiplier: float = 2.0,
                                   volatility_adjustment: bool = True) -> Dict[str, float]:
        """
        计算基于波动率的最优止损位

        参数:
            data: OHLCV数据
            atr_multiplier: ATR乘数
            volatility_adjustment: 是否根据波动率调整

        返回:
            止损计算结果
        """
        if data.empty or len(data) < 20:
            logger.warning("数据不足，无法计算最优止损位")
            return {
                'long_stop': 0.0,
                'short_stop': 0.0,
                'stop_percent': 0.0
            }

        try:
            # 获取最新价格
            close = data['close'].iloc[-1]

            # 计算ATR
            high = data['high'].values
            low = data['low'].values
            close_array = data['close'].values
            atr = talib.ATR(high, low, close_array, timeperiod=14)[-1]

            # 基础止损距离
            stop_distance = atr * atr_multiplier

            # 如果启用波动率调整
            if volatility_adjustment:
                # 分析当前波动率状态
                volatility = self.analyze_volatility(data)

                # 根据波动率状态调整ATR乘数
                if volatility['state'] in [VolatilityState.EXTREMELY_HIGH, VolatilityState.HIGH]:
                    # 高波动环境，增加止损距离
                    stop_distance *= 1.5
                elif volatility['state'] in [VolatilityState.EXTREMELY_LOW, VolatilityState.LOW]:
                    # 低波动环境，减少止损距离
                    stop_distance *= 0.8

            # 计算多头和空头止损位
            long_stop = close - stop_distance
            short_stop = close + stop_distance

            # 计算止损百分比
            stop_percent = stop_distance / close * 100

            return {
                'long_stop': long_stop,
                'short_stop': short_stop,
                'stop_percent': stop_percent
            }

        except Exception as e:
            logger.error(f"计算最优止损位失败: {e}")
            return {
                'long_stop': 0.0,
                'short_stop': 0.0,
                'stop_percent': 0.0
            }

    def analyze_multi_timeframe_volatility(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        分析多时间周期波动率

        参数:
            data_dict: 不同时间周期的OHLCV数据字典 {timeframe: dataframe}

        返回:
            多时间周期波动率分析结果
        """
        if not data_dict:
            logger.warning("没有数据，无法分析多时间周期波动率")
            return {
                'overall_state': VolatilityState.UNKNOWN,
                'consistency': 0.0,
                'timeframes': {}
            }

        try:
            # 分析每个时间周期的波动率
            timeframe_volatility = {}
            for timeframe, data in data_dict.items():
                timeframe_volatility[timeframe] = self.analyze_volatility(data)

            # 计算整体波动率状态
            # 统计各状态出现次数
            state_counts = {}
            for tf, vol in timeframe_volatility.items():
                state = vol['state']
                if state in state_counts:
                    state_counts[state] += 1
                else:
                    state_counts[state] = 1

            # 找出出现次数最多的状态
            if state_counts:
                overall_state = max(state_counts.items(), key=lambda x: x[1])[0]
            else:
                overall_state = VolatilityState.UNKNOWN

            # 计算一致性
            consistency = max(state_counts.values()) / len(timeframe_volatility) if timeframe_volatility else 0

            return {
                'overall_state': overall_state,
                'consistency': consistency,
                'timeframes': timeframe_volatility
            }

        except Exception as e:
            logger.error(f"分析多时间周期波动率失败: {e}")
            return {
                'overall_state': VolatilityState.UNKNOWN,
                'consistency': 0.0,
                'timeframes': {}
            }
