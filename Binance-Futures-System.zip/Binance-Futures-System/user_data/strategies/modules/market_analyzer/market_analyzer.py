#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场分析器

该模块提供市场分析功能，整合趋势、波动率和成交量分析。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
from enum import Enum, auto
import logging

from user_data.strategies.modules.market_analyzer.trend_analyzer import TrendAnalyzer
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer
from user_data.strategies.modules.market_analyzer.volume_analyzer import VolumeAnalyzer
from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("market_analyzer")

class MarketState(Enum):
    """市场状态枚举"""
    BULL = auto()  # 牛市
    BEAR = auto()  # 熊市
    SIDEWAYS = auto()  # 盘整
    VOLATILE = auto()  # 高波动
    UNKNOWN = auto()  # 未知

    # 兼容性别名
    UPTREND = BULL  # 上升趋势（牛市）
    DOWNTREND = BEAR  # 下降趋势（熊市）
    RANGING = SIDEWAYS  # 震荡（盘整）

class MarketAnalyzer:
    """
    市场分析器

    整合趋势、波动率和成交量分析，提供全面的市场分析功能。
    """

    def __init__(self):
        """初始化市场分析器"""
        self.trend_analyzer = TrendAnalyzer()
        self.volatility_analyzer = VolatilityAnalyzer()
        self.volume_analyzer = VolumeAnalyzer()

        # 缓存数据
        self.data_cache = {}
        self.indicator_cache = {}
        self.market_state_cache = {}

        logger.info("市场分析器初始化完成")

    def update_data(self, symbol: str, timeframe: str, data: pd.DataFrame) -> None:
        """
        更新市场数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
        """
        if data.empty:
            logger.warning(f"更新空数据: {symbol} {timeframe}")
            return

        # 缓存数据
        key = f"{symbol}_{timeframe}"
        self.data_cache[key] = data

        # 更新子分析器
        self.trend_analyzer.update_data(symbol, timeframe, data)
        self.volatility_analyzer.update_data(symbol, timeframe, data)
        self.volume_analyzer.update_data(symbol, timeframe, data)

        # 清除缓存的指标和市场状态
        if key in self.indicator_cache:
            del self.indicator_cache[key]
        if key in self.market_state_cache:
            del self.market_state_cache[key]

        logger.debug(f"已更新市场数据: {symbol} {timeframe} {len(data)} 条记录")

    def get_market_state(self, symbol: str, timeframe: str) -> MarketState:
        """
        获取市场状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            市场状态
        """
        key = f"{symbol}_{timeframe}"

        # 检查缓存
        if key in self.market_state_cache:
            return self.market_state_cache[key]

        # 获取数据
        data = self.data_cache.get(key)
        if data is None or data.empty:
            logger.warning(f"无法获取市场状态，数据不存在: {symbol} {timeframe}")
            return MarketState.UNKNOWN

        # 获取趋势状态
        trend_state = self.trend_analyzer.get_trend_state(symbol, timeframe)

        # 获取波动率状态
        volatility_state = self.volatility_analyzer.get_volatility_state(symbol, timeframe)

        # 获取成交量状态
        volume_state = self.volume_analyzer.get_volume_state(symbol, timeframe)

        # 综合分析市场状态
        if trend_state == "uptrend" and volatility_state != "high":
            market_state = MarketState.BULL
        elif trend_state == "downtrend" and volatility_state != "high":
            market_state = MarketState.BEAR
        elif trend_state == "sideways" and volatility_state == "low":
            market_state = MarketState.SIDEWAYS
        elif volatility_state == "high":
            market_state = MarketState.VOLATILE
        else:
            market_state = MarketState.UNKNOWN

        # 缓存市场状态
        self.market_state_cache[key] = market_state

        logger.debug(f"市场状态: {symbol} {timeframe} {market_state.name}")
        return market_state

    def get_indicator(self, symbol: str, timeframe: str, indicator_name: str) -> Optional[float]:
        """
        获取技术指标值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator_name: 指标名称

        返回:
            指标值
        """
        key = f"{symbol}_{timeframe}"
        cache_key = f"{key}_{indicator_name}"

        # 检查缓存
        if cache_key in self.indicator_cache:
            return self.indicator_cache[cache_key]

        # 获取数据
        data = self.data_cache.get(key)
        if data is None or data.empty:
            logger.warning(f"无法获取指标，数据不存在: {symbol} {timeframe} {indicator_name}")
            return None

        # 根据指标名称获取值
        indicator_value = None

        # 趋势指标
        if indicator_name in ['sma20', 'sma50', 'sma200', 'ema9', 'ema21']:
            indicator_value = self.trend_analyzer.get_indicator(symbol, timeframe, indicator_name)

        # 波动率指标
        elif indicator_name in ['atr', 'bollinger_upper', 'bollinger_middle', 'bollinger_lower']:
            indicator_value = self.volatility_analyzer.get_indicator(symbol, timeframe, indicator_name)

        # 成交量指标
        elif indicator_name in ['volume_sma20', 'obv', 'vwap']:
            indicator_value = self.volume_analyzer.get_indicator(symbol, timeframe, indicator_name)

        # 其他指标
        elif indicator_name == 'rsi14':
            indicator_value = self.trend_analyzer.get_indicator(symbol, timeframe, 'rsi')
        elif indicator_name in ['macd', 'macdsignal', 'macdhist']:
            macd_values = self.trend_analyzer.get_indicator(symbol, timeframe, 'macd')
            if macd_values is not None:
                if indicator_name == 'macd':
                    indicator_value = macd_values[0]
                elif indicator_name == 'macdsignal':
                    indicator_value = macd_values[1]
                elif indicator_name == 'macdhist':
                    indicator_value = macd_values[2]
        elif indicator_name in ['slowk', 'slowd']:
            stoch_values = self.trend_analyzer.get_indicator(symbol, timeframe, 'stoch')
            if stoch_values is not None:
                if indicator_name == 'slowk':
                    indicator_value = stoch_values[0]
                elif indicator_name == 'slowd':
                    indicator_value = stoch_values[1]
        elif indicator_name in ['upperband', 'middleband', 'lowerband']:
            bb_values = self.volatility_analyzer.get_indicator(symbol, timeframe, 'bollinger_bands')
            if bb_values is not None:
                if indicator_name == 'upperband':
                    indicator_value = bb_values[0]
                elif indicator_name == 'middleband':
                    indicator_value = bb_values[1]
                elif indicator_name == 'lowerband':
                    indicator_value = bb_values[2]

        # 缓存指标值
        if indicator_value is not None:
            self.indicator_cache[cache_key] = indicator_value

        return indicator_value

    def get_support_resistance_levels(self, symbol: str, timeframe: str) -> Dict[str, List[float]]:
        """
        获取支撑和阻力位

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            支撑和阻力位字典
        """
        return self.trend_analyzer.get_support_resistance_levels(symbol, timeframe)

    def get_volatility_metrics(self, symbol: str, timeframe: str) -> Dict[str, float]:
        """
        获取波动率指标

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            波动率指标字典
        """
        return self.volatility_analyzer.get_volatility_metrics(symbol, timeframe)

    def get_volume_profile(self, symbol: str, timeframe: str) -> Dict[str, Any]:
        """
        获取成交量分布

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            成交量分布字典
        """
        return self.volume_analyzer.get_volume_profile(symbol, timeframe)
