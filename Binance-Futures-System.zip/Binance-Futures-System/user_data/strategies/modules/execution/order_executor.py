#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
订单执行器模块

该模块负责执行交易订单，包括订单创建、提交、跟踪和取消等功能。

作者: 高级Python工程师
日期: 2024-05-21
"""

import time
import json
import uuid
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from datetime import datetime, timedelta
import ccxt
import asyncio
import threading

from user_data.strategies.utils.logging_utils import get_logger, log_trade
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.execution.api_manager import ApiManager

# 获取日志记录器
logger = get_logger("order_executor")

class OrderType(Enum):
    """订单类型枚举"""
    MARKET = "市价单"
    LIMIT = "限价单"
    STOP = "止损单"
    STOP_LIMIT = "止损限价单"
    TRAILING_STOP = "追踪止损单"

class OrderSide(Enum):
    """订单方向枚举"""
    BUY = "买入"
    SELL = "卖出"

class OrderStatus(Enum):
    """订单状态枚举"""
    PENDING = "等待中"
    OPEN = "已开仓"
    PARTIALLY_FILLED = "部分成交"
    FILLED = "已成交"
    CANCELED = "已取消"
    REJECTED = "已拒绝"
    EXPIRED = "已过期"
    ERROR = "错误"

class OrderExecutor:
    """
    订单执行器类

    负责执行交易订单，包括订单创建、提交、跟踪和取消等功能
    """

    def __init__(self, exchange=None):
        """
        初始化订单执行器

        参数:
            exchange: 交易所对象
        """
        self.exchange = exchange

        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 订单执行参数
            'default_order_type': OrderType.LIMIT,  # 默认订单类型
            'market_order_slippage': 0.001,  # 市价单滑点（0.1%）
            'limit_order_post_only': True,  # 限价单是否仅挂单
            'limit_order_time_in_force': 'GTC',  # 限价单有效期（GTC: 成交为止）
            'limit_order_price_buffer': 0.001,  # 限价单价格缓冲（0.1%）

            # 订单跟踪参数
            'order_update_interval': 5,  # 订单更新间隔（秒）
            'max_order_update_retries': 3,  # 最大订单更新重试次数
            'order_timeout': 60,  # 订单超时时间（秒）

            # 订单取消参数
            'cancel_all_on_exit': True,  # 退出时是否取消所有订单
            'auto_cancel_partial_fill': False,  # 是否自动取消部分成交订单
            'partial_fill_timeout': 300,  # 部分成交超时时间（秒）

            # 错误处理参数
            'retry_on_error': True,  # 错误时是否重试
            'max_retries': 3,  # 最大重试次数
            'retry_delay': 1,  # 重试延迟（秒）

            # 订单簿参数
            'use_order_book_for_limit': True,  # 是否使用订单簿优化限价单
            'order_book_depth': 5,  # 订单簿深度
        }

        # 订单缓存
        self.orders = {}  # {order_id: order_info}

        # 订单历史
        self.order_history = []

        # 订单跟踪线程
        self.tracking_thread = None
        self.tracking_active = False

    def create_order(self, symbol: str, order_type: OrderType, side: OrderSide,
                   amount: float, price: Optional[float] = None,
                   params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        创建订单

        参数:
            symbol: 交易对符号
            order_type: 订单类型
            side: 订单方向
            amount: 订单数量
            price: 订单价格（限价单必需）
            params: 其他参数

        返回:
            订单信息
        """
        if self.exchange is None:
            logger.error("交易所对象未设置，无法创建订单")
            return {
                'status': OrderStatus.ERROR,
                'error': '交易所对象未设置'
            }

        try:
            # 生成客户端订单ID
            client_order_id = f"algo_{int(time.time())}_{uuid.uuid4().hex[:8]}"

            # 准备订单参数
            order_params = params or {}
            order_params['clientOrderId'] = client_order_id

            # 根据订单类型设置参数
            if order_type == OrderType.LIMIT:
                if price is None:
                    logger.error("限价单必须指定价格")
                    return {
                        'status': OrderStatus.ERROR,
                        'error': '限价单必须指定价格'
                    }

                # 设置限价单参数
                if self.params['limit_order_post_only']:
                    order_params['postOnly'] = True

                order_params['timeInForce'] = self.params['limit_order_time_in_force']

                # 优化限价单价格
                if self.params['use_order_book_for_limit']:
                    price = self._optimize_limit_price(symbol, side, price)

            elif order_type == OrderType.MARKET:
                # 市价单不需要价格
                price = None

            elif order_type == OrderType.STOP:
                if price is None:
                    logger.error("止损单必须指定价格")
                    return {
                        'status': OrderStatus.ERROR,
                        'error': '止损单必须指定价格'
                    }

                # 设置止损单参数
                order_params['stopPrice'] = price

            elif order_type == OrderType.STOP_LIMIT:
                if price is None:
                    logger.error("止损限价单必须指定价格")
                    return {
                        'status': OrderStatus.ERROR,
                        'error': '止损限价单必须指定价格'
                    }

                # 设置止损限价单参数
                stop_price = order_params.get('stopPrice')
                if stop_price is None:
                    logger.error("止损限价单必须指定止损价格")
                    return {
                        'status': OrderStatus.ERROR,
                        'error': '止损限价单必须指定止损价格'
                    }

            elif order_type == OrderType.TRAILING_STOP:
                # 设置追踪止损单参数
                callback_rate = order_params.get('callbackRate')
                if callback_rate is None:
                    logger.error("追踪止损单必须指定回调比率")
                    return {
                        'status': OrderStatus.ERROR,
                        'error': '追踪止损单必须指定回调比率'
                    }

            # 创建订单
            ccxt_order_type = order_type.name.lower()
            ccxt_side = side.name.lower()

            # 提交订单
            response = self.exchange.create_order(
                symbol,
                ccxt_order_type,
                ccxt_side,
                amount,
                price,
                order_params
            )

            # 解析响应
            order_info = self._parse_order_response(response)

            # 添加到订单缓存
            self.orders[order_info['id']] = order_info

            # 记录订单
            logger.info(f"创建订单: {symbol} {side.name} {amount} @ {price} ({order_type.name})")

            # 启动订单跟踪
            self._ensure_tracking_thread()

            return order_info

        except Exception as e:
            logger.error(f"创建订单失败: {e}")

            # 重试
            if self.params['retry_on_error']:
                for i in range(self.params['max_retries']):
                    logger.info(f"重试创建订单 ({i+1}/{self.params['max_retries']})")
                    time.sleep(self.params['retry_delay'])

                    try:
                        # 重试创建订单
                        response = self.exchange.create_order(
                            symbol,
                            ccxt_order_type,
                            ccxt_side,
                            amount,
                            price,
                            order_params
                        )

                        # 解析响应
                        order_info = self._parse_order_response(response)

                        # 添加到订单缓存
                        self.orders[order_info['id']] = order_info

                        # 记录订单
                        logger.info(f"重试创建订单成功: {symbol} {side.name} {amount} @ {price} ({order_type.name})")

                        # 启动订单跟踪
                        self._ensure_tracking_thread()

                        return order_info

                    except Exception as retry_e:
                        logger.error(f"重试创建订单失败: {retry_e}")

            return {
                'status': OrderStatus.ERROR,
                'error': str(e),
                'symbol': symbol,
                'type': order_type.name,
                'side': side.name,
                'amount': amount,
                'price': price
            }

    def _optimize_limit_price(self, symbol: str, side: OrderSide, price: float) -> float:
        """
        优化限价单价格

        参数:
            symbol: 交易对符号
            side: 订单方向
            price: 原始价格

        返回:
            优化后的价格
        """
        try:
            # 获取订单簿
            order_book = self.exchange.fetch_order_book(symbol, self.params['order_book_depth'])

            if side == OrderSide.BUY:
                # 买单：价格应该略高于最高买单价格
                bids = order_book['bids']
                if bids:
                    best_bid = bids[0][0]
                    # 在最高买单价格和原始价格之间取较小值
                    optimized_price = min(price, best_bid * (1 + self.params['limit_order_price_buffer']))
                    return optimized_price

            else:  # OrderSide.SELL
                # 卖单：价格应该略低于最低卖单价格
                asks = order_book['asks']
                if asks:
                    best_ask = asks[0][0]
                    # 在最低卖单价格和原始价格之间取较大值
                    optimized_price = max(price, best_ask * (1 - self.params['limit_order_price_buffer']))
                    return optimized_price

            return price

        except Exception as e:
            logger.error(f"优化限价单价格失败: {e}")
            return price

    def _parse_order_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析订单响应

        参数:
            response: 交易所响应

        返回:
            标准化的订单信息
        """
        try:
            # 提取订单信息
            order_id = response.get('id', '')
            client_order_id = response.get('clientOrderId', '')
            symbol = response.get('symbol', '')
            order_type = response.get('type', '').upper()
            side = response.get('side', '').upper()
            price = response.get('price', 0.0)
            amount = response.get('amount', 0.0)
            filled = response.get('filled', 0.0)
            remaining = response.get('remaining', amount)
            status = response.get('status', '').upper()

            # 转换状态
            if status == 'OPEN':
                order_status = OrderStatus.OPEN
            elif status == 'CLOSED':
                order_status = OrderStatus.FILLED
            elif status == 'CANCELED':
                order_status = OrderStatus.CANCELED
            elif status == 'EXPIRED':
                order_status = OrderStatus.EXPIRED
            elif status == 'REJECTED':
                order_status = OrderStatus.REJECTED
            elif filled > 0 and filled < amount:
                order_status = OrderStatus.PARTIALLY_FILLED
            else:
                order_status = OrderStatus.PENDING

            # 构建标准化订单信息
            order_info = {
                'id': order_id,
                'client_order_id': client_order_id,
                'symbol': symbol,
                'type': OrderType[order_type] if order_type in OrderType.__members__ else OrderType.MARKET,
                'side': OrderSide[side] if side in OrderSide.__members__ else OrderSide.BUY,
                'price': price,
                'amount': amount,
                'filled': filled,
                'remaining': remaining,
                'status': order_status,
                'created_time': datetime.now(),
                'updated_time': datetime.now(),
                'raw_response': response
            }

            return order_info

        except Exception as e:
            logger.error(f"解析订单响应失败: {e}")
            return {
                'id': response.get('id', ''),
                'status': OrderStatus.ERROR,
                'error': str(e),
                'raw_response': response
            }

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """
        取消订单

        参数:
            order_id: 订单ID

        返回:
            取消结果
        """
        if self.exchange is None:
            logger.error("交易所对象未设置，无法取消订单")
            return {
                'status': OrderStatus.ERROR,
                'error': '交易所对象未设置'
            }

        try:
            # 检查订单是否存在
            if order_id not in self.orders:
                logger.warning(f"订单 {order_id} 不存在，无法取消")
                return {
                    'status': OrderStatus.ERROR,
                    'error': '订单不存在'
                }

            # 获取订单信息
            order_info = self.orders[order_id]

            # 检查订单状态
            if order_info['status'] in [OrderStatus.FILLED, OrderStatus.CANCELED, OrderStatus.REJECTED, OrderStatus.EXPIRED]:
                logger.warning(f"订单 {order_id} 已经处于终态 {order_info['status'].name}，无法取消")
                return order_info

            # 取消订单
            response = self.exchange.cancel_order(order_id, order_info['symbol'])

            # 更新订单信息
            updated_info = self._parse_order_response(response)
            updated_info['status'] = OrderStatus.CANCELED
            updated_info['updated_time'] = datetime.now()

            # 更新订单缓存
            self.orders[order_id] = updated_info

            # 添加到订单历史
            self.order_history.append(updated_info)

            # 从订单缓存中移除
            self.orders.pop(order_id, None)

            logger.info(f"取消订单: {order_id}")

            return updated_info

        except Exception as e:
            logger.error(f"取消订单失败: {e}")

            # 重试
            if self.params['retry_on_error']:
                for i in range(self.params['max_retries']):
                    logger.info(f"重试取消订单 ({i+1}/{self.params['max_retries']})")
                    time.sleep(self.params['retry_delay'])

                    try:
                        # 重试取消订单
                        response = self.exchange.cancel_order(order_id, order_info['symbol'])

                        # 更新订单信息
                        updated_info = self._parse_order_response(response)
                        updated_info['status'] = OrderStatus.CANCELED
                        updated_info['updated_time'] = datetime.now()

                        # 更新订单缓存
                        self.orders[order_id] = updated_info

                        # 添加到订单历史
                        self.order_history.append(updated_info)

                        # 从订单缓存中移除
                        self.orders.pop(order_id, None)

                        logger.info(f"重试取消订单成功: {order_id}")

                        return updated_info

                    except Exception as retry_e:
                        logger.error(f"重试取消订单失败: {retry_e}")

            # 标记订单为错误状态
            order_info['status'] = OrderStatus.ERROR
            order_info['error'] = str(e)
            order_info['updated_time'] = datetime.now()

            return order_info

    def fetch_order(self, order_id: str) -> Dict[str, Any]:
        """
        获取订单信息

        参数:
            order_id: 订单ID

        返回:
            订单信息
        """
        if self.exchange is None:
            logger.error("交易所对象未设置，无法获取订单信息")
            return {
                'status': OrderStatus.ERROR,
                'error': '交易所对象未设置'
            }

        try:
            # 检查订单是否存在于缓存中
            if order_id in self.orders:
                order_info = self.orders[order_id]

                # 获取最新订单信息
                response = self.exchange.fetch_order(order_id, order_info['symbol'])

                # 更新订单信息
                updated_info = self._parse_order_response(response)
                updated_info['updated_time'] = datetime.now()

                # 更新订单缓存
                self.orders[order_id] = updated_info

                # 检查订单是否已完成
                if updated_info['status'] in [OrderStatus.FILLED, OrderStatus.CANCELED, OrderStatus.REJECTED, OrderStatus.EXPIRED]:
                    # 添加到订单历史
                    self.order_history.append(updated_info)

                    # 从订单缓存中移除
                    self.orders.pop(order_id, None)

                    # 记录成交
                    if updated_info['status'] == OrderStatus.FILLED:
                        self._log_trade(updated_info)

                return updated_info

            # 如果订单不在缓存中，尝试从交易所获取
            for symbol in self.exchange.markets:
                try:
                    response = self.exchange.fetch_order(order_id, symbol)

                    # 解析订单信息
                    order_info = self._parse_order_response(response)

                    # 添加到订单历史
                    self.order_history.append(order_info)

                    return order_info

                except Exception:
                    continue

            logger.warning(f"订单 {order_id} 不存在")
            return {
                'id': order_id,
                'status': OrderStatus.ERROR,
                'error': '订单不存在'
            }

        except Exception as e:
            logger.error(f"获取订单信息失败: {e}")

            # 重试
            if self.params['retry_on_error']:
                for i in range(self.params['max_retries']):
                    logger.info(f"重试获取订单信息 ({i+1}/{self.params['max_retries']})")
                    time.sleep(self.params['retry_delay'])

                    try:
                        # 重试获取订单信息
                        response = self.exchange.fetch_order(order_id, order_info['symbol'])

                        # 更新订单信息
                        updated_info = self._parse_order_response(response)
                        updated_info['updated_time'] = datetime.now()

                        return updated_info

                    except Exception as retry_e:
                        logger.error(f"重试获取订单信息失败: {retry_e}")

            return {
                'id': order_id,
                'status': OrderStatus.ERROR,
                'error': str(e)
            }

    def _log_trade(self, order_info: Dict[str, Any]) -> None:
        """
        记录成交

        参数:
            order_info: 订单信息
        """
        try:
            # 提取交易信息
            symbol = order_info['symbol']
            side = order_info['side'].name.lower()
            amount = order_info['filled']
            price = order_info['price']

            # 记录交易
            log_trade(side, symbol, price, amount)

        except Exception as e:
            logger.error(f"记录成交失败: {e}")

    def _ensure_tracking_thread(self) -> None:
        """确保订单跟踪线程正在运行"""
        if self.tracking_thread is None or not self.tracking_thread.is_alive():
            self.tracking_active = True
            self.tracking_thread = threading.Thread(target=self._track_orders)
            self.tracking_thread.daemon = True
            self.tracking_thread.start()

    def _track_orders(self) -> None:
        """订单跟踪线程"""
        logger.info("启动订单跟踪线程")

        while self.tracking_active and self.orders:
            try:
                # 遍历所有活跃订单
                for order_id in list(self.orders.keys()):
                    # 获取订单信息
                    order_info = self.orders.get(order_id)

                    if order_info is None:
                        continue

                    # 检查订单是否已超时
                    if (datetime.now() - order_info['created_time']).total_seconds() > self.params['order_timeout']:
                        logger.warning(f"订单 {order_id} 已超时，尝试取消")
                        self.cancel_order(order_id)
                        continue

                    # 更新订单状态
                    updated_info = self.fetch_order(order_id)

                    # 检查部分成交超时
                    if (updated_info['status'] == OrderStatus.PARTIALLY_FILLED and
                        self.params['auto_cancel_partial_fill'] and
                        (datetime.now() - updated_info['updated_time']).total_seconds() > self.params['partial_fill_timeout']):
                        logger.warning(f"部分成交订单 {order_id} 已超时，尝试取消")
                        self.cancel_order(order_id)

            except Exception as e:
                logger.error(f"订单跟踪线程异常: {e}")

            # 等待下一次更新
            time.sleep(self.params['order_update_interval'])

        logger.info("订单跟踪线程结束")

    def cancel_all_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        取消所有订单

        参数:
            symbol: 交易对符号（可选）

        返回:
            取消结果列表
        """
        if self.exchange is None:
            logger.error("交易所对象未设置，无法取消订单")
            return [{
                'status': OrderStatus.ERROR,
                'error': '交易所对象未设置'
            }]

        try:
            results = []

            # 获取要取消的订单ID列表
            order_ids = list(self.orders.keys())

            # 如果指定了交易对，只取消该交易对的订单
            if symbol:
                order_ids = [oid for oid, order in self.orders.items() if order['symbol'] == symbol]

            # 取消订单
            for order_id in order_ids:
                result = self.cancel_order(order_id)
                results.append(result)

            # 如果没有指定交易对，尝试使用交易所的批量取消功能
            if not symbol:
                try:
                    self.exchange.cancel_all_orders()
                    logger.info("已取消所有订单")
                except Exception as e:
                    logger.error(f"批量取消订单失败: {e}")

            return results

        except Exception as e:
            logger.error(f"取消所有订单失败: {e}")
            return [{
                'status': OrderStatus.ERROR,
                'error': str(e)
            }]

    def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        获取未完成订单

        参数:
            symbol: 交易对符号（可选）

        返回:
            未完成订单列表
        """
        if self.exchange is None:
            logger.error("交易所对象未设置，无法获取未完成订单")
            return []

        try:
            # 从缓存中获取未完成订单
            open_orders = list(self.orders.values())

            # 如果指定了交易对，只返回该交易对的订单
            if symbol:
                open_orders = [order for order in open_orders if order['symbol'] == symbol]

            # 从交易所获取最新未完成订单
            try:
                exchange_open_orders = self.exchange.fetch_open_orders(symbol)

                # 更新订单缓存
                for order in exchange_open_orders:
                    order_info = self._parse_order_response(order)
                    self.orders[order_info['id']] = order_info

                # 重新获取未完成订单
                open_orders = list(self.orders.values())

                # 如果指定了交易对，只返回该交易对的订单
                if symbol:
                    open_orders = [order for order in open_orders if order['symbol'] == symbol]

            except Exception as e:
                logger.error(f"从交易所获取未完成订单失败: {e}")

            return open_orders

        except Exception as e:
            logger.error(f"获取未完成订单失败: {e}")
            return []

    def get_order_history(self, symbol: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取订单历史

        参数:
            symbol: 交易对符号（可选）
            limit: 返回数量限制

        返回:
            订单历史列表
        """
        try:
            # 从缓存中获取订单历史
            history = self.order_history

            # 如果指定了交易对，只返回该交易对的订单
            if symbol:
                history = [order for order in history if order['symbol'] == symbol]

            # 限制返回数量
            history = history[-limit:]

            return history

        except Exception as e:
            logger.error(f"获取订单历史失败: {e}")
            return []

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置订单执行参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取订单执行参数

        返回:
            参数字典
        """
        return self.params.copy()

    def cleanup(self) -> None:
        """清理资源"""
        # 停止订单跟踪线程
        self.tracking_active = False

        if self.tracking_thread and self.tracking_thread.is_alive():
            self.tracking_thread.join(timeout=5)

        # 取消所有订单
        if self.params['cancel_all_on_exit']:
            self.cancel_all_orders()
