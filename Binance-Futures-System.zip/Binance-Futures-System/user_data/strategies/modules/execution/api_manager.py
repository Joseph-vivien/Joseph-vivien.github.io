#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
API管理器模块

该模块负责管理交易所API连接，包括API密钥管理、请求限制、错误处理和重试机制。

作者: 高级Python工程师
日期: 2024-05-21
"""

import time
import json
import hmac
import hashlib
import base64
import urllib.parse
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from datetime import datetime, timedelta
import ccxt
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager

# 获取日志记录器
logger = get_logger("api_manager")

class ExchangeType(Enum):
    """交易所类型枚举"""
    BINANCE = "Binance"
    BINANCE_FUTURES = "Binance Futures"
    BYBIT = "Bybit"
    OKEX = "OKEx"
    HUOBI = "Huobi"
    BITFINEX = "Bitfinex"
    KRAKEN = "Kraken"
    COINBASE = "Coinbase"
    FTX = "FTX"
    DERIBIT = "Deribit"
    BITMEX = "BitMEX"
    CUSTOM = "Custom"

class ApiManager:
    """
    API管理器类
    
    负责管理交易所API连接，包括API密钥管理、请求限制、错误处理和重试机制
    """
    
    def __init__(self, exchange_type: ExchangeType = ExchangeType.BINANCE, config: Optional[Dict[str, Any]] = None):
        """
        初始化API管理器
        
        参数:
            exchange_type: 交易所类型
            config: 配置字典
        """
        self.exchange_type = exchange_type
        
        # 加载配置
        self.config_manager = get_config_manager()
        self.config = config or {}
        
        # 设置默认参数
        self.params = {
            # API参数
            'api_key': '',
            'api_secret': '',
            'password': '',  # 某些交易所需要
            'testnet': False,  # 是否使用测试网络
            
            # 请求限制参数
            'rate_limit': True,  # 是否启用请求限制
            'max_retries': 3,  # 最大重试次数
            'retry_delay': 1,  # 重试延迟（秒）
            'timeout': 30,  # 请求超时时间（秒）
            
            # 代理参数
            'use_proxy': False,  # 是否使用代理
            'proxy': '',  # 代理地址
            
            # 其他参数
            'verbose': False,  # 是否输出详细日志
            'load_markets': True,  # 是否加载市场数据
            'enable_rate_limit': True,  # 是否启用CCXT内置的请求限制
        }
        
        # 从配置中加载API参数
        self._load_api_config()
        
        # 初始化交易所对象
        self.exchange = None
        self._init_exchange()
        
        # 请求计数器
        self.request_counter = {
            'total': 0,
            'success': 0,
            'error': 0,
            'retry': 0,
            'last_reset': datetime.now()
        }
        
        # 请求限制
        self.rate_limits = {}
        
        # 初始化请求会话
        self.session = self._init_session()
        
    def _load_api_config(self) -> None:
        """加载API配置"""
        try:
            # 从配置中加载API参数
            exchange_config = self.config.get('exchange', {})
            
            if isinstance(exchange_config, dict):
                # 更新API参数
                for key, value in exchange_config.items():
                    if key in self.params:
                        self.params[key] = value
                        
            # 从环境变量或配置文件加载API密钥
            api_key_file = self.config.get('api_key_file', '')
            
            if api_key_file:
                try:
                    with open(api_key_file, 'r') as f:
                        api_keys = json.load(f)
                        
                    exchange_name = self.exchange_type.name.lower()
                    if exchange_name in api_keys:
                        exchange_keys = api_keys[exchange_name]
                        self.params['api_key'] = exchange_keys.get('api_key', '')
                        self.params['api_secret'] = exchange_keys.get('api_secret', '')
                        self.params['password'] = exchange_keys.get('password', '')
                        
                except Exception as e:
                    logger.error(f"加载API密钥文件失败: {e}")
                    
            logger.info(f"已加载API配置: {self.exchange_type.value}")
            
        except Exception as e:
            logger.error(f"加载API配置失败: {e}")
            
    def _init_exchange(self) -> None:
        """初始化交易所对象"""
        try:
            # 获取交易所类
            exchange_id = self.exchange_type.name.lower()
            
            if self.exchange_type == ExchangeType.BINANCE_FUTURES:
                exchange_id = 'binance'
                
            exchange_class = getattr(ccxt, exchange_id)
            
            # 创建交易所对象
            exchange_params = {
                'apiKey': self.params['api_key'],
                'secret': self.params['api_secret'],
                'password': self.params['password'],
                'timeout': self.params['timeout'] * 1000,  # 毫秒
                'enableRateLimit': self.params['enable_rate_limit'],
                'verbose': self.params['verbose']
            }
            
            # 设置代理
            if self.params['use_proxy'] and self.params['proxy']:
                exchange_params['proxies'] = {
                    'http': self.params['proxy'],
                    'https': self.params['proxy']
                }
                
            # 设置测试网络
            if self.params['testnet']:
                if self.exchange_type == ExchangeType.BINANCE:
                    exchange_params['options'] = {'defaultType': 'spot'}
                    exchange_params['urls'] = {
                        'api': {
                            'public': 'https://testnet.binance.vision/api/v3',
                            'private': 'https://testnet.binance.vision/api/v3',
                            'v3': 'https://testnet.binance.vision/api/v3',
                        }
                    }
                elif self.exchange_type == ExchangeType.BINANCE_FUTURES:
                    exchange_params['options'] = {'defaultType': 'future'}
                    exchange_params['urls'] = {
                        'api': {
                            'public': 'https://testnet.binancefuture.com/fapi/v1',
                            'private': 'https://testnet.binancefuture.com/fapi/v1',
                            'v1': 'https://testnet.binancefuture.com/fapi/v1',
                        }
                    }
                else:
                    exchange_params['testnet'] = True
                    
            # 创建交易所对象
            self.exchange = exchange_class(exchange_params)
            
            # 加载市场数据
            if self.params['load_markets']:
                self.exchange.load_markets()
                
            # 设置杠杆模式（如果是期货交易所）
            if self.exchange_type == ExchangeType.BINANCE_FUTURES:
                self.exchange.options['defaultType'] = 'future'
                
            logger.info(f"已初始化交易所对象: {self.exchange_type.value}")
            
        except Exception as e:
            logger.error(f"初始化交易所对象失败: {e}")
            
    def _init_session(self) -> requests.Session:
        """
        初始化请求会话
        
        返回:
            请求会话
        """
        try:
            # 创建会话
            session = requests.Session()
            
            # 设置重试策略
            retry_strategy = Retry(
                total=self.params['max_retries'],
                backoff_factor=self.params['retry_delay'],
                status_forcelist=[429, 500, 502, 503, 504],
                method_whitelist=["HEAD", "GET", "OPTIONS", "POST", "PUT", "DELETE"]
            )
            
            # 设置适配器
            adapter = HTTPAdapter(max_retries=retry_strategy)
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            
            # 设置超时
            session.timeout = self.params['timeout']
            
            # 设置代理
            if self.params['use_proxy'] and self.params['proxy']:
                session.proxies = {
                    'http': self.params['proxy'],
                    'https': self.params['proxy']
                }
                
            return session
            
        except Exception as e:
            logger.error(f"初始化请求会话失败: {e}")
            return requests.Session()
            
    def get_exchange(self) -> Any:
        """
        获取交易所对象
        
        返回:
            交易所对象
        """
        return self.exchange
        
    def execute_request(self, method: str, endpoint: str, 
                      params: Optional[Dict[str, Any]] = None, 
                      data: Optional[Dict[str, Any]] = None, 
                      headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        执行API请求
        
        参数:
            method: 请求方法（GET, POST, PUT, DELETE）
            endpoint: API端点
            params: 查询参数
            data: 请求数据
            headers: 请求头
            
        返回:
            响应数据
        """
        if self.exchange is None:
            logger.error("交易所对象未初始化，无法执行请求")
            return {
                'success': False,
                'error': '交易所对象未初始化'
            }
            
        try:
            # 更新请求计数器
            self.request_counter['total'] += 1
            
            # 检查请求限制
            if self.params['rate_limit'] and not self._check_rate_limit(endpoint):
                logger.warning(f"请求限制: {endpoint}")
                time.sleep(1)  # 等待1秒
                
            # 构建请求URL
            base_url = self.exchange.urls['api']['private']
            url = f"{base_url}/{endpoint.lstrip('/')}"
            
            # 准备请求参数
            request_params = params or {}
            request_data = data or {}
            request_headers = headers or {}
            
            # 添加认证信息
            if not endpoint.startswith('public'):
                self._add_auth_headers(method, endpoint, request_params, request_data, request_headers)
                
            # 执行请求
            response = self.session.request(
                method=method,
                url=url,
                params=request_params,
                json=request_data if method in ['POST', 'PUT'] else None,
                headers=request_headers
            )
            
            # 检查响应状态
            response.raise_for_status()
            
            # 解析响应
            result = response.json()
            
            # 更新请求计数器
            self.request_counter['success'] += 1
            
            return result
            
        except requests.exceptions.RequestException as e:
            # 更新请求计数器
            self.request_counter['error'] += 1
            
            # 重试
            if self.params['max_retries'] > 0:
                for i in range(self.params['max_retries']):
                    try:
                        # 更新请求计数器
                        self.request_counter['retry'] += 1
                        
                        logger.info(f"重试请求 ({i+1}/{self.params['max_retries']}): {endpoint}")
                        time.sleep(self.params['retry_delay'])
                        
                        # 重试请求
                        response = self.session.request(
                            method=method,
                            url=url,
                            params=request_params,
                            json=request_data if method in ['POST', 'PUT'] else None,
                            headers=request_headers
                        )
                        
                        # 检查响应状态
                        response.raise_for_status()
                        
                        # 解析响应
                        result = response.json()
                        
                        # 更新请求计数器
                        self.request_counter['success'] += 1
                        
                        return result
                        
                    except requests.exceptions.RequestException as retry_e:
                        logger.error(f"重试请求失败: {retry_e}")
                        
            logger.error(f"执行请求失败: {e}")
            return {
                'success': False,
                'error': str(e)
            }
            
    def _add_auth_headers(self, method: str, endpoint: str, 
                        params: Dict[str, Any], data: Dict[str, Any], 
                        headers: Dict[str, str]) -> None:
        """
        添加认证头
        
        参数:
            method: 请求方法
            endpoint: API端点
            params: 查询参数
            data: 请求数据
            headers: 请求头
        """
        try:
            # 根据交易所类型添加认证信息
            if self.exchange_type == ExchangeType.BINANCE or self.exchange_type == ExchangeType.BINANCE_FUTURES:
                # 添加时间戳
                params['timestamp'] = int(time.time() * 1000)
                
                # 构建签名字符串
                query_string = urllib.parse.urlencode(params)
                if data:
                    query_string += '&' + urllib.parse.urlencode(data)
                    
                # 计算签名
                signature = hmac.new(
                    self.params['api_secret'].encode('utf-8'),
                    query_string.encode('utf-8'),
                    hashlib.sha256
                ).hexdigest()
                
                # 添加签名
                params['signature'] = signature
                
                # 添加API密钥
                headers['X-MBX-APIKEY'] = self.params['api_key']
                
            elif self.exchange_type == ExchangeType.BYBIT:
                # 添加时间戳
                params['timestamp'] = int(time.time() * 1000)
                
                # 构建签名字符串
                query_string = urllib.parse.urlencode(sorted(params.items()))
                
                # 计算签名
                signature = hmac.new(
                    self.params['api_secret'].encode('utf-8'),
                    query_string.encode('utf-8'),
                    hashlib.sha256
                ).hexdigest()
                
                # 添加签名
                params['sign'] = signature
                
                # 添加API密钥
                headers['api_key'] = self.params['api_key']
                
            # 其他交易所可以根据需要添加
                
        except Exception as e:
            logger.error(f"添加认证头失败: {e}")
            
    def _check_rate_limit(self, endpoint: str) -> bool:
        """
        检查请求限制
        
        参数:
            endpoint: API端点
            
        返回:
            是否允许请求
        """
        try:
            # 获取当前时间
            now = datetime.now()
            
            # 重置计数器（每小时）
            if (now - self.request_counter['last_reset']).total_seconds() > 3600:
                self.request_counter['total'] = 0
                self.request_counter['success'] = 0
                self.request_counter['error'] = 0
                self.request_counter['retry'] = 0
                self.request_counter['last_reset'] = now
                
            # 检查端点限制
            if endpoint in self.rate_limits:
                limit_info = self.rate_limits[endpoint]
                
                # 检查是否超过限制
                if limit_info['count'] >= limit_info['limit']:
                    # 检查是否已过冷却时间
                    if (now - limit_info['last_request']).total_seconds() < limit_info['window']:
                        return False
                    else:
                        # 重置计数器
                        limit_info['count'] = 0
                        
                # 更新计数器
                limit_info['count'] += 1
                limit_info['last_request'] = now
                
            else:
                # 添加新的限制信息
                self.rate_limits[endpoint] = {
                    'count': 1,
                    'limit': 10,  # 默认限制
                    'window': 60,  # 默认窗口（秒）
                    'last_request': now
                }
                
            return True
            
        except Exception as e:
            logger.error(f"检查请求限制失败: {e}")
            return True
