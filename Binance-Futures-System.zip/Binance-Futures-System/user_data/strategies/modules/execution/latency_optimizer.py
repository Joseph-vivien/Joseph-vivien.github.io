#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
延迟优化器模块

该模块负责优化交易执行延迟，包括网络延迟测量、服务器选择和请求优化。

作者: 高级Python工程师
日期: 2024-05-21
"""

import time
import json
import socket
import threading
import statistics
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from datetime import datetime, timedelta
import requests
import numpy as np
import pandas as pd
import ccxt

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.execution.api_manager import ApiManager, ExchangeType

# 获取日志记录器
logger = get_logger("latency_optimizer")

class ServerRegion(Enum):
    """服务器区域枚举"""
    ASIA = "亚洲"
    EUROPE = "欧洲"
    US_EAST = "美国东部"
    US_WEST = "美国西部"
    GLOBAL = "全球"

class LatencyOptimizer:
    """
    延迟优化器类

    负责优化交易执行延迟，包括网络延迟测量、服务器选择和请求优化
    """

    def __init__(self, api_manager: Optional[ApiManager] = None):
        """
        初始化延迟优化器

        参数:
            api_manager: API管理器
        """
        self.api_manager = api_manager

        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 延迟测量参数
            'ping_interval': 60,  # 延迟测量间隔（秒）
            'ping_samples': 10,  # 延迟测量样本数
            'ping_timeout': 5,  # 延迟测量超时时间（秒）

            # 服务器选择参数
            'auto_select_server': True,  # 是否自动选择服务器
            'preferred_region': ServerRegion.GLOBAL,  # 首选服务器区域
            'max_latency': 500,  # 最大可接受延迟（毫秒）

            # 请求优化参数
            'use_keepalive': True,  # 是否使用长连接
            'connection_timeout': 10,  # 连接超时时间（秒）
            'read_timeout': 30,  # 读取超时时间（秒）
            'use_compression': True,  # 是否使用压缩
            'retry_on_timeout': True,  # 超时时是否重试

            # 缓存参数
            'use_cache': True,  # 是否使用缓存
            'cache_ttl': 60,  # 缓存有效期（秒）
        }

        # 服务器列表
        self.servers = {
            ServerRegion.ASIA: [
                {'url': 'https://api.binance.com', 'name': 'Binance Asia'},
                {'url': 'https://api-pub.bitfinex.com', 'name': 'Bitfinex Asia'},
                {'url': 'https://api.huobi.pro', 'name': 'Huobi Global'}
            ],
            ServerRegion.EUROPE: [
                {'url': 'https://api.binance.com', 'name': 'Binance Europe'},
                {'url': 'https://api.kraken.com', 'name': 'Kraken'}
            ],
            ServerRegion.US_EAST: [
                {'url': 'https://api.binance.us', 'name': 'Binance US'},
                {'url': 'https://api.coinbase.com', 'name': 'Coinbase'}
            ],
            ServerRegion.US_WEST: [
                {'url': 'https://api.binance.us', 'name': 'Binance US West'},
                {'url': 'https://api.coinbase.com', 'name': 'Coinbase West'}
            ],
            ServerRegion.GLOBAL: [
                {'url': 'https://api.binance.com', 'name': 'Binance Global'},
                {'url': 'https://api.bybit.com', 'name': 'Bybit Global'},
                {'url': 'https://api.kraken.com', 'name': 'Kraken Global'}
            ]
        }

        # 延迟数据
        self.latency_data = {}

        # 当前服务器
        self.current_server = None

        # 缓存
        self.cache = {}

        # 延迟测量线程
        self.latency_thread = None
        self.latency_active = False

        # 初始化
        self._init_optimizer()

    def _init_optimizer(self) -> None:
        """初始化优化器"""
        try:
            # 选择服务器
            if self.params['auto_select_server']:
                self.select_best_server()

            # 启动延迟测量线程
            self._start_latency_thread()

            logger.info("已初始化延迟优化器")

        except Exception as e:
            logger.error(f"初始化延迟优化器失败: {e}")

    def _start_latency_thread(self) -> None:
        """启动延迟测量线程"""
        if self.latency_thread is None or not self.latency_thread.is_alive():
            self.latency_active = True
            self.latency_thread = threading.Thread(target=self._latency_monitor)
            self.latency_thread.daemon = True
            self.latency_thread.start()

    def _latency_monitor(self) -> None:
        """延迟监测线程"""
        logger.info("启动延迟监测线程")

        while self.latency_active:
            try:
                # 测量所有服务器的延迟
                for region, servers in self.servers.items():
                    for server in servers:
                        latency = self.measure_latency(server['url'])

                        # 更新延迟数据
                        if server['url'] not in self.latency_data:
                            self.latency_data[server['url']] = []

                        self.latency_data[server['url']].append({
                            'timestamp': datetime.now(),
                            'latency': latency
                        })

                        # 保留最近的样本
                        if len(self.latency_data[server['url']]) > self.params['ping_samples']:
                            self.latency_data[server['url']] = self.latency_data[server['url']][-self.params['ping_samples']:]

                # 如果自动选择服务器，检查是否需要切换
                if self.params['auto_select_server']:
                    self.select_best_server()

            except Exception as e:
                logger.error(f"延迟监测异常: {e}")

            # 等待下一次测量
            time.sleep(self.params['ping_interval'])

        logger.info("延迟监测线程结束")

    def measure_latency(self, url: str) -> float:
        """
        测量服务器延迟

        参数:
            url: 服务器URL

        返回:
            延迟（毫秒）
        """
        try:
            # 解析URL
            parsed_url = requests.utils.urlparse(url)
            host = parsed_url.netloc

            # 创建套接字
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.params['ping_timeout'])

            # 测量连接时间
            start_time = time.time()
            sock.connect((host, 443))
            end_time = time.time()

            # 关闭套接字
            sock.close()

            # 计算延迟（毫秒）
            latency = (end_time - start_time) * 1000

            logger.debug(f"服务器 {url} 延迟: {latency:.2f} ms")

            return latency

        except Exception as e:
            logger.error(f"测量服务器 {url} 延迟失败: {e}")
            return float('inf')

    def select_best_server(self) -> Dict[str, Any]:
        """
        选择最佳服务器

        返回:
            服务器信息
        """
        try:
            best_server = None
            min_latency = float('inf')

            # 获取首选区域的服务器
            region_servers = self.servers.get(self.params['preferred_region'], [])

            # 如果没有首选区域的服务器，使用所有服务器
            if not region_servers:
                region_servers = []
                for servers in self.servers.values():
                    region_servers.extend(servers)

            # 计算每个服务器的平均延迟
            for server in region_servers:
                url = server['url']

                # 如果没有延迟数据，测量延迟
                if url not in self.latency_data or not self.latency_data[url]:
                    latency = self.measure_latency(url)

                    if url not in self.latency_data:
                        self.latency_data[url] = []

                    self.latency_data[url].append({
                        'timestamp': datetime.now(),
                        'latency': latency
                    })

                # 计算平均延迟
                avg_latency = statistics.mean(d['latency'] for d in self.latency_data[url])

                # 更新最佳服务器
                if avg_latency < min_latency and avg_latency <= self.params['max_latency']:
                    min_latency = avg_latency
                    best_server = server

            # 如果找到最佳服务器，更新当前服务器
            if best_server:
                if self.current_server != best_server:
                    logger.info(f"切换到服务器: {best_server['name']} ({best_server['url']}) 延迟: {min_latency:.2f} ms")
                    self.current_server = best_server

                    # 如果有API管理器，更新API URL
                    if self.api_manager and self.api_manager.exchange:
                        self.api_manager.exchange.urls['api'] = {
                            'public': best_server['url'],
                            'private': best_server['url']
                        }

            else:
                logger.warning("未找到符合条件的服务器")

            return self.current_server or {}

        except Exception as e:
            logger.error(f"选择最佳服务器失败: {e}")
            return {}

    def optimize_request(self, method: str, url: str,
                       params: Optional[Dict[str, Any]] = None,
                       data: Optional[Dict[str, Any]] = None,
                       headers: Optional[Dict[str, str]] = None) -> requests.Response:
        """
        优化请求

        参数:
            method: 请求方法
            url: 请求URL
            params: 查询参数
            data: 请求数据
            headers: 请求头

        返回:
            响应对象
        """
        try:
            # 检查缓存
            if self.params['use_cache'] and method.upper() == 'GET':
                cache_key = f"{method}:{url}:{json.dumps(params or {})}"

                if cache_key in self.cache:
                    cache_entry = self.cache[cache_key]

                    # 检查缓存是否有效
                    if (datetime.now() - cache_entry['timestamp']).total_seconds() < self.params['cache_ttl']:
                        logger.debug(f"使用缓存: {url}")
                        return cache_entry['response']

            # 准备请求参数
            request_params = params or {}
            request_data = data or {}
            request_headers = headers or {}

            # 添加优化头
            if self.params['use_keepalive']:
                request_headers['Connection'] = 'keep-alive'

            if self.params['use_compression']:
                request_headers['Accept-Encoding'] = 'gzip, deflate'

            # 设置超时
            timeout = (self.params['connection_timeout'], self.params['read_timeout'])

            # 执行请求
            response = requests.request(
                method=method,
                url=url,
                params=request_params,
                json=request_data if method.upper() in ['POST', 'PUT'] else None,
                headers=request_headers,
                timeout=timeout
            )

            # 检查响应状态
            response.raise_for_status()

            # 更新缓存
            if self.params['use_cache'] and method.upper() == 'GET':
                self.cache[cache_key] = {
                    'timestamp': datetime.now(),
                    'response': response
                }

                # 清理过期缓存
                self._clean_cache()

            return response

        except requests.exceptions.Timeout:
            logger.warning(f"请求超时: {url}")

            # 如果需要重试
            if self.params['retry_on_timeout']:
                logger.info(f"重试请求: {url}")

                # 重试请求
                response = requests.request(
                    method=method,
                    url=url,
                    params=request_params,
                    json=request_data if method.upper() in ['POST', 'PUT'] else None,
                    headers=request_headers,
                    timeout=timeout
                )

                return response

            raise

        except Exception as e:
            logger.error(f"优化请求失败: {e}")
            raise

    def _clean_cache(self) -> None:
        """清理过期缓存"""
        try:
            now = datetime.now()
            expired_keys = []

            # 查找过期缓存
            for key, entry in self.cache.items():
                if (now - entry['timestamp']).total_seconds() >= self.params['cache_ttl']:
                    expired_keys.append(key)

            # 删除过期缓存
            for key in expired_keys:
                del self.cache[key]

        except Exception as e:
            logger.error(f"清理缓存失败: {e}")

    def get_latency_stats(self) -> Dict[str, Any]:
        """
        获取延迟统计信息

        返回:
            延迟统计信息
        """
        try:
            stats = {}

            # 计算每个服务器的延迟统计信息
            for url, data in self.latency_data.items():
                if not data:
                    continue

                latencies = [d['latency'] for d in data]

                stats[url] = {
                    'min': min(latencies),
                    'max': max(latencies),
                    'avg': statistics.mean(latencies),
                    'median': statistics.median(latencies),
                    'stdev': statistics.stdev(latencies) if len(latencies) > 1 else 0,
                    'samples': len(latencies),
                    'last_update': data[-1]['timestamp']
                }

            return stats

        except Exception as e:
            logger.error(f"获取延迟统计信息失败: {e}")
            return {}

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置延迟优化参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取延迟优化参数

        返回:
            参数字典
        """
        return self.params.copy()

    def cleanup(self) -> None:
        """清理资源"""
        # 停止延迟测量线程
        self.latency_active = False

        if self.latency_thread and self.latency_thread.is_alive():
            self.latency_thread.join(timeout=5)

        # 清空缓存
        self.cache = {}
