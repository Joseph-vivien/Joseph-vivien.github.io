#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场分析模块

该模块负责多时间周期市场分析，为短期交易信号提供决策依据。
包括趋势识别、波动性分析、价格形态识别和市场情绪评估。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import talib
from scipy import stats
from sklearn.linear_model import LinearRegression

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.market_analyzer.trend_analyzer import TrendAnalyzer
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer
from user_data.strategies.modules.market_analyzer.volume_analyzer import VolumeAnalyzer

# 获取日志记录器
logger = get_logger("market_analyzer")

class MarketState(Enum):
    """市场状态枚举"""
    STRONG_UPTREND = "强上升趋势"
    UPTREND = "上升趋势"
    WEAK_UPTREND = "弱上升趋势"
    SIDEWAYS = "盘整"
    WEAK_DOWNTREND = "弱下降趋势"
    DOWNTREND = "下降趋势"
    STRONG_DOWNTREND = "强下降趋势"
    VOLATILE = "高波动"
    BREAKOUT_UP = "向上突破"
    BREAKOUT_DOWN = "向下突破"
    REVERSAL_UP = "向上反转"
    REVERSAL_DOWN = "向下反转"
    UNKNOWN = "未知"

class MarketAnalyzer:
    """
    市场分析类

    负责多时间周期市场分析，为短期交易信号提供决策依据
    """

    def __init__(self, timeframes: List[str] = None):
        """
        初始化市场分析器

        参数:
            timeframes: 分析的时间周期列表
        """
        self.timeframes = timeframes or ["1m", "5m", "15m", "1h", "4h"]
        self.data = {}  # 存储不同时间周期的数据
        self.indicators = {}  # 存储计算的指标
        self.market_states = {}  # 存储不同时间周期的市场状态

    def update_data(self, symbol: str, timeframe: str, data: pd.DataFrame) -> None:
        """
        更新特定时间周期的市场数据

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
        """
        if symbol not in self.data:
            self.data[symbol] = {}
            self.indicators[symbol] = {}
            self.market_states[symbol] = {}

        self.data[symbol][timeframe] = data

        # 计算指标
        self._calculate_indicators(symbol, timeframe)

        # 分析市场状态
        self._analyze_market_state(symbol, timeframe)

        logger.debug(f"已更新 {symbol} {timeframe} 数据和指标")

    def _calculate_indicators(self, symbol: str, timeframe: str) -> None:
        """
        计算技术指标

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
        """
        if symbol not in self.data or timeframe not in self.data[symbol]:
            logger.warning(f"没有 {symbol} {timeframe} 的数据，无法计算指标")
            return

        data = self.data[symbol][timeframe]

        if data.empty:
            logger.warning(f"{symbol} {timeframe} 数据为空，无法计算指标")
            return

        # 确保指标字典存在
        if symbol not in self.indicators:
            self.indicators[symbol] = {}
        if timeframe not in self.indicators[symbol]:
            self.indicators[symbol][timeframe] = {}

        indicators = self.indicators[symbol][timeframe]

        try:
            # 移动平均线（使用优化后的参数）
            indicators['sma10'] = talib.SMA(data['close'].values, timeperiod=10)  # 短期
            indicators['sma20'] = talib.SMA(data['close'].values, timeperiod=20)
            indicators['sma25'] = talib.SMA(data['close'].values, timeperiod=25)  # 中期
            indicators['sma50'] = talib.SMA(data['close'].values, timeperiod=50)
            indicators['sma100'] = talib.SMA(data['close'].values, timeperiod=100)  # 长期
            indicators['sma200'] = talib.SMA(data['close'].values, timeperiod=200)

            indicators['ema9'] = talib.EMA(data['close'].values, timeperiod=9)
            indicators['ema10'] = talib.EMA(data['close'].values, timeperiod=10)  # 短期
            indicators['ema21'] = talib.EMA(data['close'].values, timeperiod=21)
            indicators['ema25'] = talib.EMA(data['close'].values, timeperiod=25)  # 中期
            indicators['ema55'] = talib.EMA(data['close'].values, timeperiod=55)
            indicators['ema200'] = talib.EMA(data['close'].values, timeperiod=200)

            # 布林带（使用优化后的参数）
            indicators['upperband'], indicators['middleband'], indicators['lowerband'] = talib.BBANDS(
                data['close'].values, timeperiod=15, nbdevup=1.8, nbdevdn=1.8, matype=0)

            # 相对强弱指数（使用优化后的参数）
            indicators['rsi14'] = talib.RSI(data['close'].values, timeperiod=9)

            # MACD（使用优化后的参数）
            indicators['macd'], indicators['macdsignal'], indicators['macdhist'] = talib.MACD(
                data['close'].values, fastperiod=8, slowperiod=21, signalperiod=6)

            # 随机指标（使用优化后的参数）
            indicators['slowk'], indicators['slowd'] = talib.STOCH(
                data['high'].values, data['low'].values, data['close'].values,
                fastk_period=8, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0)

            # 平均真实波幅（使用优化后的参数）
            indicators['atr'] = talib.ATR(
                data['high'].values, data['low'].values, data['close'].values, timeperiod=10)

            # 商品通道指数（使用优化后的参数）
            indicators['cci'] = talib.CCI(
                data['high'].values, data['low'].values, data['close'].values, timeperiod=10)

            # 平均方向指数（使用优化后的参数）
            indicators['adx'] = talib.ADX(
                data['high'].values, data['low'].values, data['close'].values, timeperiod=10)

            # 能量潮指标
            indicators['obv'] = talib.OBV(data['close'].values, data['volume'].values)

            # 威廉指标
            indicators['willr'] = talib.WILLR(
                data['high'].values, data['low'].values, data['close'].values, timeperiod=14)

            # 资金流量指标
            indicators['mfi'] = talib.MFI(
                data['high'].values, data['low'].values, data['close'].values,
                data['volume'].values, timeperiod=14)

            # 计算布林带宽度
            indicators['bb_width'] = (indicators['upperband'] - indicators['lowerband']) / indicators['middleband']

            # 计算布林带位置
            indicators['bb_position'] = (data['close'].values - indicators['lowerband']) / (
                indicators['upperband'] - indicators['lowerband'])

            # 计算价格与移动平均线的距离
            indicators['dist_sma20'] = (data['close'].values - indicators['sma20']) / indicators['sma20']
            indicators['dist_sma50'] = (data['close'].values - indicators['sma50']) / indicators['sma50']
            indicators['dist_sma200'] = (data['close'].values - indicators['sma200']) / indicators['sma200']

            # 计算波动率
            indicators['volatility'] = data['close'].rolling(window=20).std() / data['close'].rolling(window=20).mean()

            # 计算趋势强度
            indicators['trend_strength'] = self._calculate_trend_strength(data)

            # 计算支撑和阻力位
            indicators['support'], indicators['resistance'] = self._calculate_support_resistance(data)

            # 计算价格动量
            indicators['momentum'] = data['close'].diff(5).values

            # 计算成交量变化率
            indicators['volume_change'] = data['volume'].pct_change().values

            logger.debug(f"已计算 {symbol} {timeframe} 的技术指标")

        except Exception as e:
            logger.error(f"计算 {symbol} {timeframe} 指标失败: {e}")

    def _analyze_market_state(self, symbol: str, timeframe: str) -> None:
        """
        分析市场状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
        """
        if symbol not in self.data or timeframe not in self.data[symbol]:
            logger.warning(f"没有 {symbol} {timeframe} 的数据，无法分析市场状态")
            return

        if symbol not in self.indicators or timeframe not in self.indicators[symbol]:
            logger.warning(f"没有 {symbol} {timeframe} 的指标，无法分析市场状态")
            return

        data = self.data[symbol][timeframe]
        indicators = self.indicators[symbol][timeframe]

        if data.empty:
            logger.warning(f"{symbol} {timeframe} 数据为空，无法分析市场状态")
            return

        # 确保市场状态字典存在
        if symbol not in self.market_states:
            self.market_states[symbol] = {}

        try:
            # 获取最新数据点的指标值
            close = data['close'].iloc[-1]
            sma20 = indicators['sma20'][-1]
            sma50 = indicators['sma50'][-1]
            sma200 = indicators['sma200'][-1]
            ema9 = indicators['ema9'][-1]
            ema21 = indicators['ema21'][-1]
            rsi14 = indicators['rsi14'][-1]
            macd = indicators['macd'][-1]
            macdsignal = indicators['macdsignal'][-1]
            adx = indicators['adx'][-1]
            bb_width = indicators['bb_width'][-1]
            bb_position = indicators['bb_position'][-1]
            trend_strength = indicators['trend_strength'][-1]
            volatility = indicators['volatility'][-1]

            # 趋势判断
            trend = self._determine_trend(close, sma20, sma50, sma200, ema9, ema21, macd, macdsignal, adx)

            # 波动性判断
            is_volatile = volatility > np.nanmean(indicators['volatility'][-20:]) * 1.5

            # 突破判断
            is_breakout_up = (close > indicators['upperband'][-1] and
                             bb_width > np.nanmean(indicators['bb_width'][-20:]) * 1.2)
            is_breakout_down = (close < indicators['lowerband'][-1] and
                               bb_width > np.nanmean(indicators['bb_width'][-20:]) * 1.2)

            # 反转判断
            is_reversal_up = (rsi14 < 30 and rsi14 > indicators['rsi14'][-2] and
                             close < sma20 and indicators['macd'][-1] > indicators['macd'][-2])
            is_reversal_down = (rsi14 > 70 and rsi14 < indicators['rsi14'][-2] and
                               close > sma20 and indicators['macd'][-1] < indicators['macd'][-2])

            # 确定市场状态
            if is_volatile:
                market_state = MarketState.VOLATILE
            elif is_breakout_up:
                market_state = MarketState.BREAKOUT_UP
            elif is_breakout_down:
                market_state = MarketState.BREAKOUT_DOWN
            elif is_reversal_up:
                market_state = MarketState.REVERSAL_UP
            elif is_reversal_down:
                market_state = MarketState.REVERSAL_DOWN
            else:
                market_state = trend

            # 保存市场状态
            self.market_states[symbol][timeframe] = market_state

            logger.debug(f"{symbol} {timeframe} 市场状态: {market_state.value}")

        except Exception as e:
            logger.error(f"分析 {symbol} {timeframe} 市场状态失败: {e}")
            self.market_states[symbol][timeframe] = MarketState.UNKNOWN

    def _determine_trend(self, close: float, sma20: float, sma50: float, sma200: float,
                        ema9: float, ema21: float, macd: float, macdsignal: float, adx: float) -> MarketState:
        """
        确定趋势状态

        参数:
            close: 收盘价
            sma20: 20周期简单移动平均线
            sma50: 50周期简单移动平均线
            sma200: 200周期简单移动平均线
            ema9: 9周期指数移动平均线
            ema21: 21周期指数移动平均线
            macd: MACD值
            macdsignal: MACD信号线
            adx: 平均方向指数

        返回:
            趋势状态
        """
        # 计算趋势得分
        trend_score = 0

        # 价格与移动平均线关系
        if close > sma20:
            trend_score += 1
        else:
            trend_score -= 1

        if close > sma50:
            trend_score += 1
        else:
            trend_score -= 1

        if close > sma200:
            trend_score += 1
        else:
            trend_score -= 1

        # 移动平均线排列
        if sma20 > sma50:
            trend_score += 1
        else:
            trend_score -= 1

        if sma50 > sma200:
            trend_score += 1
        else:
            trend_score -= 1

        # EMA关系
        if ema9 > ema21:
            trend_score += 1
        else:
            trend_score -= 1

        # MACD
        if macd > macdsignal:
            trend_score += 1
        else:
            trend_score -= 1

        if macd > 0:
            trend_score += 1
        else:
            trend_score -= 1

        # 趋势强度
        if adx > 25:
            if trend_score > 0:
                trend_score += 1
            else:
                trend_score -= 1

        if adx > 40:
            if trend_score > 0:
                trend_score += 1
            else:
                trend_score -= 1

        # 根据得分确定趋势状态
        if trend_score >= 7:
            return MarketState.STRONG_UPTREND
        elif trend_score >= 4:
            return MarketState.UPTREND
        elif trend_score >= 1:
            return MarketState.WEAK_UPTREND
        elif trend_score >= -1:
            return MarketState.SIDEWAYS
        elif trend_score >= -4:
            return MarketState.WEAK_DOWNTREND
        elif trend_score >= -7:
            return MarketState.DOWNTREND
        else:
            return MarketState.STRONG_DOWNTREND

    def _calculate_trend_strength(self, data: pd.DataFrame, window: int = 20) -> np.ndarray:
        """
        计算趋势强度

        参数:
            data: OHLCV数据
            window: 计算窗口大小

        返回:
            趋势强度数组
        """
        close = data['close'].values
        trend_strength = np.zeros_like(close)

        for i in range(window, len(close)):
            # 使用线性回归计算趋势强度
            x = np.arange(window)
            y = close[i-window:i]

            slope, _, r_value, _, _ = stats.linregress(x, y)

            # 趋势强度 = 斜率 * R²
            trend_strength[i] = slope * (r_value ** 2)

        return trend_strength

    def _calculate_support_resistance(self, data: pd.DataFrame, window: int = 20,
                                     threshold: float = 0.02) -> Tuple[np.ndarray, np.ndarray]:
        """
        计算支撑和阻力位

        参数:
            data: OHLCV数据
            window: 计算窗口大小
            threshold: 价格聚集阈值

        返回:
            (支撑位数组, 阻力位数组)
        """
        high = data['high'].values
        low = data['low'].values
        close = data['close'].values

        support = np.zeros_like(close)
        resistance = np.zeros_like(close)

        for i in range(window, len(close)):
            # 获取窗口内的数据
            window_high = high[i-window:i]
            window_low = low[i-window:i]

            # 使用KDE寻找价格聚集区域
            try:
                kde_high = stats.gaussian_kde(window_high)
                kde_low = stats.gaussian_kde(window_low)

                # 在价格范围内采样
                price_range = np.linspace(min(window_low), max(window_high), 100)
                high_density = kde_high(price_range)
                low_density = kde_low(price_range)

                # 找出密度峰值对应的价格
                high_peaks = price_range[np.r_[True, high_density[1:] > high_density[:-1]] &
                                        np.r_[high_density[:-1] > high_density[1:], True]]
                low_peaks = price_range[np.r_[True, low_density[1:] > low_density[:-1]] &
                                       np.r_[low_density[:-1] > low_density[1:], True]]

                # 找出最近的支撑位和阻力位
                if len(high_peaks) > 0 and len(low_peaks) > 0:
                    # 支撑位：当前价格以下的最高密度点
                    support_candidates = low_peaks[low_peaks < close[i]]
                    if len(support_candidates) > 0:
                        support[i] = max(support_candidates)
                    else:
                        support[i] = min(low_peaks)

                    # 阻力位：当前价格以上的最低密度点
                    resistance_candidates = high_peaks[high_peaks > close[i]]
                    if len(resistance_candidates) > 0:
                        resistance[i] = min(resistance_candidates)
                    else:
                        resistance[i] = max(high_peaks)
                else:
                    # 如果KDE方法失败，使用简单的最高点和最低点
                    support[i] = min(window_low)
                    resistance[i] = max(window_high)

            except Exception:
                # 如果KDE方法失败，使用简单的最高点和最低点
                support[i] = min(window_low)
                resistance[i] = max(window_high)

        return support, resistance

    def get_market_state(self, symbol: str, timeframe: str) -> MarketState:
        """
        获取特定交易对和时间周期的市场状态

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            市场状态
        """
        if symbol not in self.market_states or timeframe not in self.market_states[symbol]:
            logger.warning(f"没有 {symbol} {timeframe} 的市场状态")
            return MarketState.UNKNOWN

        return self.market_states[symbol][timeframe]

    def get_multi_timeframe_consensus(self, symbol: str) -> Dict[str, int]:
        """
        获取多时间周期共识

        参数:
            symbol: 交易对符号

        返回:
            共识字典 {共识类型: 强度}
        """
        if symbol not in self.market_states:
            logger.warning(f"没有 {symbol} 的市场状态")
            return {'trend': 0, 'volatility': 0, 'breakout': 0, 'reversal': 0}

        # 初始化共识计数
        consensus = {
            'trend': 0,  # 正值表示上升趋势，负值表示下降趋势
            'volatility': 0,  # 正值表示高波动
            'breakout': 0,  # 正值表示向上突破，负值表示向下突破
            'reversal': 0  # 正值表示向上反转，负值表示向下反转
        }

        # 时间周期权重，较短时间周期权重较低
        weights = {
            '1m': 0.5,
            '3m': 0.6,
            '5m': 0.7,
            '15m': 0.8,
            '30m': 0.9,
            '1h': 1.0,
            '2h': 1.1,
            '4h': 1.2,
            '6h': 1.3,
            '12h': 1.4,
            '1d': 1.5
        }

        # 计算共识
        for tf in self.market_states[symbol]:
            state = self.market_states[symbol][tf]
            weight = weights.get(tf, 1.0)

            if state == MarketState.STRONG_UPTREND:
                consensus['trend'] += 2 * weight
            elif state == MarketState.UPTREND:
                consensus['trend'] += 1 * weight
            elif state == MarketState.WEAK_UPTREND:
                consensus['trend'] += 0.5 * weight
            elif state == MarketState.WEAK_DOWNTREND:
                consensus['trend'] -= 0.5 * weight
            elif state == MarketState.DOWNTREND:
                consensus['trend'] -= 1 * weight
            elif state == MarketState.STRONG_DOWNTREND:
                consensus['trend'] -= 2 * weight
            elif state == MarketState.VOLATILE:
                consensus['volatility'] += 1 * weight
            elif state == MarketState.BREAKOUT_UP:
                consensus['breakout'] += 1 * weight
            elif state == MarketState.BREAKOUT_DOWN:
                consensus['breakout'] -= 1 * weight
            elif state == MarketState.REVERSAL_UP:
                consensus['reversal'] += 1 * weight
            elif state == MarketState.REVERSAL_DOWN:
                consensus['reversal'] -= 1 * weight

        return consensus

    def get_indicator(self, symbol: str, timeframe: str, indicator: str) -> Optional[np.ndarray]:
        """
        获取特定指标的值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator: 指标名称

        返回:
            指标值数组
        """
        if (symbol not in self.indicators or
            timeframe not in self.indicators[symbol] or
            indicator not in self.indicators[symbol][timeframe]):
            logger.warning(f"没有 {symbol} {timeframe} 的 {indicator} 指标")
            return None

        return self.indicators[symbol][timeframe][indicator]

    def get_latest_indicator(self, symbol: str, timeframe: str, indicator: str) -> Optional[float]:
        """
        获取特定指标的最新值

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            indicator: 指标名称

        返回:
            指标最新值
        """
        indicator_array = self.get_indicator(symbol, timeframe, indicator)

        if indicator_array is None or len(indicator_array) == 0:
            return None

        return indicator_array[-1]

    def get_support_resistance(self, symbol: str, timeframe: str) -> Tuple[Optional[float], Optional[float]]:
        """
        获取最新的支撑位和阻力位

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            (支撑位, 阻力位)
        """
        support = self.get_latest_indicator(symbol, timeframe, 'support')
        resistance = self.get_latest_indicator(symbol, timeframe, 'resistance')

        return support, resistance

    def is_overbought(self, symbol: str, timeframe: str) -> bool:
        """
        判断是否超买

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            是否超买
        """
        rsi = self.get_latest_indicator(symbol, timeframe, 'rsi14')

        if rsi is None:
            return False

        return rsi > 70

    def is_oversold(self, symbol: str, timeframe: str) -> bool:
        """
        判断是否超卖

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            是否超卖
        """
        rsi = self.get_latest_indicator(symbol, timeframe, 'rsi14')

        if rsi is None:
            return False

        return rsi < 30
