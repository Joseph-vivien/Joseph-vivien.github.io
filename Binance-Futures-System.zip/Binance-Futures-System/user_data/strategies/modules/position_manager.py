#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓位管理模块

该模块负责管理交易仓位，包括入场、出场和仓位大小计算。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import time
from datetime import datetime

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.risk_manager import RiskManager
from user_data.strategies.modules.leverage_manager import LeverageManager
from user_data.strategies.modules.signal_generator import SignalType
from user_data.strategies.modules.position_manager.entry_manager import EntryManager
from user_data.strategies.modules.position_manager.exit_manager import ExitManager
from user_data.strategies.modules.position_manager.size_calculator import SizeCalculator

# 获取日志记录器
logger = get_logger("position_manager")

class PositionType(Enum):
    """仓位类型枚举"""
    LONG = "多头"
    SHORT = "空头"
    NONE = "无仓位"

class PositionStatus(Enum):
    """仓位状态枚举"""
    PENDING = "等待中"
    OPEN = "已开仓"
    PARTIALLY_CLOSED = "部分平仓"
    CLOSED = "已平仓"
    CANCELED = "已取消"
    ERROR = "错误"

class PositionManager:
    """
    仓位管理类

    负责管理交易仓位，包括入场、出场和仓位大小计算
    """

    def __init__(self, risk_manager: Optional[RiskManager] = None,
               leverage_manager: Optional[LeverageManager] = None):
        """
        初始化仓位管理器

        参数:
            risk_manager: 风险管理器
            leverage_manager: 杠杆管理器
        """
        self.risk_manager = risk_manager
        self.leverage_manager = leverage_manager

        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 仓位大小参数
            'default_risk_pct': 2.0,  # 默认账户风险百分比
            'max_position_size_pct': 20.0,  # 最大仓位大小百分比
            'min_position_size': 10.0,  # 最小仓位大小（USDT）
            'position_sizing_method': 'risk',  # 仓位大小计算方法 (risk, fixed, percentage)
            'fixed_position_size': 100.0,  # 固定仓位大小（USDT）
            'percentage_position_size': 5.0,  # 账户百分比仓位大小

            # 入场参数
            'entry_confirmation_window': 3,  # 入场确认窗口（K线数）
            'entry_timeout': 60,  # 入场超时时间（秒）
            'entry_price_buffer': 0.001,  # 入场价格缓冲（0.1%）
            'use_limit_entry': True,  # 是否使用限价单入场
            'allow_partial_entry': True,  # 是否允许部分入场
            'min_entry_fill_pct': 0.8,  # 最小入场成交百分比

            # 出场参数
            'exit_timeout': 60,  # 出场超时时间（秒）
            'exit_price_buffer': 0.001,  # 出场价格缓冲（0.1%）
            'use_limit_exit': True,  # 是否使用限价单出场
            'allow_partial_exit': True,  # 是否允许部分出场
            'min_exit_fill_pct': 0.8,  # 最小出场成交百分比

            # 分段出场参数
            'use_staged_exit': True,  # 是否使用分段出场
            'profit_targets': [0.05, 0.1, 0.2],  # 利润目标（5%, 10%, 20%）
            'exit_percentages': [0.3, 0.3, 0.4],  # 出场百分比（30%, 30%, 40%）

            # 时间出场参数
            'use_time_exit': True,  # 是否使用时间出场
            'max_trade_duration': 24 * 60 * 60,  # 最大交易持续时间（秒）
            'time_exit_percentage': 1.0,  # 时间出场百分比（100%）
        }

        # 当前持仓
        self.positions = {}  # {symbol: position_info}

        # 订单历史
        self.order_history = []

    def calculate_position_size(self, symbol: str, entry_price: float,
                              stop_loss_price: float, account_balance: float,
                              position_type: PositionType = PositionType.LONG) -> Dict[str, Any]:
        """
        计算仓位大小

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stop_loss_price: 止损价格
            account_balance: 账户余额
            position_type: 仓位类型

        返回:
            仓位计算结果
        """
        try:
            # 获取杠杆倍数
            leverage = 1
            if self.leverage_manager:
                leverage = self.leverage_manager.get_leverage(symbol)

            # 计算价格风险百分比
            price_risk_pct = abs(entry_price - stop_loss_price) / entry_price

            # 根据仓位大小计算方法确定仓位大小
            method = self.params['position_sizing_method']

            if method == 'fixed':
                # 固定金额
                position_size_quote = self.params['fixed_position_size']

            elif method == 'percentage':
                # 账户百分比
                position_size_quote = account_balance * (self.params['percentage_position_size'] / 100)

            else:  # 'risk'
                # 风险基础
                risk_amount = account_balance * (self.params['default_risk_pct'] / 100)

                # 计算仓位大小
                if price_risk_pct > 0:
                    position_size_quote = risk_amount / price_risk_pct
                else:
                    position_size_quote = 0
                    logger.warning(f"价格风险为零，无法计算仓位大小: {symbol}")

            # 确保仓位不超过最大允许值
            max_position_size = account_balance * (self.params['max_position_size_pct'] / 100)
            position_size_quote = min(position_size_quote, max_position_size)

            # 确保仓位不低于最小允许值
            if position_size_quote < self.params['min_position_size']:
                if account_balance >= self.params['min_position_size']:
                    position_size_quote = self.params['min_position_size']
                else:
                    position_size_quote = account_balance * 0.95  # 使用95%的账户余额

            # 计算仓位大小（币数量）
            position_size = position_size_quote / entry_price

            # 计算实际风险
            actual_risk_amount = position_size_quote * price_risk_pct
            actual_risk_pct = (actual_risk_amount / account_balance) * 100

            # 计算保证金
            margin = position_size_quote / leverage

            # 计算强平价格
            liquidation_buffer = 0.2  # 20%保证金缓冲

            if position_type == PositionType.LONG:
                liquidation_price = entry_price * (1 - (1 - liquidation_buffer) / leverage)
            else:
                liquidation_price = entry_price * (1 + (1 - liquidation_buffer) / leverage)

            return {
                'symbol': symbol,
                'position_type': position_type,
                'entry_price': entry_price,
                'stop_loss_price': stop_loss_price,
                'position_size': position_size,
                'position_size_quote': position_size_quote,
                'risk_amount': actual_risk_amount,
                'risk_pct': actual_risk_pct,
                'leverage': leverage,
                'margin': margin,
                'liquidation_price': liquidation_price,
                'price_risk_pct': price_risk_pct * 100
            }

        except Exception as e:
            logger.error(f"计算仓位大小失败: {e}")
            return {
                'symbol': symbol,
                'position_type': position_type,
                'entry_price': entry_price,
                'stop_loss_price': stop_loss_price,
                'position_size': 0.0,
                'position_size_quote': 0.0,
                'risk_amount': 0.0,
                'risk_pct': 0.0,
                'leverage': 1,
                'margin': 0.0,
                'liquidation_price': 0.0,
                'price_risk_pct': 0.0
            }

    def create_entry_order(self, symbol: str, position_type: PositionType,
                         entry_price: float, stop_loss_price: float,
                         position_size: float, signal_type: SignalType = SignalType.NONE,
                         signal_confidence: float = 0.0) -> Dict[str, Any]:
        """
        创建入场订单

        参数:
            symbol: 交易对符号
            position_type: 仓位类型
            entry_price: 入场价格
            stop_loss_price: 止损价格
            position_size: 仓位大小（币数量）
            signal_type: 信号类型
            signal_confidence: 信号置信度

        返回:
            入场订单信息
        """
        try:
            # 生成订单ID
            order_id = f"{symbol}_{int(time.time())}_{position_type.name}"

            # 创建入场订单
            entry_order = {
                'order_id': order_id,
                'symbol': symbol,
                'position_type': position_type,
                'order_type': 'LIMIT' if self.params['use_limit_entry'] else 'MARKET',
                'price': entry_price,
                'stop_loss_price': stop_loss_price,
                'size': position_size,
                'status': PositionStatus.PENDING,
                'signal_type': signal_type,
                'signal_confidence': signal_confidence,
                'created_time': datetime.now(),
                'updated_time': datetime.now(),
                'filled_size': 0.0,
                'filled_price': 0.0,
                'remaining_size': position_size,
                'timeout': self.params['entry_timeout'],
                'profit_targets': self._calculate_profit_targets(entry_price, stop_loss_price, position_type)
            }

            # 添加到订单历史
            self.order_history.append(entry_order)

            logger.info(f"创建入场订单: {symbol} {position_type.name} {position_size} @ {entry_price}")

            return entry_order

        except Exception as e:
            logger.error(f"创建入场订单失败: {e}")
            return {
                'order_id': f"ERROR_{symbol}_{int(time.time())}",
                'symbol': symbol,
                'position_type': position_type,
                'order_type': 'ERROR',
                'status': PositionStatus.ERROR,
                'error': str(e)
            }

    def _calculate_profit_targets(self, entry_price: float, stop_loss_price: float,
                                position_type: PositionType) -> List[Dict[str, Any]]:
        """
        计算利润目标

        参数:
            entry_price: 入场价格
            stop_loss_price: 止损价格
            position_type: 仓位类型

        返回:
            利润目标列表
        """
        try:
            # 计算风险
            risk = abs(entry_price - stop_loss_price)

            # 计算利润目标
            profit_targets = []

            for i, target_pct in enumerate(self.params['profit_targets']):
                # 计算目标价格
                if position_type == PositionType.LONG:
                    target_price = entry_price * (1 + target_pct)
                else:
                    target_price = entry_price * (1 - target_pct)

                # 计算风险回报比
                risk_reward = (abs(target_price - entry_price) / risk) if risk > 0 else 0

                # 添加到目标列表
                profit_targets.append({
                    'target_pct': target_pct,
                    'target_price': target_price,
                    'exit_pct': self.params['exit_percentages'][i],
                    'risk_reward': risk_reward,
                    'status': 'PENDING'
                })

            return profit_targets

        except Exception as e:
            logger.error(f"计算利润目标失败: {e}")
            return []

    def update_entry_order(self, order_id: str, filled_size: float,
                         filled_price: float) -> Dict[str, Any]:
        """
        更新入场订单

        参数:
            order_id: 订单ID
            filled_size: 已成交数量
            filled_price: 成交价格

        返回:
            更新后的订单信息
        """
        try:
            # 查找订单
            order = None
            for o in self.order_history:
                if o['order_id'] == order_id:
                    order = o
                    break

            if order is None:
                logger.warning(f"未找到订单: {order_id}")
                return {
                    'order_id': order_id,
                    'status': PositionStatus.ERROR,
                    'error': '未找到订单'
                }

            # 更新订单信息
            order['filled_size'] += filled_size
            order['filled_price'] = ((order['filled_price'] * (order['filled_size'] - filled_size)) +
                                   (filled_price * filled_size)) / order['filled_size'] if order['filled_size'] > 0 else 0
            order['remaining_size'] = order['size'] - order['filled_size']
            order['updated_time'] = datetime.now()

            # 检查是否完全成交
            if order['filled_size'] >= order['size'] * self.params['min_entry_fill_pct']:
                order['status'] = PositionStatus.OPEN

                # 创建持仓记录
                position = {
                    'symbol': order['symbol'],
                    'position_type': order['position_type'],
                    'entry_price': order['filled_price'],
                    'stop_loss_price': order['stop_loss_price'],
                    'size': order['filled_size'],
                    'entry_time': datetime.now(),
                    'profit_targets': order['profit_targets'],
                    'current_price': filled_price,
                    'unrealized_pnl': 0.0,
                    'realized_pnl': 0.0,
                    'status': PositionStatus.OPEN,
                    'exit_orders': []
                }

                # 添加到持仓字典
                self.positions[order['symbol']] = position

                logger.info(f"入场订单已成交: {order['symbol']} {order['position_type'].name} {order['filled_size']} @ {order['filled_price']}")

            return order

        except Exception as e:
            logger.error(f"更新入场订单失败: {e}")
            return {
                'order_id': order_id,
                'status': PositionStatus.ERROR,
                'error': str(e)
            }

    def create_exit_order(self, symbol: str, exit_price: float,
                        exit_size: float, exit_reason: str) -> Dict[str, Any]:
        """
        创建出场订单

        参数:
            symbol: 交易对符号
            exit_price: 出场价格
            exit_size: 出场数量
            exit_reason: 出场原因

        返回:
            出场订单信息
        """
        try:
            # 检查是否有持仓
            if symbol not in self.positions:
                logger.warning(f"未找到持仓: {symbol}")
                return {
                    'symbol': symbol,
                    'status': PositionStatus.ERROR,
                    'error': '未找到持仓'
                }

            # 获取持仓信息
            position = self.positions[symbol]

            # 检查出场数量
            if exit_size > position['size']:
                logger.warning(f"出场数量超过持仓数量: {exit_size} > {position['size']}")
                exit_size = position['size']

            # 生成订单ID
            order_id = f"{symbol}_EXIT_{int(time.time())}"

            # 创建出场订单
            exit_order = {
                'order_id': order_id,
                'symbol': symbol,
                'position_type': position['position_type'],
                'order_type': 'LIMIT' if self.params['use_limit_exit'] else 'MARKET',
                'price': exit_price,
                'size': exit_size,
                'status': PositionStatus.PENDING,
                'reason': exit_reason,
                'created_time': datetime.now(),
                'updated_time': datetime.now(),
                'filled_size': 0.0,
                'filled_price': 0.0,
                'remaining_size': exit_size,
                'timeout': self.params['exit_timeout']
            }

            # 添加到持仓的出场订单列表
            position['exit_orders'].append(exit_order)

            # 添加到订单历史
            self.order_history.append(exit_order)

            logger.info(f"创建出场订单: {symbol} {exit_size} @ {exit_price} ({exit_reason})")

            return exit_order

        except Exception as e:
            logger.error(f"创建出场订单失败: {e}")
            return {
                'order_id': f"ERROR_{symbol}_EXIT_{int(time.time())}",
                'symbol': symbol,
                'order_type': 'ERROR',
                'status': PositionStatus.ERROR,
                'error': str(e)
            }

    def update_exit_order(self, order_id: str, filled_size: float,
                        filled_price: float) -> Dict[str, Any]:
        """
        更新出场订单

        参数:
            order_id: 订单ID
            filled_size: 已成交数量
            filled_price: 成交价格

        返回:
            更新后的订单信息
        """
        try:
            # 查找订单
            order = None
            position = None

            for symbol, pos in self.positions.items():
                for o in pos['exit_orders']:
                    if o['order_id'] == order_id:
                        order = o
                        position = pos
                        break
                if order:
                    break

            if order is None or position is None:
                logger.warning(f"未找到出场订单: {order_id}")
                return {
                    'order_id': order_id,
                    'status': PositionStatus.ERROR,
                    'error': '未找到出场订单'
                }

            # 更新订单信息
            order['filled_size'] += filled_size
            order['filled_price'] = ((order['filled_price'] * (order['filled_size'] - filled_size)) +
                                   (filled_price * filled_size)) / order['filled_size'] if order['filled_size'] > 0 else 0
            order['remaining_size'] = order['size'] - order['filled_size']
            order['updated_time'] = datetime.now()

            # 计算已实现盈亏
            if position['position_type'] == PositionType.LONG:
                pnl = (filled_price - position['entry_price']) * filled_size
            else:
                pnl = (position['entry_price'] - filled_price) * filled_size

            # 更新持仓信息
            position['size'] -= filled_size
            position['realized_pnl'] += pnl

            # 检查是否完全出场
            if position['size'] <= 0:
                position['status'] = PositionStatus.CLOSED
                logger.info(f"持仓已平仓: {position['symbol']} 实现盈亏: {position['realized_pnl']:.2f}")

                # 从持仓字典中移除
                if order['filled_size'] >= order['size'] * self.params['min_exit_fill_pct']:
                    self.positions.pop(position['symbol'], None)
            else:
                position['status'] = PositionStatus.PARTIALLY_CLOSED
                logger.info(f"持仓部分平仓: {position['symbol']} 剩余: {position['size']} 实现盈亏: {pnl:.2f}")

            # 检查订单是否完成
            if order['filled_size'] >= order['size'] * self.params['min_exit_fill_pct']:
                order['status'] = PositionStatus.CLOSED

            return order

        except Exception as e:
            logger.error(f"更新出场订单失败: {e}")
            return {
                'order_id': order_id,
                'status': PositionStatus.ERROR,
                'error': str(e)
            }

    def update_position_price(self, symbol: str, current_price: float) -> Dict[str, Any]:
        """
        更新持仓价格

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            更新后的持仓信息
        """
        try:
            # 检查是否有持仓
            if symbol not in self.positions:
                return None

            # 获取持仓信息
            position = self.positions[symbol]

            # 更新当前价格
            position['current_price'] = current_price

            # 计算未实现盈亏
            if position['position_type'] == PositionType.LONG:
                position['unrealized_pnl'] = (current_price - position['entry_price']) * position['size']
            else:
                position['unrealized_pnl'] = (position['entry_price'] - current_price) * position['size']

            # 检查是否达到利润目标
            if self.params['use_staged_exit'] and position['status'] == PositionStatus.OPEN:
                for target in position['profit_targets']:
                    if target['status'] == 'PENDING':
                        # 检查是否达到目标价格
                        if ((position['position_type'] == PositionType.LONG and current_price >= target['target_price']) or
                            (position['position_type'] == PositionType.SHORT and current_price <= target['target_price'])):

                            # 计算出场数量
                            exit_size = position['size'] * target['exit_pct']

                            # 创建出场订单
                            exit_reason = f"利润目标 {target['target_pct'] * 100:.1f}%"
                            self.create_exit_order(symbol, current_price, exit_size, exit_reason)

                            # 更新目标状态
                            target['status'] = 'TRIGGERED'

            # 检查是否触发止损
            if position['status'] == PositionStatus.OPEN:
                if ((position['position_type'] == PositionType.LONG and current_price <= position['stop_loss_price']) or
                    (position['position_type'] == PositionType.SHORT and current_price >= position['stop_loss_price'])):

                    # 创建止损出场订单
                    self.create_exit_order(symbol, current_price, position['size'], "止损触发")

            # 检查是否达到最大持仓时间
            if (self.params['use_time_exit'] and position['status'] == PositionStatus.OPEN and
                (datetime.now() - position['entry_time']).total_seconds() >= self.params['max_trade_duration']):

                # 创建时间出场订单
                self.create_exit_order(symbol, current_price, position['size'], "最大持仓时间到达")

            return position

        except Exception as e:
            logger.error(f"更新持仓价格失败: {e}")
            return None

    def get_position(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取持仓信息

        参数:
            symbol: 交易对符号

        返回:
            持仓信息
        """
        return self.positions.get(symbol)

    def get_all_positions(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有持仓信息

        返回:
            所有持仓信息
        """
        return self.positions

    def get_position_summary(self) -> Dict[str, Any]:
        """
        获取持仓摘要

        返回:
            持仓摘要
        """
        try:
            total_positions = len(self.positions)
            total_long = sum(1 for p in self.positions.values() if p['position_type'] == PositionType.LONG)
            total_short = sum(1 for p in self.positions.values() if p['position_type'] == PositionType.SHORT)

            total_unrealized_pnl = sum(p['unrealized_pnl'] for p in self.positions.values())
            total_realized_pnl = sum(p['realized_pnl'] for p in self.positions.values())

            return {
                'total_positions': total_positions,
                'total_long': total_long,
                'total_short': total_short,
                'total_unrealized_pnl': total_unrealized_pnl,
                'total_realized_pnl': total_realized_pnl,
                'total_pnl': total_unrealized_pnl + total_realized_pnl
            }

        except Exception as e:
            logger.error(f"获取持仓摘要失败: {e}")
            return {
                'total_positions': 0,
                'total_long': 0,
                'total_short': 0,
                'total_unrealized_pnl': 0.0,
                'total_realized_pnl': 0.0,
                'total_pnl': 0.0
            }

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置仓位管理参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取仓位管理参数

        返回:
            参数字典
        """
        return self.params.copy()
