#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
信号生成模块

该模块负责基于技术指标和机器学习模型生成交易信号，支持多级信号确认和信号强度分级。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import talib

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.market_analyzer import MarketState
from user_data.strategies.modules.signal_generator.technical_signals import TechnicalSignals
from user_data.strategies.modules.signal_generator.price_patterns import PricePatternRecognizer
from user_data.strategies.modules.signal_generator.ml_signals import MLSignalGenerator
from user_data.strategies.modules.signal_generator.ensemble_signals import EnsembleSignalGenerator

# 获取日志记录器
logger = get_logger("signal_generator")

class SignalType(Enum):
    """信号类型枚举"""
    BUY = "买入"
    SELL = "卖出"
    STRONG_BUY = "强力买入"
    STRONG_SELL = "强力卖出"
    EXIT_LONG = "平多"
    EXIT_SHORT = "平空"
    NONE = "无信号"

class SignalStrength(Enum):
    """信号强度枚举"""
    LEVEL_1 = 1  # 单一时间周期信号
    LEVEL_2 = 2  # 两个时间周期共振
    LEVEL_3 = 3  # 三个以上时间周期共振且机器学习确认

class SignalGenerator:
    """
    信号生成类

    负责基于技术指标和机器学习模型生成交易信号
    """

    def __init__(self):
        """初始化信号生成器"""
        # 信号生成器参数
        self.params = {
            'rsi_oversold': 30,
            'rsi_overbought': 70,
            'macd_threshold': 0.0,
            'cci_oversold': -100,
            'cci_overbought': 100,
            'stoch_oversold': 20,
            'stoch_overbought': 80,
            'bb_threshold': 0.05,
            'atr_multiplier': 1.5,
            'volume_threshold': 1.5
        }

    def generate_signals(self, data: pd.DataFrame, indicators: Dict[str, np.ndarray],
                        market_state: MarketState) -> Dict[str, Any]:
        """
        生成交易信号

        参数:
            data: OHLCV数据
            indicators: 技术指标字典
            market_state: 市场状态

        返回:
            信号字典
        """
        if data.empty or not indicators:
            logger.warning("数据或指标为空，无法生成信号")
            return {
                'type': SignalType.NONE,
                'strength': 0,
                'entry_price': 0.0,
                'stop_loss': 0.0,
                'take_profit': 0.0,
                'risk_reward': 0.0,
                'confidence': 0.0,
                'reasons': []
            }

        try:
            # 获取最新价格和指标值
            close = data['close'].iloc[-1]

            # 初始化信号评分
            buy_score = 0
            sell_score = 0
            reasons = []

            # 1. RSI信号
            if 'rsi14' in indicators:
                rsi = indicators['rsi14'][-1]

                if rsi < self.params['rsi_oversold']:
                    buy_score += 1
                    reasons.append(f"RSI超卖 ({rsi:.2f})")
                elif rsi > self.params['rsi_overbought']:
                    sell_score += 1
                    reasons.append(f"RSI超买 ({rsi:.2f})")

            # 2. MACD信号
            if all(k in indicators for k in ['macd', 'macdsignal']):
                macd = indicators['macd'][-1]
                macdsignal = indicators['macdsignal'][-1]

                # MACD金叉
                if (macd > macdsignal and
                    indicators['macd'][-2] <= indicators['macdsignal'][-2]):
                    buy_score += 1
                    reasons.append("MACD金叉")

                # MACD死叉
                if (macd < macdsignal and
                    indicators['macd'][-2] >= indicators['macdsignal'][-2]):
                    sell_score += 1
                    reasons.append("MACD死叉")

                # MACD柱状图方向
                if 'macdhist' in indicators:
                    macdhist = indicators['macdhist'][-1]
                    macdhist_prev = indicators['macdhist'][-2]

                    if macdhist > 0 and macdhist > macdhist_prev:
                        buy_score += 0.5
                        reasons.append("MACD柱状图上升")
                    elif macdhist < 0 and macdhist < macdhist_prev:
                        sell_score += 0.5
                        reasons.append("MACD柱状图下降")

            # 3. 布林带信号
            if all(k in indicators for k in ['upperband', 'middleband', 'lowerband']):
                upperband = indicators['upperband'][-1]
                middleband = indicators['middleband'][-1]
                lowerband = indicators['lowerband'][-1]

                # 价格接近下轨
                if close < lowerband * (1 + self.params['bb_threshold']):
                    buy_score += 1
                    reasons.append("价格接近布林带下轨")

                # 价格接近上轨
                if close > upperband * (1 - self.params['bb_threshold']):
                    sell_score += 1
                    reasons.append("价格接近布林带上轨")

                # 布林带宽度扩大
                if 'bb_width' in indicators:
                    bb_width = indicators['bb_width'][-1]
                    bb_width_prev = indicators['bb_width'][-2]

                    if bb_width > bb_width_prev * 1.1:
                        # 根据价格位置判断方向
                        if close > middleband:
                            buy_score += 0.5
                            reasons.append("布林带宽度扩大，价格在中轨上方")
                        else:
                            sell_score += 0.5
                            reasons.append("布林带宽度扩大，价格在中轨下方")

            # 4. 随机指标信号
            if all(k in indicators for k in ['slowk', 'slowd']):
                slowk = indicators['slowk'][-1]
                slowd = indicators['slowd'][-1]

                # 超卖区域金叉
                if (slowk > slowd and
                    indicators['slowk'][-2] <= indicators['slowd'][-2] and
                    slowk < self.params['stoch_oversold']):
                    buy_score += 1
                    reasons.append("随机指标超卖区域金叉")

                # 超买区域死叉
                if (slowk < slowd and
                    indicators['slowk'][-2] >= indicators['slowd'][-2] and
                    slowk > self.params['stoch_overbought']):
                    sell_score += 1
                    reasons.append("随机指标超买区域死叉")

            # 5. CCI信号
            if 'cci' in indicators:
                cci = indicators['cci'][-1]

                if cci < self.params['cci_oversold']:
                    buy_score += 0.5
                    reasons.append(f"CCI超卖 ({cci:.2f})")
                elif cci > self.params['cci_overbought']:
                    sell_score += 0.5
                    reasons.append(f"CCI超买 ({cci:.2f})")

            # 6. 移动平均线信号
            if all(k in indicators for k in ['sma20', 'sma50', 'sma200']):
                sma20 = indicators['sma20'][-1]
                sma50 = indicators['sma50'][-1]
                sma200 = indicators['sma200'][-1]

                # 价格突破短期均线
                if (close > sma20 and data['close'].iloc[-2] <= indicators['sma20'][-2]):
                    buy_score += 0.5
                    reasons.append("价格突破20日均线")
                elif (close < sma20 and data['close'].iloc[-2] >= indicators['sma20'][-2]):
                    sell_score += 0.5
                    reasons.append("价格跌破20日均线")

                # 均线多头排列
                if sma20 > sma50 and sma50 > sma200:
                    buy_score += 0.5
                    reasons.append("均线多头排列")

                # 均线空头排列
                if sma20 < sma50 and sma50 < sma200:
                    sell_score += 0.5
                    reasons.append("均线空头排列")

                # 黄金交叉
                if (sma20 > sma50 and
                    indicators['sma20'][-2] <= indicators['sma50'][-2]):
                    buy_score += 1
                    reasons.append("短期均线金叉中期均线")

                # 死亡交叉
                if (sma20 < sma50 and
                    indicators['sma20'][-2] >= indicators['sma50'][-2]):
                    sell_score += 1
                    reasons.append("短期均线死叉中期均线")

            # 7. 考虑市场状态
            if market_state in [MarketState.STRONG_UPTREND, MarketState.UPTREND]:
                buy_score += 1
                reasons.append(f"市场处于{market_state.value}")
            elif market_state in [MarketState.STRONG_DOWNTREND, MarketState.DOWNTREND]:
                sell_score += 1
                reasons.append(f"市场处于{market_state.value}")
            elif market_state == MarketState.BREAKOUT_UP:
                buy_score += 1.5
                reasons.append("市场向上突破")
            elif market_state == MarketState.BREAKOUT_DOWN:
                sell_score += 1.5
                reasons.append("市场向下突破")
            elif market_state == MarketState.REVERSAL_UP:
                buy_score += 1.5
                reasons.append("市场向上反转")
            elif market_state == MarketState.REVERSAL_DOWN:
                sell_score += 1.5
                reasons.append("市场向下反转")

            # 8. 成交量确认
            if 'volume' in data.columns:
                current_volume = data['volume'].iloc[-1]
                avg_volume = data['volume'].iloc[-20:].mean()

                if current_volume > avg_volume * self.params['volume_threshold']:
                    # 根据价格变化方向增强信号
                    price_change = data['close'].iloc[-1] - data['close'].iloc[-2]
                    if price_change > 0:
                        buy_score += 0.5
                        reasons.append("成交量放大，价格上涨")
                    elif price_change < 0:
                        sell_score += 0.5
                        reasons.append("成交量放大，价格下跌")

            # 确定信号类型和强度
            signal_type = SignalType.NONE
            signal_strength = 0

            if buy_score >= 4:
                signal_type = SignalType.STRONG_BUY
                signal_strength = 3
            elif buy_score >= 2.5:
                signal_type = SignalType.BUY
                signal_strength = 2
            elif buy_score >= 1.5:
                signal_type = SignalType.BUY
                signal_strength = 1
            elif sell_score >= 4:
                signal_type = SignalType.STRONG_SELL
                signal_strength = 3
            elif sell_score >= 2.5:
                signal_type = SignalType.SELL
                signal_strength = 2
            elif sell_score >= 1.5:
                signal_type = SignalType.SELL
                signal_strength = 1

            # 计算入场价、止损和止盈
            entry_price = close
            stop_loss = 0.0
            take_profit = 0.0
            risk_reward = 0.0

            if signal_type in [SignalType.BUY, SignalType.STRONG_BUY]:
                # 使用ATR计算止损
                if 'atr' in indicators:
                    atr = indicators['atr'][-1]
                    stop_loss = entry_price - atr * self.params['atr_multiplier']
                    take_profit = entry_price + atr * self.params['atr_multiplier'] * 2
                else:
                    # 使用固定百分比
                    stop_loss = entry_price * 0.98
                    take_profit = entry_price * 1.04

            elif signal_type in [SignalType.SELL, SignalType.STRONG_SELL]:
                # 使用ATR计算止损
                if 'atr' in indicators:
                    atr = indicators['atr'][-1]
                    stop_loss = entry_price + atr * self.params['atr_multiplier']
                    take_profit = entry_price - atr * self.params['atr_multiplier'] * 2
                else:
                    # 使用固定百分比
                    stop_loss = entry_price * 1.02
                    take_profit = entry_price * 0.96

            # 计算风险回报比
            if entry_price != stop_loss:
                risk = abs(entry_price - stop_loss)
                reward = abs(take_profit - entry_price)
                risk_reward = reward / risk if risk > 0 else 0

            # 计算信号置信度
            confidence = max(buy_score, sell_score) / 5  # 归一化到0-1
            confidence = min(max(confidence, 0), 1)  # 限制在0-1范围内

            return {
                'type': signal_type,
                'strength': signal_strength,
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'risk_reward': risk_reward,
                'confidence': confidence,
                'reasons': reasons
            }

        except Exception as e:
            logger.error(f"生成信号失败: {e}")
            return {
                'type': SignalType.NONE,
                'strength': 0,
                'entry_price': 0.0,
                'stop_loss': 0.0,
                'take_profit': 0.0,
                'risk_reward': 0.0,
                'confidence': 0.0,
                'reasons': []
            }

    def generate_multi_timeframe_signals(self, data_dict: Dict[str, pd.DataFrame],
                                        indicators_dict: Dict[str, Dict[str, np.ndarray]],
                                        market_states: Dict[str, MarketState]) -> Dict[str, Any]:
        """
        生成多时间周期交易信号

        参数:
            data_dict: 不同时间周期的OHLCV数据字典 {timeframe: dataframe}
            indicators_dict: 不同时间周期的指标字典 {timeframe: {indicator: array}}
            market_states: 不同时间周期的市场状态字典 {timeframe: state}

        返回:
            多时间周期信号分析结果
        """
        if not data_dict or not indicators_dict or not market_states:
            logger.warning("数据、指标或市场状态为空，无法生成多时间周期信号")
            return {
                'consensus': SignalType.NONE,
                'strength': 0,
                'confidence': 0.0,
                'timeframes': {}
            }

        try:
            # 生成每个时间周期的信号
            timeframe_signals = {}
            for timeframe in data_dict:
                if timeframe in indicators_dict and timeframe in market_states:
                    timeframe_signals[timeframe] = self.generate_signals(
                        data_dict[timeframe],
                        indicators_dict[timeframe],
                        market_states[timeframe]
                    )

            if not timeframe_signals:
                return {
                    'consensus': SignalType.NONE,
                    'strength': 0,
                    'confidence': 0.0,
                    'timeframes': {}
                }

            # 计算信号共识
            buy_count = 0
            sell_count = 0
            strong_buy_count = 0
            strong_sell_count = 0
            total_confidence = 0.0

            # 时间周期权重，较短时间周期权重较低
            weights = {
                '1m': 0.5,
                '3m': 0.6,
                '5m': 0.7,
                '15m': 0.8,
                '30m': 0.9,
                '1h': 1.0,
                '2h': 1.1,
                '4h': 1.2,
                '6h': 1.3,
                '12h': 1.4,
                '1d': 1.5
            }

            # 计算加权信号计数
            for tf, signal in timeframe_signals.items():
                weight = weights.get(tf, 1.0)

                if signal['type'] == SignalType.BUY:
                    buy_count += weight
                elif signal['type'] == SignalType.STRONG_BUY:
                    buy_count += weight
                    strong_buy_count += weight
                elif signal['type'] == SignalType.SELL:
                    sell_count += weight
                elif signal['type'] == SignalType.STRONG_SELL:
                    sell_count += weight
                    strong_sell_count += weight

                total_confidence += signal['confidence'] * weight

            # 计算总权重
            total_weight = sum(weights.get(tf, 1.0) for tf in timeframe_signals)

            # 确定共识信号类型
            consensus = SignalType.NONE

            if buy_count > sell_count:
                if strong_buy_count > 0 and buy_count >= total_weight * 0.6:
                    consensus = SignalType.STRONG_BUY
                elif buy_count >= total_weight * 0.5:
                    consensus = SignalType.BUY
            elif sell_count > buy_count:
                if strong_sell_count > 0 and sell_count >= total_weight * 0.6:
                    consensus = SignalType.STRONG_SELL
                elif sell_count >= total_weight * 0.5:
                    consensus = SignalType.SELL

            # 确定信号强度
            strength = 0

            if consensus in [SignalType.BUY, SignalType.STRONG_BUY, SignalType.SELL, SignalType.STRONG_SELL]:
                # 计算共振的时间周期数
                aligned_timeframes = 0
                for tf, signal in timeframe_signals.items():
                    if (consensus in [SignalType.BUY, SignalType.STRONG_BUY] and
                        signal['type'] in [SignalType.BUY, SignalType.STRONG_BUY]):
                        aligned_timeframes += 1
                    elif (consensus in [SignalType.SELL, SignalType.STRONG_SELL] and
                          signal['type'] in [SignalType.SELL, SignalType.STRONG_SELL]):
                        aligned_timeframes += 1

                # 根据共振时间周期数确定强度
                if aligned_timeframes >= 3:
                    strength = 3
                elif aligned_timeframes >= 2:
                    strength = 2
                elif aligned_timeframes >= 1:
                    strength = 1

            # 计算整体置信度
            confidence = total_confidence / total_weight if total_weight > 0 else 0

            return {
                'consensus': consensus,
                'strength': strength,
                'confidence': confidence,
                'timeframes': timeframe_signals
            }

        except Exception as e:
            logger.error(f"生成多时间周期信号失败: {e}")
            return {
                'consensus': SignalType.NONE,
                'strength': 0,
                'confidence': 0.0,
                'timeframes': {}
            }

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置信号生成器参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取信号生成器参数

        返回:
            参数字典
        """
        return self.params.copy()
