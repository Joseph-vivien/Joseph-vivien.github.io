#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
风险管理模块初始化文件
"""

from enum import Enum, auto

# 定义风险级别枚举
class RiskLevel(Enum):
    """风险级别枚举"""
    LOW = auto()  # 低风险
    MEDIUM = auto()  # 中等风险
    HIGH = auto()  # 高风险
    EXTREME = auto()  # 极端风险

# 导入其他模块
from user_data.strategies.modules.risk_manager.global_risk_monitor import GlobalRiskMonitor, SystemRiskLevel
from user_data.strategies.modules.risk_manager.position_risk_calculator import PositionRiskCalculator
from user_data.strategies.modules.risk_manager.stop_loss_manager import StopLossManager, StopLossType
from user_data.strategies.modules.risk_manager.risk_manager import RiskManager, PositionSizing

__all__ = ['RiskManager', 'PositionSizing', 'RiskLevel', 'GlobalRiskMonitor', 'SystemRiskLevel', 'PositionRiskCalculator', 'StopLossManager', 'StopLossType']
