#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓位风险计算器模块

该模块负责计算交易仓位的风险指标，包括风险敞口、回撤风险、强平风险和波动率风险等。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import math
from datetime import datetime, timedelta

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer

# 获取日志记录器
logger = get_logger("position_risk_calculator")

class RiskMetricType(Enum):
    """风险指标类型枚举"""
    EXPOSURE = "风险敞口"
    DRAWDOWN = "回撤风险"
    LIQUIDATION = "强平风险"
    VOLATILITY = "波动率风险"
    CORRELATION = "相关性风险"
    CONCENTRATION = "集中度风险"
    SLIPPAGE = "滑点风险"
    OVERNIGHT = "隔夜风险"
    FUNDING = "资金费率风险"

class PositionRiskCalculator:
    """
    仓位风险计算器类

    负责计算交易仓位的风险指标，提供风险评估和优化建议
    """

    def __init__(self):
        """初始化仓位风险计算器"""
        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 风险计算参数
            'account_balance': 10000.0,  # 账户余额
            'max_risk_per_trade': 0.02,  # 单笔交易最大风险（2%）
            'max_portfolio_risk': 0.1,  # 投资组合最大风险（10%）
            'max_concentration': 0.2,  # 最大集中度（20%）
            'max_correlation': 0.7,  # 最大相关性（70%）
            'max_overnight_exposure': 0.5,  # 最大隔夜敞口（50%）

            # 强平风险参数
            'liquidation_buffer': 0.2,  # 强平缓冲（20%）
            'min_distance_to_liquidation': 0.1,  # 最小强平距离（10%）

            # 波动率风险参数
            'volatility_lookback': 20,  # 波动率回溯期
            'volatility_multiplier': 2.0,  # 波动率乘数
            'max_volatility_risk': 0.05,  # 最大波动率风险（5%）

            # 资金费率风险参数
            'max_funding_rate': 0.001,  # 最大资金费率（0.1%）
            'funding_rate_threshold': 0.0005,  # 资金费率阈值（0.05%）
        }

        # 初始化波动率分析器
        self.volatility_analyzer = VolatilityAnalyzer()

        # 仓位缓存
        self.positions = {}

        # 市场数据缓存
        self.market_data = {}

    def calculate_position_risk(self, symbol: str, position_size: float,
                              entry_price: float, current_price: float,
                              stop_loss_price: float, leverage: float = 1.0,
                              data: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """
        计算仓位风险

        参数:
            symbol: 交易对符号
            position_size: 仓位大小（币数量）
            entry_price: 入场价格
            current_price: 当前价格
            stop_loss_price: 止损价格
            leverage: 杠杆倍数
            data: OHLCV数据

        返回:
            风险计算结果
        """
        try:
            # 计算仓位价值
            position_value = position_size * current_price

            # 计算是否做多
            is_long = entry_price < stop_loss_price

            # 计算风险敞口
            risk_exposure = self._calculate_risk_exposure(
                position_value, self.params['account_balance'])

            # 计算回撤风险
            drawdown_risk = self._calculate_drawdown_risk(
                position_size, entry_price, stop_loss_price, is_long)

            # 计算强平风险
            liquidation_risk = self._calculate_liquidation_risk(
                entry_price, current_price, stop_loss_price, leverage, is_long)

            # 计算波动率风险
            volatility_risk = self._calculate_volatility_risk(
                symbol, position_value, data)

            # 计算相关性风险
            correlation_risk = self._calculate_correlation_risk(symbol)

            # 计算集中度风险
            concentration_risk = self._calculate_concentration_risk(
                symbol, position_value)

            # 计算滑点风险
            slippage_risk = self._calculate_slippage_risk(symbol, position_size)

            # 计算隔夜风险
            overnight_risk = self._calculate_overnight_risk(
                symbol, position_value)

            # 计算资金费率风险
            funding_risk = self._calculate_funding_risk(symbol)

            # 计算总风险分数
            total_risk_score = (
                risk_exposure * 0.15 +
                drawdown_risk * 0.2 +
                liquidation_risk * 0.2 +
                volatility_risk * 0.15 +
                correlation_risk * 0.05 +
                concentration_risk * 0.1 +
                slippage_risk * 0.05 +
                overnight_risk * 0.05 +
                funding_risk * 0.05
            )

            # 构建风险报告
            risk_report = {
                'symbol': symbol,
                'position_size': position_size,
                'position_value': position_value,
                'entry_price': entry_price,
                'current_price': current_price,
                'stop_loss_price': stop_loss_price,
                'leverage': leverage,
                'is_long': is_long,
                'risk_metrics': {
                    RiskMetricType.EXPOSURE.value: risk_exposure,
                    RiskMetricType.DRAWDOWN.value: drawdown_risk,
                    RiskMetricType.LIQUIDATION.value: liquidation_risk,
                    RiskMetricType.VOLATILITY.value: volatility_risk,
                    RiskMetricType.CORRELATION.value: correlation_risk,
                    RiskMetricType.CONCENTRATION.value: concentration_risk,
                    RiskMetricType.SLIPPAGE.value: slippage_risk,
                    RiskMetricType.OVERNIGHT.value: overnight_risk,
                    RiskMetricType.FUNDING.value: funding_risk
                },
                'total_risk_score': total_risk_score,
                'risk_level': self._determine_risk_level(total_risk_score),
                'timestamp': datetime.now()
            }

            # 缓存仓位风险
            self.positions[symbol] = risk_report

            return risk_report

        except Exception as e:
            logger.error(f"计算仓位风险失败: {e}")
            return {
                'symbol': symbol,
                'error': str(e),
                'timestamp': datetime.now()
            }

    def _calculate_risk_exposure(self, position_value: float, account_balance: float) -> float:
        """
        计算风险敞口

        参数:
            position_value: 仓位价值
            account_balance: 账户余额

        返回:
            风险敞口分数 (0-1)
        """
        try:
            # 计算仓位占账户余额的比例
            exposure_ratio = position_value / account_balance if account_balance > 0 else 1.0

            # 计算风险敞口分数
            risk_score = min(1.0, exposure_ratio / self.params['max_risk_per_trade'])

            return risk_score

        except Exception as e:
            logger.error(f"计算风险敞口失败: {e}")
            return 0.5

    def _calculate_drawdown_risk(self, position_size: float, entry_price: float,
                               stop_loss_price: float, is_long: bool) -> float:
        """
        计算回撤风险

        参数:
            position_size: 仓位大小
            entry_price: 入场价格
            stop_loss_price: 止损价格
            is_long: 是否做多

        返回:
            回撤风险分数 (0-1)
        """
        try:
            # 计算止损距离
            if is_long:
                stop_distance = (entry_price - stop_loss_price) / entry_price
            else:
                stop_distance = (stop_loss_price - entry_price) / entry_price

            # 计算最大亏损金额
            max_loss = position_size * entry_price * stop_distance

            # 计算最大亏损占账户余额的比例
            max_loss_ratio = max_loss / self.params['account_balance'] if self.params['account_balance'] > 0 else 1.0

            # 计算回撤风险分数
            risk_score = min(1.0, max_loss_ratio / self.params['max_risk_per_trade'])

            return risk_score

        except Exception as e:
            logger.error(f"计算回撤风险失败: {e}")
            return 0.5

    def _calculate_liquidation_risk(self, entry_price: float, current_price: float,
                                  stop_loss_price: float, leverage: float,
                                  is_long: bool) -> float:
        """
        计算强平风险

        参数:
            entry_price: 入场价格
            current_price: 当前价格
            stop_loss_price: 止损价格
            leverage: 杠杆倍数
            is_long: 是否做多

        返回:
            强平风险分数 (0-1)
        """
        try:
            # 如果不使用杠杆，强平风险为0
            if leverage <= 1.0:
                return 0.0

            # 计算强平价格
            liquidation_buffer = self.params['liquidation_buffer']

            if is_long:
                liquidation_price = entry_price * (1 - (1 - liquidation_buffer) / leverage)
            else:
                liquidation_price = entry_price * (1 + (1 - liquidation_buffer) / leverage)

            # 计算当前价格到强平价格的距离
            if is_long:
                distance_to_liquidation = (current_price - liquidation_price) / current_price
            else:
                distance_to_liquidation = (liquidation_price - current_price) / current_price

            # 计算强平风险分数
            if distance_to_liquidation <= 0:
                risk_score = 1.0
            else:
                risk_score = min(1.0, self.params['min_distance_to_liquidation'] / distance_to_liquidation)

            return risk_score

        except Exception as e:
            logger.error(f"计算强平风险失败: {e}")
            return 0.5

    def _calculate_volatility_risk(self, symbol: str, position_value: float,
                                 data: Optional[pd.DataFrame]) -> float:
        """
        计算波动率风险

        参数:
            symbol: 交易对符号
            position_value: 仓位价值
            data: OHLCV数据

        返回:
            波动率风险分数 (0-1)
        """
        try:
            # 如果没有数据，使用默认风险分数
            if data is None or data.empty:
                return 0.5

            # 计算波动率
            volatility = self.volatility_analyzer.analyze_volatility(
                data, short_window=self.params['volatility_lookback'])

            # 获取ATR百分比
            atr_percent = volatility.get('atr_percent', 0.01)  # 默认1%

            # 计算波动率风险
            volatility_risk = atr_percent * self.params['volatility_multiplier']

            # 计算波动率风险分数
            risk_score = min(1.0, volatility_risk / self.params['max_volatility_risk'])

            return risk_score

        except Exception as e:
            logger.error(f"计算波动率风险失败: {e}")
            return 0.5

    def _calculate_correlation_risk(self, symbol: str) -> float:
        """
        计算相关性风险

        参数:
            symbol: 交易对符号

        返回:
            相关性风险分数 (0-1)
        """
        try:
            # 如果没有其他仓位，相关性风险为0
            if len(self.positions) <= 1:
                return 0.0

            # 这里应该计算与其他仓位的相关性
            # 由于需要历史价格数据，这里使用模拟数据
            correlation = 0.3  # 模拟相关性

            # 计算相关性风险分数
            risk_score = min(1.0, correlation / self.params['max_correlation'])

            return risk_score

        except Exception as e:
            logger.error(f"计算相关性风险失败: {e}")
            return 0.3

    def _calculate_concentration_risk(self, symbol: str, position_value: float) -> float:
        """
        计算集中度风险

        参数:
            symbol: 交易对符号
            position_value: 仓位价值

        返回:
            集中度风险分数 (0-1)
        """
        try:
            # 计算总仓位价值
            total_position_value = sum(p.get('position_value', 0) for p in self.positions.values())

            # 如果总仓位价值为0，集中度风险为0
            if total_position_value <= 0:
                return 0.0

            # 计算集中度
            concentration = position_value / total_position_value

            # 计算集中度风险分数
            risk_score = min(1.0, concentration / self.params['max_concentration'])

            return risk_score

        except Exception as e:
            logger.error(f"计算集中度风险失败: {e}")
            return 0.2

    def _calculate_slippage_risk(self, symbol: str, position_size: float) -> float:
        """
        计算滑点风险

        参数:
            symbol: 交易对符号
            position_size: 仓位大小

        返回:
            滑点风险分数 (0-1)
        """
        try:
            # 这里应该获取市场深度数据计算滑点
            # 由于需要订单簿数据，这里使用模拟数据
            market_depth = self.market_data.get(symbol, {}).get('depth', {})

            # 如果没有市场深度数据，使用默认风险分数
            if not market_depth:
                return 0.3

            # 模拟计算滑点风险
            slippage_risk = 0.2  # 模拟滑点风险

            return slippage_risk

        except Exception as e:
            logger.error(f"计算滑点风险失败: {e}")
            return 0.3

    def _calculate_overnight_risk(self, symbol: str, position_value: float) -> float:
        """
        计算隔夜风险

        参数:
            symbol: 交易对符号
            position_value: 仓位价值

        返回:
            隔夜风险分数 (0-1)
        """
        try:
            # 计算隔夜敞口
            overnight_exposure = position_value / self.params['account_balance'] if self.params['account_balance'] > 0 else 0

            # 计算隔夜风险分数
            risk_score = min(1.0, overnight_exposure / self.params['max_overnight_exposure'])

            return risk_score

        except Exception as e:
            logger.error(f"计算隔夜风险失败: {e}")
            return 0.2

    def _calculate_funding_risk(self, symbol: str) -> float:
        """
        计算资金费率风险

        参数:
            symbol: 交易对符号

        返回:
            资金费率风险分数 (0-1)
        """
        try:
            # 获取资金费率
            funding_rate = self.market_data.get(symbol, {}).get('funding_rate', 0)

            # 计算资金费率风险分数
            if abs(funding_rate) < self.params['funding_rate_threshold']:
                risk_score = 0.0
            else:
                risk_score = min(1.0, abs(funding_rate) / self.params['max_funding_rate'])

            return risk_score

        except Exception as e:
            logger.error(f"计算资金费率风险失败: {e}")
            return 0.1

    def _determine_risk_level(self, risk_score: float) -> str:
        """
        确定风险级别

        参数:
            risk_score: 风险分数

        返回:
            风险级别
        """
        if risk_score >= 0.8:
            return "极高风险"
        elif risk_score >= 0.6:
            return "高风险"
        elif risk_score >= 0.4:
            return "中等风险"
        elif risk_score >= 0.2:
            return "低风险"
        else:
            return "极低风险"

    def calculate_portfolio_risk(self) -> Dict[str, Any]:
        """
        计算投资组合风险

        返回:
            投资组合风险报告
        """
        try:
            # 如果没有仓位，返回空报告
            if not self.positions:
                return {
                    'total_positions': 0,
                    'total_value': 0.0,
                    'total_risk_score': 0.0,
                    'risk_level': "无风险",
                    'timestamp': datetime.now()
                }

            # 计算总仓位价值
            total_value = sum(p.get('position_value', 0) for p in self.positions.values())

            # 计算加权风险分数
            weighted_risk_score = sum(
                p.get('total_risk_score', 0) * p.get('position_value', 0) / total_value
                for p in self.positions.values()
            ) if total_value > 0 else 0

            # 计算投资组合风险敞口
            portfolio_exposure = total_value / self.params['account_balance'] if self.params['account_balance'] > 0 else 0

            # 计算投资组合集中度
            max_position_value = max((p.get('position_value', 0) for p in self.positions.values()), default=0)
            concentration = max_position_value / total_value if total_value > 0 else 0

            # 计算投资组合相关性
            # 这里应该计算仓位之间的相关性矩阵
            # 由于需要历史价格数据，这里使用模拟数据
            correlation = 0.3  # 模拟相关性

            # 计算投资组合总风险分数
            total_risk_score = (
                weighted_risk_score * 0.4 +
                min(1.0, portfolio_exposure / self.params['max_portfolio_risk']) * 0.3 +
                min(1.0, concentration / self.params['max_concentration']) * 0.2 +
                min(1.0, correlation / self.params['max_correlation']) * 0.1
            )

            # 构建投资组合风险报告
            portfolio_report = {
                'total_positions': len(self.positions),
                'total_value': total_value,
                'account_balance': self.params['account_balance'],
                'exposure_ratio': portfolio_exposure,
                'concentration': concentration,
                'correlation': correlation,
                'weighted_risk_score': weighted_risk_score,
                'total_risk_score': total_risk_score,
                'risk_level': self._determine_risk_level(total_risk_score),
                'positions': {symbol: p.get('risk_level', "未知") for symbol, p in self.positions.items()},
                'timestamp': datetime.now()
            }

            return portfolio_report

        except Exception as e:
            logger.error(f"计算投资组合风险失败: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.now()
            }

    def get_position_risk(self, symbol: str) -> Dict[str, Any]:
        """
        获取仓位风险

        参数:
            symbol: 交易对符号

        返回:
            仓位风险报告
        """
        return self.positions.get(symbol, {})

    def get_all_position_risks(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有仓位风险

        返回:
            所有仓位风险报告
        """
        return self.positions

    def update_market_data(self, symbol: str, data: Dict[str, Any]) -> None:
        """
        更新市场数据

        参数:
            symbol: 交易对符号
            data: 市场数据
        """
        if symbol not in self.market_data:
            self.market_data[symbol] = {}

        self.market_data[symbol].update(data)

    def set_account_balance(self, balance: float) -> None:
        """
        设置账户余额

        参数:
            balance: 账户余额
        """
        self.params['account_balance'] = balance

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置风险计算参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取风险计算参数

        返回:
            参数字典
        """
        return self.params.copy()

    def clear_positions(self) -> None:
        """清空仓位缓存"""
        self.positions = {}

    def clear_market_data(self) -> None:
        """清空市场数据缓存"""
        self.market_data = {}
