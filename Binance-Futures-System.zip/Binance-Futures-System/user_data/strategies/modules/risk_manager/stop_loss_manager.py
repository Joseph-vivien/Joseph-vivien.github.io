#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
止损管理器模块

该模块负责管理交易止损，包括固定止损、追踪止损、波动率止损和时间止损等。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from datetime import datetime, timedelta

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer

# 获取日志记录器
logger = get_logger("stop_loss_manager")

class StopLossType(Enum):
    """止损类型枚举"""
    FIXED = "固定止损"
    TRAILING = "追踪止损"
    VOLATILITY = "波动率止损"
    TIME = "时间止损"
    BREAKEVEN = "保本止损"
    PARTIAL = "部分止损"
    TIERED = "分层止损"

class StopLossManager:
    """
    止损管理器类

    负责管理交易止损，包括固定止损、追踪止损、波动率止损和时间止损等
    """

    def __init__(self):
        """初始化止损管理器"""
        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 固定止损参数
            'fixed_stop_loss_pct': 0.02,  # 固定止损百分比（2%）
            'min_stop_loss_pct': 0.005,  # 最小止损百分比（0.5%）
            'max_stop_loss_pct': 0.1,  # 最大止损百分比（10%）

            # 追踪止损参数
            'use_trailing_stop': True,  # 是否使用追踪止损
            'trailing_stop_activation_pct': 0.01,  # 追踪止损激活百分比（1%）
            'trailing_stop_distance_pct': 0.01,  # 追踪止损距离百分比（1%）
            'trailing_stop_step_pct': 0.002,  # 追踪止损步长百分比（0.2%）

            # 波动率止损参数
            'use_volatility_stop': True,  # 是否使用波动率止损
            'volatility_lookback': 20,  # 波动率计算回溯期
            'volatility_multiplier': 2.0,  # 波动率乘数
            'min_volatility_stop_pct': 0.01,  # 最小波动率止损百分比（1%）
            'max_volatility_stop_pct': 0.05,  # 最大波动率止损百分比（5%）

            # 时间止损参数
            'use_time_stop': True,  # 是否使用时间止损
            'time_stop_minutes': 60 * 24,  # 时间止损分钟数（24小时）

            # 保本止损参数
            'use_breakeven_stop': True,  # 是否使用保本止损
            'breakeven_activation_pct': 0.01,  # 保本止损激活百分比（1%）
            'breakeven_buffer_pct': 0.001,  # 保本止损缓冲百分比（0.1%）

            # 部分止损参数
            'use_partial_stop': False,  # 是否使用部分止损
            'partial_stop_levels': [0.02, 0.03, 0.04],  # 部分止损级别（2%, 3%, 4%）
            'partial_stop_percentages': [0.3, 0.3, 0.4],  # 部分止损百分比（30%, 30%, 40%）

            # 分层止损参数
            'use_tiered_stop': False,  # 是否使用分层止损
            'tiered_stop_levels': [0.01, 0.02, 0.03],  # 分层止损级别（1%, 2%, 3%）
        }

        # 初始化波动率分析器
        self.volatility_analyzer = VolatilityAnalyzer()

        # 止损状态
        self.stop_loss_state = {}  # {symbol: {type: StopLossType, price: float, ...}}

    def calculate_stop_loss(self, symbol: str, entry_price: float,
                          current_price: float, is_long: bool,
                          data: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """
        计算止损价格

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            current_price: 当前价格
            is_long: 是否做多
            data: OHLCV数据

        返回:
            止损计算结果
        """
        try:
            # 计算固定止损
            fixed_stop = self._calculate_fixed_stop_loss(
                entry_price, is_long)

            # 计算追踪止损
            trailing_stop = self._calculate_trailing_stop_loss(
                symbol, entry_price, current_price, is_long)

            # 计算波动率止损
            volatility_stop = self._calculate_volatility_stop_loss(
                entry_price, is_long, data)

            # 计算保本止损
            breakeven_stop = self._calculate_breakeven_stop_loss(
                entry_price, current_price, is_long)

            # 选择最佳止损价格
            stop_loss_price, stop_loss_type = self._select_best_stop_loss(
                fixed_stop, trailing_stop, volatility_stop, breakeven_stop,
                entry_price, current_price, is_long)

            # 更新止损状态
            self._update_stop_loss_state(
                symbol, stop_loss_type, stop_loss_price, entry_price, current_price, is_long)

            # 构建止损结果
            stop_loss_result = {
                'symbol': symbol,
                'entry_price': entry_price,
                'current_price': current_price,
                'is_long': is_long,
                'stop_loss_price': stop_loss_price,
                'stop_loss_type': stop_loss_type.value,
                'stop_loss_pct': abs(stop_loss_price - entry_price) / entry_price * 100,
                'fixed_stop': fixed_stop,
                'trailing_stop': trailing_stop,
                'volatility_stop': volatility_stop,
                'breakeven_stop': breakeven_stop,
                'timestamp': datetime.now()
            }

            return stop_loss_result

        except Exception as e:
            logger.error(f"计算止损价格失败: {e}")

            # 返回默认止损
            default_stop = self._calculate_fixed_stop_loss(entry_price, is_long)

            return {
                'symbol': symbol,
                'entry_price': entry_price,
                'current_price': current_price,
                'is_long': is_long,
                'stop_loss_price': default_stop,
                'stop_loss_type': StopLossType.FIXED.value,
                'stop_loss_pct': self.params['fixed_stop_loss_pct'] * 100,
                'error': str(e),
                'timestamp': datetime.now()
            }

    def _calculate_fixed_stop_loss(self, entry_price: float, is_long: bool) -> float:
        """
        计算固定止损价格

        参数:
            entry_price: 入场价格
            is_long: 是否做多

        返回:
            止损价格
        """
        try:
            # 获取固定止损百分比
            stop_loss_pct = self.params['fixed_stop_loss_pct']

            # 计算止损价格
            if is_long:
                stop_loss_price = entry_price * (1 - stop_loss_pct)
            else:
                stop_loss_price = entry_price * (1 + stop_loss_pct)

            return stop_loss_price

        except Exception as e:
            logger.error(f"计算固定止损价格失败: {e}")

            # 返回默认止损价格
            if is_long:
                return entry_price * 0.98  # 默认2%止损
            else:
                return entry_price * 1.02

    def _calculate_trailing_stop_loss(self, symbol: str, entry_price: float,
                                    current_price: float, is_long: bool) -> float:
        """
        计算追踪止损价格

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            current_price: 当前价格
            is_long: 是否做多

        返回:
            止损价格
        """
        try:
            # 如果不使用追踪止损，返回无效价格
            if not self.params['use_trailing_stop']:
                return 0.0

            # 获取追踪止损参数
            activation_pct = self.params['trailing_stop_activation_pct']
            distance_pct = self.params['trailing_stop_distance_pct']

            # 计算激活价格
            if is_long:
                activation_price = entry_price * (1 + activation_pct)
            else:
                activation_price = entry_price * (1 - activation_pct)

            # 检查是否已激活
            if (is_long and current_price >= activation_price) or (not is_long and current_price <= activation_price):
                # 已激活，计算追踪止损价格
                if is_long:
                    stop_loss_price = current_price * (1 - distance_pct)
                else:
                    stop_loss_price = current_price * (1 + distance_pct)

                # 获取之前的追踪止损价格
                prev_stop = self.stop_loss_state.get(symbol, {}).get('trailing_stop', 0.0)

                # 更新追踪止损价格（只有更好的止损才更新）
                if prev_stop > 0:
                    if is_long:
                        stop_loss_price = max(stop_loss_price, prev_stop)
                    else:
                        stop_loss_price = min(stop_loss_price, prev_stop) if prev_stop > 0 else stop_loss_price

                return stop_loss_price
            else:
                # 未激活，返回固定止损价格
                return self._calculate_fixed_stop_loss(entry_price, is_long)

        except Exception as e:
            logger.error(f"计算追踪止损价格失败: {e}")
            return self._calculate_fixed_stop_loss(entry_price, is_long)

    def _calculate_volatility_stop_loss(self, entry_price: float, is_long: bool,
                                      data: Optional[pd.DataFrame]) -> float:
        """
        计算波动率止损价格

        参数:
            entry_price: 入场价格
            is_long: 是否做多
            data: OHLCV数据

        返回:
            止损价格
        """
        try:
            # 如果不使用波动率止损或没有数据，返回固定止损价格
            if not self.params['use_volatility_stop'] or data is None or data.empty:
                return self._calculate_fixed_stop_loss(entry_price, is_long)

            # 计算波动率
            volatility = self.volatility_analyzer.analyze_volatility(
                data, short_window=self.params['volatility_lookback'])

            # 获取ATR值
            atr = volatility.get('atr', 0)

            # 如果ATR为0，返回固定止损价格
            if atr <= 0:
                return self._calculate_fixed_stop_loss(entry_price, is_long)

            # 计算波动率止损距离
            stop_distance = atr * self.params['volatility_multiplier']

            # 计算止损百分比
            stop_loss_pct = stop_distance / entry_price

            # 限制止损百分比范围
            stop_loss_pct = max(self.params['min_volatility_stop_pct'],
                              min(stop_loss_pct, self.params['max_volatility_stop_pct']))

            # 计算止损价格
            if is_long:
                stop_loss_price = entry_price * (1 - stop_loss_pct)
            else:
                stop_loss_price = entry_price * (1 + stop_loss_pct)

            return stop_loss_price

        except Exception as e:
            logger.error(f"计算波动率止损价格失败: {e}")
            return self._calculate_fixed_stop_loss(entry_price, is_long)

    def _calculate_breakeven_stop_loss(self, entry_price: float, current_price: float,
                                     is_long: bool) -> float:
        """
        计算保本止损价格

        参数:
            entry_price: 入场价格
            current_price: 当前价格
            is_long: 是否做多

        返回:
            止损价格
        """
        try:
            # 如果不使用保本止损，返回无效价格
            if not self.params['use_breakeven_stop']:
                return 0.0

            # 获取保本止损参数
            activation_pct = self.params['breakeven_activation_pct']
            buffer_pct = self.params['breakeven_buffer_pct']

            # 计算激活价格
            if is_long:
                activation_price = entry_price * (1 + activation_pct)
            else:
                activation_price = entry_price * (1 - activation_pct)

            # 检查是否已激活
            if (is_long and current_price >= activation_price) or (not is_long and current_price <= activation_price):
                # 已激活，计算保本止损价格
                if is_long:
                    stop_loss_price = entry_price * (1 + buffer_pct)
                else:
                    stop_loss_price = entry_price * (1 - buffer_pct)

                return stop_loss_price
            else:
                # 未激活，返回无效价格
                return 0.0

        except Exception as e:
            logger.error(f"计算保本止损价格失败: {e}")
            return 0.0

    def _select_best_stop_loss(self, fixed_stop: float, trailing_stop: float,
                             volatility_stop: float, breakeven_stop: float,
                             entry_price: float, current_price: float,
                             is_long: bool) -> Tuple[float, StopLossType]:
        """
        选择最佳止损价格

        参数:
            fixed_stop: 固定止损价格
            trailing_stop: 追踪止损价格
            volatility_stop: 波动率止损价格
            breakeven_stop: 保本止损价格
            entry_price: 入场价格
            current_price: 当前价格
            is_long: 是否做多

        返回:
            (止损价格, 止损类型)
        """
        try:
            # 初始化最佳止损
            best_stop = fixed_stop
            best_type = StopLossType.FIXED

            # 检查追踪止损
            if trailing_stop > 0:
                if is_long:
                    if trailing_stop > best_stop:
                        best_stop = trailing_stop
                        best_type = StopLossType.TRAILING
                else:
                    if trailing_stop < best_stop and trailing_stop > 0:
                        best_stop = trailing_stop
                        best_type = StopLossType.TRAILING

            # 检查波动率止损
            if volatility_stop > 0:
                if is_long:
                    if volatility_stop > best_stop:
                        best_stop = volatility_stop
                        best_type = StopLossType.VOLATILITY
                else:
                    if volatility_stop < best_stop and volatility_stop > 0:
                        best_stop = volatility_stop
                        best_type = StopLossType.VOLATILITY

            # 检查保本止损
            if breakeven_stop > 0:
                if is_long:
                    if breakeven_stop > best_stop:
                        best_stop = breakeven_stop
                        best_type = StopLossType.BREAKEVEN
                else:
                    if breakeven_stop < best_stop and breakeven_stop > 0:
                        best_stop = breakeven_stop
                        best_type = StopLossType.BREAKEVEN

            return best_stop, best_type

        except Exception as e:
            logger.error(f"选择最佳止损价格失败: {e}")
            return fixed_stop, StopLossType.FIXED

    def _update_stop_loss_state(self, symbol: str, stop_loss_type: StopLossType,
                              stop_loss_price: float, entry_price: float,
                              current_price: float, is_long: bool) -> None:
        """
        更新止损状态

        参数:
            symbol: 交易对符号
            stop_loss_type: 止损类型
            stop_loss_price: 止损价格
            entry_price: 入场价格
            current_price: 当前价格
            is_long: 是否做多
        """
        try:
            # 如果符号不在状态字典中，初始化
            if symbol not in self.stop_loss_state:
                self.stop_loss_state[symbol] = {
                    'type': stop_loss_type,
                    'price': stop_loss_price,
                    'entry_price': entry_price,
                    'is_long': is_long,
                    'trailing_stop': 0.0,
                    'breakeven_stop': 0.0,
                    'partial_stops': [],
                    'tiered_stops': [],
                    'last_update': datetime.now()
                }
            else:
                # 更新状态
                state = self.stop_loss_state[symbol]

                # 更新止损类型和价格
                state['type'] = stop_loss_type
                state['price'] = stop_loss_price

                # 更新追踪止损价格
                if stop_loss_type == StopLossType.TRAILING:
                    state['trailing_stop'] = stop_loss_price

                # 更新保本止损价格
                if stop_loss_type == StopLossType.BREAKEVEN:
                    state['breakeven_stop'] = stop_loss_price

                # 更新最后更新时间
                state['last_update'] = datetime.now()

        except Exception as e:
            logger.error(f"更新止损状态失败: {e}")

    def calculate_partial_stops(self, symbol: str, entry_price: float,
                              position_size: float, is_long: bool) -> List[Dict[str, Any]]:
        """
        计算部分止损

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            position_size: 仓位大小
            is_long: 是否做多

        返回:
            部分止损列表
        """
        try:
            # 如果不使用部分止损，返回空列表
            if not self.params['use_partial_stop']:
                return []

            # 获取部分止损参数
            levels = self.params['partial_stop_levels']
            percentages = self.params['partial_stop_percentages']

            # 确保参数长度一致
            min_len = min(len(levels), len(percentages))
            levels = levels[:min_len]
            percentages = percentages[:min_len]

            # 计算部分止损
            partial_stops = []

            for i, (level, percentage) in enumerate(zip(levels, percentages)):
                # 计算止损价格
                if is_long:
                    stop_price = entry_price * (1 - level)
                else:
                    stop_price = entry_price * (1 + level)

                # 计算止损数量
                stop_size = position_size * percentage

                # 添加到列表
                partial_stops.append({
                    'level': i + 1,
                    'price': stop_price,
                    'size': stop_size,
                    'percentage': percentage,
                    'status': 'PENDING'
                })

            # 更新状态
            if symbol in self.stop_loss_state:
                self.stop_loss_state[symbol]['partial_stops'] = partial_stops

            return partial_stops

        except Exception as e:
            logger.error(f"计算部分止损失败: {e}")
            return []

    def calculate_tiered_stops(self, symbol: str, entry_price: float,
                             is_long: bool) -> List[Dict[str, Any]]:
        """
        计算分层止损

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            is_long: 是否做多

        返回:
            分层止损列表
        """
        try:
            # 如果不使用分层止损，返回空列表
            if not self.params['use_tiered_stop']:
                return []

            # 获取分层止损参数
            levels = self.params['tiered_stop_levels']

            # 计算分层止损
            tiered_stops = []

            for i, level in enumerate(levels):
                # 计算止损价格
                if is_long:
                    stop_price = entry_price * (1 - level)
                else:
                    stop_price = entry_price * (1 + level)

                # 添加到列表
                tiered_stops.append({
                    'level': i + 1,
                    'price': stop_price,
                    'status': 'PENDING'
                })

            # 更新状态
            if symbol in self.stop_loss_state:
                self.stop_loss_state[symbol]['tiered_stops'] = tiered_stops

            return tiered_stops

        except Exception as e:
            logger.error(f"计算分层止损失败: {e}")
            return []

    def check_stop_loss_triggered(self, symbol: str, current_price: float) -> bool:
        """
        检查止损是否触发

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            是否触发
        """
        try:
            # 如果符号不在状态字典中，返回False
            if symbol not in self.stop_loss_state:
                return False

            # 获取止损状态
            state = self.stop_loss_state[symbol]

            # 获取止损价格和方向
            stop_price = state['price']
            is_long = state['is_long']

            # 检查是否触发
            if is_long:
                return current_price <= stop_price
            else:
                return current_price >= stop_price

        except Exception as e:
            logger.error(f"检查止损触发失败: {e}")
            return False

    def check_partial_stops_triggered(self, symbol: str, current_price: float) -> List[Dict[str, Any]]:
        """
        检查部分止损是否触发

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            触发的部分止损列表
        """
        try:
            # 如果符号不在状态字典中，返回空列表
            if symbol not in self.stop_loss_state:
                return []

            # 获取止损状态
            state = self.stop_loss_state[symbol]

            # 获取部分止损列表和方向
            partial_stops = state.get('partial_stops', [])
            is_long = state['is_long']

            # 检查是否触发
            triggered_stops = []

            for stop in partial_stops:
                if stop['status'] == 'PENDING':
                    if is_long:
                        if current_price <= stop['price']:
                            stop['status'] = 'TRIGGERED'
                            triggered_stops.append(stop)
                    else:
                        if current_price >= stop['price']:
                            stop['status'] = 'TRIGGERED'
                            triggered_stops.append(stop)

            return triggered_stops

        except Exception as e:
            logger.error(f"检查部分止损触发失败: {e}")
            return []

    def check_tiered_stops_triggered(self, symbol: str, current_price: float) -> List[Dict[str, Any]]:
        """
        检查分层止损是否触发

        参数:
            symbol: 交易对符号
            current_price: 当前价格

        返回:
            触发的分层止损列表
        """
        try:
            # 如果符号不在状态字典中，返回空列表
            if symbol not in self.stop_loss_state:
                return []

            # 获取止损状态
            state = self.stop_loss_state[symbol]

            # 获取分层止损列表和方向
            tiered_stops = state.get('tiered_stops', [])
            is_long = state['is_long']

            # 检查是否触发
            triggered_stops = []

            for stop in tiered_stops:
                if stop['status'] == 'PENDING':
                    if is_long:
                        if current_price <= stop['price']:
                            stop['status'] = 'TRIGGERED'
                            triggered_stops.append(stop)
                    else:
                        if current_price >= stop['price']:
                            stop['status'] = 'TRIGGERED'
                            triggered_stops.append(stop)

            return triggered_stops

        except Exception as e:
            logger.error(f"检查分层止损触发失败: {e}")
            return []

    def get_stop_loss_state(self, symbol: str) -> Dict[str, Any]:
        """
        获取止损状态

        参数:
            symbol: 交易对符号

        返回:
            止损状态
        """
        return self.stop_loss_state.get(symbol, {})

    def get_all_stop_loss_states(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有止损状态

        返回:
            所有止损状态
        """
        return self.stop_loss_state

    def reset_stop_loss(self, symbol: str) -> None:
        """
        重置止损状态

        参数:
            symbol: 交易对符号
        """
        if symbol in self.stop_loss_state:
            del self.stop_loss_state[symbol]

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置止损参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取止损参数

        返回:
            参数字典
        """
        return self.params.copy()
