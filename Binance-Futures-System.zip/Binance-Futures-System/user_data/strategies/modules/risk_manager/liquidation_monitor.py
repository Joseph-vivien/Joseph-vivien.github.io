#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
爆仓监控器

该模块负责监控期货交易中的保证金水平，防止爆仓并在必要时执行强制平仓。

作者: 高级Python工程师
日期: 2024-05-23
"""

import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from enum import Enum
import pandas as pd

from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("liquidation_monitor")

class MarginLevel(Enum):
    """保证金水平枚举"""
    SAFE = "安全"           # 保证金率 > 300%
    WARNING = "警告"       # 保证金率 200-300%
    DANGER = "危险"        # 保证金率 120-200%
    CRITICAL = "临界"      # 保证金率 110-120%
    LIQUIDATION = "爆仓"   # 保证金率 <= 110%

class LiquidationMonitor:
    """
    爆仓监控器
    
    负责监控保证金水平，预警和执行强制平仓
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化爆仓监控器
        
        参数:
            config: 配置参数
        """
        self.config = config or {}
        
        # 保证金水平阈值
        self.margin_thresholds = {
            'safe_level': 3.0,        # 300% - 安全水平
            'warning_level': 2.0,     # 200% - 警告水平
            'danger_level': 1.2,      # 120% - 危险水平
            'critical_level': 1.1,    # 110% - 临界水平
            'liquidation_level': 1.0  # 100% - 爆仓水平
        }
        
        # 监控参数
        self.monitor_params = {
            'check_interval': 1,      # 检查间隔（秒）
            'alert_cooldown': 30,     # 警报冷却时间（秒）
            'force_close_enabled': True,  # 是否启用强制平仓
            'emergency_close_pct': 0.95,  # 紧急平仓百分比
        }
        
        # 状态跟踪
        self.last_alert_time = {}
        self.margin_history = []
        self.liquidation_events = []
        self.position_info = {}
        
        logger.info("爆仓监控器初始化完成")
        
    def update_position_info(self, symbol: str, position_data: Dict[str, Any]):
        """
        更新持仓信息
        
        参数:
            symbol: 交易对符号
            position_data: 持仓数据
        """
        self.position_info[symbol] = {
            'size': position_data.get('size', 0.0),
            'entry_price': position_data.get('entry_price', 0.0),
            'current_price': position_data.get('current_price', 0.0),
            'margin_used': position_data.get('margin_used', 0.0),
            'unrealized_pnl': position_data.get('unrealized_pnl', 0.0),
            'leverage': position_data.get('leverage', 1.0),
            'timestamp': datetime.now()
        }
        
    def calculate_margin_ratio(self, account_balance: float, total_margin_used: float, 
                             unrealized_pnl: float) -> float:
        """
        计算保证金比率
        
        参数:
            account_balance: 账户余额
            total_margin_used: 总占用保证金
            unrealized_pnl: 未实现盈亏
            
        返回:
            保证金比率
        """
        try:
            # 计算净值
            equity = account_balance + unrealized_pnl
            
            # 计算保证金比率
            if total_margin_used <= 0:
                return float('inf')  # 无持仓时保证金比率为无穷大
                
            margin_ratio = equity / total_margin_used
            
            return max(0.0, margin_ratio)  # 确保不为负数
            
        except Exception as e:
            logger.error(f"计算保证金比率失败: {e}")
            return 0.0
            
    def get_margin_level(self, margin_ratio: float) -> MarginLevel:
        """
        获取保证金水平
        
        参数:
            margin_ratio: 保证金比率
            
        返回:
            保证金水平
        """
        if margin_ratio >= self.margin_thresholds['safe_level']:
            return MarginLevel.SAFE
        elif margin_ratio >= self.margin_thresholds['warning_level']:
            return MarginLevel.WARNING
        elif margin_ratio >= self.margin_thresholds['danger_level']:
            return MarginLevel.DANGER
        elif margin_ratio >= self.margin_thresholds['critical_level']:
            return MarginLevel.CRITICAL
        else:
            return MarginLevel.LIQUIDATION
            
    def check_liquidation_risk(self, account_balance: float, positions: Dict[str, Dict]) -> Dict[str, Any]:
        """
        检查爆仓风险
        
        参数:
            account_balance: 账户余额
            positions: 持仓信息字典
            
        返回:
            风险检查结果
        """
        try:
            # 计算总保证金和未实现盈亏
            total_margin_used = 0.0
            total_unrealized_pnl = 0.0
            
            for symbol, pos in positions.items():
                if pos.get('size', 0) != 0:  # 有持仓
                    margin = abs(pos.get('size', 0)) * pos.get('current_price', 0) / pos.get('leverage', 1)
                    total_margin_used += margin
                    total_unrealized_pnl += pos.get('unrealized_pnl', 0)
            
            # 计算保证金比率
            margin_ratio = self.calculate_margin_ratio(account_balance, total_margin_used, total_unrealized_pnl)
            
            # 获取保证金水平
            margin_level = self.get_margin_level(margin_ratio)
            
            # 记录历史
            self.margin_history.append({
                'timestamp': datetime.now(),
                'margin_ratio': margin_ratio,
                'margin_level': margin_level.value,
                'account_balance': account_balance,
                'total_margin_used': total_margin_used,
                'total_unrealized_pnl': total_unrealized_pnl
            })
            
            # 保持历史记录长度
            if len(self.margin_history) > 1000:
                self.margin_history = self.margin_history[-500:]
            
            # 构建结果
            result = {
                'margin_ratio': margin_ratio,
                'margin_level': margin_level,
                'account_balance': account_balance,
                'total_margin_used': total_margin_used,
                'total_unrealized_pnl': total_unrealized_pnl,
                'equity': account_balance + total_unrealized_pnl,
                'requires_action': margin_level in [MarginLevel.CRITICAL, MarginLevel.LIQUIDATION],
                'force_liquidation': margin_level == MarginLevel.LIQUIDATION,
                'positions_at_risk': []
            }
            
            # 识别风险持仓
            if margin_level in [MarginLevel.DANGER, MarginLevel.CRITICAL, MarginLevel.LIQUIDATION]:
                for symbol, pos in positions.items():
                    if pos.get('size', 0) != 0 and pos.get('unrealized_pnl', 0) < 0:
                        result['positions_at_risk'].append({
                            'symbol': symbol,
                            'size': pos.get('size', 0),
                            'unrealized_pnl': pos.get('unrealized_pnl', 0),
                            'loss_pct': pos.get('unrealized_pnl', 0) / (abs(pos.get('size', 0)) * pos.get('entry_price', 1)) * 100
                        })
            
            return result
            
        except Exception as e:
            logger.error(f"检查爆仓风险失败: {e}")
            return {
                'margin_ratio': 0.0,
                'margin_level': MarginLevel.LIQUIDATION,
                'requires_action': True,
                'force_liquidation': True,
                'error': str(e)
            }
            
    def should_send_alert(self, margin_level: MarginLevel) -> bool:
        """
        判断是否应该发送警报
        
        参数:
            margin_level: 保证金水平
            
        返回:
            是否发送警报
        """
        if margin_level in [MarginLevel.SAFE]:
            return False
            
        # 检查冷却时间
        now = time.time()
        last_alert = self.last_alert_time.get(margin_level.value, 0)
        
        if now - last_alert < self.monitor_params['alert_cooldown']:
            return False
            
        self.last_alert_time[margin_level.value] = now
        return True
        
    def generate_liquidation_plan(self, positions: Dict[str, Dict], target_margin_ratio: float = 2.0) -> List[Dict]:
        """
        生成平仓计划
        
        参数:
            positions: 持仓信息
            target_margin_ratio: 目标保证金比率
            
        返回:
            平仓计划列表
        """
        liquidation_plan = []
        
        try:
            # 按亏损程度排序持仓
            losing_positions = []
            for symbol, pos in positions.items():
                if pos.get('size', 0) != 0 and pos.get('unrealized_pnl', 0) < 0:
                    loss_pct = pos.get('unrealized_pnl', 0) / (abs(pos.get('size', 0)) * pos.get('entry_price', 1)) * 100
                    losing_positions.append({
                        'symbol': symbol,
                        'position': pos,
                        'loss_pct': loss_pct
                    })
            
            # 按亏损百分比排序（亏损最大的优先平仓）
            losing_positions.sort(key=lambda x: x['loss_pct'])
            
            # 生成平仓计划
            for pos_info in losing_positions:
                symbol = pos_info['symbol']
                position = pos_info['position']
                
                # 计算平仓比例
                if pos_info['loss_pct'] < -10:  # 亏损超过10%，全部平仓
                    close_ratio = 1.0
                elif pos_info['loss_pct'] < -5:   # 亏损5-10%，平仓80%
                    close_ratio = 0.8
                else:  # 亏损小于5%，平仓50%
                    close_ratio = 0.5
                
                liquidation_plan.append({
                    'symbol': symbol,
                    'action': 'close',
                    'size': position.get('size', 0),
                    'close_ratio': close_ratio,
                    'close_size': position.get('size', 0) * close_ratio,
                    'reason': f'亏损{pos_info["loss_pct"]:.2f}%',
                    'priority': abs(pos_info['loss_pct'])  # 亏损越大优先级越高
                })
            
            # 按优先级排序
            liquidation_plan.sort(key=lambda x: x['priority'], reverse=True)
            
            return liquidation_plan
            
        except Exception as e:
            logger.error(f"生成平仓计划失败: {e}")
            return []
            
    def log_liquidation_event(self, event_type: str, details: Dict[str, Any]):
        """
        记录爆仓事件
        
        参数:
            event_type: 事件类型
            details: 事件详情
        """
        event = {
            'timestamp': datetime.now(),
            'type': event_type,
            'details': details
        }
        
        self.liquidation_events.append(event)
        
        # 保持事件记录长度
        if len(self.liquidation_events) > 100:
            self.liquidation_events = self.liquidation_events[-50:]
            
        logger.warning(f"爆仓事件: {event_type} - {details}")
        
    def get_margin_history(self, hours: int = 24) -> List[Dict]:
        """
        获取保证金历史记录
        
        参数:
            hours: 获取最近几小时的记录
            
        返回:
            历史记录列表
        """
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        return [
            record for record in self.margin_history
            if record['timestamp'] >= cutoff_time
        ]
        
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取监控统计信息
        
        返回:
            统计信息字典
        """
        if not self.margin_history:
            return {}
            
        recent_history = self.get_margin_history(24)
        
        if not recent_history:
            return {}
            
        margin_ratios = [r['margin_ratio'] for r in recent_history if r['margin_ratio'] != float('inf')]
        
        if not margin_ratios:
            return {}
            
        return {
            'current_margin_ratio': self.margin_history[-1]['margin_ratio'] if self.margin_history else 0,
            'min_margin_ratio_24h': min(margin_ratios),
            'max_margin_ratio_24h': max(margin_ratios),
            'avg_margin_ratio_24h': sum(margin_ratios) / len(margin_ratios),
            'liquidation_events_24h': len([e for e in self.liquidation_events 
                                         if e['timestamp'] >= datetime.now() - timedelta(hours=24)]),
            'total_checks': len(self.margin_history),
            'last_check_time': self.margin_history[-1]['timestamp'] if self.margin_history else None
        }
