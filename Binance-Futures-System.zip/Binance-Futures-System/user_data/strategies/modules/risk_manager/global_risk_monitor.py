#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
全局风险监控模块

该模块负责监控整个交易系统的风险状况，包括账户风险、市场风险和系统风险。
提供全局风险评估和风险预警功能。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from datetime import datetime, timedelta
import threading
import time

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.risk_manager import RiskLevel

# 获取日志记录器
logger = get_logger("global_risk_monitor")

class SystemRiskLevel(Enum):
    """系统风险级别枚举"""
    NORMAL = "正常"
    ELEVATED = "风险升高"
    HIGH = "高风险"
    EXTREME = "极端风险"
    EMERGENCY = "紧急风险"

class RiskSource(Enum):
    """风险来源枚举"""
    ACCOUNT = "账户风险"
    MARKET = "市场风险"
    POSITION = "仓位风险"
    LIQUIDITY = "流动性风险"
    TECHNICAL = "技术风险"
    REGULATORY = "监管风险"

class RiskAlert:
    """风险警报类"""

    def __init__(self, level: SystemRiskLevel, source: RiskSource,
                message: str, timestamp: datetime = None):
        """
        初始化风险警报

        参数:
            level: 风险级别
            source: 风险来源
            message: 警报消息
            timestamp: 时间戳
        """
        self.level = level
        self.source = source
        self.message = message
        self.timestamp = timestamp or datetime.now()
        self.acknowledged = False
        self.resolved = False
        self.resolution_time = None
        self.resolution_message = ""

    def acknowledge(self) -> None:
        """确认警报"""
        self.acknowledged = True

    def resolve(self, message: str = "") -> None:
        """
        解决警报

        参数:
            message: 解决方案消息
        """
        self.resolved = True
        self.resolution_time = datetime.now()
        self.resolution_message = message

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典

        返回:
            警报字典
        """
        return {
            'level': self.level.value,
            'source': self.source.value,
            'message': self.message,
            'timestamp': self.timestamp.isoformat(),
            'acknowledged': self.acknowledged,
            'resolved': self.resolved,
            'resolution_time': self.resolution_time.isoformat() if self.resolution_time else None,
            'resolution_message': self.resolution_message
        }

class GlobalRiskMonitor:
    """
    全局风险监控类

    负责监控整个交易系统的风险状况，提供风险评估和预警功能
    """

    def __init__(self):
        """初始化全局风险监控器"""
        # 加载配置
        self.config_manager = get_config_manager()

        # 设置默认参数
        self.params = {
            # 风险监控参数
            'monitor_interval': 60,  # 风险监控间隔（秒）
            'risk_history_length': 100,  # 风险历史记录长度
            'alert_history_length': 100,  # 警报历史记录长度

            # 账户风险参数
            'max_account_drawdown': 0.15,  # 最大账户回撤（15%）
            'max_daily_loss': 0.05,  # 最大日亏损（5%）
            'min_margin_level': 2.0,  # 最小保证金水平（200%）

            # 市场风险参数
            'max_volatility': 0.05,  # 最大波动率（5%）
            'max_correlation': 0.8,  # 最大相关性（80%）
            'max_spread': 0.005,  # 最大价差（0.5%）

            # 仓位风险参数
            'max_position_size': 0.2,  # 最大仓位规模（账户的20%）
            'max_leverage': 10.0,  # 最大杠杆倍数
            'max_positions': 10,  # 最大持仓数量

            # 流动性风险参数
            'min_daily_volume': 1000000,  # 最小日交易量（USDT）
            'max_slippage': 0.002,  # 最大滑点（0.2%）

            # 技术风险参数
            'max_api_errors': 5,  # 最大API错误次数
            'max_execution_delay': 2.0,  # 最大执行延迟（秒）

            # 警报参数
            'enable_email_alerts': False,  # 是否启用邮件警报
            'enable_sms_alerts': False,  # 是否启用短信警报
            'email_recipients': [],  # 邮件接收人
            'sms_recipients': [],  # 短信接收人
        }

        # 风险状态
        self.risk_state = {
            'system_risk_level': SystemRiskLevel.NORMAL,
            'account_risk_level': RiskLevel.LOW,
            'market_risk_level': RiskLevel.LOW,
            'position_risk_level': RiskLevel.LOW,
            'liquidity_risk_level': RiskLevel.LOW,
            'technical_risk_level': RiskLevel.LOW,
            'last_update': datetime.now()
        }

        # 风险历史
        self.risk_history = []

        # 警报列表
        self.active_alerts = []
        self.alert_history = []

        # 账户信息
        self.account_info = {
            'balance': 0.0,
            'equity': 0.0,
            'margin': 0.0,
            'free_margin': 0.0,
            'margin_level': 0.0,
            'unrealized_pnl': 0.0,
            'daily_pnl': 0.0,
            'positions': {}
        }

        # 市场信息
        self.market_info = {
            'volatility': {},
            'correlation': {},
            'spreads': {},
            'volumes': {}
        }

        # 监控线程
        self.monitor_thread = None
        self.monitoring_active = False

    def start_monitoring(self) -> None:
        """启动风险监控"""
        if self.monitor_thread is None or not self.monitor_thread.is_alive():
            self.monitoring_active = True
            self.monitor_thread = threading.Thread(target=self._risk_monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            logger.info("已启动全局风险监控")

    def stop_monitoring(self) -> None:
        """停止风险监控"""
        self.monitoring_active = False
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=5)
            logger.info("已停止全局风险监控")

    def _risk_monitor_loop(self) -> None:
        """风险监控循环"""
        while self.monitoring_active:
            try:
                # 评估风险
                self.assess_risk()

                # 检查风险阈值
                self.check_risk_thresholds()

                # 更新风险历史
                self._update_risk_history()

            except Exception as e:
                logger.error(f"风险监控异常: {e}")

            # 等待下一次监控
            time.sleep(self.params['monitor_interval'])

    def assess_risk(self) -> Dict[str, Any]:
        """
        评估系统风险

        返回:
            风险评估结果
        """
        try:
            # 评估账户风险
            account_risk = self._assess_account_risk()

            # 评估市场风险
            market_risk = self._assess_market_risk()

            # 评估仓位风险
            position_risk = self._assess_position_risk()

            # 评估流动性风险
            liquidity_risk = self._assess_liquidity_risk()

            # 评估技术风险
            technical_risk = self._assess_technical_risk()

            # 确定系统风险级别
            system_risk = self._determine_system_risk(
                account_risk, market_risk, position_risk, liquidity_risk, technical_risk)

            # 更新风险状态
            self.risk_state = {
                'system_risk_level': system_risk,
                'account_risk_level': account_risk,
                'market_risk_level': market_risk,
                'position_risk_level': position_risk,
                'liquidity_risk_level': liquidity_risk,
                'technical_risk_level': technical_risk,
                'last_update': datetime.now()
            }

            return self.risk_state

        except Exception as e:
            logger.error(f"评估风险失败: {e}")
            return self.risk_state

    def _assess_account_risk(self) -> RiskLevel:
        """
        评估账户风险

        返回:
            风险级别
        """
        try:
            # 获取账户信息
            balance = self.account_info['balance']
            equity = self.account_info['equity']
            margin = self.account_info['margin']
            daily_pnl = self.account_info['daily_pnl']

            if balance <= 0:
                return RiskLevel.EXTREME

            # 计算风险指标
            drawdown = (balance - equity) / balance if balance > 0 else 0
            daily_loss_pct = -daily_pnl / balance if balance > 0 else 0
            margin_level = equity / margin if margin > 0 else float('inf')

            # 确定风险级别
            if (drawdown > self.params['max_account_drawdown'] or
                daily_loss_pct > self.params['max_daily_loss'] or
                margin_level < self.params['min_margin_level']):
                return RiskLevel.EXTREME
            elif (drawdown > self.params['max_account_drawdown'] * 0.7 or
                 daily_loss_pct > self.params['max_daily_loss'] * 0.7 or
                 margin_level < self.params['min_margin_level'] * 1.3):
                return RiskLevel.HIGH
            elif (drawdown > self.params['max_account_drawdown'] * 0.5 or
                 daily_loss_pct > self.params['max_daily_loss'] * 0.5 or
                 margin_level < self.params['min_margin_level'] * 1.5):
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估账户风险失败: {e}")
            return RiskLevel.HIGH

    def _assess_market_risk(self) -> RiskLevel:
        """
        评估市场风险

        返回:
            风险级别
        """
        try:
            # 获取市场信息
            volatility = self.market_info['volatility']
            correlation = self.market_info['correlation']
            spreads = self.market_info['spreads']

            # 计算平均波动率
            avg_volatility = sum(volatility.values()) / max(len(volatility), 1)

            # 计算平均相关性
            avg_correlation = sum(correlation.values()) / max(len(correlation), 1) if correlation else 0

            # 计算平均价差
            avg_spread = sum(spreads.values()) / max(len(spreads), 1) if spreads else 0

            # 确定风险级别
            if (avg_volatility > self.params['max_volatility'] or
                avg_correlation > self.params['max_correlation'] or
                avg_spread > self.params['max_spread']):
                return RiskLevel.EXTREME
            elif (avg_volatility > self.params['max_volatility'] * 0.7 or
                 avg_correlation > self.params['max_correlation'] * 0.7 or
                 avg_spread > self.params['max_spread'] * 0.7):
                return RiskLevel.HIGH
            elif (avg_volatility > self.params['max_volatility'] * 0.5 or
                 avg_correlation > self.params['max_correlation'] * 0.5 or
                 avg_spread > self.params['max_spread'] * 0.5):
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估市场风险失败: {e}")
            return RiskLevel.MEDIUM

    def _assess_position_risk(self) -> RiskLevel:
        """
        评估仓位风险

        返回:
            风险级别
        """
        try:
            # 获取仓位信息
            positions = self.account_info['positions']
            balance = self.account_info['balance']

            if not positions:
                return RiskLevel.LOW

            # 计算风险指标
            total_position_value = sum(p.get('value', 0) for p in positions.values())
            position_ratio = total_position_value / balance if balance > 0 else 0
            max_position_value = max((p.get('value', 0) for p in positions.values()), default=0)
            max_position_ratio = max_position_value / balance if balance > 0 else 0
            max_leverage = max((p.get('leverage', 1) for p in positions.values()), default=1)

            # 确定风险级别
            if (position_ratio > self.params['max_position_size'] or
                max_position_ratio > self.params['max_position_size'] * 0.5 or
                max_leverage > self.params['max_leverage'] or
                len(positions) > self.params['max_positions']):
                return RiskLevel.EXTREME
            elif (position_ratio > self.params['max_position_size'] * 0.7 or
                 max_position_ratio > self.params['max_position_size'] * 0.35 or
                 max_leverage > self.params['max_leverage'] * 0.7 or
                 len(positions) > self.params['max_positions'] * 0.7):
                return RiskLevel.HIGH
            elif (position_ratio > self.params['max_position_size'] * 0.5 or
                 max_position_ratio > self.params['max_position_size'] * 0.25 or
                 max_leverage > self.params['max_leverage'] * 0.5 or
                 len(positions) > self.params['max_positions'] * 0.5):
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估仓位风险失败: {e}")
            return RiskLevel.MEDIUM

    def _assess_liquidity_risk(self) -> RiskLevel:
        """
        评估流动性风险

        返回:
            风险级别
        """
        try:
            # 获取流动性信息
            volumes = self.market_info['volumes']
            spreads = self.market_info['spreads']
            positions = self.account_info['positions']

            if not positions:
                return RiskLevel.LOW

            # 计算风险指标
            liquidity_risk_scores = []

            for symbol, position in positions.items():
                # 获取交易量
                volume = volumes.get(symbol, 0)

                # 获取价差
                spread = spreads.get(symbol, 0)

                # 计算仓位价值
                position_value = position.get('value', 0)

                # 计算流动性风险分数
                if volume > 0:
                    volume_risk = min(1.0, position_value / volume)
                else:
                    volume_risk = 1.0

                spread_risk = min(1.0, spread / self.params['max_slippage'])

                # 综合风险分数
                risk_score = (volume_risk * 0.7) + (spread_risk * 0.3)
                liquidity_risk_scores.append(risk_score)

            # 计算平均风险分数
            avg_risk_score = sum(liquidity_risk_scores) / max(len(liquidity_risk_scores), 1)

            # 确定风险级别
            if avg_risk_score > 0.8:
                return RiskLevel.EXTREME
            elif avg_risk_score > 0.6:
                return RiskLevel.HIGH
            elif avg_risk_score > 0.4:
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估流动性风险失败: {e}")
            return RiskLevel.MEDIUM

    def _assess_technical_risk(self) -> RiskLevel:
        """
        评估技术风险

        返回:
            风险级别
        """
        try:
            # 这里应该从系统中获取技术指标
            # 例如API错误次数、执行延迟等
            # 这里使用模拟数据
            api_errors = 0
            execution_delay = 0.5

            # 确定风险级别
            if (api_errors > self.params['max_api_errors'] or
                execution_delay > self.params['max_execution_delay']):
                return RiskLevel.EXTREME
            elif (api_errors > self.params['max_api_errors'] * 0.7 or
                 execution_delay > self.params['max_execution_delay'] * 0.7):
                return RiskLevel.HIGH
            elif (api_errors > self.params['max_api_errors'] * 0.5 or
                 execution_delay > self.params['max_execution_delay'] * 0.5):
                return RiskLevel.MEDIUM
            else:
                return RiskLevel.LOW

        except Exception as e:
            logger.error(f"评估技术风险失败: {e}")
            return RiskLevel.MEDIUM

    def _determine_system_risk(self, account_risk: RiskLevel, market_risk: RiskLevel,
                             position_risk: RiskLevel, liquidity_risk: RiskLevel,
                             technical_risk: RiskLevel) -> SystemRiskLevel:
        """
        确定系统风险级别

        参数:
            account_risk: 账户风险级别
            market_risk: 市场风险级别
            position_risk: 仓位风险级别
            liquidity_risk: 流动性风险级别
            technical_risk: 技术风险级别

        返回:
            系统风险级别
        """
        try:
            # 将风险级别转换为数值
            risk_values = {
                RiskLevel.LOW: 1,
                RiskLevel.MEDIUM: 2,
                RiskLevel.HIGH: 3,
                RiskLevel.EXTREME: 4
            }

            # 计算风险值
            account_value = risk_values[account_risk]
            market_value = risk_values[market_risk]
            position_value = risk_values[position_risk]
            liquidity_value = risk_values[liquidity_risk]
            technical_value = risk_values[technical_risk]

            # 计算加权风险值
            weighted_risk = (
                account_value * 0.3 +
                market_value * 0.2 +
                position_value * 0.25 +
                liquidity_value * 0.15 +
                technical_value * 0.1
            )

            # 确定系统风险级别
            if weighted_risk >= 3.5:
                return SystemRiskLevel.EMERGENCY
            elif weighted_risk >= 3.0:
                return SystemRiskLevel.EXTREME
            elif weighted_risk >= 2.5:
                return SystemRiskLevel.HIGH
            elif weighted_risk >= 2.0:
                return SystemRiskLevel.ELEVATED
            else:
                return SystemRiskLevel.NORMAL

        except Exception as e:
            logger.error(f"确定系统风险级别失败: {e}")
            return SystemRiskLevel.HIGH

    def check_risk_thresholds(self) -> List[RiskAlert]:
        """
        检查风险阈值

        返回:
            触发的风险警报列表
        """
        try:
            alerts = []

            # 检查系统风险级别
            if self.risk_state['system_risk_level'] in [SystemRiskLevel.EXTREME, SystemRiskLevel.EMERGENCY]:
                alert = RiskAlert(
                    level=self.risk_state['system_risk_level'],
                    source=RiskSource.ACCOUNT,
                    message=f"系统风险级别达到{self.risk_state['system_risk_level'].value}"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 检查账户风险
            if self.risk_state['account_risk_level'] == RiskLevel.EXTREME:
                alert = RiskAlert(
                    level=SystemRiskLevel.EXTREME,
                    source=RiskSource.ACCOUNT,
                    message="账户风险达到极端水平"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 检查市场风险
            if self.risk_state['market_risk_level'] == RiskLevel.EXTREME:
                alert = RiskAlert(
                    level=SystemRiskLevel.HIGH,
                    source=RiskSource.MARKET,
                    message="市场风险达到极端水平"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 检查仓位风险
            if self.risk_state['position_risk_level'] == RiskLevel.EXTREME:
                alert = RiskAlert(
                    level=SystemRiskLevel.EXTREME,
                    source=RiskSource.POSITION,
                    message="仓位风险达到极端水平"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 检查流动性风险
            if self.risk_state['liquidity_risk_level'] == RiskLevel.EXTREME:
                alert = RiskAlert(
                    level=SystemRiskLevel.HIGH,
                    source=RiskSource.LIQUIDITY,
                    message="流动性风险达到极端水平"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 检查技术风险
            if self.risk_state['technical_risk_level'] == RiskLevel.EXTREME:
                alert = RiskAlert(
                    level=SystemRiskLevel.HIGH,
                    source=RiskSource.TECHNICAL,
                    message="技术风险达到极端水平"
                )
                alerts.append(alert)
                self.active_alerts.append(alert)

            # 发送警报
            if alerts:
                self._send_alerts(alerts)

            return alerts

        except Exception as e:
            logger.error(f"检查风险阈值失败: {e}")
            return []

    def _send_alerts(self, alerts: List[RiskAlert]) -> None:
        """
        发送警报

        参数:
            alerts: 警报列表
        """
        try:
            for alert in alerts:
                # 记录警报
                logger.warning(f"风险警报: [{alert.level.value}] {alert.source.value} - {alert.message}")

                # 发送邮件警报
                if self.params['enable_email_alerts']:
                    self._send_email_alert(alert)

                # 发送短信警报
                if self.params['enable_sms_alerts']:
                    self._send_sms_alert(alert)

        except Exception as e:
            logger.error(f"发送警报失败: {e}")

    def _send_email_alert(self, alert: RiskAlert) -> None:
        """
        发送邮件警报

        参数:
            alert: 风险警报
        """
        # 这里应该实现邮件发送逻辑
        pass

    def _send_sms_alert(self, alert: RiskAlert) -> None:
        """
        发送短信警报

        参数:
            alert: 风险警报
        """
        # 这里应该实现短信发送逻辑
        pass

    def _update_risk_history(self) -> None:
        """更新风险历史"""
        try:
            # 创建风险记录
            risk_record = {
                'timestamp': datetime.now(),
                'system_risk_level': self.risk_state['system_risk_level'].value,
                'account_risk_level': self.risk_state['account_risk_level'].value,
                'market_risk_level': self.risk_state['market_risk_level'].value,
                'position_risk_level': self.risk_state['position_risk_level'].value,
                'liquidity_risk_level': self.risk_state['liquidity_risk_level'].value,
                'technical_risk_level': self.risk_state['technical_risk_level'].value
            }

            # 添加到风险历史
            self.risk_history.append(risk_record)

            # 限制历史记录长度
            if len(self.risk_history) > self.params['risk_history_length']:
                self.risk_history = self.risk_history[-self.params['risk_history_length']:]

            # 更新警报历史
            self._update_alert_history()

        except Exception as e:
            logger.error(f"更新风险历史失败: {e}")

    def _update_alert_history(self) -> None:
        """更新警报历史"""
        try:
            # 检查已解决的警报
            resolved_alerts = []

            for alert in self.active_alerts:
                if alert.resolved:
                    resolved_alerts.append(alert)
                    self.alert_history.append(alert)

            # 从活动警报中移除已解决的警报
            for alert in resolved_alerts:
                self.active_alerts.remove(alert)

            # 限制警报历史记录长度
            if len(self.alert_history) > self.params['alert_history_length']:
                self.alert_history = self.alert_history[-self.params['alert_history_length']:]

        except Exception as e:
            logger.error(f"更新警报历史失败: {e}")

    def update_account_info(self, account_info: Dict[str, Any]) -> None:
        """
        更新账户信息

        参数:
            account_info: 账户信息字典
        """
        self.account_info.update(account_info)

    def update_market_info(self, market_info: Dict[str, Any]) -> None:
        """
        更新市场信息

        参数:
            market_info: 市场信息字典
        """
        self.market_info.update(market_info)

    def get_risk_state(self) -> Dict[str, Any]:
        """
        获取风险状态

        返回:
            风险状态字典
        """
        return {
            'system_risk_level': self.risk_state['system_risk_level'].value,
            'account_risk_level': self.risk_state['account_risk_level'].value,
            'market_risk_level': self.risk_state['market_risk_level'].value,
            'position_risk_level': self.risk_state['position_risk_level'].value,
            'liquidity_risk_level': self.risk_state['liquidity_risk_level'].value,
            'technical_risk_level': self.risk_state['technical_risk_level'].value,
            'last_update': self.risk_state['last_update'].isoformat()
        }

    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """
        获取活动警报

        返回:
            活动警报列表
        """
        return [alert.to_dict() for alert in self.active_alerts]

    def get_alert_history(self) -> List[Dict[str, Any]]:
        """
        获取警报历史

        返回:
            警报历史列表
        """
        return [alert.to_dict() for alert in self.alert_history]

    def get_risk_history(self) -> List[Dict[str, Any]]:
        """
        获取风险历史

        返回:
            风险历史列表
        """
        return self.risk_history

    def acknowledge_alert(self, alert_id: int) -> bool:
        """
        确认警报

        参数:
            alert_id: 警报ID

        返回:
            是否成功
        """
        try:
            if 0 <= alert_id < len(self.active_alerts):
                self.active_alerts[alert_id].acknowledge()
                return True
            return False
        except Exception as e:
            logger.error(f"确认警报失败: {e}")
            return False

    def resolve_alert(self, alert_id: int, message: str = "") -> bool:
        """
        解决警报

        参数:
            alert_id: 警报ID
            message: 解决方案消息

        返回:
            是否成功
        """
        try:
            if 0 <= alert_id < len(self.active_alerts):
                self.active_alerts[alert_id].resolve(message)
                return True
            return False
        except Exception as e:
            logger.error(f"解决警报失败: {e}")
            return False

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置风险监控参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取风险监控参数

        返回:
            参数字典
        """
        return self.params.copy()
