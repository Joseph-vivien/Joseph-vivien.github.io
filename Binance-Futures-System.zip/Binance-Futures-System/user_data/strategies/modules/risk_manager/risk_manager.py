#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
风险管理器

该模块提供风险管理功能，整合全局风险监控、仓位风险计算和止损管理。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
import logging

from user_data.strategies.modules.risk_manager import RiskLevel
from user_data.strategies.modules.risk_manager.global_risk_monitor import GlobalRiskMonitor, SystemRiskLevel
from user_data.strategies.modules.risk_manager.position_risk_calculator import PositionRiskCalculator
from user_data.strategies.modules.risk_manager.stop_loss_manager import StopLossManager, StopLossType
from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("risk_manager")

class PositionSizing:
    """
    仓位大小计算

    提供不同的仓位大小计算方法。
    """

    @staticmethod
    def fixed_size(account_balance: float, fixed_amount: float) -> float:
        """
        固定金额仓位

        参数:
            account_balance: 账户余额
            fixed_amount: 固定金额

        返回:
            仓位大小
        """
        return fixed_amount

    @staticmethod
    def percentage_of_balance(account_balance: float, percentage: float) -> float:
        """
        账户余额百分比仓位

        参数:
            account_balance: 账户余额
            percentage: 百分比 (0-100)

        返回:
            仓位大小
        """
        return account_balance * (percentage / 100)

    @staticmethod
    def risk_based(account_balance: float, risk_percentage: float,
                  entry_price: float, stop_loss_price: float) -> float:
        """
        基于风险的仓位

        参数:
            account_balance: 账户余额
            risk_percentage: 风险百分比 (0-100)
            entry_price: 入场价格
            stop_loss_price: 止损价格

        返回:
            仓位大小
        """
        if entry_price <= 0 or stop_loss_price <= 0:
            logger.warning(f"无效的价格: entry_price={entry_price}, stop_loss_price={stop_loss_price}")
            return 0

        risk_amount = account_balance * (risk_percentage / 100)
        price_difference = abs(entry_price - stop_loss_price)

        if price_difference == 0:
            logger.warning("入场价格和止损价格相同，无法计算仓位大小")
            return 0

        position_size = risk_amount / price_difference
        return position_size

    @staticmethod
    def kelly_criterion(account_balance: float, win_rate: float,
                       reward_risk_ratio: float) -> float:
        """
        凯利公式仓位

        参数:
            account_balance: 账户余额
            win_rate: 胜率 (0-1)
            reward_risk_ratio: 盈亏比

        返回:
            仓位大小
        """
        if win_rate <= 0 or win_rate >= 1 or reward_risk_ratio <= 0:
            logger.warning(f"无效的参数: win_rate={win_rate}, reward_risk_ratio={reward_risk_ratio}")
            return 0

        kelly_percentage = (win_rate * reward_risk_ratio - (1 - win_rate)) / reward_risk_ratio

        # 限制凯利值在0-0.5之间
        kelly_percentage = max(0, min(0.5, kelly_percentage))

        return account_balance * kelly_percentage

class RiskManager:
    """
    风险管理器

    整合全局风险监控、仓位风险计算和止损管理，提供全面的风险管理功能。
    """

    def __init__(self):
        """初始化风险管理器"""
        self.global_risk_monitor = GlobalRiskMonitor()
        self.position_risk_calculator = PositionRiskCalculator()
        self.stop_loss_manager = StopLossManager()

        # 默认参数
        self.parameters = {
            'max_open_trades': 5,
            'max_open_trades_per_pair': 1,
            'max_position_size_pct': 20.0,
            'default_risk_pct': 2.0,
            'max_drawdown_pct': 20.0,
            'max_daily_drawdown_pct': 5.0,
            'position_sizing_method': 'risk',
            'fixed_position_size': 100.0,
            'percentage_position_size': 5.0,
            'stoploss_method': 'atr',
            'atr_multiplier': 2.0,
            'trailing_stop': True,
            'trailing_stop_positive': 0.01,
            'trailing_stop_positive_offset': 0.02,
            'trailing_only_offset_is_reached': True
        }

        logger.info("风险管理器初始化完成")

    def set_parameters(self, parameters: Dict[str, Any]) -> None:
        """
        设置风险管理参数

        参数:
            parameters: 参数字典
        """
        self.parameters.update(parameters)
        logger.info("已更新风险管理参数")

    def get_system_risk_level(self) -> RiskLevel:
        """
        获取系统风险级别

        返回:
            风险级别
        """
        system_risk = self.global_risk_monitor.get_system_risk_level()

        if system_risk == SystemRiskLevel.LOW:
            return RiskLevel.LOW
        elif system_risk == SystemRiskLevel.MEDIUM:
            return RiskLevel.MEDIUM
        elif system_risk == SystemRiskLevel.HIGH:
            return RiskLevel.HIGH
        elif system_risk == SystemRiskLevel.EXTREME:
            return RiskLevel.EXTREME
        else:
            return RiskLevel.MEDIUM

    def can_open_position(self, symbol: str, position_size_quote: float) -> Tuple[bool, str]:
        """
        检查是否可以开仓

        参数:
            symbol: 交易对符号
            position_size_quote: 仓位大小（计价货币）

        返回:
            (是否可以开仓, 原因)
        """
        # 检查全局风险
        system_risk = self.get_system_risk_level()
        if system_risk == RiskLevel.EXTREME:
            return False, "系统风险极高，禁止开仓"

        # 检查最大开仓数量
        open_trades = self.global_risk_monitor.get_open_trades_count()
        if open_trades >= self.parameters['max_open_trades']:
            return False, f"已达到最大开仓数量 ({open_trades}/{self.parameters['max_open_trades']})"

        # 检查单个交易对最大开仓数量
        open_trades_for_pair = self.global_risk_monitor.get_open_trades_count_for_pair(symbol)
        if open_trades_for_pair >= self.parameters['max_open_trades_per_pair']:
            return False, f"已达到单个交易对最大开仓数量 ({open_trades_for_pair}/{self.parameters['max_open_trades_per_pair']})"

        # 检查仓位大小
        account_balance = self.global_risk_monitor.get_account_balance()
        max_position_size = account_balance * (self.parameters['max_position_size_pct'] / 100)
        if position_size_quote > max_position_size:
            return False, f"仓位大小超过最大限制 ({position_size_quote:.2f}/{max_position_size:.2f})"

        # 检查回撤
        current_drawdown = self.global_risk_monitor.get_current_drawdown_percentage()
        if current_drawdown > self.parameters['max_drawdown_pct']:
            return False, f"当前回撤超过最大限制 ({current_drawdown:.2f}%/{self.parameters['max_drawdown_pct']}%)"

        # 检查日内回撤
        daily_drawdown = self.global_risk_monitor.get_daily_drawdown_percentage()
        if daily_drawdown > self.parameters['max_daily_drawdown_pct']:
            return False, f"日内回撤超过最大限制 ({daily_drawdown:.2f}%/{self.parameters['max_daily_drawdown_pct']}%)"

        return True, "可以开仓"

    def calculate_position_size(self, symbol: str, entry_price: float,
                              stop_loss_price: float, data: pd.DataFrame) -> Dict[str, Any]:
        """
        计算仓位大小

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stop_loss_price: 止损价格
            data: OHLCV数据

        返回:
            仓位信息字典
        """
        account_balance = self.global_risk_monitor.get_account_balance()

        # 根据系统风险级别调整风险百分比
        risk_level = self.get_system_risk_level()
        risk_pct = self.parameters['default_risk_pct']

        if risk_level == RiskLevel.LOW:
            risk_pct = self.parameters['default_risk_pct'] * 1.2
        elif risk_level == RiskLevel.MEDIUM:
            risk_pct = self.parameters['default_risk_pct']
        elif risk_level == RiskLevel.HIGH:
            risk_pct = self.parameters['default_risk_pct'] * 0.8
        elif risk_level == RiskLevel.EXTREME:
            risk_pct = self.parameters['default_risk_pct'] * 0.5

        # 根据仓位计算方法计算仓位大小
        position_size = 0.0
        position_size_quote = 0.0

        if self.parameters['position_sizing_method'] == 'fixed':
            position_size_quote = PositionSizing.fixed_size(
                account_balance, self.parameters['fixed_position_size'])
            position_size = position_size_quote / entry_price

        elif self.parameters['position_sizing_method'] == 'percentage':
            position_size_quote = PositionSizing.percentage_of_balance(
                account_balance, self.parameters['percentage_position_size'])
            position_size = position_size_quote / entry_price

        elif self.parameters['position_sizing_method'] == 'risk':
            position_size = PositionSizing.risk_based(
                account_balance, risk_pct, entry_price, stop_loss_price)
            position_size_quote = position_size * entry_price

        elif self.parameters['position_sizing_method'] == 'kelly':
            # 获取历史胜率和盈亏比
            win_rate, reward_risk_ratio = self.position_risk_calculator.calculate_historical_metrics(symbol)

            position_size_quote = PositionSizing.kelly_criterion(
                account_balance, win_rate, reward_risk_ratio)
            position_size = position_size_quote / entry_price

        else:
            logger.warning(f"未知的仓位计算方法: {self.parameters['position_sizing_method']}")
            position_size_quote = PositionSizing.percentage_of_balance(
                account_balance, self.parameters['percentage_position_size'])
            position_size = position_size_quote / entry_price

        return {
            'position_size': position_size,
            'position_size_quote': position_size_quote,
            'risk_percentage': risk_pct,
            'account_balance': account_balance,
            'entry_price': entry_price,
            'stop_loss_price': stop_loss_price
        }

    def calculate_stoploss(self, symbol: str, current_price: float,
                         is_long: bool, data: pd.DataFrame) -> Dict[str, Any]:
        """
        计算止损价格

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            is_long: 是否做多
            data: OHLCV数据

        返回:
            止损信息字典
        """
        return self.stop_loss_manager.calculate_stoploss(
            symbol, current_price, is_long, data,
            method=StopLossType[self.parameters['stoploss_method'].upper()],
            atr_multiplier=self.parameters['atr_multiplier']
        )

    def update_trailing_stoploss(self, symbol: str, current_price: float,
                               position_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新追踪止损

        参数:
            symbol: 交易对符号
            current_price: 当前价格
            position_info: 仓位信息

        返回:
            更新后的仓位信息
        """
        if not self.parameters['trailing_stop']:
            return position_info

        return self.stop_loss_manager.update_trailing_stoploss(
            symbol, current_price, position_info,
            trailing_stop_positive=self.parameters['trailing_stop_positive'],
            trailing_stop_positive_offset=self.parameters['trailing_stop_positive_offset'],
            trailing_only_offset_is_reached=self.parameters['trailing_only_offset_is_reached']
        )
