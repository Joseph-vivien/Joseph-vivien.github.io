#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
固定杠杆实现模块

该模块实现了固定杠杆策略，简化交易决策并降低系统复杂度。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
import ccxt

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager

# 获取日志记录器
logger = get_logger("fixed_leverage")

class FixedLeverage:
    """
    固定杠杆计算器

    提供简单的固定杠杆计算功能。
    """

    def __init__(self):
        """初始化固定杠杆计算器"""
        pass

    def calculate_leverage(self, base_leverage: int, risk_level: str = 'medium') -> int:
        """
        计算固定杠杆倍数

        参数:
            base_leverage: 基础杠杆倍数
            risk_level: 风险级别 (low, medium, high)

        返回:
            杠杆倍数
        """
        # 根据风险级别调整杠杆
        if risk_level == 'low':
            leverage = max(1, base_leverage // 2)
        elif risk_level == 'high':
            leverage = min(50, base_leverage * 2)
        else:  # medium
            leverage = base_leverage

        return int(leverage)

class FixedLeverageManager:
    """
    固定杠杆管理类

    实现固定杠杆策略，简化交易决策并降低系统复杂度
    """

    def __init__(self, exchange=None, config=None, leverage: int = 25):
        """
        初始化固定杠杆管理器

        参数:
            exchange: 交易所对象
            config: 配置字典
            leverage: 固定杠杆倍数
        """
        self.exchange = exchange

        # 加载配置
        self.config_manager = get_config_manager()
        self.config = config or {}

        # 设置固定杠杆倍数
        self.leverage = leverage

        # 从配置中加载杠杆倍数
        self._load_leverage_config()

        # 当前杠杆设置
        self.current_leverage = {}  # {symbol: leverage}

        # 初始化杠杆
        self._initialize_leverage()

    def _load_leverage_config(self) -> None:
        """加载杠杆配置"""
        try:
            # 从配置中加载杠杆倍数
            leverage_config = self.config.get('leverage', 25)

            if isinstance(leverage_config, (int, float)):
                self.leverage = int(leverage_config)

            # 确保杠杆倍数在合理范围内
            self.leverage = max(1, min(self.leverage, 125))

            logger.info(f"已加载固定杠杆配置: {self.leverage}倍")

        except Exception as e:
            logger.error(f"加载固定杠杆配置失败: {e}")

    def _initialize_leverage(self) -> None:
        """初始化杠杆设置"""
        if self.exchange is None:
            logger.warning("交易所对象未设置，无法初始化杠杆")
            return

        try:
            # 获取交易对列表
            pairs = self.config.get('pairs', [])

            if not pairs:
                logger.warning("交易对列表为空，无法初始化杠杆")
                return

            # 设置每个交易对的杠杆
            for pair in pairs:
                self.set_leverage(pair)

        except Exception as e:
            logger.error(f"初始化杠杆失败: {e}")

    def set_leverage(self, symbol: str) -> bool:
        """
        设置交易对的固定杠杆倍数

        参数:
            symbol: 交易对符号

        返回:
            是否设置成功
        """
        if self.exchange is None:
            logger.warning(f"交易所对象未设置，无法为 {symbol} 设置杠杆")
            return False

        try:
            # 设置杠杆
            self.exchange.set_leverage(self.leverage, symbol)

            # 更新当前杠杆设置
            self.current_leverage[symbol] = self.leverage

            logger.info(f"已为 {symbol} 设置固定杠杆: {self.leverage}倍")
            return True

        except Exception as e:
            logger.error(f"为 {symbol} 设置固定杠杆失败: {e}")
            return False

    def get_leverage(self, symbol: str = None) -> int:
        """
        获取固定杠杆倍数

        参数:
            symbol: 交易对符号（可选）

        返回:
            固定杠杆倍数
        """
        return self.leverage

    def calculate_position_size(self, account_balance: float, entry_price: float,
                              stop_loss_price: float, risk_pct: float = 2.0) -> Dict[str, Any]:
        """
        计算仓位大小

        参数:
            account_balance: 账户余额
            entry_price: 入场价格
            stop_loss_price: 止损价格
            risk_pct: 账户风险百分比

        返回:
            仓位计算结果
        """
        try:
            # 计算价格风险百分比
            price_risk_pct = abs(entry_price - stop_loss_price) / entry_price

            # 计算账户风险金额
            account_risk = account_balance * (risk_pct / 100)

            # 计算仓位大小（币数量）
            position_size_quote = account_risk / price_risk_pct
            position_size = position_size_quote / entry_price

            # 计算实际风险
            actual_risk_amount = position_size_quote * price_risk_pct
            actual_risk_pct = (actual_risk_amount / account_balance) * 100

            # 计算预期盈亏平衡点
            breakeven_price = entry_price * (1 + (1 / self.leverage) * 0.01)  # 考虑0.1%手续费

            # 计算强平价格
            liquidation_buffer = 0.2  # 20%保证金缓冲
            is_long = entry_price > stop_loss_price

            if is_long:
                liquidation_price = entry_price * (1 - (1 - liquidation_buffer) / self.leverage)
            else:
                liquidation_price = entry_price * (1 + (1 - liquidation_buffer) / self.leverage)

            return {
                'position_size': position_size,
                'position_size_quote': position_size_quote,
                'risk_amount': actual_risk_amount,
                'risk_pct': actual_risk_pct,
                'leverage': self.leverage,
                'breakeven_price': breakeven_price,
                'liquidation_price': liquidation_price,
                'margin_required': position_size_quote / self.leverage
            }

        except Exception as e:
            logger.error(f"计算仓位大小失败: {e}")
            return {
                'position_size': 0.0,
                'position_size_quote': 0.0,
                'risk_amount': 0.0,
                'risk_pct': 0.0,
                'leverage': self.leverage,
                'breakeven_price': 0.0,
                'liquidation_price': 0.0,
                'margin_required': 0.0
            }

    def optimize_stop_loss(self, entry_price: float, atr_value: float,
                         atr_multiplier: float = 2.0, side: str = 'long') -> float:
        """
        优化止损价格

        参数:
            entry_price: 入场价格
            atr_value: ATR值
            atr_multiplier: ATR乘数
            side: 交易方向 ('long' 或 'short')

        返回:
            优化后的止损价格
        """
        try:
            # 计算基于ATR的止损距离
            atr_distance = atr_multiplier * atr_value

            # 计算最大允许止损距离（基于杠杆）
            # 预留20%保证金缓冲，避免强平
            max_loss_pct = 0.8 / self.leverage
            max_distance = entry_price * max_loss_pct

            # 取两者中较小值，确保安全
            safe_distance = min(atr_distance, max_distance)

            # 计算止损价格
            if side.lower() == 'long':
                stop_loss_price = entry_price - safe_distance
            else:
                stop_loss_price = entry_price + safe_distance

            return stop_loss_price

        except Exception as e:
            logger.error(f"优化止损价格失败: {e}")

            # 返回默认止损价格（2%距离）
            if side.lower() == 'long':
                return entry_price * 0.98
            else:
                return entry_price * 1.02

    def calculate_risk_metrics(self, entry_price: float, stop_loss_price: float,
                             position_size: float) -> Dict[str, Any]:
        """
        计算风险指标

        参数:
            entry_price: 入场价格
            stop_loss_price: 止损价格
            position_size: 仓位大小（币数量）

        返回:
            风险指标字典
        """
        try:
            # 计算价格风险百分比
            price_risk_pct = abs(entry_price - stop_loss_price) / entry_price

            # 计算仓位价值
            position_value = position_size * entry_price

            # 计算所需保证金
            margin_required = position_value / self.leverage

            # 计算最大亏损金额
            max_loss = position_size * abs(entry_price - stop_loss_price)

            # 计算强平价格
            liquidation_buffer = 0.2  # 20%保证金缓冲
            is_long = entry_price > stop_loss_price

            if is_long:
                liquidation_price = entry_price * (1 - (1 - liquidation_buffer) / self.leverage)
            else:
                liquidation_price = entry_price * (1 + (1 - liquidation_buffer) / self.leverage)

            # 计算止损到强平的安全距离
            safety_buffer = abs(stop_loss_price - liquidation_price) / entry_price * 100

            return {
                'price_risk_pct': price_risk_pct * 100,
                'position_value': position_value,
                'margin_required': margin_required,
                'max_loss': max_loss,
                'liquidation_price': liquidation_price,
                'safety_buffer_pct': safety_buffer,
                'leverage': self.leverage
            }

        except Exception as e:
            logger.error(f"计算风险指标失败: {e}")
            return {
                'price_risk_pct': 0.0,
                'position_value': 0.0,
                'margin_required': 0.0,
                'max_loss': 0.0,
                'liquidation_price': 0.0,
                'safety_buffer_pct': 0.0,
                'leverage': self.leverage
            }

    def set_leverage_value(self, leverage: int) -> None:
        """
        设置固定杠杆倍数

        参数:
            leverage: 杠杆倍数
        """
        try:
            # 确保杠杆倍数在合理范围内
            leverage = max(1, min(leverage, 125))

            # 更新杠杆倍数
            self.leverage = leverage

            logger.info(f"已更新固定杠杆倍数: {self.leverage}倍")

            # 重新初始化所有交易对的杠杆
            self._initialize_leverage()

        except Exception as e:
            logger.error(f"设置固定杠杆倍数失败: {e}")

    def get_leverage_info(self) -> Dict[str, Any]:
        """
        获取杠杆信息

        返回:
            杠杆信息字典
        """
        return {
            'leverage': self.leverage,
            'mode': 'fixed',
            'current_leverage': self.current_leverage,
            'max_safe_position_pct': 80 / self.leverage,  # 最大安全仓位百分比
            'margin_ratio': 1 / self.leverage  # 保证金比例
        }
