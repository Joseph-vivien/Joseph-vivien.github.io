#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
杠杆管理器

该模块提供杠杆管理功能，用于计算和调整交易杠杆。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
from enum import Enum, auto
import logging

from user_data.strategies.modules.leverage_manager.fixed_leverage import FixedLeverage
from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("leverage_manager")

class LeverageManager:
    """
    杠杆管理器
    
    管理交易杠杆，提供不同的杠杆计算策略。
    """
    
    def __init__(self):
        """初始化杠杆管理器"""
        self.fixed_leverage = FixedLeverage()
        
        # 默认参数
        self.parameters = {
            'mode': 'fixed',
            'value': 1,
            'max_leverage': 50,
            'min_leverage': 1,
            'adaptive_method': 'volatility',
            'volatility_lookback': 14,
            'volatility_threshold_high': 0.05,
            'volatility_threshold_low': 0.02
        }
        
        logger.info("杠杆管理器初始化完成")
        
    def set_parameters(self, parameters: Dict[str, Any]) -> None:
        """
        设置杠杆管理参数
        
        参数:
            parameters: 参数字典
        """
        self.parameters.update(parameters)
        logger.info("已更新杠杆管理参数")
        
    def calculate_leverage(self, symbol: str, data: pd.DataFrame, 
                         risk_level: str = 'medium') -> int:
        """
        计算杠杆倍数
        
        参数:
            symbol: 交易对符号
            data: OHLCV数据
            risk_level: 风险级别 (low, medium, high)
            
        返回:
            杠杆倍数
        """
        mode = self.parameters['mode']
        
        if mode == 'fixed':
            leverage = self.fixed_leverage.calculate_leverage(
                self.parameters['value'], risk_level)
                
        elif mode == 'adaptive':
            leverage = self.calculate_adaptive_leverage(symbol, data, risk_level)
            
        else:
            logger.warning(f"未知的杠杆模式: {mode}，使用固定杠杆")
            leverage = self.fixed_leverage.calculate_leverage(
                self.parameters['value'], risk_level)
                
        # 确保杠杆在允许范围内
        leverage = max(self.parameters['min_leverage'], 
                     min(self.parameters['max_leverage'], leverage))
                     
        logger.info(f"计算杠杆倍数: {symbol} {leverage}x (模式: {mode}, 风险级别: {risk_level})")
        return leverage
        
    def calculate_adaptive_leverage(self, symbol: str, data: pd.DataFrame, 
                                  risk_level: str = 'medium') -> int:
        """
        计算自适应杠杆倍数
        
        参数:
            symbol: 交易对符号
            data: OHLCV数据
            risk_level: 风险级别 (low, medium, high)
            
        返回:
            杠杆倍数
        """
        method = self.parameters['adaptive_method']
        
        if method == 'volatility':
            return self.calculate_volatility_based_leverage(data, risk_level)
        else:
            logger.warning(f"未知的自适应杠杆方法: {method}，使用固定杠杆")
            return self.fixed_leverage.calculate_leverage(
                self.parameters['value'], risk_level)
                
    def calculate_volatility_based_leverage(self, data: pd.DataFrame, 
                                         risk_level: str = 'medium') -> int:
        """
        基于波动率计算杠杆倍数
        
        参数:
            data: OHLCV数据
            risk_level: 风险级别 (low, medium, high)
            
        返回:
            杠杆倍数
        """
        if data.empty:
            logger.warning("数据为空，无法计算波动率，使用默认杠杆")
            return self.parameters['value']
            
        # 计算波动率
        lookback = self.parameters['volatility_lookback']
        if len(data) < lookback:
            lookback = len(data)
            
        returns = data['close'].pct_change().dropna()
        if len(returns) < 2:
            logger.warning("数据不足，无法计算波动率，使用默认杠杆")
            return self.parameters['value']
            
        volatility = returns.tail(lookback).std()
        
        # 根据波动率调整杠杆
        high_threshold = self.parameters['volatility_threshold_high']
        low_threshold = self.parameters['volatility_threshold_low']
        
        if volatility > high_threshold:
            # 高波动率，降低杠杆
            leverage = self.parameters['min_leverage']
        elif volatility < low_threshold:
            # 低波动率，提高杠杆
            leverage = self.parameters['max_leverage']
        else:
            # 中等波动率，线性插值
            leverage_range = self.parameters['max_leverage'] - self.parameters['min_leverage']
            volatility_range = high_threshold - low_threshold
            leverage = self.parameters['max_leverage'] - leverage_range * (volatility - low_threshold) / volatility_range
            
        # 根据风险级别调整
        if risk_level == 'low':
            leverage = max(self.parameters['min_leverage'], leverage / 2)
        elif risk_level == 'high':
            leverage = min(self.parameters['max_leverage'], leverage * 1.5)
            
        return int(leverage)
        
    def adjust_position_for_leverage(self, position_size: float, 
                                   current_leverage: int, 
                                   new_leverage: int) -> float:
        """
        根据杠杆调整仓位大小
        
        参数:
            position_size: 原始仓位大小
            current_leverage: 当前杠杆
            new_leverage: 新杠杆
            
        返回:
            调整后的仓位大小
        """
        if current_leverage <= 0 or new_leverage <= 0:
            logger.warning(f"无效的杠杆值: current_leverage={current_leverage}, new_leverage={new_leverage}")
            return position_size
            
        adjusted_size = position_size * (current_leverage / new_leverage)
        logger.info(f"调整仓位大小: {position_size} -> {adjusted_size} (杠杆: {current_leverage}x -> {new_leverage}x)")
        return adjusted_size
