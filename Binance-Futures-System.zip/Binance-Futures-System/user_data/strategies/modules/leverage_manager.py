#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
杠杆管理模块

该模块负责管理交易杠杆，支持固定杠杆模式和动态杠杆调整。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import ccxt

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.leverage_manager.fixed_leverage import FixedLeverage

# 获取日志记录器
logger = get_logger("leverage_manager")

class LeverageMode(Enum):
    """杠杆模式枚举"""
    FIXED = "固定杠杆"
    DYNAMIC = "动态杠杆"
    ADAPTIVE = "自适应杠杆"

class LeverageManager:
    """
    杠杆管理类

    负责管理交易杠杆，支持固定杠杆模式和动态杠杆调整
    """

    def __init__(self, exchange=None, config=None):
        """
        初始化杠杆管理器

        参数:
            exchange: 交易所对象
            config: 配置字典
        """
        self.exchange = exchange

        # 加载配置
        self.config_manager = get_config_manager()
        self.config = config or {}

        # 设置默认杠杆参数
        self.params = {
            'leverage_mode': LeverageMode.FIXED,  # 默认使用固定杠杆模式
            'default_leverage': 25,  # 默认杠杆倍数
            'max_leverage': 50,  # 最大允许杠杆倍数
            'min_leverage': 1,  # 最小允许杠杆倍数
            'leverage_step': 1,  # 杠杆调整步长
            'auto_adjust_leverage': False,  # 是否自动调整杠杆
            'volatility_based_adjustment': False,  # 是否基于波动率调整杠杆
            'account_size_based_adjustment': False,  # 是否基于账户规模调整杠杆
            'small_account_threshold': 1000,  # 小账户阈值 (USDT)
            'medium_account_threshold': 10000,  # 中等账户阈值 (USDT)
            'small_account_max_leverage': 25,  # 小账户最大杠杆
            'medium_account_max_leverage': 20,  # 中等账户最大杠杆
            'large_account_max_leverage': 15,  # 大账户最大杠杆
            'high_volatility_max_leverage': 10,  # 高波动率时最大杠杆
            'extreme_volatility_max_leverage': 5,  # 极端波动率时最大杠杆
        }

        # 从配置中加载杠杆参数
        self._load_leverage_config()

        # 当前杠杆设置
        self.current_leverage = {}  # {symbol: leverage}

        # 初始化杠杆
        self._initialize_leverage()

    def _load_leverage_config(self) -> None:
        """加载杠杆配置"""
        try:
            # 从配置中加载杠杆参数
            leverage_config = self.config.get('leverage', {})

            if isinstance(leverage_config, dict):
                # 更新杠杆参数
                for key, value in leverage_config.items():
                    if key in self.params:
                        self.params[key] = value

            elif isinstance(leverage_config, (int, float)):
                # 如果配置中的杠杆是一个数字，则设置为默认杠杆倍数
                self.params['default_leverage'] = int(leverage_config)

            # 确保杠杆倍数在合理范围内
            self.params['default_leverage'] = max(
                self.params['min_leverage'],
                min(self.params['default_leverage'], self.params['max_leverage'])
            )

            # 设置杠杆模式
            mode_str = self.config.get('leverage_mode', 'fixed')
            if mode_str.lower() == 'fixed':
                self.params['leverage_mode'] = LeverageMode.FIXED
            elif mode_str.lower() == 'dynamic':
                self.params['leverage_mode'] = LeverageMode.DYNAMIC
            elif mode_str.lower() == 'adaptive':
                self.params['leverage_mode'] = LeverageMode.ADAPTIVE

            logger.info(f"已加载杠杆配置: 模式={self.params['leverage_mode'].value}, 默认杠杆={self.params['default_leverage']}倍")

        except Exception as e:
            logger.error(f"加载杠杆配置失败: {e}")

    def _initialize_leverage(self) -> None:
        """初始化杠杆设置"""
        if self.exchange is None:
            logger.warning("交易所对象未设置，无法初始化杠杆")
            return

        try:
            # 获取交易对列表
            pairs = self.config.get('pairs', [])

            if not pairs:
                logger.warning("交易对列表为空，无法初始化杠杆")
                return

            # 设置每个交易对的杠杆
            for pair in pairs:
                self.set_leverage(pair, self.params['default_leverage'])

        except Exception as e:
            logger.error(f"初始化杠杆失败: {e}")

    def set_leverage(self, symbol: str, leverage: int) -> bool:
        """
        设置交易对的杠杆倍数

        参数:
            symbol: 交易对符号
            leverage: 杠杆倍数

        返回:
            是否设置成功
        """
        if self.exchange is None:
            logger.warning(f"交易所对象未设置，无法为 {symbol} 设置杠杆")
            return False

        try:
            # 确保杠杆倍数在合理范围内
            leverage = max(
                self.params['min_leverage'],
                min(leverage, self.params['max_leverage'])
            )

            # 设置杠杆
            self.exchange.set_leverage(leverage, symbol)

            # 更新当前杠杆设置
            self.current_leverage[symbol] = leverage

            logger.info(f"已为 {symbol} 设置杠杆: {leverage}倍")
            return True

        except Exception as e:
            logger.error(f"为 {symbol} 设置杠杆失败: {e}")
            return False

    def get_leverage(self, symbol: str) -> int:
        """
        获取交易对的当前杠杆倍数

        参数:
            symbol: 交易对符号

        返回:
            当前杠杆倍数
        """
        # 如果已缓存，直接返回
        if symbol in self.current_leverage:
            return self.current_leverage[symbol]

        # 否则返回默认杠杆
        return self.params['default_leverage']

    def adjust_leverage_by_volatility(self, symbol: str, volatility: float) -> int:
        """
        根据波动率调整杠杆倍数

        参数:
            symbol: 交易对符号
            volatility: 波动率

        返回:
            调整后的杠杆倍数
        """
        if not self.params['volatility_based_adjustment']:
            return self.get_leverage(symbol)

        try:
            # 获取当前杠杆
            current_leverage = self.get_leverage(symbol)

            # 根据波动率调整杠杆
            if volatility > 0.05:  # 极端波动率 (>5%)
                new_leverage = min(current_leverage, self.params['extreme_volatility_max_leverage'])
            elif volatility > 0.03:  # 高波动率 (3-5%)
                new_leverage = min(current_leverage, self.params['high_volatility_max_leverage'])
            else:
                # 正常波动率，使用默认杠杆
                new_leverage = current_leverage

            # 如果杠杆需要调整，设置新杠杆
            if new_leverage != current_leverage:
                self.set_leverage(symbol, new_leverage)
                logger.info(f"根据波动率({volatility:.2%})调整 {symbol} 杠杆: {current_leverage}倍 -> {new_leverage}倍")

            return new_leverage

        except Exception as e:
            logger.error(f"根据波动率调整杠杆失败: {e}")
            return self.get_leverage(symbol)

    def adjust_leverage_by_account_size(self, symbol: str, account_balance: float) -> int:
        """
        根据账户规模调整杠杆倍数

        参数:
            symbol: 交易对符号
            account_balance: 账户余额

        返回:
            调整后的杠杆倍数
        """
        if not self.params['account_size_based_adjustment']:
            return self.get_leverage(symbol)

        try:
            # 获取当前杠杆
            current_leverage = self.get_leverage(symbol)

            # 根据账户规模调整杠杆
            if account_balance < self.params['small_account_threshold']:
                # 小账户
                new_leverage = min(current_leverage, self.params['small_account_max_leverage'])
            elif account_balance < self.params['medium_account_threshold']:
                # 中等账户
                new_leverage = min(current_leverage, self.params['medium_account_max_leverage'])
            else:
                # 大账户
                new_leverage = min(current_leverage, self.params['large_account_max_leverage'])

            # 如果杠杆需要调整，设置新杠杆
            if new_leverage != current_leverage:
                self.set_leverage(symbol, new_leverage)
                logger.info(f"根据账户规模({account_balance:.2f} USDT)调整 {symbol} 杠杆: {current_leverage}倍 -> {new_leverage}倍")

            return new_leverage

        except Exception as e:
            logger.error(f"根据账户规模调整杠杆失败: {e}")
            return self.get_leverage(symbol)

    def calculate_max_safe_leverage(self, symbol: str, entry_price: float,
                                  stop_loss_price: float) -> int:
        """
        计算最大安全杠杆倍数

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stop_loss_price: 止损价格

        返回:
            最大安全杠杆倍数
        """
        try:
            # 计算止损距离百分比
            stop_loss_pct = abs(entry_price - stop_loss_price) / entry_price

            # 计算最大安全杠杆
            # 预留20%保证金缓冲，避免强平
            # 例如：如果止损距离是2%，则最大安全杠杆 = 0.8 / 0.02 = 40倍
            max_safe_leverage = int(0.8 / stop_loss_pct)

            # 确保杠杆在合理范围内
            max_safe_leverage = max(
                self.params['min_leverage'],
                min(max_safe_leverage, self.params['max_leverage'])
            )

            return max_safe_leverage

        except Exception as e:
            logger.error(f"计算最大安全杠杆失败: {e}")
            return self.params['default_leverage']

    def optimize_leverage(self, symbol: str, entry_price: float,
                        stop_loss_price: float, volatility: float,
                        account_balance: float) -> int:
        """
        优化杠杆设置

        参数:
            symbol: 交易对符号
            entry_price: 入场价格
            stop_loss_price: 止损价格
            volatility: 波动率
            account_balance: 账户余额

        返回:
            优化后的杠杆倍数
        """
        try:
            # 如果使用固定杠杆模式，直接返回默认杠杆
            if self.params['leverage_mode'] == LeverageMode.FIXED:
                return self.get_leverage(symbol)

            # 计算最大安全杠杆
            max_safe_leverage = self.calculate_max_safe_leverage(
                symbol, entry_price, stop_loss_price)

            # 根据波动率调整杠杆
            if self.params['volatility_based_adjustment']:
                volatility_leverage = self.adjust_leverage_by_volatility(
                    symbol, volatility)
                max_safe_leverage = min(max_safe_leverage, volatility_leverage)

            # 根据账户规模调整杠杆
            if self.params['account_size_based_adjustment']:
                account_leverage = self.adjust_leverage_by_account_size(
                    symbol, account_balance)
                max_safe_leverage = min(max_safe_leverage, account_leverage)

            # 设置优化后的杠杆
            self.set_leverage(symbol, max_safe_leverage)

            return max_safe_leverage

        except Exception as e:
            logger.error(f"优化杠杆设置失败: {e}")
            return self.get_leverage(symbol)

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置杠杆管理参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取杠杆管理参数

        返回:
            参数字典
        """
        return self.params.copy()
