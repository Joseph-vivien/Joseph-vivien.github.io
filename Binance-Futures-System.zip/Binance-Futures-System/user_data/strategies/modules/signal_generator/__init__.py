#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
信号生成模块初始化文件
"""

from enum import Enum, auto

# 定义信号类型枚举
class SignalType(Enum):
    """信号类型枚举"""
    STRONG_BUY = auto()  # 强烈买入
    BUY = auto()  # 买入
    NEUTRAL = auto()  # 中性
    SELL = auto()  # 卖出
    STRONG_SELL = auto()  # 强烈卖出
    NONE = auto()  # 无信号

# 导入其他模块
from user_data.strategies.modules.signal_generator.technical_signals import TechnicalSignals
from user_data.strategies.modules.signal_generator.price_patterns import PricePatternRecognizer, PatternType
from user_data.strategies.modules.signal_generator.ml_signals import MLSignalGenerator, ModelType
from user_data.strategies.modules.signal_generator.ensemble_signals import EnsembleSignalGenerator, EnsembleMethod
from user_data.strategies.modules.signal_generator.signal_generator import SignalGenerator

__all__ = ['SignalGenerator', 'SignalType', 'TechnicalSignals', 'PricePatternRecognizer', 'PatternType', 'MLSignalGenerator', 'ModelType', 'EnsembleSignalGenerator', 'EnsembleMethod']
