#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
机器学习信号组件

该模块负责基于机器学习模型生成交易信号，支持多种模型类型和特征工程。

作者: 高级Python工程师
日期: 2024-05-21
"""

import os
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import joblib
import pickle
from datetime import datetime
import json

from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential, load_model
    from tensorflow.keras.layers import Dense, LSTM, Dropout, GRU
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.signal_generator import SignalType

# 获取日志记录器
logger = get_logger("ml_signals")

class ModelType(Enum):
    """模型类型枚举"""
    RANDOM_FOREST = "随机森林"
    GRADIENT_BOOSTING = "梯度提升"
    LOGISTIC_REGRESSION = "逻辑回归"
    SVM = "支持向量机"
    LSTM = "长短期记忆网络"
    GRU = "门控循环单元"
    ENSEMBLE = "集成模型"

class MLSignalGenerator:
    """
    机器学习信号生成类

    负责基于机器学习模型生成交易信号
    """

    def __init__(self, model_dir: str = "user_data/models"):
        """
        初始化机器学习信号生成器

        参数:
            model_dir: 模型保存目录
        """
        self.model_dir = model_dir

        # 确保模型目录存在
        os.makedirs(model_dir, exist_ok=True)

        # 初始化模型
        self.models = {}
        self.scalers = {}
        self.feature_names = {}
        self.model_configs = {}

        # 加载已有模型
        self._load_models()

    def _load_models(self) -> None:
        """加载已有模型"""
        try:
            # 查找模型目录中的所有模型文件
            for filename in os.listdir(self.model_dir):
                if filename.endswith('.joblib') or filename.endswith('.pkl') or filename.endswith('.h5'):
                    model_name = os.path.splitext(filename)[0]
                    model_path = os.path.join(self.model_dir, filename)

                    # 检查是否有对应的配置文件
                    config_path = os.path.join(self.model_dir, f"{model_name}_config.json")
                    if not os.path.exists(config_path):
                        logger.warning(f"模型 {model_name} 没有配置文件，跳过加载")
                        continue

                    # 加载配置
                    with open(config_path, 'r') as f:
                        config = json.load(f)

                    # 加载模型
                    if filename.endswith('.joblib'):
                        model = joblib.load(model_path)
                    elif filename.endswith('.pkl'):
                        with open(model_path, 'rb') as f:
                            model = pickle.load(f)
                    elif filename.endswith('.h5') and TF_AVAILABLE:
                        model = load_model(model_path)
                    else:
                        logger.warning(f"不支持的模型文件格式: {filename}")
                        continue

                    # 加载特征缩放器
                    scaler_path = os.path.join(self.model_dir, f"{model_name}_scaler.joblib")
                    if os.path.exists(scaler_path):
                        scaler = joblib.load(scaler_path)
                    else:
                        scaler = None

                    # 保存模型和配置
                    self.models[model_name] = model
                    self.scalers[model_name] = scaler
                    self.feature_names[model_name] = config.get('feature_names', [])
                    self.model_configs[model_name] = config

                    logger.info(f"已加载模型: {model_name}")

        except Exception as e:
            logger.error(f"加载模型失败: {e}")

    def train_model(self, data: pd.DataFrame, model_type: ModelType,
                   target_column: str, feature_columns: List[str],
                   model_name: str, **kwargs) -> Dict[str, Any]:
        """
        训练机器学习模型

        参数:
            data: 训练数据
            model_type: 模型类型
            target_column: 目标列名
            feature_columns: 特征列名列表
            model_name: 模型名称
            **kwargs: 模型参数

        返回:
            训练结果
        """
        if data.empty:
            logger.warning("训练数据为空，无法训练模型")
            return {
                'success': False,
                'message': "训练数据为空",
                'metrics': {}
            }

        try:
            # 准备特征和目标
            X = data[feature_columns].values
            y = data[target_column].values

            # 特征缩放
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)

            # 划分训练集和测试集
            train_size = int(len(X) * 0.8)
            X_train, X_test = X_scaled[:train_size], X_scaled[train_size:]
            y_train, y_test = y[:train_size], y[train_size:]

            # 创建模型
            model = self._create_model(model_type, **kwargs)

            # 训练模型
            if model_type in [ModelType.LSTM, ModelType.GRU]:
                # 重塑数据为3D格式 [样本数, 时间步, 特征数]
                lookback = kwargs.get('lookback', 10)
                X_train_reshaped, y_train_reshaped = self._reshape_data_for_rnn(X_train, y_train, lookback)
                X_test_reshaped, y_test_reshaped = self._reshape_data_for_rnn(X_test, y_test, lookback)

                # 训练RNN模型
                model.fit(X_train_reshaped, y_train_reshaped,
                         epochs=kwargs.get('epochs', 50),
                         batch_size=kwargs.get('batch_size', 32),
                         validation_data=(X_test_reshaped, y_test_reshaped),
                         verbose=1)

                # 评估模型 - 使用重塑后的测试数据
                y_pred = (model.predict(X_test_reshaped) > 0.5).astype(int).flatten()
                y_test_eval = y_test_reshaped  # 使用重塑后的标签

            else:
                # 训练传统模型
                model.fit(X_train, y_train)

                # 评估模型
                y_pred = model.predict(X_test)
                y_test_eval = y_test  # 使用原始标签

            # 计算评估指标
            metrics = {
                'accuracy': accuracy_score(y_test_eval, y_pred),
                'precision': precision_score(y_test_eval, y_pred, average='binary'),
                'recall': recall_score(y_test_eval, y_pred, average='binary'),
                'f1': f1_score(y_test_eval, y_pred, average='binary')
            }

            # 保存模型
            self._save_model(model, scaler, feature_columns, model_type, model_name, kwargs)

            # 更新模型字典
            self.models[model_name] = model
            self.scalers[model_name] = scaler
            self.feature_names[model_name] = feature_columns
            self.model_configs[model_name] = {
                'model_type': model_type.value,
                'feature_names': feature_columns,
                'target_column': target_column,
                'params': kwargs,
                'metrics': metrics,
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

            return {
                'success': True,
                'message': f"模型 {model_name} 训练成功",
                'metrics': metrics
            }

        except Exception as e:
            logger.error(f"训练模型失败: {e}")
            return {
                'success': False,
                'message': f"训练模型失败: {e}",
                'metrics': {}
            }

    def _create_model(self, model_type: ModelType, **kwargs) -> Any:
        """
        创建机器学习模型

        参数:
            model_type: 模型类型
            **kwargs: 模型参数

        返回:
            模型对象
        """
        if model_type == ModelType.RANDOM_FOREST:
            return RandomForestClassifier(
                n_estimators=kwargs.get('n_estimators', 100),
                max_depth=kwargs.get('max_depth', None),
                min_samples_split=kwargs.get('min_samples_split', 2),
                random_state=kwargs.get('random_state', 42)
            )
        elif model_type == ModelType.GRADIENT_BOOSTING:
            return GradientBoostingClassifier(
                n_estimators=kwargs.get('n_estimators', 100),
                learning_rate=kwargs.get('learning_rate', 0.1),
                max_depth=kwargs.get('max_depth', 3),
                random_state=kwargs.get('random_state', 42)
            )
        elif model_type == ModelType.LOGISTIC_REGRESSION:
            return LogisticRegression(
                C=kwargs.get('C', 1.0),
                penalty=kwargs.get('penalty', 'l2'),
                solver=kwargs.get('solver', 'liblinear'),
                random_state=kwargs.get('random_state', 42)
            )
        elif model_type == ModelType.SVM:
            return SVC(
                C=kwargs.get('C', 1.0),
                kernel=kwargs.get('kernel', 'rbf'),
                probability=True,
                random_state=kwargs.get('random_state', 42)
            )
        elif model_type == ModelType.LSTM and TF_AVAILABLE:
            # 创建LSTM模型
            input_shape = (kwargs.get('lookback', 10), kwargs.get('n_features', 1))
            model = Sequential()
            model.add(LSTM(units=kwargs.get('units', 50),
                          return_sequences=kwargs.get('return_sequences', False),
                          input_shape=input_shape))
            model.add(Dropout(kwargs.get('dropout', 0.2)))

            if kwargs.get('return_sequences', False):
                model.add(LSTM(units=kwargs.get('units2', 50)))
                model.add(Dropout(kwargs.get('dropout2', 0.2)))

            model.add(Dense(units=1, activation='sigmoid'))
            model.compile(optimizer=kwargs.get('optimizer', 'adam'),
                         loss=kwargs.get('loss', 'binary_crossentropy'),
                         metrics=['accuracy'])
            return model
        elif model_type == ModelType.GRU and TF_AVAILABLE:
            # 创建GRU模型
            input_shape = (kwargs.get('lookback', 10), kwargs.get('n_features', 1))
            model = Sequential()
            model.add(GRU(units=kwargs.get('units', 50),
                         return_sequences=kwargs.get('return_sequences', False),
                         input_shape=input_shape))
            model.add(Dropout(kwargs.get('dropout', 0.2)))

            if kwargs.get('return_sequences', False):
                model.add(GRU(units=kwargs.get('units2', 50)))
                model.add(Dropout(kwargs.get('dropout2', 0.2)))

            model.add(Dense(units=1, activation='sigmoid'))
            model.compile(optimizer=kwargs.get('optimizer', 'adam'),
                         loss=kwargs.get('loss', 'binary_crossentropy'),
                         metrics=['accuracy'])
            return model
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")

    def _reshape_data_for_rnn(self, X: np.ndarray, y: np.ndarray,
                             lookback: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        重塑数据为RNN模型所需的格式

        参数:
            X: 特征数据
            y: 目标数据
            lookback: 回溯时间步数

        返回:
            (重塑后的特征数据, 重塑后的目标数据)
        """
        X_reshaped = []
        y_reshaped = []

        # 确保X和y的长度一致
        min_len = min(len(X), len(y))
        X = X[:min_len]
        y = y[:min_len]

        # 修正循环范围，确保不会超出y的索引
        for i in range(min_len - lookback):
            X_reshaped.append(X[i:i+lookback])
            y_reshaped.append(y[i+lookback])

        return np.array(X_reshaped), np.array(y_reshaped)

    def _save_model(self, model: Any, scaler: Any, feature_names: List[str],
                   model_type: ModelType, model_name: str, params: Dict[str, Any]) -> None:
        """
        保存模型

        参数:
            model: 模型对象
            scaler: 特征缩放器
            feature_names: 特征名称列表
            model_type: 模型类型
            model_name: 模型名称
            params: 模型参数
        """
        try:
            # 保存模型
            if model_type in [ModelType.LSTM, ModelType.GRU]:
                model_path = os.path.join(self.model_dir, f"{model_name}.h5")
                model.save(model_path)
            else:
                model_path = os.path.join(self.model_dir, f"{model_name}.joblib")
                joblib.dump(model, model_path)

            # 保存缩放器
            if scaler is not None:
                scaler_path = os.path.join(self.model_dir, f"{model_name}_scaler.joblib")
                joblib.dump(scaler, scaler_path)

            # 保存配置
            config = {
                'model_type': model_type.value,
                'feature_names': feature_names,
                'params': params,
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

            config_path = os.path.join(self.model_dir, f"{model_name}_config.json")
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=4)

            logger.info(f"已保存模型: {model_name}")

        except Exception as e:
            logger.error(f"保存模型失败: {e}")

    def generate_signal(self, data: pd.DataFrame, model_name: str) -> Dict[str, Any]:
        """
        生成交易信号

        参数:
            data: 特征数据
            model_name: 模型名称

        返回:
            信号字典
        """
        if model_name not in self.models:
            logger.warning(f"模型 {model_name} 不存在")
            return {
                'signal': SignalType.NONE,
                'probability': 0.0,
                'confidence': 0.0
            }

        if data.empty:
            logger.warning("数据为空，无法生成信号")
            return {
                'signal': SignalType.NONE,
                'probability': 0.0,
                'confidence': 0.0
            }

        try:
            # 获取模型和配置
            model = self.models[model_name]
            scaler = self.scalers.get(model_name)
            feature_names = self.feature_names.get(model_name, [])
            config = self.model_configs.get(model_name, {})

            # 检查特征列是否存在
            if not all(feature in data.columns for feature in feature_names):
                missing_features = [f for f in feature_names if f not in data.columns]
                logger.warning(f"数据缺少特征列: {missing_features}")
                return {
                    'signal': SignalType.NONE,
                    'probability': 0.0,
                    'confidence': 0.0
                }

            # 准备特征
            X = data[feature_names].values

            # 特征缩放
            if scaler is not None:
                X = scaler.transform(X)

            # 生成预测
            model_type = ModelType(config.get('model_type', ModelType.RANDOM_FOREST.value))

            if model_type in [ModelType.LSTM, ModelType.GRU]:
                # 重塑数据为3D格式
                lookback = config.get('params', {}).get('lookback', 10)
                n_features = len(feature_names)

                # 确保有足够的数据
                if len(X) < lookback:
                    logger.warning(f"数据不足，需要至少 {lookback} 个时间步")
                    return {
                        'signal': SignalType.NONE,
                        'probability': 0.0,
                        'confidence': 0.0
                    }

                # 获取最近的lookback个时间步
                X_recent = X[-lookback:].reshape(1, lookback, n_features)

                # 预测
                probability = model.predict(X_recent)[0][0]

            else:
                # 获取最新的一行数据
                X_recent = X[-1:].reshape(1, -1)

                # 预测
                if hasattr(model, 'predict_proba'):
                    probability = model.predict_proba(X_recent)[0][1]
                else:
                    probability = model.predict(X_recent)[0]

            # 确定信号类型
            if probability > 0.7:
                signal = SignalType.BUY
                confidence = probability
            elif probability < 0.3:
                signal = SignalType.SELL
                confidence = 1 - probability
            else:
                signal = SignalType.NONE
                confidence = abs(probability - 0.5) * 2  # 距离中性点越远信心度越高

            # 限制信心度范围并添加调试信息
            confidence = max(0.0, min(1.0, confidence))

            # 添加调试日志
            if probability < 0.1 or probability > 0.9:
                logger.debug(f"ML信号: probability={probability:.3f}, signal={signal}, confidence={confidence:.3f}")

            return {
                'signal': signal,
                'probability': probability,
                'confidence': confidence
            }

        except Exception as e:
            logger.error(f"生成信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'probability': 0.0,
                'confidence': 0.0
            }
