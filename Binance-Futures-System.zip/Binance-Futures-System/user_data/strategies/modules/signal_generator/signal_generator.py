#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
信号生成器

该模块提供交易信号生成功能，整合技术指标、价格模式、机器学习和集成信号。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
import logging

from user_data.strategies.modules.signal_generator import SignalType
from user_data.strategies.modules.signal_generator.technical_signals import TechnicalSignals
from user_data.strategies.modules.signal_generator.price_patterns import PricePatternRecognizer, PatternType
from user_data.strategies.modules.signal_generator.ml_signals import MLSignalGenerator, ModelType
from user_data.strategies.modules.signal_generator.ensemble_signals import EnsembleSignalGenerator, EnsembleMethod
from user_data.strategies.utils.logging_utils import get_logger

# 获取日志记录器
logger = get_logger("signal_generator")

class SignalGenerator:
    """
    信号生成器

    整合技术指标、价格模式、机器学习和集成信号，提供全面的交易信号生成功能。
    """

    def __init__(self):
        """初始化信号生成器"""
        self.technical_signals = TechnicalSignals()
        self.pattern_recognizer = PricePatternRecognizer()
        self.ml_signals = MLSignalGenerator()
        self.ensemble_signals = EnsembleSignalGenerator()

        # 缓存数据
        self.signal_cache = {}

        logger.info("信号生成器初始化完成")

    def generate_signal(self, symbol: str, timeframe: str, data: pd.DataFrame,
                       use_ml: bool = True, use_patterns: bool = True) -> Dict[str, Any]:
        """
        生成交易信号

        参数:
            symbol: 交易对符号
            timeframe: 时间周期
            data: OHLCV数据
            use_ml: 是否使用机器学习信号
            use_patterns: 是否使用价格模式信号

        返回:
            信号字典
        """
        if data.empty:
            logger.warning(f"生成信号失败，数据为空: {symbol} {timeframe}")
            return {
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'source': 'empty_data'
            }

        # 缓存键
        key = f"{symbol}_{timeframe}"

        # 检查缓存
        if key in self.signal_cache:
            cached_signal = self.signal_cache[key]
            # 检查缓存是否过期
            if 'timestamp' in cached_signal:
                cache_time = cached_signal['timestamp']
                if isinstance(cache_time, datetime) and (datetime.now() - cache_time).total_seconds() < 60:
                    return cached_signal

        # 生成技术指标信号
        tech_signal = self.technical_signals.generate_signal(data)

        signals = [
            {
                'signal': tech_signal['signal'],
                'confidence': tech_signal['confidence'],
                'source': 'technical',
                'weight': 0.4
            }
        ]

        # 生成价格模式信号
        if use_patterns:
            pattern_signal = self.pattern_recognizer.recognize_patterns(data)
            if pattern_signal['pattern'] != PatternType.NONE:
                signals.append({
                    'signal': pattern_signal['signal'],
                    'confidence': pattern_signal['confidence'],
                    'source': 'pattern',
                    'weight': 0.3
                })

        # 生成机器学习信号
        if use_ml:
            ml_signal = self.ml_signals.predict(data)
            if ml_signal['confidence'] > 0.5:
                signals.append({
                    'signal': ml_signal['signal'],
                    'confidence': ml_signal['confidence'],
                    'source': 'ml',
                    'weight': 0.3
                })

        # 如果只有技术指标信号，直接返回
        if len(signals) == 1:
            result = {
                'signal': signals[0]['signal'],
                'confidence': signals[0]['confidence'],
                'source': signals[0]['source'],
                'timestamp': datetime.now()
            }
            self.signal_cache[key] = result
            return result

        # 生成集成信号
        ensemble_result = self.ensemble_signals.generate_ensemble_signal(
            data, method=EnsembleMethod.WEIGHTED_VOTING, signals=signals)

        # 缓存结果
        ensemble_result['timestamp'] = datetime.now()
        self.signal_cache[key] = ensemble_result

        return ensemble_result

    def get_signal_explanation(self, symbol: str, timeframe: str) -> Dict[str, Any]:
        """
        获取信号解释

        参数:
            symbol: 交易对符号
            timeframe: 时间周期

        返回:
            信号解释字典
        """
        key = f"{symbol}_{timeframe}"

        if key not in self.signal_cache:
            logger.warning(f"无法获取信号解释，信号不存在: {symbol} {timeframe}")
            return {
                'signal': SignalType.NONE,
                'explanation': '无可用信号'
            }

        signal = self.signal_cache[key]

        explanation = {
            'signal': signal['signal'],
            'confidence': signal['confidence'],
            'source': signal['source'],
            'timestamp': signal['timestamp'],
            'details': []
        }

        if 'components' in signal:
            for component in signal['components']:
                explanation['details'].append({
                    'source': component['source'],
                    'signal': component['signal'],
                    'confidence': component['confidence'],
                    'weight': component.get('weight', 1.0)
                })

        return explanation
