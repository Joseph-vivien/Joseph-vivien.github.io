#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
价格模式识别组件

该模块负责识别各种价格形态，包括头肩顶、双顶双底、三角形、楔形和旗形等。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
from scipy import signal, stats
from scipy.stats import linregress
import talib

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.signal_generator import SignalType

# 获取日志记录器
logger = get_logger("price_patterns")

class PatternType(Enum):
    """价格形态类型枚举"""
    HEAD_AND_SHOULDERS = "头肩顶"
    INVERSE_HEAD_AND_SHOULDERS = "倒头肩底"
    DOUBLE_TOP = "双顶"
    DOUBLE_BOTTOM = "双底"
    TRIPLE_TOP = "三重顶"
    TRIPLE_BOTTOM = "三重底"
    ASCENDING_TRIANGLE = "上升三角形"
    DESCENDING_TRIANGLE = "下降三角形"
    SYMMETRICAL_TRIANGLE = "对称三角形"
    RISING_WEDGE = "上升楔形"
    FALLING_WEDGE = "下降楔形"
    BULL_FLAG = "牛旗"
    BEAR_FLAG = "熊旗"
    CUP_AND_HANDLE = "杯柄形态"
    NONE = "无形态"

class PricePatternRecognizer:
    """
    价格形态识别类

    负责识别各种价格形态，包括头肩顶、双顶双底、三角形、楔形和旗形等
    """

    def __init__(self):
        """初始化价格形态识别器"""
        # 形态识别参数
        self.params = {
            # 峰谷识别参数
            'peak_distance': 5,  # 峰值之间的最小距离
            'peak_prominence': 0.005,  # 峰值突出度
            'peak_width': 2,  # 峰值宽度
            'peak_height': 0.002,  # 峰值高度

            # 形态识别参数
            'pattern_threshold': 0.8,  # 形态匹配阈值
            'pattern_lookback': 100,  # 形态识别回溯周期

            # 趋势线参数
            'min_points': 3,  # 趋势线最小点数
            'r_squared_threshold': 0.8,  # R平方阈值

            # 形态确认参数
            'volume_confirmation': True,  # 是否使用成交量确认
            'breakout_threshold': 0.01  # 突破阈值
        }

    def recognize_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        识别价格形态

        参数:
            data: OHLCV数据

        返回:
            价格形态分析结果
        """
        if data.empty or len(data) < self.params['pattern_lookback']:
            logger.warning("数据不足，无法识别价格形态")
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        try:
            # 获取最近的数据
            recent_data = data.iloc[-self.params['pattern_lookback']:].copy()

            # 识别各种形态
            patterns = []

            # 头肩顶和倒头肩底
            hs_pattern = self._check_head_and_shoulders(recent_data)
            if hs_pattern['pattern'] != PatternType.NONE:
                patterns.append(hs_pattern)

            # 双顶双底
            dt_pattern = self._check_double_patterns(recent_data)
            if dt_pattern['pattern'] != PatternType.NONE:
                patterns.append(dt_pattern)

            # 三角形
            triangle_pattern = self._check_triangle_patterns(recent_data)
            if triangle_pattern['pattern'] != PatternType.NONE:
                patterns.append(triangle_pattern)

            # 楔形
            wedge_pattern = self._check_wedge_patterns(recent_data)
            if wedge_pattern['pattern'] != PatternType.NONE:
                patterns.append(wedge_pattern)

            # 旗形
            flag_pattern = self._check_flag_patterns(recent_data)
            if flag_pattern['pattern'] != PatternType.NONE:
                patterns.append(flag_pattern)

            # 杯柄形态
            cup_pattern = self._check_cup_and_handle(recent_data)
            if cup_pattern['pattern'] != PatternType.NONE:
                patterns.append(cup_pattern)

            # 如果没有识别到形态
            if not patterns:
                return {
                    'pattern': PatternType.NONE,
                    'signal': SignalType.NONE,
                    'confidence': 0.0,
                    'start_idx': 0,
                    'end_idx': 0,
                    'target_price': 0.0
                }

            # 选择置信度最高的形态
            best_pattern = max(patterns, key=lambda x: x['confidence'])

            return best_pattern

        except Exception as e:
            logger.error(f"识别价格形态失败: {e}")
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

    def _find_peaks_and_valleys(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        查找价格的峰和谷

        参数:
            data: OHLCV数据

        返回:
            (峰索引数组, 谷索引数组)
        """
        # 获取价格数据
        prices = data['close'].values

        # 查找峰
        peaks, _ = signal.find_peaks(
            prices,
            distance=self.params['peak_distance'],
            prominence=self.params['peak_prominence'] * np.mean(prices),
            width=self.params['peak_width'],
            height=self.params['peak_height'] * np.mean(prices)
        )

        # 查找谷
        valleys, _ = signal.find_peaks(
            -prices,
            distance=self.params['peak_distance'],
            prominence=self.params['peak_prominence'] * np.mean(prices),
            width=self.params['peak_width'],
            height=self.params['peak_height'] * np.mean(prices)
        )

        return peaks, valleys

    def _check_head_and_shoulders(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查头肩顶和倒头肩底形态

        参数:
            data: OHLCV数据

        返回:
            头肩形态分析结果
        """
        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 如果峰或谷不足，无法形成头肩形态
        if len(peaks) < 3 or len(valleys) < 2:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 检查头肩顶
        for i in range(len(peaks) - 2):
            # 获取三个峰
            left_shoulder_idx = peaks[i]
            head_idx = peaks[i + 1]
            right_shoulder_idx = peaks[i + 2]

            # 获取峰值
            left_shoulder = data['close'].iloc[left_shoulder_idx]
            head = data['close'].iloc[head_idx]
            right_shoulder = data['close'].iloc[right_shoulder_idx]

            # 检查头肩顶条件
            # 1. 头部高于两肩
            # 2. 两肩高度相近
            if (head > left_shoulder and head > right_shoulder and
                abs(left_shoulder - right_shoulder) / left_shoulder < 0.1):

                # 查找颈线
                # 找到头部两侧的谷
                left_valley_candidates = [v for v in valleys if left_shoulder_idx < v < head_idx]
                right_valley_candidates = [v for v in valleys if head_idx < v < right_shoulder_idx]

                if left_valley_candidates and right_valley_candidates:
                    left_valley_idx = left_valley_candidates[-1]
                    right_valley_idx = right_valley_candidates[0]

                    left_valley = data['close'].iloc[left_valley_idx]
                    right_valley = data['close'].iloc[right_valley_idx]

                    # 颈线水平
                    neckline = (left_valley + right_valley) / 2

                    # 计算形态高度
                    height = head - neckline

                    # 检查是否已突破颈线
                    current_price = data['close'].iloc[-1]
                    breakout = current_price < neckline

                    # 计算目标价格（颈线下方的形态高度）
                    target_price = neckline - height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破颈线，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查右肩成交量是否低于头部
                        head_volume = data['volume'].iloc[head_idx]
                        right_shoulder_volume = data['volume'].iloc[right_shoulder_idx]

                        if right_shoulder_volume < head_volume:
                            confidence += 0.1

                    return {
                        'pattern': PatternType.HEAD_AND_SHOULDERS,
                        'signal': SignalType.SELL if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': left_shoulder_idx,
                        'end_idx': right_shoulder_idx,
                        'target_price': target_price
                    }

        # 检查倒头肩底
        for i in range(len(valleys) - 2):
            # 获取三个谷
            left_shoulder_idx = valleys[i]
            head_idx = valleys[i + 1]
            right_shoulder_idx = valleys[i + 2]

            # 获取谷值
            left_shoulder = data['close'].iloc[left_shoulder_idx]
            head = data['close'].iloc[head_idx]
            right_shoulder = data['close'].iloc[right_shoulder_idx]

            # 检查倒头肩底条件
            # 1. 头部低于两肩
            # 2. 两肩高度相近
            if (head < left_shoulder and head < right_shoulder and
                abs(left_shoulder - right_shoulder) / left_shoulder < 0.1):

                # 查找颈线
                # 找到头部两侧的峰
                left_peak_candidates = [p for p in peaks if left_shoulder_idx < p < head_idx]
                right_peak_candidates = [p for p in peaks if head_idx < p < right_shoulder_idx]

                if left_peak_candidates and right_peak_candidates:
                    left_peak_idx = left_peak_candidates[-1]
                    right_peak_idx = right_peak_candidates[0]

                    left_peak = data['close'].iloc[left_peak_idx]
                    right_peak = data['close'].iloc[right_peak_idx]

                    # 颈线水平
                    neckline = (left_peak + right_peak) / 2

                    # 计算形态高度
                    height = neckline - head

                    # 检查是否已突破颈线
                    current_price = data['close'].iloc[-1]
                    breakout = current_price > neckline

                    # 计算目标价格（颈线上方的形态高度）
                    target_price = neckline + height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破颈线，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查右肩成交量是否高于头部
                        head_volume = data['volume'].iloc[head_idx]
                        right_shoulder_volume = data['volume'].iloc[right_shoulder_idx]

                        if right_shoulder_volume > head_volume:
                            confidence += 0.1

                    return {
                        'pattern': PatternType.INVERSE_HEAD_AND_SHOULDERS,
                        'signal': SignalType.BUY if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': left_shoulder_idx,
                        'end_idx': right_shoulder_idx,
                        'target_price': target_price
                    }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }

    def _check_double_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查双顶双底和三重顶底形态

        参数:
            data: OHLCV数据

        返回:
            双顶双底形态分析结果
        """
        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 如果峰或谷不足，无法形成双顶双底
        if len(peaks) < 2 or len(valleys) < 1:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 检查双顶
        for i in range(len(peaks) - 1):
            # 获取两个峰
            first_peak_idx = peaks[i]
            second_peak_idx = peaks[i + 1]

            # 获取峰值
            first_peak = data['close'].iloc[first_peak_idx]
            second_peak = data['close'].iloc[second_peak_idx]

            # 检查双顶条件
            # 1. 两个峰高度相近
            # 2. 两个峰之间有足够距离
            if (abs(first_peak - second_peak) / first_peak < 0.05 and
                second_peak_idx - first_peak_idx >= self.params['peak_distance'] * 2):

                # 查找颈线
                # 找到两峰之间的谷
                valley_candidates = [v for v in valleys if first_peak_idx < v < second_peak_idx]

                if valley_candidates:
                    valley_idx = valley_candidates[0]
                    valley = data['close'].iloc[valley_idx]

                    # 颈线水平
                    neckline = valley

                    # 计算形态高度
                    height = first_peak - neckline

                    # 检查是否已突破颈线
                    current_price = data['close'].iloc[-1]
                    breakout = current_price < neckline

                    # 计算目标价格（颈线下方的形态高度）
                    target_price = neckline - height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破颈线，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查第二个峰的成交量是否低于第一个峰
                        first_volume = data['volume'].iloc[first_peak_idx]
                        second_volume = data['volume'].iloc[second_peak_idx]

                        if second_volume < first_volume:
                            confidence += 0.1

                    # 检查是否为三重顶
                    if i + 2 < len(peaks):
                        third_peak_idx = peaks[i + 2]
                        third_peak = data['close'].iloc[third_peak_idx]

                        if (abs(third_peak - first_peak) / first_peak < 0.05 and
                            third_peak_idx - second_peak_idx >= self.params['peak_distance'] * 2):

                            return {
                                'pattern': PatternType.TRIPLE_TOP,
                                'signal': SignalType.SELL if breakout else SignalType.NONE,
                                'confidence': confidence + 0.1,  # 三重顶比双顶更可靠
                                'start_idx': first_peak_idx,
                                'end_idx': third_peak_idx,
                                'target_price': target_price
                            }

                    return {
                        'pattern': PatternType.DOUBLE_TOP,
                        'signal': SignalType.SELL if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': first_peak_idx,
                        'end_idx': second_peak_idx,
                        'target_price': target_price
                    }

        # 检查双底
        for i in range(len(valleys) - 1):
            # 获取两个谷
            first_valley_idx = valleys[i]
            second_valley_idx = valleys[i + 1]

            # 获取谷值
            first_valley = data['close'].iloc[first_valley_idx]
            second_valley = data['close'].iloc[second_valley_idx]

            # 检查双底条件
            # 1. 两个谷高度相近
            # 2. 两个谷之间有足够距离
            if (abs(first_valley - second_valley) / first_valley < 0.05 and
                second_valley_idx - first_valley_idx >= self.params['peak_distance'] * 2):

                # 查找颈线
                # 找到两谷之间的峰
                peak_candidates = [p for p in peaks if first_valley_idx < p < second_valley_idx]

                if peak_candidates:
                    peak_idx = peak_candidates[0]
                    peak = data['close'].iloc[peak_idx]

                    # 颈线水平
                    neckline = peak

                    # 计算形态高度
                    height = neckline - first_valley

                    # 检查是否已突破颈线
                    current_price = data['close'].iloc[-1]
                    breakout = current_price > neckline

                    # 计算目标价格（颈线上方的形态高度）
                    target_price = neckline + height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破颈线，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查第二个谷的成交量是否高于第一个谷
                        first_volume = data['volume'].iloc[first_valley_idx]
                        second_volume = data['volume'].iloc[second_valley_idx]

                        if second_volume > first_volume:
                            confidence += 0.1

                    # 检查是否为三重底
                    if i + 2 < len(valleys):
                        third_valley_idx = valleys[i + 2]
                        third_valley = data['close'].iloc[third_valley_idx]

                        if (abs(third_valley - first_valley) / first_valley < 0.05 and
                            third_valley_idx - second_valley_idx >= self.params['peak_distance'] * 2):

                            return {
                                'pattern': PatternType.TRIPLE_BOTTOM,
                                'signal': SignalType.BUY if breakout else SignalType.NONE,
                                'confidence': confidence + 0.1,  # 三重底比双底更可靠
                                'start_idx': first_valley_idx,
                                'end_idx': third_valley_idx,
                                'target_price': target_price
                            }

                    return {
                        'pattern': PatternType.DOUBLE_BOTTOM,
                        'signal': SignalType.BUY if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': first_valley_idx,
                        'end_idx': second_valley_idx,
                        'target_price': target_price
                    }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }

    def _check_triangle_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查三角形形态

        参数:
            data: OHLCV数据

        返回:
            三角形形态分析结果
        """
        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 如果峰或谷不足，无法形成三角形
        if len(peaks) < 2 or len(valleys) < 2:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 检查上升三角形
        # 上升三角形特征：底部抬升，顶部水平
        if len(valleys) >= 2 and len(peaks) >= 2:
            # 获取最近的两个谷
            valley1_idx = valleys[-2]
            valley2_idx = valleys[-1]

            # 获取最近的两个峰
            peak1_idx = peaks[-2]
            peak2_idx = peaks[-1]

            # 确保峰谷顺序合理
            if valley1_idx < peak1_idx < valley2_idx < peak2_idx:
                # 获取谷值和峰值
                valley1 = data['close'].iloc[valley1_idx]
                valley2 = data['close'].iloc[valley2_idx]
                peak1 = data['close'].iloc[peak1_idx]
                peak2 = data['close'].iloc[peak2_idx]

                # 检查上升三角形条件
                # 1. 底部抬升（第二个谷高于第一个谷）
                # 2. 顶部水平（两个峰高度相近）
                if (valley2 > valley1 * 1.01 and  # 底部抬升
                    abs(peak2 - peak1) / peak1 < 0.03):  # 顶部水平

                    # 计算上升趋势线
                    slope = (valley2 - valley1) / (valley2_idx - valley1_idx)
                    intercept = valley1 - slope * valley1_idx

                    # 计算当前趋势线位置
                    current_idx = len(data) - 1
                    trend_line_value = slope * current_idx + intercept

                    # 计算阻力位（顶部水平线）
                    resistance = (peak1 + peak2) / 2

                    # 计算形态高度
                    height = resistance - trend_line_value

                    # 检查是否已突破阻力位
                    current_price = data['close'].iloc[-1]
                    breakout = current_price > resistance

                    # 计算目标价格（形态高度加到突破点）
                    target_price = resistance + height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破阻力位，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查突破时的成交量是否放大
                        avg_volume = data['volume'].iloc[-10:-1].mean()
                        current_volume = data['volume'].iloc[-1]

                        if current_volume > avg_volume * 1.5:
                            confidence += 0.1

                    return {
                        'pattern': PatternType.ASCENDING_TRIANGLE,
                        'signal': SignalType.BUY if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': valley1_idx,
                        'end_idx': peak2_idx,
                        'target_price': target_price
                    }

        # 检查下降三角形
        # 下降三角形特征：顶部下降，底部水平
        if len(peaks) >= 2 and len(valleys) >= 2:
            # 获取最近的两个峰
            peak1_idx = peaks[-2]
            peak2_idx = peaks[-1]

            # 获取最近的两个谷
            valley1_idx = valleys[-2]
            valley2_idx = valleys[-1]

            # 确保峰谷顺序合理
            if peak1_idx < valley1_idx < peak2_idx < valley2_idx:
                # 获取峰值和谷值
                peak1 = data['close'].iloc[peak1_idx]
                peak2 = data['close'].iloc[peak2_idx]
                valley1 = data['close'].iloc[valley1_idx]
                valley2 = data['close'].iloc[valley2_idx]

                # 检查下降三角形条件
                # 1. 顶部下降（第二个峰低于第一个峰）
                # 2. 底部水平（两个谷高度相近）
                if (peak2 < peak1 * 0.99 and  # 顶部下降
                    abs(valley2 - valley1) / valley1 < 0.03):  # 底部水平

                    # 计算下降趋势线
                    slope = (peak2 - peak1) / (peak2_idx - peak1_idx)
                    intercept = peak1 - slope * peak1_idx

                    # 计算当前趋势线位置
                    current_idx = len(data) - 1
                    trend_line_value = slope * current_idx + intercept

                    # 计算支撑位（底部水平线）
                    support = (valley1 + valley2) / 2

                    # 计算形态高度
                    height = trend_line_value - support

                    # 检查是否已突破支撑位
                    current_price = data['close'].iloc[-1]
                    breakout = current_price < support

                    # 计算目标价格（形态高度从突破点减去）
                    target_price = support - height

                    # 计算置信度
                    confidence = 0.7

                    # 如果已突破支撑位，增加置信度
                    if breakout:
                        confidence += 0.2

                    # 如果成交量确认，增加置信度
                    if self.params['volume_confirmation'] and 'volume' in data.columns:
                        # 检查突破时的成交量是否放大
                        avg_volume = data['volume'].iloc[-10:-1].mean()
                        current_volume = data['volume'].iloc[-1]

                        if current_volume > avg_volume * 1.5:
                            confidence += 0.1

                    return {
                        'pattern': PatternType.DESCENDING_TRIANGLE,
                        'signal': SignalType.SELL if breakout else SignalType.NONE,
                        'confidence': confidence,
                        'start_idx': peak1_idx,
                        'end_idx': valley2_idx,
                        'target_price': target_price
                    }

        # 检查对称三角形
        # 对称三角形特征：顶部下降，底部抬升，逐渐收敛
        if len(peaks) >= 2 and len(valleys) >= 2:
            # 获取最近的两个峰
            peak1_idx = peaks[-2]
            peak2_idx = peaks[-1]

            # 获取最近的两个谷
            valley1_idx = valleys[-2]
            valley2_idx = valleys[-1]

            # 获取峰值和谷值
            peak1 = data['close'].iloc[peak1_idx]
            peak2 = data['close'].iloc[peak2_idx]
            valley1 = data['close'].iloc[valley1_idx]
            valley2 = data['close'].iloc[valley2_idx]

            # 检查对称三角形条件
            # 1. 顶部下降（第二个峰低于第一个峰）
            # 2. 底部抬升（第二个谷高于第一个谷）
            if (peak2 < peak1 * 0.99 and  # 顶部下降
                valley2 > valley1 * 1.01):  # 底部抬升

                # 计算上升趋势线
                up_slope = (valley2 - valley1) / (valley2_idx - valley1_idx)
                up_intercept = valley1 - up_slope * valley1_idx

                # 计算下降趋势线
                down_slope = (peak2 - peak1) / (peak2_idx - peak1_idx)
                down_intercept = peak1 - down_slope * peak1_idx

                # 计算当前趋势线位置
                current_idx = len(data) - 1
                up_trend_line = up_slope * current_idx + up_intercept
                down_trend_line = down_slope * current_idx + down_intercept

                # 计算形态高度（在形态开始处）
                start_idx = min(peak1_idx, valley1_idx)
                height = peak1 - valley1

                # 检查是否已突破趋势线
                current_price = data['close'].iloc[-1]
                breakout_up = current_price > down_trend_line
                breakout_down = current_price < up_trend_line

                # 计算目标价格（形态高度加到或减去突破点）
                if breakout_up:
                    target_price = down_trend_line + height
                    signal = SignalType.BUY
                elif breakout_down:
                    target_price = up_trend_line - height
                    signal = SignalType.SELL
                else:
                    target_price = (up_trend_line + down_trend_line) / 2
                    signal = SignalType.NONE

                # 计算置信度
                confidence = 0.7

                # 如果已突破趋势线，增加置信度
                if breakout_up or breakout_down:
                    confidence += 0.2

                # 如果成交量确认，增加置信度
                if self.params['volume_confirmation'] and 'volume' in data.columns:
                    # 检查突破时的成交量是否放大
                    avg_volume = data['volume'].iloc[-10:-1].mean()
                    current_volume = data['volume'].iloc[-1]

                    if current_volume > avg_volume * 1.5:
                        confidence += 0.1

                return {
                    'pattern': PatternType.SYMMETRICAL_TRIANGLE,
                    'signal': signal,
                    'confidence': confidence,
                    'start_idx': start_idx,
                    'end_idx': max(peak2_idx, valley2_idx),
                    'target_price': target_price
                }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }

    def _check_wedge_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查楔形形态

        参数:
            data: OHLCV数据

        返回:
            楔形形态分析结果
        """
        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 如果峰或谷不足，无法形成楔形
        if len(peaks) < 2 or len(valleys) < 2:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 检查上升楔形
        # 上升楔形特征：顶部和底部都上升，但底部上升速度更快，两条趋势线逐渐收敛
        if len(peaks) >= 2 and len(valleys) >= 2:
            # 获取最近的两个峰
            peak1_idx = peaks[-2]
            peak2_idx = peaks[-1]

            # 获取最近的两个谷
            valley1_idx = valleys[-2]
            valley2_idx = valleys[-1]

            # 获取峰值和谷值
            peak1 = data['close'].iloc[peak1_idx]
            peak2 = data['close'].iloc[peak2_idx]
            valley1 = data['close'].iloc[valley1_idx]
            valley2 = data['close'].iloc[valley2_idx]

            # 检查上升楔形条件
            # 1. 顶部上升（第二个峰高于第一个峰）
            # 2. 底部上升（第二个谷高于第一个谷）
            # 3. 底部上升速度快于顶部
            if (peak2 > peak1 * 1.01 and  # 顶部上升
                valley2 > valley1 * 1.01 and  # 底部上升
                (valley2 - valley1) / valley1 > (peak2 - peak1) / peak1):  # 底部上升速度更快

                # 计算上升趋势线（底部）
                up_slope = (valley2 - valley1) / (valley2_idx - valley1_idx)
                up_intercept = valley1 - up_slope * valley1_idx

                # 计算上升趋势线（顶部）
                top_slope = (peak2 - peak1) / (peak2_idx - peak1_idx)
                top_intercept = peak1 - top_slope * peak1_idx

                # 计算当前趋势线位置
                current_idx = len(data) - 1
                up_trend_line = up_slope * current_idx + up_intercept
                top_trend_line = top_slope * current_idx + top_intercept

                # 计算形态高度（在当前位置）
                height = top_trend_line - up_trend_line

                # 检查是否已突破底部趋势线
                current_price = data['close'].iloc[-1]
                breakout = current_price < up_trend_line

                # 计算目标价格（回撤到形态起始点）
                # 上升楔形通常是看跌形态，突破后目标价格为形态起始点
                start_idx = min(peak1_idx, valley1_idx)
                start_price = data['close'].iloc[start_idx]
                target_price = start_price

                # 计算置信度
                confidence = 0.7

                # 如果已突破趋势线，增加置信度
                if breakout:
                    confidence += 0.2

                # 如果成交量确认，增加置信度
                if self.params['volume_confirmation'] and 'volume' in data.columns:
                    # 检查楔形形成过程中成交量是否递减
                    volume_trend = np.polyfit(range(len(data.iloc[-20:]['volume'])),
                                             data.iloc[-20:]['volume'], 1)[0]

                    if volume_trend < 0:
                        confidence += 0.1

                return {
                    'pattern': PatternType.RISING_WEDGE,
                    'signal': SignalType.SELL if breakout else SignalType.NONE,
                    'confidence': confidence,
                    'start_idx': start_idx,
                    'end_idx': max(peak2_idx, valley2_idx),
                    'target_price': target_price
                }

        # 检查下降楔形
        # 下降楔形特征：顶部和底部都下降，但顶部下降速度更快，两条趋势线逐渐收敛
        if len(peaks) >= 2 and len(valleys) >= 2:
            # 获取最近的两个峰
            peak1_idx = peaks[-2]
            peak2_idx = peaks[-1]

            # 获取最近的两个谷
            valley1_idx = valleys[-2]
            valley2_idx = valleys[-1]

            # 获取峰值和谷值
            peak1 = data['close'].iloc[peak1_idx]
            peak2 = data['close'].iloc[peak2_idx]
            valley1 = data['close'].iloc[valley1_idx]
            valley2 = data['close'].iloc[valley2_idx]

            # 检查下降楔形条件
            # 1. 顶部下降（第二个峰低于第一个峰）
            # 2. 底部下降（第二个谷低于第一个谷）
            # 3. 顶部下降速度快于底部
            if (peak2 < peak1 * 0.99 and  # 顶部下降
                valley2 < valley1 * 0.99 and  # 底部下降
                (peak1 - peak2) / peak1 > (valley1 - valley2) / valley1):  # 顶部下降速度更快

                # 计算下降趋势线（顶部）
                top_slope = (peak2 - peak1) / (peak2_idx - peak1_idx)
                top_intercept = peak1 - top_slope * peak1_idx

                # 计算下降趋势线（底部）
                bottom_slope = (valley2 - valley1) / (valley2_idx - valley1_idx)
                bottom_intercept = valley1 - bottom_slope * valley1_idx

                # 计算当前趋势线位置
                current_idx = len(data) - 1
                top_trend_line = top_slope * current_idx + top_intercept
                bottom_trend_line = bottom_slope * current_idx + bottom_intercept

                # 计算形态高度（在当前位置）
                height = top_trend_line - bottom_trend_line

                # 检查是否已突破顶部趋势线
                current_price = data['close'].iloc[-1]
                breakout = current_price > top_trend_line

                # 计算目标价格（反弹到形态起始点）
                # 下降楔形通常是看涨形态，突破后目标价格为形态起始点
                start_idx = min(peak1_idx, valley1_idx)
                start_price = data['close'].iloc[start_idx]
                target_price = start_price

                # 计算置信度
                confidence = 0.7

                # 如果已突破趋势线，增加置信度
                if breakout:
                    confidence += 0.2

                # 如果成交量确认，增加置信度
                if self.params['volume_confirmation'] and 'volume' in data.columns:
                    # 检查楔形形成过程中成交量是否递减
                    volume_trend = np.polyfit(range(len(data.iloc[-20:]['volume'])),
                                             data.iloc[-20:]['volume'], 1)[0]

                    if volume_trend < 0:
                        confidence += 0.1

                return {
                    'pattern': PatternType.FALLING_WEDGE,
                    'signal': SignalType.BUY if breakout else SignalType.NONE,
                    'confidence': confidence,
                    'start_idx': start_idx,
                    'end_idx': max(peak2_idx, valley2_idx),
                    'target_price': target_price
                }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }

    def _check_flag_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查旗形和三角旗形态

        参数:
            data: OHLCV数据

        返回:
            旗形形态分析结果
        """
        # 如果数据不足，无法形成旗形
        if len(data) < 20:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 检查旗杆
        # 旗杆是一段强劲的单向走势
        pole_length = 10  # 旗杆长度
        if len(data) < pole_length + 5:  # 确保有足够的数据形成旗杆和旗帜
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 检查看涨旗形（旗杆向上，旗帜向下整理）
        pole_start_idx = len(data) - pole_length - 10
        pole_end_idx = pole_start_idx + pole_length

        pole_start_price = data['close'].iloc[pole_start_idx]
        pole_end_price = data['close'].iloc[pole_end_idx]

        # 检查是否有强劲的上涨旗杆
        if pole_end_price > pole_start_price * 1.05:  # 旗杆至少上涨5%
            # 检查旗帜部分是否为下降通道或三角形
            flag_start_idx = pole_end_idx
            flag_end_idx = len(data) - 1

            # 获取旗帜部分的数据
            flag_data = data.iloc[flag_start_idx:flag_end_idx+1]

            # 检查旗帜是否为下降通道（矩形旗）
            if len(flag_data) >= 5:
                # 计算旗帜部分的线性回归
                x = np.arange(len(flag_data))
                y = flag_data['close'].values
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

                # 检查是否为下降通道
                if slope < 0 and abs(r_value) > 0.6:
                    # 计算通道上下轨
                    regression_line = slope * x + intercept
                    residuals = y - regression_line
                    channel_width = 2 * np.std(residuals)

                    upper_channel = regression_line + channel_width
                    lower_channel = regression_line - channel_width

                    # 检查价格是否在通道内波动
                    in_channel = np.logical_and(y <= upper_channel, y >= lower_channel)
                    if np.mean(in_channel) > 0.8:  # 80%的价格在通道内
                        # 检查是否已突破通道上轨
                        current_price = data['close'].iloc[-1]
                        expected_regression = slope * (len(flag_data) - 1) + intercept
                        breakout = current_price > expected_regression + channel_width

                        if breakout:
                            # 计算目标价格（旗杆高度加到突破点）
                            pole_height = pole_end_price - pole_start_price
                            target_price = current_price + pole_height

                            return {
                                'pattern': PatternType.FLAG,
                                'signal': SignalType.BUY,
                                'confidence': 0.8,
                                'start_idx': pole_start_idx,
                                'end_idx': flag_end_idx,
                                'target_price': target_price
                            }
                        else:
                            # 潜在的旗形，但尚未突破
                            return {
                                'pattern': PatternType.FLAG,
                                'signal': SignalType.NONE,
                                'confidence': 0.6,
                                'start_idx': pole_start_idx,
                                'end_idx': flag_end_idx,
                                'target_price': expected_regression + channel_width + (pole_end_price - pole_start_price)
                            }

                # 检查是否为三角旗
                elif len(peaks) >= 2 and len(valleys) >= 2:
                    # 获取旗帜部分的峰和谷
                    flag_peaks = [p for p in peaks if p >= flag_start_idx]
                    flag_valleys = [v for v in valleys if v >= flag_start_idx]

                    if len(flag_peaks) >= 2 and len(flag_valleys) >= 2:
                        # 获取最近的两个峰
                        peak1_idx = flag_peaks[-2]
                        peak2_idx = flag_peaks[-1]

                        # 获取最近的两个谷
                        valley1_idx = flag_valleys[-2]
                        valley2_idx = flag_valleys[-1]

                        # 获取峰值和谷值
                        peak1 = data['close'].iloc[peak1_idx]
                        peak2 = data['close'].iloc[peak2_idx]
                        valley1 = data['close'].iloc[valley1_idx]
                        valley2 = data['close'].iloc[valley2_idx]

                        # 检查三角旗条件
                        # 1. 顶部下降（第二个峰低于第一个峰）
                        # 2. 底部上升（第二个谷高于第一个谷）
                        if peak2 < peak1 and valley2 > valley1:
                            # 计算上升趋势线（底部）
                            up_slope = (valley2 - valley1) / (valley2_idx - valley1_idx)
                            up_intercept = valley1 - up_slope * valley1_idx

                            # 计算下降趋势线（顶部）
                            down_slope = (peak2 - peak1) / (peak2_idx - peak1_idx)
                            down_intercept = peak1 - down_slope * peak1_idx

                            # 计算当前趋势线位置
                            current_idx = len(data) - 1
                            up_trend_line = up_slope * current_idx + up_intercept
                            down_trend_line = down_slope * current_idx + down_intercept

                            # 检查是否已突破上轨
                            current_price = data['close'].iloc[-1]
                            breakout = current_price > down_trend_line

                            if breakout:
                                # 计算目标价格（旗杆高度加到突破点）
                                pole_height = pole_end_price - pole_start_price
                                target_price = current_price + pole_height

                                return {
                                    'pattern': PatternType.PENNANT,
                                    'signal': SignalType.BUY,
                                    'confidence': 0.8,
                                    'start_idx': pole_start_idx,
                                    'end_idx': flag_end_idx,
                                    'target_price': target_price
                                }
                            else:
                                # 潜在的三角旗，但尚未突破
                                return {
                                    'pattern': PatternType.PENNANT,
                                    'signal': SignalType.NONE,
                                    'confidence': 0.6,
                                    'start_idx': pole_start_idx,
                                    'end_idx': flag_end_idx,
                                    'target_price': down_trend_line + (pole_end_price - pole_start_price)
                                }

        # 检查看跌旗形（旗杆向下，旗帜向上整理）
        if pole_end_price < pole_start_price * 0.95:  # 旗杆至少下跌5%
            # 检查旗帜部分是否为上升通道或三角形
            flag_start_idx = pole_end_idx
            flag_end_idx = len(data) - 1

            # 获取旗帜部分的数据
            flag_data = data.iloc[flag_start_idx:flag_end_idx+1]

            # 检查旗帜是否为上升通道（矩形旗）
            if len(flag_data) >= 5:
                # 计算旗帜部分的线性回归
                x = np.arange(len(flag_data))
                y = flag_data['close'].values
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

                # 检查是否为上升通道
                if slope > 0 and abs(r_value) > 0.6:
                    # 计算通道上下轨
                    regression_line = slope * x + intercept
                    residuals = y - regression_line
                    channel_width = 2 * np.std(residuals)

                    upper_channel = regression_line + channel_width
                    lower_channel = regression_line - channel_width

                    # 检查价格是否在通道内波动
                    in_channel = np.logical_and(y <= upper_channel, y >= lower_channel)
                    if np.mean(in_channel) > 0.8:  # 80%的价格在通道内
                        # 检查是否已突破通道下轨
                        current_price = data['close'].iloc[-1]
                        expected_regression = slope * (len(flag_data) - 1) + intercept
                        breakout = current_price < expected_regression - channel_width

                        if breakout:
                            # 计算目标价格（旗杆高度从突破点减去）
                            pole_height = pole_start_price - pole_end_price
                            target_price = current_price - pole_height

                            return {
                                'pattern': PatternType.FLAG,
                                'signal': SignalType.SELL,
                                'confidence': 0.8,
                                'start_idx': pole_start_idx,
                                'end_idx': flag_end_idx,
                                'target_price': target_price
                            }
                        else:
                            # 潜在的旗形，但尚未突破
                            return {
                                'pattern': PatternType.FLAG,
                                'signal': SignalType.NONE,
                                'confidence': 0.6,
                                'start_idx': pole_start_idx,
                                'end_idx': flag_end_idx,
                                'target_price': expected_regression - channel_width - (pole_start_price - pole_end_price)
                            }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }

    def _check_cup_and_handle(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查杯柄形态

        参数:
            data: OHLCV数据

        返回:
            杯柄形态分析结果
        """
        # 如果数据不足，无法形成杯柄形态
        if len(data) < 30:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 查找峰和谷
        peaks, valleys = self._find_peaks_and_valleys(data)

        # 杯柄形态需要至少3个峰和2个谷
        if len(peaks) < 3 or len(valleys) < 2:
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 获取最近的三个峰和两个谷
        peak1_idx = peaks[-3]
        peak2_idx = peaks[-2]
        peak3_idx = peaks[-1]

        valley1_idx = valleys[-2]
        valley2_idx = valleys[-1]

        # 确保峰谷顺序合理（左峰-谷-右峰-谷-最新峰）
        if not (peak1_idx < valley1_idx < peak2_idx < valley2_idx < peak3_idx):
            return {
                'pattern': PatternType.NONE,
                'signal': SignalType.NONE,
                'confidence': 0.0,
                'start_idx': 0,
                'end_idx': 0,
                'target_price': 0.0
            }

        # 获取峰值和谷值
        peak1 = data['close'].iloc[peak1_idx]
        peak2 = data['close'].iloc[peak2_idx]
        peak3 = data['close'].iloc[peak3_idx]

        valley1 = data['close'].iloc[valley1_idx]
        valley2 = data['close'].iloc[valley2_idx]

        # 检查杯柄形态条件
        # 1. 左右峰高度相近（杯口水平）
        # 2. 中间谷形成杯底
        # 3. 右侧谷形成柄
        # 4. 柄的深度小于杯的深度
        if (abs(peak1 - peak2) / peak1 < 0.05 and  # 杯口水平
            valley1 < min(peak1, peak2) * 0.9 and  # 杯底足够深
            valley2 > valley1 and  # 柄高于杯底
            valley2 < peak2 and  # 柄低于杯口
            peak3 > peak2):  # 最新峰突破杯口

            # 计算杯的深度
            cup_depth = min(peak1, peak2) - valley1

            # 计算柄的深度
            handle_depth = peak2 - valley2

            # 检查柄的深度是否小于杯的深度
            if handle_depth < cup_depth * 0.7:
                # 计算目标价格（杯深度加到突破点）
                target_price = peak2 + cup_depth

                # 检查是否已突破杯口
                current_price = data['close'].iloc[-1]
                breakout = current_price > peak2

                # 计算置信度
                confidence = 0.7

                # 如果已突破杯口，增加置信度
                if breakout:
                    confidence += 0.2

                # 如果成交量确认，增加置信度
                if self.params['volume_confirmation'] and 'volume' in data.columns:
                    # 检查突破时的成交量是否放大
                    avg_volume = data['volume'].iloc[peak2_idx:peak3_idx].mean()
                    breakout_volume = data['volume'].iloc[peak3_idx]

                    if breakout_volume > avg_volume * 1.5:
                        confidence += 0.1

                return {
                    'pattern': PatternType.CUP_AND_HANDLE,
                    'signal': SignalType.BUY if breakout else SignalType.NONE,
                    'confidence': confidence,
                    'start_idx': peak1_idx,
                    'end_idx': peak3_idx,
                    'target_price': target_price
                }

        return {
            'pattern': PatternType.NONE,
            'signal': SignalType.NONE,
            'confidence': 0.0,
            'start_idx': 0,
            'end_idx': 0,
            'target_price': 0.0
        }