#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
技术指标信号组件

该模块负责基于各种技术指标生成交易信号，包括趋势指标、动量指标、波动指标和成交量指标。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum
import talib

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.signal_generator import SignalType

# 获取日志记录器
logger = get_logger("technical_signals")

class TechnicalSignals:
    """
    技术指标信号类

    负责基于各种技术指标生成交易信号
    """

    def __init__(self):
        """初始化技术指标信号生成器"""
        # 指标参数 - 针对期货5分钟交易优化
        self.params = {
            # RSI参数 - 更敏感的设置
            'rsi_period': 9,        # 从14降低到9，更快响应
            'rsi_oversold': 25,     # 从30降低到25，更早发现超卖
            'rsi_overbought': 75,   # 从70提高到75，更晚发现超买

            # MACD参数 - 适应短周期
            'macd_fast_period': 8,  # 从12降低到8
            'macd_slow_period': 21, # 从26降低到21
            'macd_signal_period': 6, # 从9降低到6

            # 布林带参数 - 更敏感
            'bb_period': 15,        # 从20降低到15
            'bb_dev_up': 1.8,       # 从2.0降低到1.8，更早触发
            'bb_dev_down': 1.8,     # 从2.0降低到1.8

            # 随机指标参数 - 更快响应
            'stoch_k_period': 8,    # 从5提高到8
            'stoch_d_period': 3,
            'stoch_slowing': 3,
            'stoch_oversold': 25,   # 从20提高到25
            'stoch_overbought': 75, # 从80降低到75

            # 移动平均线参数 - 适应短周期
            'sma_short': 10,        # 从20降低到10
            'sma_medium': 25,       # 从50降低到25
            'sma_long': 100,        # 从200降低到100

            # ATR参数
            'atr_period': 10,       # 从14降低到10

            # CCI参数 - 更敏感
            'cci_period': 10,       # 从14降低到10
            'cci_oversold': -120,   # 从-100降低到-120
            'cci_overbought': 120,  # 从100提高到120

            # ADX参数
            'adx_period': 10,       # 从14降低到10
            'adx_threshold': 20,    # 从25降低到20

            # 成交量参数 - 期货市场调整
            'volume_ma_period': 15, # 从20降低到15
            'volume_threshold': 1.3 # 从1.5降低到1.3，更容易触发
        }

    def check_rsi_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查RSI信号

        参数:
            data: OHLCV数据

        返回:
            RSI信号分析结果
        """
        if data.empty or len(data) < self.params['rsi_period']:
            return {'signal': SignalType.NONE, 'value': 0.0, 'strength': 0.0}

        try:
            # 计算RSI
            close = data['close'].values
            rsi = talib.RSI(close, timeperiod=self.params['rsi_period'])

            # 获取最新RSI值
            current_rsi = rsi[-1]

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0

            if current_rsi < self.params['rsi_oversold']:
                signal = SignalType.BUY
                # 信号强度与RSI值成反比
                strength = (self.params['rsi_oversold'] - current_rsi) / self.params['rsi_oversold']
            elif current_rsi > self.params['rsi_overbought']:
                signal = SignalType.SELL
                # 信号强度与RSI值成正比
                strength = (current_rsi - self.params['rsi_overbought']) / (100 - self.params['rsi_overbought'])

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {'signal': signal, 'value': current_rsi, 'strength': strength}

        except Exception as e:
            logger.error(f"检查RSI信号失败: {e}")
            return {'signal': SignalType.NONE, 'value': 0.0, 'strength': 0.0}

    def check_macd_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查MACD信号

        参数:
            data: OHLCV数据

        返回:
            MACD信号分析结果
        """
        if data.empty or len(data) < self.params['macd_slow_period'] + self.params['macd_signal_period']:
            return {'signal': SignalType.NONE, 'histogram': 0.0, 'strength': 0.0, 'crossover': False}

        try:
            # 计算MACD
            close = data['close'].values
            macd, macdsignal, macdhist = talib.MACD(
                close,
                fastperiod=self.params['macd_fast_period'],
                slowperiod=self.params['macd_slow_period'],
                signalperiod=self.params['macd_signal_period']
            )

            # 获取最新值
            current_macd = macd[-1]
            current_signal = macdsignal[-1]
            current_hist = macdhist[-1]
            prev_hist = macdhist[-2] if len(macdhist) > 1 else 0

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0
            crossover = False

            # 检查金叉
            if current_macd > current_signal and macd[-2] <= macdsignal[-2]:
                signal = SignalType.BUY
                crossover = True
                # 信号强度与柱状图大小成正比
                strength = min(abs(current_hist) / 0.01, 1.0)
            # 检查死叉
            elif current_macd < current_signal and macd[-2] >= macdsignal[-2]:
                signal = SignalType.SELL
                crossover = True
                # 信号强度与柱状图大小成正比
                strength = min(abs(current_hist) / 0.01, 1.0)
            # 检查柱状图方向
            elif current_hist > 0 and current_hist > prev_hist:
                signal = SignalType.BUY
                # 信号强度与柱状图变化成正比
                strength = min((current_hist - prev_hist) / 0.005, 1.0)
            elif current_hist < 0 and current_hist < prev_hist:
                signal = SignalType.SELL
                # 信号强度与柱状图变化成正比
                strength = min((prev_hist - current_hist) / 0.005, 1.0)

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {
                'signal': signal,
                'histogram': current_hist,
                'strength': strength,
                'crossover': crossover
            }

        except Exception as e:
            logger.error(f"检查MACD信号失败: {e}")
            return {'signal': SignalType.NONE, 'histogram': 0.0, 'strength': 0.0, 'crossover': False}

    def check_bollinger_bands_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查布林带信号

        参数:
            data: OHLCV数据

        返回:
            布林带信号分析结果
        """
        if data.empty or len(data) < self.params['bb_period']:
            return {
                'signal': SignalType.NONE,
                'width': 0.0,
                'position': 0.0,
                'strength': 0.0
            }

        try:
            # 计算布林带
            close = data['close'].values
            upperband, middleband, lowerband = talib.BBANDS(
                close,
                timeperiod=self.params['bb_period'],
                nbdevup=self.params['bb_dev_up'],
                nbdevdn=self.params['bb_dev_down'],
                matype=0
            )

            # 获取最新值
            current_close = close[-1]
            current_upper = upperband[-1]
            current_middle = middleband[-1]
            current_lower = lowerband[-1]

            # 计算布林带宽度和位置
            width = (current_upper - current_lower) / current_middle
            position = (current_close - current_lower) / (current_upper - current_lower) if current_upper > current_lower else 0.5

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0

            # 价格突破下轨（强买入信号）
            if current_close < current_lower:
                signal = SignalType.BUY
                # 突破程度越大，信号越强
                breakthrough = (current_lower - current_close) / current_lower
                strength = min(0.8 + breakthrough * 10, 1.0)
            # 价格突破上轨（强卖出信号）
            elif current_close > current_upper:
                signal = SignalType.SELL
                # 突破程度越大，信号越强
                breakthrough = (current_close - current_upper) / current_upper
                strength = min(0.8 + breakthrough * 10, 1.0)
            # 价格接近下轨且有反弹迹象
            elif position < 0.15 and data['close'].iloc[-1] > data['close'].iloc[-2]:
                signal = SignalType.BUY
                strength = 0.6 + (0.15 - position) * 2  # 越接近下轨信号越强
            # 价格接近上轨且有回落迹象
            elif position > 0.85 and data['close'].iloc[-1] < data['close'].iloc[-2]:
                signal = SignalType.SELL
                strength = 0.6 + (position - 0.85) * 2  # 越接近上轨信号越强
            # 价格回到中轨附近（趋势延续）
            elif 0.4 < position < 0.6:
                # 检查趋势方向
                if data['close'].iloc[-1] > data['close'].iloc[-3]:  # 上升趋势
                    signal = SignalType.BUY
                    strength = 0.4
                elif data['close'].iloc[-1] < data['close'].iloc[-3]:  # 下降趋势
                    signal = SignalType.SELL
                    strength = 0.4

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {
                'signal': signal,
                'width': width,
                'position': position,
                'strength': strength
            }

        except Exception as e:
            logger.error(f"检查布林带信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'width': 0.0,
                'position': 0.0,
                'strength': 0.0
            }

    def check_stochastic_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查随机指标信号

        参数:
            data: OHLCV数据

        返回:
            随机指标信号分析结果
        """
        if data.empty or len(data) < self.params['stoch_k_period'] + self.params['stoch_d_period']:
            return {
                'signal': SignalType.NONE,
                'k_value': 0.0,
                'd_value': 0.0,
                'strength': 0.0,
                'crossover': False
            }

        try:
            # 计算随机指标
            high = data['high'].values
            low = data['low'].values
            close = data['close'].values

            slowk, slowd = talib.STOCH(
                high, low, close,
                fastk_period=self.params['stoch_k_period'],
                slowk_period=self.params['stoch_slowing'],
                slowk_matype=0,
                slowd_period=self.params['stoch_d_period'],
                slowd_matype=0
            )

            # 获取最新值
            current_k = slowk[-1]
            current_d = slowd[-1]
            prev_k = slowk[-2] if len(slowk) > 1 else current_k
            prev_d = slowd[-2] if len(slowd) > 1 else current_d

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0
            crossover = False

            # 超卖区域金叉
            if current_k > current_d and prev_k <= prev_d and current_k < self.params['stoch_oversold']:
                signal = SignalType.BUY
                crossover = True
                # 信号强度与K值接近超卖区域程度成反比
                strength = min((self.params['stoch_oversold'] - current_k) / self.params['stoch_oversold'] + 0.5, 1.0)
            # 超买区域死叉
            elif current_k < current_d and prev_k >= prev_d and current_k > self.params['stoch_overbought']:
                signal = SignalType.SELL
                crossover = True
                # 信号强度与K值接近超买区域程度成正比
                strength = min((current_k - self.params['stoch_overbought']) / (100 - self.params['stoch_overbought']) + 0.5, 1.0)
            # 超卖区域
            elif current_k < self.params['stoch_oversold'] and current_k > prev_k:
                signal = SignalType.BUY
                # 信号强度与K值接近超卖区域程度成反比
                strength = min((self.params['stoch_oversold'] - current_k) / self.params['stoch_oversold'] + 0.3, 1.0)
            # 超买区域
            elif current_k > self.params['stoch_overbought'] and current_k < prev_k:
                signal = SignalType.SELL
                # 信号强度与K值接近超买区域程度成正比
                strength = min((current_k - self.params['stoch_overbought']) / (100 - self.params['stoch_overbought']) + 0.3, 1.0)

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {
                'signal': signal,
                'k_value': current_k,
                'd_value': current_d,
                'strength': strength,
                'crossover': crossover
            }

        except Exception as e:
            logger.error(f"检查随机指标信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'k_value': 0.0,
                'd_value': 0.0,
                'strength': 0.0,
                'crossover': False
            }

    def check_moving_average_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查移动平均线信号

        参数:
            data: OHLCV数据

        返回:
            移动平均线信号分析结果
        """
        if data.empty or len(data) < self.params['sma_long']:
            return {
                'signal': SignalType.NONE,
                'ma_alignment': 0,
                'price_position': 0,
                'strength': 0.0,
                'crossover': False
            }

        try:
            # 计算移动平均线
            close = data['close'].values
            sma_short = talib.SMA(close, timeperiod=self.params['sma_short'])
            sma_medium = talib.SMA(close, timeperiod=self.params['sma_medium'])
            sma_long = talib.SMA(close, timeperiod=self.params['sma_long'])

            # 获取最新值
            current_close = close[-1]
            current_short = sma_short[-1]
            current_medium = sma_medium[-1]
            current_long = sma_long[-1]

            prev_close = close[-2] if len(close) > 1 else current_close
            prev_short = sma_short[-2] if len(sma_short) > 1 else current_short

            # 计算均线排列和价格位置
            ma_alignment = 0
            if current_short > current_medium:
                ma_alignment += 1
            else:
                ma_alignment -= 1

            if current_medium > current_long:
                ma_alignment += 1
            else:
                ma_alignment -= 1

            price_position = 0
            if current_close > current_short:
                price_position += 1
            else:
                price_position -= 1

            if current_close > current_medium:
                price_position += 1
            else:
                price_position -= 1

            if current_close > current_long:
                price_position += 1
            else:
                price_position -= 1

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0
            crossover = False

            # 价格突破短期均线（强信号）
            if current_close > current_short and prev_close <= prev_short:
                signal = SignalType.BUY
                crossover = True
                # 突破幅度越大，信号越强
                breakthrough = (current_close - current_short) / current_short
                strength = min(0.7 + breakthrough * 20, 1.0)
            elif current_close < current_short and prev_close >= prev_short:
                signal = SignalType.SELL
                crossover = True
                breakthrough = (current_short - current_close) / current_short
                strength = min(0.7 + breakthrough * 20, 1.0)
            # 黄金交叉（非常强的买入信号）
            elif current_short > current_medium and sma_short[-2] <= sma_medium[-2]:
                signal = SignalType.BUY
                crossover = True
                # 交叉角度越大，信号越强
                angle = (current_short - current_medium) / current_medium
                strength = min(0.8 + angle * 50, 1.0)
            # 死亡交叉（非常强的卖出信号）
            elif current_short < current_medium and sma_short[-2] >= sma_medium[-2]:
                signal = SignalType.SELL
                crossover = True
                angle = (current_medium - current_short) / current_medium
                strength = min(0.8 + angle * 50, 1.0)
            # 均线多头排列且价格在均线上方
            elif ma_alignment >= 1 and price_position > 0.02:  # 价格至少高于均线2%
                signal = SignalType.BUY
                # 排列越强，价格位置越高，信号越强
                strength = 0.4 + (ma_alignment / 2) * 0.3 + min(price_position / 0.1, 0.3)
            # 均线空头排列且价格在均线下方
            elif ma_alignment <= -1 and price_position < -0.02:  # 价格至少低于均线2%
                signal = SignalType.SELL
                strength = 0.4 + (-ma_alignment / 2) * 0.3 + min(-price_position / 0.1, 0.3)
            # 价格远离均线后回归（反转信号）
            elif abs(price_position) > 0.05:  # 价格偏离均线超过5%
                if price_position > 0.05 and current_close < prev_close:  # 高位回落
                    signal = SignalType.SELL
                    strength = min(price_position * 5, 0.6)
                elif price_position < -0.05 and current_close > prev_close:  # 低位反弹
                    signal = SignalType.BUY
                    strength = min(-price_position * 5, 0.6)

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {
                'signal': signal,
                'ma_alignment': ma_alignment,
                'price_position': price_position,
                'strength': strength,
                'crossover': crossover
            }

        except Exception as e:
            logger.error(f"检查移动平均线信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'ma_alignment': 0,
                'price_position': 0,
                'strength': 0.0,
                'crossover': False
            }

    def check_volume_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        检查成交量信号

        参数:
            data: OHLCV数据

        返回:
            成交量信号分析结果
        """
        if data.empty or len(data) < self.params['volume_ma_period'] or 'volume' not in data.columns:
            return {
                'signal': SignalType.NONE,
                'relative_volume': 0.0,
                'strength': 0.0
            }

        try:
            # 获取成交量数据
            volume = data['volume'].values
            close = data['close'].values

            # 计算成交量移动平均线
            volume_ma = talib.SMA(volume, timeperiod=self.params['volume_ma_period'])

            # 获取最新值
            current_volume = volume[-1]
            current_volume_ma = volume_ma[-1]

            # 计算相对成交量
            relative_volume = current_volume / current_volume_ma if current_volume_ma > 0 else 1.0

            # 计算价格变化
            price_change = 0.0
            if len(close) > 1:
                price_change = (close[-1] - close[-2]) / close[-2] if close[-2] > 0 else 0.0

            # 确定信号
            signal = SignalType.NONE
            strength = 0.0

            # 成交量放大且价格上涨
            if relative_volume > self.params['volume_threshold'] and price_change > 0:
                signal = SignalType.BUY
                # 信号强度与相对成交量和价格变化成正比
                strength = min((relative_volume - 1) * 0.5 + abs(price_change) * 10, 1.0)
            # 成交量放大且价格下跌
            elif relative_volume > self.params['volume_threshold'] and price_change < 0:
                signal = SignalType.SELL
                # 信号强度与相对成交量和价格变化成正比
                strength = min((relative_volume - 1) * 0.5 + abs(price_change) * 10, 1.0)

            # 限制强度在0-1范围内
            strength = min(max(strength, 0.0), 1.0)

            return {
                'signal': signal,
                'relative_volume': relative_volume,
                'strength': strength
            }

        except Exception as e:
            logger.error(f"检查成交量信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'relative_volume': 0.0,
                'strength': 0.0
            }

    def check_all_signals(self, data: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
        """
        检查所有技术指标信号

        参数:
            data: OHLCV数据

        返回:
            所有信号分析结果
        """
        if data.empty:
            logger.warning("数据为空，无法检查信号")
            return {}

        try:
            signals = {
                'rsi': self.check_rsi_signal(data),
                'macd': self.check_macd_signal(data),
                'bollinger': self.check_bollinger_bands_signal(data),
                'stochastic': self.check_stochastic_signal(data),
                'moving_average': self.check_moving_average_signal(data),
                'volume': self.check_volume_signal(data)
            }

            return signals

        except Exception as e:
            logger.error(f"检查所有信号失败: {e}")
            return {}

    def set_parameters(self, params: Dict[str, Any]) -> None:
        """
        设置技术指标参数

        参数:
            params: 参数字典
        """
        for key, value in params.items():
            if key in self.params:
                self.params[key] = value
                logger.debug(f"设置参数 {key} = {value}")
            else:
                logger.warning(f"未知参数: {key}")

    def get_parameters(self) -> Dict[str, Any]:
        """
        获取技术指标参数

        返回:
            参数字典
        """
        return self.params.copy()

    def generate_signal(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        生成综合技术指标信号

        参数:
            data: OHLCV数据

        返回:
            综合技术指标信号
        """
        if data.empty:
            logger.warning("数据为空，无法生成技术指标信号")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'details': {}
            }

        try:
            # 获取所有技术指标信号
            signals = self.check_all_signals(data)

            if not signals:
                return {
                    'signal': SignalType.NONE,
                    'strength': 0.0,
                    'confidence': 0.0,
                    'details': {}
                }

            # 计算综合信号
            buy_score = 0.0
            sell_score = 0.0
            total_weight = 0.0

            # 各指标权重配置
            weights = {
                'rsi': 0.15,           # RSI权重15%
                'macd': 0.20,          # MACD权重20%
                'bollinger': 0.20,     # 布林带权重20%
                'stochastic': 0.10,    # 随机指标权重10%
                'moving_average': 0.25, # 移动平均线权重25%
                'volume': 0.10         # 成交量权重10%
            }

            # 计算加权得分
            for indicator, result in signals.items():
                if indicator in weights and result.get('signal') != SignalType.NONE:
                    weight = weights[indicator]
                    strength = result.get('strength', 0.0)

                    if result['signal'] == SignalType.BUY:
                        buy_score += weight * strength
                    elif result['signal'] == SignalType.SELL:
                        sell_score += weight * strength

                    total_weight += weight

            # 确定最终信号
            final_signal = SignalType.NONE
            final_strength = 0.0
            final_confidence = 0.0

            # 信号阈值
            signal_threshold = 0.3  # 30%的权重得分才产生信号

            if buy_score > signal_threshold and buy_score > sell_score:
                final_signal = SignalType.BUY
                final_strength = buy_score
                final_confidence = min(buy_score / 0.6, 1.0)  # 60%得分=100%信心度
            elif sell_score > signal_threshold and sell_score > buy_score:
                final_signal = SignalType.SELL
                final_strength = sell_score
                final_confidence = min(sell_score / 0.6, 1.0)

            # 如果信号强度差距不大，保持中性
            if abs(buy_score - sell_score) < 0.1:
                final_signal = SignalType.NONE
                final_strength = 0.0
                final_confidence = 0.0

            logger.debug(f"技术指标信号: 买入得分={buy_score:.3f} 卖出得分={sell_score:.3f} "
                        f"最终信号={final_signal} 信心度={final_confidence:.3f}")

            return {
                'signal': final_signal,
                'strength': final_strength,
                'confidence': final_confidence,
                'details': signals
            }

        except Exception as e:
            logger.error(f"生成技术指标信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'details': {}
            }
