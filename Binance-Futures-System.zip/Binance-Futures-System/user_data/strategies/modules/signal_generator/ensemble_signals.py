#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
集成信号组件

该模块负责整合多种信号源，包括技术指标信号、价格形态信号和机器学习信号，
通过加权投票或其他集成方法生成最终交易信号。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from enum import Enum

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.modules.signal_generator import SignalType
from user_data.strategies.modules.signal_generator.technical_signals import TechnicalSignals
from user_data.strategies.modules.signal_generator.price_patterns import PricePatternRecognizer, PatternType
from user_data.strategies.modules.signal_generator.ml_signals import MLSignalGenerator, ModelType

# 获取日志记录器
logger = get_logger("ensemble_signals")

class EnsembleMethod(Enum):
    """集成方法枚举"""
    WEIGHTED_VOTING = "加权投票"
    MAJORITY_VOTING = "多数投票"
    HIERARCHICAL = "层次集成"
    SEQUENTIAL = "顺序集成"

class EnsembleSignalGenerator:
    """
    集成信号生成类

    负责整合多种信号源，生成最终交易信号
    """

    def __init__(self):
        """初始化集成信号生成器"""
        # 初始化信号生成器
        self.technical_signals = TechnicalSignals()
        self.pattern_recognizer = PricePatternRecognizer()
        self.ml_signals = MLSignalGenerator()

        # 设置默认权重 - 降低ML权重，提高技术指标权重
        self.weights = {
            'technical': 0.5,  # 提高技术指标权重
            'pattern': 0.3,
            'ml': 0.2          # 降低ML权重
        }

        # 设置默认阈值
        self.thresholds = {
            'buy': 0.2,
            'sell': 0.2
        }

    def generate_ensemble_signal(self, data: pd.DataFrame,
                               method: EnsembleMethod = EnsembleMethod.WEIGHTED_VOTING,
                               ml_model_name: Optional[str] = None) -> Dict[str, Any]:
        """
        生成集成信号

        参数:
            data: OHLCV数据
            method: 集成方法
            ml_model_name: 机器学习模型名称

        返回:
            集成信号字典
        """
        if data.empty:
            logger.warning("数据为空，无法生成集成信号")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {}
            }

        try:
            # 生成各种信号
            technical_result = self._generate_technical_signals(data)
            pattern_result = self._generate_pattern_signals(data)
            ml_result = self._generate_ml_signals(data, ml_model_name)

            # 根据集成方法整合信号
            if method == EnsembleMethod.WEIGHTED_VOTING:
                ensemble_result = self._weighted_voting(technical_result, pattern_result, ml_result)
            elif method == EnsembleMethod.MAJORITY_VOTING:
                ensemble_result = self._majority_voting(technical_result, pattern_result, ml_result)
            elif method == EnsembleMethod.HIERARCHICAL:
                ensemble_result = self._hierarchical_ensemble(technical_result, pattern_result, ml_result)
            elif method == EnsembleMethod.SEQUENTIAL:
                ensemble_result = self._sequential_ensemble(technical_result, pattern_result, ml_result)
            else:
                logger.warning(f"不支持的集成方法: {method}")
                ensemble_result = self._weighted_voting(technical_result, pattern_result, ml_result)

            return ensemble_result

        except Exception as e:
            logger.error(f"生成集成信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {}
            }

    def _generate_technical_signals(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        生成技术指标信号

        参数:
            data: OHLCV数据

        返回:
            技术指标信号字典
        """
        try:
            # 检查所有技术指标信号
            signals = self.technical_signals.check_all_signals(data)

            # 统计买入和卖出信号
            buy_count = 0
            sell_count = 0
            total_strength = 0.0

            for signal_type, signal_info in signals.items():
                if signal_info['signal'] == SignalType.BUY:
                    buy_count += 1
                    total_strength += signal_info['strength']
                elif signal_info['signal'] == SignalType.SELL:
                    sell_count += 1
                    total_strength += signal_info['strength']

            # 确定最终信号
            if buy_count > sell_count:
                signal = SignalType.BUY
                strength = total_strength / max(buy_count, 1)
            elif sell_count > buy_count:
                signal = SignalType.SELL
                strength = total_strength / max(sell_count, 1)
            else:
                signal = SignalType.NONE
                strength = 0.0

            # 计算置信度
            if signal != SignalType.NONE:
                confidence = strength * (max(buy_count, sell_count) / max(len(signals), 1))
            else:
                confidence = 0.0

            return {
                'signal': signal,
                'strength': strength,
                'confidence': confidence,
                'details': signals
            }

        except Exception as e:
            logger.error(f"生成技术指标信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'details': {}
            }

    def _generate_pattern_signals(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        生成价格形态信号

        参数:
            data: OHLCV数据

        返回:
            价格形态信号字典
        """
        try:
            # 识别价格形态
            pattern = self.pattern_recognizer.recognize_patterns(data)

            # 提取信号
            signal = pattern.get('signal', SignalType.NONE)
            confidence = pattern.get('confidence', 0.0)

            return {
                'signal': signal,
                'strength': confidence,
                'confidence': confidence,
                'pattern': pattern.get('pattern', PatternType.NONE),
                'details': pattern
            }

        except Exception as e:
            logger.error(f"生成价格形态信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'pattern': PatternType.NONE,
                'details': {}
            }

    def _generate_ml_signals(self, data: pd.DataFrame,
                           model_name: Optional[str] = None) -> Dict[str, Any]:
        """
        生成机器学习信号

        参数:
            data: OHLCV数据
            model_name: 模型名称

        返回:
            机器学习信号字典
        """
        try:
            # 如果没有指定模型名称，使用所有可用模型
            if model_name is None:
                # 获取所有可用模型
                models = list(self.ml_signals.models.keys())

                if not models:
                    logger.warning("没有可用的机器学习模型")
                    return {
                        'signal': SignalType.NONE,
                        'strength': 0.0,
                        'confidence': 0.0,
                        'details': {}
                    }

                # 使用所有模型生成信号
                signals = {}
                for model in models:
                    signals[model] = self.ml_signals.generate_signal(data, model)

                # 统计买入和卖出信号
                buy_count = 0
                sell_count = 0
                total_confidence = 0.0

                for model, signal_info in signals.items():
                    if signal_info['signal'] == SignalType.BUY:
                        buy_count += 1
                        total_confidence += signal_info['confidence']
                    elif signal_info['signal'] == SignalType.SELL:
                        sell_count += 1
                        total_confidence += signal_info['confidence']

                # 确定最终信号
                if buy_count > sell_count:
                    signal = SignalType.BUY
                    confidence = total_confidence / max(buy_count, 1)
                elif sell_count > buy_count:
                    signal = SignalType.SELL
                    confidence = total_confidence / max(sell_count, 1)
                else:
                    signal = SignalType.NONE
                    confidence = 0.0

                return {
                    'signal': signal,
                    'strength': confidence,
                    'confidence': confidence,
                    'details': signals
                }

            else:
                # 使用指定模型生成信号
                signal_info = self.ml_signals.generate_signal(data, model_name)

                return {
                    'signal': signal_info['signal'],
                    'strength': signal_info['confidence'],
                    'confidence': signal_info['confidence'],
                    'details': {model_name: signal_info}
                }

        except Exception as e:
            logger.error(f"生成机器学习信号失败: {e}")
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'details': {}
            }

    def _weighted_voting(self, technical: Dict[str, Any],
                        pattern: Dict[str, Any],
                        ml: Dict[str, Any]) -> Dict[str, Any]:
        """
        加权投票集成方法

        参数:
            technical: 技术指标信号
            pattern: 价格形态信号
            ml: 机器学习信号

        返回:
            集成信号字典
        """
        # 计算买入和卖出得分
        buy_score = 0.0
        sell_score = 0.0

        # 技术指标信号
        if technical['signal'] == SignalType.BUY:
            buy_score += technical['confidence'] * self.weights['technical']
        elif technical['signal'] == SignalType.SELL:
            sell_score += technical['confidence'] * self.weights['technical']

        # 价格形态信号
        if pattern['signal'] == SignalType.BUY:
            buy_score += pattern['confidence'] * self.weights['pattern']
        elif pattern['signal'] == SignalType.SELL:
            sell_score += pattern['confidence'] * self.weights['pattern']

        # 机器学习信号 - 添加过滤机制
        ml_weight = self.weights['ml']

        # 如果ML信号过于极端（信心度>0.95），降低其权重
        if ml['confidence'] > 0.95:
            ml_weight *= 0.5  # 降低极端信号的权重
            logger.debug(f"ML信号过于极端，降低权重: confidence={ml['confidence']:.3f}")

        if ml['signal'] == SignalType.BUY:
            buy_score += ml['confidence'] * ml_weight
        elif ml['signal'] == SignalType.SELL:
            sell_score += ml['confidence'] * ml_weight

        # 确定最终信号
        if buy_score > self.thresholds['buy'] and buy_score > sell_score:
            signal = SignalType.BUY
            strength = buy_score
        elif sell_score > self.thresholds['sell'] and sell_score > buy_score:
            signal = SignalType.SELL
            strength = sell_score
        else:
            signal = SignalType.NONE
            strength = 0.0

        # 计算置信度
        confidence = max(buy_score, sell_score)

        return {
            'signal': signal,
            'strength': strength,
            'confidence': confidence,
            'components': {
                'technical': technical,
                'pattern': pattern,
                'ml': ml
            }
        }

    def _majority_voting(self, technical: Dict[str, Any],
                        pattern: Dict[str, Any],
                        ml: Dict[str, Any]) -> Dict[str, Any]:
        """
        多数投票集成方法

        参数:
            technical: 技术指标信号
            pattern: 价格形态信号
            ml: 机器学习信号

        返回:
            集成信号字典
        """
        # 统计买入和卖出信号
        signals = [technical['signal'], pattern['signal'], ml['signal']]
        buy_count = signals.count(SignalType.BUY)
        sell_count = signals.count(SignalType.SELL)

        # 确定最终信号
        if buy_count > sell_count and buy_count >= 2:
            signal = SignalType.BUY
            # 计算平均置信度
            confidence = (technical['confidence'] if technical['signal'] == SignalType.BUY else 0.0 +
                         pattern['confidence'] if pattern['signal'] == SignalType.BUY else 0.0 +
                         ml['confidence'] if ml['signal'] == SignalType.BUY else 0.0) / buy_count
        elif sell_count > buy_count and sell_count >= 2:
            signal = SignalType.SELL
            # 计算平均置信度
            confidence = (technical['confidence'] if technical['signal'] == SignalType.SELL else 0.0 +
                         pattern['confidence'] if pattern['signal'] == SignalType.SELL else 0.0 +
                         ml['confidence'] if ml['signal'] == SignalType.SELL else 0.0) / sell_count
        else:
            signal = SignalType.NONE
            confidence = 0.0

        return {
            'signal': signal,
            'strength': confidence,
            'confidence': confidence,
            'components': {
                'technical': technical,
                'pattern': pattern,
                'ml': ml
            }
        }

    def _hierarchical_ensemble(self, technical: Dict[str, Any],
                              pattern: Dict[str, Any],
                              ml: Dict[str, Any]) -> Dict[str, Any]:
        """
        层次集成方法

        参数:
            technical: 技术指标信号
            pattern: 价格形态信号
            ml: 机器学习信号

        返回:
            集成信号字典
        """
        # 层次集成逻辑：
        # 1. 首先检查价格形态信号，如果有强烈信号则采用
        # 2. 否则，检查技术指标信号，如果有强烈信号则采用
        # 3. 最后，使用机器学习信号作为确认

        signal = SignalType.NONE
        confidence = 0.0

        # 检查价格形态信号
        if pattern['signal'] != SignalType.NONE and pattern['confidence'] > 0.7:
            signal = pattern['signal']
            confidence = pattern['confidence']

            # 使用技术指标和机器学习信号进行确认
            if (technical['signal'] == signal and ml['signal'] == signal):
                # 所有信号一致，增强置信度
                confidence = min(confidence + 0.2, 1.0)
            elif (technical['signal'] == signal or ml['signal'] == signal):
                # 部分信号一致，略微增强置信度
                confidence = min(confidence + 0.1, 1.0)
            elif (technical['signal'] != SignalType.NONE and
                 technical['signal'] != signal and
                 ml['signal'] != SignalType.NONE and
                 ml['signal'] != signal):
                # 信号冲突，降低置信度
                confidence = max(confidence - 0.2, 0.0)

        # 如果没有强烈的价格形态信号，检查技术指标信号
        elif technical['signal'] != SignalType.NONE and technical['confidence'] > 0.6:
            signal = technical['signal']
            confidence = technical['confidence']

            # 使用机器学习信号进行确认
            if ml['signal'] == signal:
                # 机器学习信号一致，增强置信度
                confidence = min(confidence + 0.1, 1.0)
            elif ml['signal'] != SignalType.NONE and ml['signal'] != signal:
                # 机器学习信号冲突，降低置信度
                confidence = max(confidence - 0.1, 0.0)

        # 如果没有强烈的技术指标信号，使用机器学习信号
        elif ml['signal'] != SignalType.NONE and ml['confidence'] > 0.6:
            signal = ml['signal']
            confidence = ml['confidence']

        # 检查最终置信度是否达到阈值
        if (signal == SignalType.BUY and confidence < self.thresholds['buy']) or \
           (signal == SignalType.SELL and confidence < self.thresholds['sell']):
            signal = SignalType.NONE
            confidence = 0.0

        return {
            'signal': signal,
            'strength': confidence,
            'confidence': confidence,
            'components': {
                'technical': technical,
                'pattern': pattern,
                'ml': ml
            }
        }

    def _sequential_ensemble(self, technical: Dict[str, Any],
                            pattern: Dict[str, Any],
                            ml: Dict[str, Any]) -> Dict[str, Any]:
        """
        顺序集成方法

        参数:
            technical: 技术指标信号
            pattern: 价格形态信号
            ml: 机器学习信号

        返回:
            集成信号字典
        """
        # 顺序集成逻辑：
        # 1. 使用技术指标信号确定市场方向
        # 2. 使用价格形态信号确认入场时机
        # 3. 使用机器学习信号进行最终确认

        # 如果技术指标没有明确信号，不生成交易信号
        if technical['signal'] == SignalType.NONE or technical['confidence'] < 0.5:
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {
                    'technical': technical,
                    'pattern': pattern,
                    'ml': ml
                }
            }

        # 如果价格形态与技术指标方向不一致，不生成交易信号
        if pattern['signal'] != SignalType.NONE and pattern['signal'] != technical['signal']:
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {
                    'technical': technical,
                    'pattern': pattern,
                    'ml': ml
                }
            }

        # 如果机器学习信号与技术指标方向不一致，不生成交易信号
        if ml['signal'] != SignalType.NONE and ml['signal'] != technical['signal']:
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {
                    'technical': technical,
                    'pattern': pattern,
                    'ml': ml
                }
            }

        # 计算综合置信度
        confidence = technical['confidence']

        # 如果价格形态信号一致，增强置信度
        if pattern['signal'] == technical['signal']:
            confidence = min(confidence + pattern['confidence'] * 0.3, 1.0)

        # 如果机器学习信号一致，增强置信度
        if ml['signal'] == technical['signal']:
            confidence = min(confidence + ml['confidence'] * 0.2, 1.0)

        # 检查最终置信度是否达到阈值
        if (technical['signal'] == SignalType.BUY and confidence < self.thresholds['buy']) or \
           (technical['signal'] == SignalType.SELL and confidence < self.thresholds['sell']):
            return {
                'signal': SignalType.NONE,
                'strength': 0.0,
                'confidence': 0.0,
                'components': {
                    'technical': technical,
                    'pattern': pattern,
                    'ml': ml
                }
            }

        return {
            'signal': technical['signal'],
            'strength': confidence,
            'confidence': confidence,
            'components': {
                'technical': technical,
                'pattern': pattern,
                'ml': ml
            }
        }

    def set_weights(self, technical: float, pattern: float, ml: float) -> None:
        """
        设置信号源权重

        参数:
            technical: 技术指标权重
            pattern: 价格形态权重
            ml: 机器学习权重
        """
        # 归一化权重
        total = technical + pattern + ml
        self.weights = {
            'technical': technical / total,
            'pattern': pattern / total,
            'ml': ml / total
        }

        logger.info(f"已设置信号源权重: {self.weights}")

    def set_thresholds(self, buy: float, sell: float) -> None:
        """
        设置信号阈值

        参数:
            buy: 买入信号阈值
            sell: 卖出信号阈值
        """
        self.thresholds = {
            'buy': buy,
            'sell': sell
        }

        logger.info(f"已设置信号阈值: {self.thresholds}")
