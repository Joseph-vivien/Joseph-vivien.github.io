#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
主策略类

该模块整合了所有子模块，实现了完整的交易策略。

作者: 高级Python工程师
日期: 2024-05-21
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
import time
import json
import os

import backtrader as bt
import backtrader.indicators as btind
import backtrader.analyzers as btanalyzers

from user_data.strategies.utils.logging_utils import get_logger
from user_data.strategies.utils.config_manager import get_config_manager
from user_data.strategies.modules.market_analyzer import MarketAnalyzer, MarketState
from user_data.strategies.modules.market_analyzer.trend_analyzer import TrendAnalyzer
from user_data.strategies.modules.market_analyzer.volatility_analyzer import VolatilityAnalyzer
from user_data.strategies.modules.market_analyzer.volume_analyzer import VolumeAnalyzer
from user_data.strategies.modules.signal_generator import SignalGenerator, SignalType
from user_data.strategies.modules.signal_generator.technical_signals import TechnicalSignals
from user_data.strategies.modules.signal_generator.price_patterns import PricePatternRecognizer, PatternType
from user_data.strategies.modules.signal_generator.ml_signals import MLSignalGenerator, ModelType
from user_data.strategies.modules.signal_generator.ensemble_signals import EnsembleSignalGenerator, EnsembleMethod
from user_data.strategies.modules.risk_manager import RiskManager, PositionSizing, RiskLevel
from user_data.strategies.modules.risk_manager.global_risk_monitor import GlobalRiskMonitor, SystemRiskLevel
from user_data.strategies.modules.risk_manager.position_risk_calculator import PositionRiskCalculator
from user_data.strategies.modules.risk_manager.stop_loss_manager import StopLossManager, StopLossType
from user_data.strategies.modules.leverage_manager import LeverageManager
from user_data.strategies.modules.leverage_manager.fixed_leverage import FixedLeverage
from user_data.strategies.modules.position_manager import PositionManager
from user_data.strategies.modules.position_manager.entry_manager import EntryManager
from user_data.strategies.modules.position_manager.exit_manager import ExitManager
from user_data.strategies.modules.position_manager.size_calculator import SizeCalculator
from user_data.strategies.modules.execution.order_executor import OrderExecutor
from user_data.strategies.modules.execution.api_manager import ApiManager
from user_data.strategies.modules.execution.latency_optimizer import LatencyOptimizer
from user_data.strategies.utils.visualization import Visualizer

# 获取日志记录器
logger = get_logger("master_strategy")

class MasterStrategy(bt.Strategy):
    """
    主策略类

    整合所有子模块，实现完整的交易策略
    """

    # 策略参数
    params = (
        # 技术指标参数（与TechnicalSignals保持一致）
        ('rsi_period', 9),
        ('rsi_overbought', 75),
        ('rsi_oversold', 25),
        ('ema_short', 10),
        ('ema_long', 25),
        ('bb_period', 15),
        ('bb_dev', 1.8),
        ('macd_fast_period', 8),
        ('macd_slow_period', 21),
        ('macd_signal_period', 6),
        ('sma_short', 10),
        ('sma_medium', 25),
        ('sma_long', 100),

        # 交易参数
        ('atr_period', 10),
        ('atr_multiplier', 2.0),
        ('stoploss', -0.005),  # 0.5%止损
        ('risk_per_trade', 0.02),
        ('trailing_stop', True),
        ('trailing_stop_positive', 0.01),
        ('trailing_stop_positive_offset', 0.02),
        ('use_custom_stoploss', True),
    )

    def __init__(self):
        """
        初始化策略
        """
        super(MasterStrategy, self).__init__()

        # 初始化指标
        self.rsi = btind.RSI(self.data.close, period=self.params.rsi_period)
        self.ema_short = btind.EMA(self.data.close, period=self.params.ema_short)
        self.ema_long = btind.EMA(self.data.close, period=self.params.ema_long)
        self.atr = btind.ATR(self.data, period=self.params.atr_period)

        # 初始化市场分析相关模块
        self.market_analyzer = MarketAnalyzer()
        self.trend_analyzer = TrendAnalyzer()
        self.volatility_analyzer = VolatilityAnalyzer()
        self.volume_analyzer = VolumeAnalyzer()

        # 初始化信号生成相关模块
        self.signal_generator = SignalGenerator()
        self.technical_signals = TechnicalSignals()
        self.pattern_recognizer = PricePatternRecognizer()
        self.ml_signals = MLSignalGenerator()
        self.ensemble_signals = EnsembleSignalGenerator()

        # 初始化风险管理相关模块
        self.risk_manager = RiskManager()
        self.global_risk_monitor = GlobalRiskMonitor()
        self.position_risk_calculator = PositionRiskCalculator()
        self.stop_loss_manager = StopLossManager()

        # 初始化杠杆管理相关模块
        self.leverage_manager = LeverageManager()
        self.fixed_leverage = FixedLeverage()

        # 初始化仓位管理相关模块
        self.position_manager = PositionManager()
        self.entry_manager = EntryManager()
        self.exit_manager = ExitManager()
        self.size_calculator = SizeCalculator()

        # 初始化执行相关模块
        self.order_executor = OrderExecutor()
        self.api_manager = ApiManager()
        self.latency_optimizer = LatencyOptimizer()

        # 初始化可视化模块
        self.visualizer = Visualizer()

        # 订单和止损跟踪
        self.order = None
        self.stop_loss = None
        self.take_profit = None

        # 性能指标
        self.trade_count = 0
        self.win_count = 0
        self.loss_count = 0

        # 进度跟踪
        self.bar_count = 0
        self.total_bars = 0
        self.last_progress_log = 0
        self.progress_interval = 1000  # 每1000个bar记录一次进度
        self.start_time = None

        # 缓存数据
        self.data_cache = {}
        self.market_state_cache = {}
        self.signal_cache = {}

        # 添加信号统计
        self.signal_stats = {
            'total_signals': 0,
            'buy_signals': 0,
            'sell_signals': 0,
            'strong_buy_signals': 0,
            'strong_sell_signals': 0,
            'none_signals': 0,
            'high_confidence_signals': 0,  # 信心度 >= 0.6
            'medium_confidence_signals': 0,  # 信心度 0.3-0.6
            'low_confidence_signals': 0,  # 信心度 < 0.3
        }

        # 初始化回测报告生成器
        from user_data.utils.backtest_reporter import BacktestReporter
        from user_data.utils.advanced_backtest_analyzer import AdvancedBacktestAnalyzer
        from user_data.utils.professional_console_reporter import ProfessionalConsoleReporter
        from user_data.utils.enhanced_html_reporter import EnhancedHTMLReporter

        self.reporter = BacktestReporter()
        self.advanced_analyzer = None  # 将在stop()中初始化
        self.console_reporter = ProfessionalConsoleReporter()
        self.enhanced_html_reporter = EnhancedHTMLReporter()

        # 初始化爆仓监控器
        from user_data.strategies.modules.risk_manager.liquidation_monitor import LiquidationMonitor, MarginLevel
        self.liquidation_monitor = LiquidationMonitor()

        # 爆仓监控状态
        self.last_margin_check = 0
        self.margin_check_interval = 5  # 每5个bar检查一次保证金

        # 交易冷却机制
        self.last_trade_bar = 0
        self.trade_cooldown = 3  # 交易后冷却3个bar

        logger.info("策略初始化完成")

    def start(self):
        """
        策略开始时调用，设置总数据量
        """
        import time
        self.start_time = time.time()

        # 获取数据总量
        try:
            # 尝试多种方法获取数据长度
            if hasattr(self.data, 'buflen'):
                self.total_bars = self.data.buflen()
            elif hasattr(self.data, '_len'):
                self.total_bars = self.data._len
            elif hasattr(self.data, 'array') and hasattr(self.data.array, '__len__'):
                self.total_bars = len(self.data.array)
            elif hasattr(self.data, '__len__'):
                self.total_bars = len(self.data)
            else:
                # 如果都无法获取，设置为0，后续动态更新
                self.total_bars = 0
                logger.warning("无法获取数据总量，将在运行过程中动态更新")
        except Exception as e:
            logger.warning(f"获取数据总量失败: {e}")
            self.total_bars = 0

        logger.info(f"回测开始 - 数据总量: {self.total_bars} bars")

        # 调整进度显示间隔
        if self.total_bars > 0:
            # 根据数据量调整进度显示频率
            if self.total_bars > 50000:
                self.progress_interval = 5000  # 大数据集，每5000个bar显示一次
            elif self.total_bars > 10000:
                self.progress_interval = 1000  # 中等数据集，每1000个bar显示一次
            else:
                self.progress_interval = 500   # 小数据集，每500个bar显示一次

    def next(self):
        """
        每个bar调用一次，这是策略的主要逻辑
        """
        # 更新进度计数
        self.bar_count += 1

        # 收集价格数据用于报告
        current_price = self.data.close[0]
        self.reporter.add_price_data({
            'open': self.data.open[0],
            'high': self.data.high[0],
            'low': self.data.low[0],
            'close': current_price,
            'volume': self.data.volume[0]
        })

        # 收集组合价值数据
        self.reporter.add_portfolio_value({
            'total_value': self.broker.getvalue(),
            'cash': self.broker.getcash(),
            'position_value': self.broker.getvalue() - self.broker.getcash()
        })

        # 动态更新总数据量（如果初始时无法获取）
        if self.total_bars == 0:
            try:
                # 尝试在运行时获取数据长度
                if hasattr(self.data, 'buflen'):
                    self.total_bars = self.data.buflen()
                elif hasattr(self.data, '_len'):
                    self.total_bars = self.data._len
                elif hasattr(self.data, 'array') and hasattr(self.data.array, '__len__'):
                    self.total_bars = len(self.data.array)

                if self.total_bars > 0:
                    logger.info(f"动态获取数据总量: {self.total_bars} bars")
            except:
                pass

        # 显示进度
        if self.bar_count - self.last_progress_log >= self.progress_interval:
            if self.total_bars > 0:
                progress = (self.bar_count / self.total_bars) * 100

                # 计算时间估算
                if self.start_time and self.bar_count > 0:
                    import time
                    elapsed_time = time.time() - self.start_time
                    bars_per_second = self.bar_count / elapsed_time
                    remaining_bars = self.total_bars - self.bar_count
                    estimated_remaining_time = remaining_bars / bars_per_second if bars_per_second > 0 else 0

                    # 格式化时间
                    if estimated_remaining_time > 3600:
                        time_str = f"{estimated_remaining_time/3600:.1f}小时"
                    elif estimated_remaining_time > 60:
                        time_str = f"{estimated_remaining_time/60:.1f}分钟"
                    else:
                        time_str = f"{estimated_remaining_time:.0f}秒"

                    logger.info(f"回测进度: {self.bar_count}/{self.total_bars} ({progress:.1f}%) - 交易次数: {self.trade_count} - 预计剩余: {time_str}")
                else:
                    logger.info(f"回测进度: {self.bar_count}/{self.total_bars} ({progress:.1f}%) - 交易次数: {self.trade_count}")
            else:
                # 如果仍然无法获取总量，只显示当前进度
                if self.start_time and self.bar_count > 0:
                    import time
                    elapsed_time = time.time() - self.start_time
                    bars_per_second = self.bar_count / elapsed_time
                    logger.info(f"回测进度: {self.bar_count} bars - 交易次数: {self.trade_count} - 速度: {bars_per_second:.1f} bars/秒")
                else:
                    logger.info(f"回测进度: {self.bar_count} bars - 交易次数: {self.trade_count}")
            self.last_progress_log = self.bar_count

        # 如果有未完成的订单，不执行新的交易
        if self.order:
            return

        # 检查交易冷却时间
        if self.bar_count - self.last_trade_bar < self.trade_cooldown:
            return

        # 更新市场分析
        self.update_market_analysis()

        # 生成交易信号
        self.generate_signals()

        # 检查爆仓风险
        self.check_liquidation_risk()

        # 执行交易逻辑
        self.execute_trading_logic()

    def update_market_analysis(self):
        """
        更新市场分析
        """
        # 获取当前数据
        data = self.data

        # 获取足够的历史数据窗口（最近200个数据点）
        symbol = data._name
        window_size = min(200, len(data))

        if window_size < 10:
            # 数据不足，跳过分析
            logger.debug(f"数据不足，跳过分析: {symbol} 只有 {window_size} 条数据")
            return

        # 构建历史数据窗口
        ohlcv_data = []
        for i in range(-window_size + 1, 1):  # 从-199到0
            try:
                ohlcv_data.append({
                    'open': data.open[i],
                    'high': data.high[i],
                    'low': data.low[i],
                    'close': data.close[i],
                    'volume': data.volume[i],
                    'datetime': bt.num2date(data.datetime[i])
                })
            except IndexError:
                # 如果索引超出范围，跳过
                continue

        if len(ohlcv_data) < 10:
            logger.debug(f"有效数据不足: {symbol} 只有 {len(ohlcv_data)} 条有效数据")
            return

        # 转换为DataFrame
        ohlcv = pd.DataFrame(ohlcv_data)

        # 添加技术指标计算
        from user_data.strategies.utils.data_preprocessor import DataPreprocessor
        preprocessor = DataPreprocessor()

        # 重命名列以匹配DataPreprocessor期望的格式
        ohlcv_for_indicators = ohlcv.rename(columns={'datetime': 'timestamp'})

        # 计算技术指标
        ohlcv_with_indicators = preprocessor.add_technical_indicators(ohlcv_for_indicators)

        # 将技术指标添加回原始DataFrame
        for col in ohlcv_with_indicators.columns:
            if col not in ohlcv.columns and col != 'timestamp':
                ohlcv[col] = ohlcv_with_indicators[col].values

        # 更新市场分析器（使用配置的时间框架）
        self.market_analyzer.update_data(symbol, '5m', ohlcv)

        # 缓存数据（现在包含技术指标）
        self.data_cache[symbol] = ohlcv

        # 缓存市场状态
        self.market_state_cache[symbol] = self.market_analyzer.get_market_state(symbol, '5m')

        logger.debug(f"已更新市场分析: {symbol} 使用 {len(ohlcv)} 条数据")

    def generate_signals(self):
        """
        生成交易信号
        """
        # 获取当前数据
        data = self.data
        symbol = data._name

        # 获取市场状态
        market_state = self.market_state_cache.get(symbol, MarketState.UNKNOWN)

        # 获取技术指标
        indicators = {
            'rsi': self.rsi[0],
            'ema_short': self.ema_short[0],
            'ema_long': self.ema_long[0],
            'atr': self.atr[0]
        }

        # 生成集成信号
        ohlcv = self.data_cache.get(symbol)
        if ohlcv is not None:
            ensemble_result = self.ensemble_signals.generate_ensemble_signal(
                ohlcv, method=EnsembleMethod.WEIGHTED_VOTING)

            # 缓存信号
            self.signal_cache[symbol] = ensemble_result

            # 统计信号
            self._update_signal_stats(ensemble_result)

            # 收集信号数据用于报告
            self.reporter.add_signal({
                'signal_type': str(ensemble_result.get('signal', SignalType.NONE)),
                'confidence': ensemble_result.get('confidence', 0.0),
                'source': ensemble_result.get('source', 'ensemble'),
                'price': self.data.close[0]
            })

            # 详细日志：显示信号信息
            if self.bar_count % 100 == 0:  # 每100个bar显示一次详细信号
                current_price = self.data.close[0]
                logger.info(f"[Bar {self.bar_count}] {symbol} 价格: {current_price:.2f}")
                logger.info(f"  最终信号: {ensemble_result.get('signal', 'NONE')}")
                logger.info(f"  最终信心度: {ensemble_result.get('confidence', 0):.3f}")
                logger.info(f"  信号来源: {ensemble_result.get('source', 'unknown')}")

                # 显示技术指标
                if hasattr(self, 'rsi') and len(self.rsi) > 0:
                    logger.info(f"  RSI: {self.rsi[0]:.2f}")
                if hasattr(self, 'ema_short') and len(self.ema_short) > 0:
                    logger.info(f"  EMA短: {self.ema_short[0]:.2f}")
                if hasattr(self, 'ema_long') and len(self.ema_long) > 0:
                    logger.info(f"  EMA长: {self.ema_long[0]:.2f}")

                # 显示集成信号的详细组成
                if 'components' in ensemble_result:
                    components = ensemble_result['components']
                    logger.info(f"  === 信号组成分析 ===")

                    # 技术指标信号
                    tech = components.get('technical', {})
                    logger.info(f"  技术指标: {tech.get('signal', 'NONE')} (信心度: {tech.get('confidence', 0):.3f})")

                    # 价格形态信号
                    pattern = components.get('pattern', {})
                    logger.info(f"  价格形态: {pattern.get('signal', 'NONE')} (信心度: {pattern.get('confidence', 0):.3f})")

                    # ML信号
                    ml = components.get('ml', {})
                    logger.info(f"  ML信号: {ml.get('signal', 'NONE')} (信心度: {ml.get('confidence', 0):.3f})")

                    # 显示权重计算
                    if tech.get('signal') and pattern.get('signal') and ml.get('signal'):
                        tech_score = tech.get('confidence', 0) * 0.5 if tech.get('signal') != 'SignalType.NONE' else 0
                        pattern_score = pattern.get('confidence', 0) * 0.3 if pattern.get('signal') != 'SignalType.NONE' else 0
                        ml_score = ml.get('confidence', 0) * 0.2 if ml.get('signal') != 'SignalType.NONE' else 0
                        logger.info(f"  权重得分: 技术={tech_score:.3f} 形态={pattern_score:.3f} ML={ml_score:.3f}")

                # 显示信号统计
                logger.info(f"  信号统计: 总计={self.signal_stats['total_signals']} "
                          f"买入={self.signal_stats['buy_signals']} "
                          f"强买入={self.signal_stats['strong_buy_signals']} "
                          f"高信心度={self.signal_stats['high_confidence_signals']}")

    def _update_signal_stats(self, ensemble_result):
        """更新信号统计"""
        signal_type = ensemble_result.get('signal', SignalType.NONE)
        confidence = ensemble_result.get('confidence', 0.0)

        self.signal_stats['total_signals'] += 1

        # 统计信号类型
        if signal_type == SignalType.BUY:
            self.signal_stats['buy_signals'] += 1
        elif signal_type == SignalType.SELL:
            self.signal_stats['sell_signals'] += 1
        elif signal_type == SignalType.STRONG_BUY:
            self.signal_stats['strong_buy_signals'] += 1
        elif signal_type == SignalType.STRONG_SELL:
            self.signal_stats['strong_sell_signals'] += 1
        else:
            self.signal_stats['none_signals'] += 1

        # 统计信心度
        if confidence >= 0.6:
            self.signal_stats['high_confidence_signals'] += 1
        elif confidence >= 0.3:
            self.signal_stats['medium_confidence_signals'] += 1
        else:
            self.signal_stats['low_confidence_signals'] += 1

    def stop(self):
        """策略结束时调用"""
        logger.info("=" * 60)
        logger.info("回测结束 - 详细统计报告")
        logger.info("=" * 60)

        # 基本统计
        logger.info(f"总处理Bar数: {self.bar_count}")
        logger.info(f"总交易次数: {self.trade_count}")
        logger.info(f"盈利交易: {self.win_count}")
        logger.info(f"亏损交易: {self.loss_count}")

        if self.trade_count > 0:
            win_rate = (self.win_count / self.trade_count) * 100
            logger.info(f"胜率: {win_rate:.2f}%")
        else:
            logger.info("胜率: 0.00% (无交易)")

        # 信号统计
        logger.info("\n信号生成统计:")
        logger.info(f"  总信号数: {self.signal_stats['total_signals']}")
        logger.info(f"  买入信号: {self.signal_stats['buy_signals']}")
        logger.info(f"  强买入信号: {self.signal_stats['strong_buy_signals']}")
        logger.info(f"  卖出信号: {self.signal_stats['sell_signals']}")
        logger.info(f"  强卖出信号: {self.signal_stats['strong_sell_signals']}")
        logger.info(f"  无信号: {self.signal_stats['none_signals']}")

        logger.info("\n信心度分布:")
        logger.info(f"  高信心度 (≥0.6): {self.signal_stats['high_confidence_signals']}")
        logger.info(f"  中信心度 (0.3-0.6): {self.signal_stats['medium_confidence_signals']}")
        logger.info(f"  低信心度 (<0.3): {self.signal_stats['low_confidence_signals']}")

        # 分析为什么没有交易
        if self.trade_count == 0:
            logger.info("\n❌ 无交易分析:")
            total_buy_signals = self.signal_stats['buy_signals'] + self.signal_stats['strong_buy_signals']
            if total_buy_signals == 0:
                logger.info("  原因: 没有生成任何买入信号")
            elif self.signal_stats['high_confidence_signals'] == 0:
                logger.info("  原因: 没有高信心度信号 (需要≥0.6)")
                logger.info(f"  建议: 降低信心度阈值或优化模型")
            else:
                logger.info("  原因: 其他交易条件不满足 (资金、风险管理等)")

        logger.info("=" * 60)

        # 🚀 生成世界级专业报告系统
        logger.info("\n🚀 正在生成超级详细专业回测报告...")

        # 1. 初始化高级分析器并生成专业报告
        try:
            self.advanced_analyzer = AdvancedBacktestAnalyzer(
                trades_data=self.reporter.trades,
                portfolio_data=self.reporter.portfolio_values,
                signals_data=self.reporter.signals,
                price_data=self.reporter.price_data
            )

            # 2. 计算全面的指标
            comprehensive_metrics = self.advanced_analyzer.calculate_comprehensive_metrics()

            # 3. 生成专业控制台报告
            professional_report = self.console_reporter.generate_comprehensive_report(
                metrics=comprehensive_metrics,
                trades_data=self.reporter.trades,
                signals_data=self.reporter.signals
            )
            print(professional_report)

            # 4. 生成高级图表
            advanced_charts = self.advanced_analyzer.generate_advanced_charts()
            logger.info(f"📊 生成了 {len(advanced_charts)} 个高级图表")

        except Exception as e:
            logger.error(f"生成高级报告失败: {e}")
            # 回退到原始报告
            self.reporter.print_detailed_console_report()

        # 5. 保存数据到JSON
        json_file = self.reporter.save_data_to_json()
        logger.info(f"📄 JSON数据文件已保存: {json_file}")

        # 6. 生成HTML报告
        try:
            # 生成原始HTML报告
            html_file = self.reporter.generate_html_report()
            logger.info(f"🌐 基础HTML报告已生成: {html_file}")

            # 生成增强版HTML报告
            if hasattr(self, 'advanced_analyzer') and self.advanced_analyzer:
                enhanced_html_file = self.enhanced_html_reporter.generate_enhanced_report(
                    metrics=comprehensive_metrics,
                    trades_data=self.reporter.trades,
                    portfolio_data=self.reporter.portfolio_values,
                    signals_data=self.reporter.signals,
                    price_data=self.reporter.price_data,
                    advanced_charts=advanced_charts if 'advanced_charts' in locals() else {}
                )
                logger.info(f"🚀 增强版HTML报告已生成: {enhanced_html_file}")
                logger.info(f"📊 请在浏览器中打开查看世界级专业分析报告")
            else:
                logger.info(f"📊 请在浏览器中打开查看详细图表和分析")

        except Exception as e:
            logger.error(f"生成HTML报告失败: {e}")
            logger.info("💡 提示: 请确保已安装相关依赖库")

        logger.info(f"🎉 世界级专业回测报告生成完成！")

    def execute_trading_logic(self):
        """
        执行交易逻辑
        """
        # 获取当前数据
        data = self.data
        symbol = data._name

        # 获取信号
        ensemble_result = self.signal_cache.get(symbol, {
            'signal': SignalType.NONE,
            'confidence': 0.0
        })

        # 详细日志：显示交易决策过程
        current_price = self.data.close[0]
        signal_type = ensemble_result.get('signal', SignalType.NONE)
        confidence = ensemble_result.get('confidence', 0.0)

        # 每50个bar显示一次决策过程
        if self.bar_count % 50 == 0:
            logger.info(f"[交易决策 Bar {self.bar_count}] {symbol}")
            logger.info(f"  当前价格: {current_price:.2f}")
            logger.info(f"  信号类型: {signal_type}")
            logger.info(f"  信心度: {confidence:.3f}")
            logger.info(f"  持仓状态: {'有持仓' if self.position else '无持仓'}")
            logger.info(f"  现金余额: {self.broker.getcash():.2f}")

        # 检查是否有持仓
        if not self.position:
            # 没有持仓，检查交易信号

            # 做多信号
            if (signal_type == SignalType.BUY or signal_type == SignalType.STRONG_BUY):
                logger.info(f"[做多信号检测] {symbol} 信号={signal_type} 信心度={confidence:.3f}")

                if confidence >= 0.5:  # 提高阈值减少过度交易
                    logger.info(f"[做多条件满足] 信心度 {confidence:.3f} >= 0.5")

                    # 期货仓位计算（考虑杠杆）
                    cash = self.broker.getcash()
                    leverage = 25  # 从配置文件读取
                    risk_per_trade = 0.02  # 每次交易风险2%

                    price = self.data.close[0]
                    risk_amount = cash * risk_per_trade

                    # 期货合约价值计算
                    contract_value = price * 1  # 假设1个合约
                    margin_required = contract_value / leverage

                    # 计算可开仓数量
                    max_contracts = cash / margin_required
                    risk_contracts = risk_amount / (price * 0.02)  # 基于2%止损

                    size = min(max_contracts, risk_contracts)

                    logger.info(f"[期货仓位计算] 现金={cash:.2f} 杠杆={leverage} 合约价值={contract_value:.2f}")
                    logger.info(f"[期货仓位计算] 保证金需求={margin_required:.2f} 开仓数量={size:.6f}")

                    # 下单做多
                    if size > 0.001:  # 最小交易量
                        self.order = self.buy(size=size)
                        self.last_trade_bar = self.bar_count  # 更新交易时间
                        logger.info(f"✅ [执行做多] {symbol} 价格={price:.2f} 数量={size:.6f} 信心={confidence:.3f}")

                        # 设置止损（做多止损在下方）- 考虑杠杆调整止损幅度
                        stop_loss_pct = 0.005  # 0.5%止损，在25倍杠杆下相当于12.5%本金风险
                        stop_price = price * (1 - stop_loss_pct)
                        self.stop_loss = self.sell(size=size, exectype=bt.Order.Stop, price=stop_price)
                        logger.info(f"[设置止损] 止损价格={stop_price:.2f} 止损幅度={stop_loss_pct*100:.1f}%")
                    else:
                        logger.warning(f"[做多失败] 计算的头寸大小太小: {size:.6f}")
                else:
                    logger.debug(f"[做多条件不满足] 信心度 {confidence:.3f} < 0.3")

            # 做空信号
            elif (signal_type == SignalType.SELL or signal_type == SignalType.STRONG_SELL):
                logger.info(f"[做空信号检测] {symbol} 信号={signal_type} 信心度={confidence:.3f}")

                if confidence >= 0.5:  # 提高阈值减少过度交易
                    logger.info(f"[做空条件满足] 信心度 {confidence:.3f} >= 0.5")

                    # 期货仓位计算（考虑杠杆）
                    cash = self.broker.getcash()
                    leverage = 25
                    risk_per_trade = 0.02

                    price = self.data.close[0]
                    risk_amount = cash * risk_per_trade

                    # 期货合约价值计算
                    contract_value = price * 1
                    margin_required = contract_value / leverage

                    # 计算可开仓数量
                    max_contracts = cash / margin_required
                    risk_contracts = risk_amount / (price * 0.02)

                    size = min(max_contracts, risk_contracts)

                    logger.info(f"[期货仓位计算] 现金={cash:.2f} 杠杆={leverage} 合约价值={contract_value:.2f}")
                    logger.info(f"[期货仓位计算] 保证金需求={margin_required:.2f} 开仓数量={size:.6f}")

                    # 下单做空
                    if size > 0.001:
                        self.order = self.sell(size=size)  # 期货做空用sell
                        self.last_trade_bar = self.bar_count  # 更新交易时间
                        logger.info(f"✅ [执行做空] {symbol} 价格={price:.2f} 数量={size:.6f} 信心={confidence:.3f}")

                        # 设置止损（做空止损在上方）- 考虑杠杆调整止损幅度
                        stop_loss_pct = 0.005  # 0.5%止损，在25倍杠杆下相当于12.5%本金风险
                        stop_price = price * (1 + stop_loss_pct)
                        self.stop_loss = self.buy(size=size, exectype=bt.Order.Stop, price=stop_price)
                        logger.info(f"[设置止损] 止损价格={stop_price:.2f} 止损幅度={stop_loss_pct*100:.1f}%")
                    else:
                        logger.warning(f"[做空失败] 计算的头寸大小太小: {size:.6f}")
                else:
                    logger.debug(f"[做空条件不满足] 信心度 {confidence:.3f} < 0.3")

        else:
            # 有持仓，检查平仓信号
            current_price = self.data.close[0]
            position_size = self.position.size

            logger.info(f"[持仓检查] {symbol} 持仓={position_size:.6f} 价格={current_price:.2f}")

            # 检查反向信号平仓
            should_close = False
            close_reason = ""

            if position_size > 0:  # 多头持仓
                if (signal_type == SignalType.SELL or signal_type == SignalType.STRONG_SELL) and confidence >= 0.4:
                    should_close = True
                    close_reason = f"多头平仓-反向信号 信心度={confidence:.3f}"
            elif position_size < 0:  # 空头持仓
                if (signal_type == SignalType.BUY or signal_type == SignalType.STRONG_BUY) and confidence >= 0.4:
                    should_close = True
                    close_reason = f"空头平仓-反向信号 信心度={confidence:.3f}"

            if should_close:
                # 平仓
                self.order = self.close()
                self.last_trade_bar = self.bar_count  # 更新交易时间
                logger.info(f"✅ [执行平仓] {symbol} 价格={current_price:.2f} 原因={close_reason}")

                # 取消止损单
                if self.stop_loss:
                    self.cancel(self.stop_loss)
                    self.stop_loss = None
                    logger.info(f"[取消止损] 已取消止损单")

    def notify_order(self, order):
        """
        订单状态变化通知
        """
        if order.status in [order.Submitted, order.Accepted]:
            # 订单已提交或已接受，无需操作
            return

        # 检查订单是否完成
        if order.status in [order.Completed]:
            trade_type = "BUY" if order.isbuy() else "SELL"

            if order.isbuy():
                logger.info(f"✅ 买入执行: 价格={order.executed.price:.2f} 数量={order.executed.size:.6f} 成本={order.executed.value:.2f} 手续费={order.executed.comm:.2f}")
            else:
                logger.info(f"✅ 卖出执行: 价格={order.executed.price:.2f} 数量={order.executed.size:.6f} 成本={order.executed.value:.2f} 手续费={order.executed.comm:.2f}")

            # 暂存订单信息，等待交易完成时再收集完整数据
            if not hasattr(self, 'pending_trades'):
                self.pending_trades = []

            self.pending_trades.append({
                'type': trade_type,
                'price': order.executed.price,
                'size': order.executed.size,
                'value': order.executed.value,
                'commission': order.executed.comm,
                'timestamp': datetime.now()
            })

            # 收集订单数据
            self.reporter.add_order({
                'type': trade_type,
                'price': order.executed.price,
                'size': order.executed.size,
                'status': 'COMPLETED'
            })

            # 显示当前持仓状态
            if hasattr(self, 'position') and self.position:
                logger.info(f"📊 当前持仓: {self.position.size:.6f} 成本价: {self.position.price:.2f}")

                # 收集持仓数据
                self.reporter.add_position({
                    'size': self.position.size,
                    'price': self.position.price,
                    'value': self.position.size * self.data.close[0]
                })

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            logger.warning(f"订单未执行: {order.status}")

        # 重置订单 - 只重置主订单，不重置止损单
        if order == self.order:
            self.order = None
        elif order == self.stop_loss:
            self.stop_loss = None

    def notify_trade(self, trade):
        """
        交易完成通知 - 在这里可以获得实际的盈亏信息
        """
        if not trade.isclosed:
            return

        # 计算交易盈亏
        self.trade_count += 1
        pnl = trade.pnl
        pnl_net = trade.pnlcomm  # 扣除手续费后的净盈亏

        if trade.pnl > 0:
            self.win_count += 1
            logger.info(f"✅ 交易盈利: {pnl:.2f} 净盈利: {pnl_net:.2f}")
        else:
            self.loss_count += 1
            logger.info(f"❌ 交易亏损: {pnl:.2f} 净亏损: {pnl_net:.2f}")

        # 收集完整的交易数据（包含实际盈亏）
        if hasattr(self, 'pending_trades') and self.pending_trades:
            # 获取对应的订单信息
            recent_trade = self.pending_trades.pop(0) if self.pending_trades else {}

            # 更新交易记录，添加实际盈亏
            trade_data = recent_trade.copy()
            trade_data.update({
                'pnl': pnl,  # 实际盈亏
                'pnl_net': pnl_net,  # 净盈亏
            })

            # 添加到报告
            self.reporter.add_trade(trade_data)

            logger.info(f"📊 交易记录已更新: 类型={recent_trade.get('type', 'UNKNOWN')} 盈亏={pnl:.2f}")
        else:
            # 如果没有pending_trades，直接添加基本信息
            self.reporter.add_trade({
                'type': 'CLOSE',
                'price': trade.price,
                'size': trade.size,
                'value': trade.value,
                'commission': trade.commission,
                'pnl': pnl,
                'pnl_net': pnl_net,
                'timestamp': datetime.now()
            })

    def check_liquidation_risk(self):
        """
        检查爆仓风险并执行必要的风险控制措施
        """
        # 每隔一定bar数检查一次
        if self.bar_count - self.last_margin_check < self.margin_check_interval:
            return

        self.last_margin_check = self.bar_count

        try:
            # 获取账户信息
            account_balance = self.broker.getcash()
            total_value = self.broker.getvalue()

            # 构建持仓信息
            positions = {}
            if self.position and self.position.size != 0:
                symbol = self.data._name
                current_price = self.data.close[0]
                entry_price = self.position.price
                position_size = self.position.size

                # 计算未实现盈亏
                if position_size > 0:  # 多头
                    unrealized_pnl = position_size * (current_price - entry_price)
                else:  # 空头
                    unrealized_pnl = position_size * (current_price - entry_price)

                # 计算占用保证金
                leverage = 25  # 从配置读取
                margin_used = abs(position_size) * current_price / leverage

                positions[symbol] = {
                    'size': position_size,
                    'entry_price': entry_price,
                    'current_price': current_price,
                    'margin_used': margin_used,
                    'unrealized_pnl': unrealized_pnl,
                    'leverage': leverage
                }

                # 更新爆仓监控器的持仓信息
                self.liquidation_monitor.update_position_info(symbol, positions[symbol])

            # 检查爆仓风险
            risk_result = self.liquidation_monitor.check_liquidation_risk(account_balance, positions)

            margin_ratio = risk_result.get('margin_ratio', 0)
            margin_level = risk_result.get('margin_level')

            # 每50个bar显示一次保证金状态
            if self.bar_count % 50 == 0:
                logger.info(f"[保证金监控] 比率={margin_ratio:.2f} 水平={margin_level.value if margin_level else 'UNKNOWN'} "
                          f"余额={account_balance:.2f} 总值={total_value:.2f}")

            # 处理不同的风险水平
            if margin_level and margin_level.value in ['危险', '临界', '爆仓']:
                logger.warning(f"🚨 保证金风险警告: {margin_level.value} (比率: {margin_ratio:.2f})")

                # 发送警报
                if self.liquidation_monitor.should_send_alert(margin_level):
                    self.liquidation_monitor.log_liquidation_event(
                        f"保证金{margin_level.value}警告",
                        {
                            'margin_ratio': margin_ratio,
                            'account_balance': account_balance,
                            'total_value': total_value,
                            'positions': positions
                        }
                    )

                # 临界或爆仓时强制平仓
                if margin_level.value in ['临界', '爆仓'] and risk_result.get('force_liquidation', False):
                    logger.error(f"💥 触发强制平仓! 保证金水平: {margin_level.value}")
                    self.execute_emergency_liquidation(positions, risk_result)

                # 危险水平时部分平仓
                elif margin_level.value == '危险' and positions:
                    logger.warning(f"⚠️ 执行风险控制平仓")
                    self.execute_risk_control_liquidation(positions, risk_result)

        except Exception as e:
            logger.error(f"检查爆仓风险失败: {e}")

    def execute_emergency_liquidation(self, positions: Dict[str, Dict], risk_result: Dict[str, Any]):
        """
        执行紧急强制平仓

        参数:
            positions: 持仓信息
            risk_result: 风险检查结果
        """
        try:
            logger.error("🚨 执行紧急强制平仓!")

            # 取消所有挂单
            if self.order:
                self.cancel(self.order)
                self.order = None

            if self.stop_loss:
                self.cancel(self.stop_loss)
                self.stop_loss = None

            # 强制平仓所有持仓
            if self.position and self.position.size != 0:
                symbol = self.data._name
                position_size = self.position.size
                current_price = self.data.close[0]

                # 市价平仓
                if position_size > 0:  # 多头持仓
                    self.order = self.sell(size=abs(position_size))
                    logger.error(f"💥 强制平仓多头: {symbol} 数量={position_size:.6f} 价格={current_price:.2f}")
                else:  # 空头持仓
                    self.order = self.buy(size=abs(position_size))
                    logger.error(f"💥 强制平仓空头: {symbol} 数量={abs(position_size):.6f} 价格={current_price:.2f}")

                # 记录强制平仓事件
                self.liquidation_monitor.log_liquidation_event(
                    "紧急强制平仓",
                    {
                        'symbol': symbol,
                        'position_size': position_size,
                        'liquidation_price': current_price,
                        'margin_ratio': risk_result.get('margin_ratio', 0),
                        'reason': '保证金不足'
                    }
                )

        except Exception as e:
            logger.error(f"执行紧急强制平仓失败: {e}")

    def execute_risk_control_liquidation(self, positions: Dict[str, Dict], risk_result: Dict[str, Any]):
        """
        执行风险控制平仓（部分平仓）

        参数:
            positions: 持仓信息
            risk_result: 风险检查结果
        """
        try:
            logger.warning("⚠️ 执行风险控制平仓")

            # 生成平仓计划
            liquidation_plan = self.liquidation_monitor.generate_liquidation_plan(positions, target_margin_ratio=2.0)

            if not liquidation_plan:
                return

            # 执行平仓计划（只执行第一个，避免过度平仓）
            plan = liquidation_plan[0]
            symbol = plan['symbol']
            close_ratio = plan['close_ratio']

            if self.position and self.position.size != 0:
                position_size = self.position.size
                close_size = abs(position_size) * close_ratio
                current_price = self.data.close[0]

                # 部分平仓
                if position_size > 0:  # 多头持仓
                    self.order = self.sell(size=close_size)
                    logger.warning(f"⚠️ 风控平仓多头: {symbol} 平仓={close_size:.6f}/{abs(position_size):.6f} ({close_ratio*100:.1f}%)")
                else:  # 空头持仓
                    self.order = self.buy(size=close_size)
                    logger.warning(f"⚠️ 风控平仓空头: {symbol} 平仓={close_size:.6f}/{abs(position_size):.6f} ({close_ratio*100:.1f}%)")

                # 记录风控平仓事件
                self.liquidation_monitor.log_liquidation_event(
                    "风险控制平仓",
                    {
                        'symbol': symbol,
                        'original_size': position_size,
                        'close_size': close_size,
                        'close_ratio': close_ratio,
                        'price': current_price,
                        'reason': plan['reason']
                    }
                )

        except Exception as e:
            logger.error(f"执行风险控制平仓失败: {e}")

